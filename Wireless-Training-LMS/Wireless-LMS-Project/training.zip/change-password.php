<?php
require_once __DIR__ . '/includes/auth.php';
require_login();

$user  = current_user();
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $new     = $_POST['new_password']     ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($new) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($new !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hash = password_hash($new, PASSWORD_BCRYPT);
        $stmt = db()->prepare('UPDATE users SET password = ?, must_change_pw = 0 WHERE id = ?');
        $stmt->execute([$hash, $user['id']]);

        // Update session
        $_SESSION['lms_user']['must_change_pw'] = false;

        header('Location: /wts_documentation/training/dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Set Password — WTS AMP Training</title>
<link rel="stylesheet" href="/wts_documentation/training/assets/css/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-box">
        <img src="/wts_documentation/training/assets/img/wts-logo.png" alt="WTS">
        <h1>Set Your Password</h1>
        <p class="sub">Choose a new password to continue.</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" required minlength="8" autocomplete="new-password">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" required minlength="8" autocomplete="new-password">
            </div>
            <button type="submit" class="btn btn-primary btn-full" style="margin-top:.5rem">Save Password</button>
        </form>
    </div>
</div>
</body>
</html>







