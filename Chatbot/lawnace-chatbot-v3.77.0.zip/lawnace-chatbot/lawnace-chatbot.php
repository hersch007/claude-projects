<?php
/**
 * Plugin Name: LawnAce Chatbot
 * Plugin URI:  https://startadvertising.com
 * Description: AI-powered lawn care chat widget for LawnAce, powered by Claude.
 * Version:     3.77.0
 * Author:      Start Performance | Richard Brashear
 * Author URI:  https://startadvertising.com
 * License:     GPL-2.0-or-later
 * Text Domain: lawnace-chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'LAWNACE_VERSION',    '3.77.0' );
define( 'LAWNACE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LAWNACE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

define( 'LAWNACE_MODEL',       'claude-sonnet-4-6' );
define( 'LAWNACE_MAX_TOKENS',  700 );
define( 'LAWNACE_MAX_HISTORY', 12 );
define( 'LAWNACE_RATE_LIMIT',  40 );

require_once LAWNACE_PLUGIN_DIR . 'includes/logging.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/rate-limit.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/system-prompt.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/lead.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/ajax.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/admin.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/public-dashboard.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/client-dashboard.php';

register_activation_hook( __FILE__, 'lawnace_activate' );

function lawnace_activate() {
    lawnace_chatbot_ensure_log_table();
    lawnace_register_dashboard_rewrite();
    lawnace_register_client_dashboard_rewrite();
    flush_rewrite_rules();
}

// Flush rewrite rules whenever the plugin version changes (i.e. after every zip upload)
add_action( 'init', 'lawnace_maybe_flush_rewrites', 20 );

function lawnace_maybe_flush_rewrites() {
    if ( get_option( 'lawnace_flushed_version' ) !== LAWNACE_VERSION ) {
        lawnace_register_dashboard_rewrite();
        lawnace_register_client_dashboard_rewrite();
        flush_rewrite_rules();
        update_option( 'lawnace_flushed_version', LAWNACE_VERSION );
    }
}

/*
|--------------------------------------------------------------------------
| FRONTEND ASSETS + WIDGET HTML
|--------------------------------------------------------------------------
*/

add_action( 'wp_enqueue_scripts', 'lawnace_enqueue_assets' );

function lawnace_enqueue_assets() {
    wp_enqueue_style(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/css/widget.css',
        array(),
        LAWNACE_VERSION
    );

    wp_enqueue_script(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/js/widget.js',
        array(),
        LAWNACE_VERSION,
        true
    );

    wp_localize_script(
        'lawnace-widget',
        'lawnaceChat',
        array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'lawnace_chat_nonce' ),
            'sessionId' => wp_generate_uuid4(),
        )
    );
}

add_action( 'wp_footer', 'lawnace_render_widget' );

function lawnace_render_widget() {
    ?>
    <div id="la-nudge" style="display:none;" aria-live="polite">
        <button id="la-nudge-close" aria-label="Dismiss">&times;</button>
        <div id="la-nudge-text">🌿 Have a lawn question? I'm Lawnie — ask me anything.</div>
    </div>

    <div id="lawnace-ai-widget">
        <button id="la-launcher" aria-label="Open Lawn Ace AI chat">
            <span id="la-launcher-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="44" height="44" aria-hidden="true" style="display:block;">
                    <!-- Circle border with white fill -->
                    <circle cx="50" cy="50" r="48" fill="white" stroke="#3a8a1e" stroke-width="3.5"/>
                    <!-- Left side blades -->
                    <path d="M28 74 C20 62 22 50 30 40 C28 50 28 62 32 74 Z" fill="#52a83a"/>
                    <path d="M35 74 C30 66 30 56 36 48 C35 56 35 66 38 74 Z" fill="#4a9e28"/>
                    <!-- Right side blades -->
                    <path d="M68 74 C76 64 74 52 66 42 C68 52 70 64 70 74 Z" fill="#52a83a"/>
                    <path d="M60 74 C66 66 66 56 60 48 C60 56 62 66 63 74 Z" fill="#4a9e28"/>
                    <!-- Main blade body — curved, leans right at tip -->
                    <path d="M35 74 C26 58 28 32 44 12 C48 6 56 7 62 14 C58 24 56 48 57 74 Z" fill="#4a9e28"/>
                    <!-- Blade highlight — bright stripe left of center -->
                    <path d="M35 74 C26 58 28 32 44 12 C44 24 42 46 40 74 Z" fill="#80d44e" opacity="0.65"/>
                    <!-- Eyes -->
                    <circle cx="44" cy="51" r="3.8" fill="#1a3a10"/>
                    <circle cx="55" cy="51" r="3.8" fill="#1a3a10"/>
                    <circle cx="43" cy="50" r="1.4" fill="white"/>
                    <circle cx="54" cy="50" r="1.4" fill="white"/>
                    <!-- Smile -->
                    <path d="M42 58 Q49.5 66 57 58" stroke="#1a3a10" stroke-width="2.8" fill="none" stroke-linecap="round"/>
                </svg>
            </span>
            <span id="la-dot"></span>
        </button>

        <div id="la-panel" aria-label="Lawn Ace AI chat window">
            <div id="la-header">
                <div id="la-avatar">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="32" height="32" aria-hidden="true" style="display:block;">
                        <circle cx="50" cy="50" r="48" fill="white" stroke="#3a8a1e" stroke-width="3.5"/>
                        <path d="M28 74 C20 62 22 50 30 40 C28 50 28 62 32 74 Z" fill="#52a83a"/>
                        <path d="M35 74 C30 66 30 56 36 48 C35 56 35 66 38 74 Z" fill="#4a9e28"/>
                        <path d="M68 74 C76 64 74 52 66 42 C68 52 70 64 70 74 Z" fill="#52a83a"/>
                        <path d="M60 74 C66 66 66 56 60 48 C60 56 62 66 63 74 Z" fill="#4a9e28"/>
                        <path d="M35 74 C26 58 28 32 44 12 C48 6 56 7 62 14 C58 24 56 48 57 74 Z" fill="#4a9e28"/>
                        <path d="M35 74 C26 58 28 32 44 12 C44 24 42 46 40 74 Z" fill="#80d44e" opacity="0.65"/>
                        <circle cx="44" cy="51" r="3.8" fill="#1a3a10"/>
                        <circle cx="55" cy="51" r="3.8" fill="#1a3a10"/>
                        <circle cx="43" cy="50" r="1.4" fill="white"/>
                        <circle cx="54" cy="50" r="1.4" fill="white"/>
                        <path d="M42 58 Q49.5 66 57 58" stroke="#1a3a10" stroke-width="2.8" fill="none" stroke-linecap="round"/>
                    </svg>
                </div>
                <div>
                    <div id="la-header-title">Lawnie &mdash; Your Lawn Expert</div>
                    <div id="la-header-sub"><span id="la-online-dot"></span>Online now &middot; Augusta &amp; CSRA</div>
                </div>
                <button id="la-close" aria-label="Close chat">&times;</button>
            </div>

            <div id="la-body"></div>

            <div id="la-input-wrap">
                <button id="la-photo-btn" aria-label="Attach photo" title="Send a photo of your lawn"></button>
                <input type="file" id="la-photo-input" accept="image/*" style="display:none;">
                <textarea id="la-input" rows="1" maxlength="600" placeholder="Type your message..."></textarea>
                <button id="la-send" aria-label="Send message">&#10148;</button>
            </div>

            <div id="la-footer">Local. Trusted. Here to help. &middot; <a href="tel:7063642338" id="la-footer-phone">706-364-2338</a></div>
        </div>
    </div>
    <?php
}
