<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/*
|--------------------------------------------------------------------------
| AUTH HELPERS
|--------------------------------------------------------------------------
*/

function lawnace_client_dash_cookie_value() {
    $pin = get_option( 'lawnace_client_pin', '' );
    if ( empty( $pin ) ) return '';
    return hash( 'sha256', $pin . wp_salt( 'auth' ) . 'lawnace-client-v1' );
}

function lawnace_client_dash_is_authed() {
    $expected = lawnace_client_dash_cookie_value();
    if ( empty( $expected ) ) return false;
    $cookie = isset( $_COOKIE['lawnace_client_auth'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['lawnace_client_auth'] ) ) : '';
    return ! empty( $cookie ) && hash_equals( $expected, $cookie );
}

/*
|--------------------------------------------------------------------------
| REWRITE RULE
|--------------------------------------------------------------------------
*/

add_action( 'init', 'lawnace_register_client_dashboard_rewrite' );

function lawnace_register_client_dashboard_rewrite() {
    add_rewrite_rule( '^lawnace-client/?$', 'index.php?lawnace_client_dashboard=1', 'top' );
}

add_filter( 'query_vars', 'lawnace_client_dashboard_query_vars' );

function lawnace_client_dashboard_query_vars( $vars ) {
    $vars[] = 'lawnace_client_dashboard';
    return $vars;
}

/*
|--------------------------------------------------------------------------
| TEMPLATE REDIRECT
|--------------------------------------------------------------------------
*/

add_action( 'template_redirect', 'lawnace_maybe_render_client_dashboard' );

function lawnace_maybe_render_client_dashboard() {
    if ( ! get_query_var( 'lawnace_client_dashboard' ) ) return;

    $pin = get_option( 'lawnace_client_pin', '' );

    if ( isset( $_GET['logout'] ) ) {
        setcookie( 'lawnace_client_auth', '', [
            'expires'  => time() - 3600,
            'path'     => COOKIEPATH,
            'domain'   => COOKIE_DOMAIN,
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ] );
        wp_redirect( home_url( '/lawnace-client/' ) );
        exit;
    }

    if ( isset( $_POST['lawnace_client_pin'] ) ) {
        if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'lawnace_client_dash_login' ) ) {
            lawnace_render_client_login( 'Invalid request. Please try again.' );
            exit;
        }
        $submitted = sanitize_text_field( wp_unslash( $_POST['lawnace_client_pin'] ) );
        if ( ! empty( $pin ) && hash_equals( $pin, $submitted ) ) {
            setcookie( 'lawnace_client_auth', lawnace_client_dash_cookie_value(), [
                'expires'  => time() + 8 * HOUR_IN_SECONDS,
                'path'     => COOKIEPATH,
                'domain'   => COOKIE_DOMAIN,
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ] );
            wp_redirect( home_url( '/lawnace-client/' ) );
            exit;
        } else {
            lawnace_render_client_login( 'Incorrect password. Please try again.' );
            exit;
        }
    }

    if ( empty( $pin ) ) {
        lawnace_render_client_not_configured();
        exit;
    }

    if ( ! lawnace_client_dash_is_authed() ) {
        lawnace_render_client_login( false );
        exit;
    }

    lawnace_render_client_dashboard_page();
    exit;
}

/*
|--------------------------------------------------------------------------
| WEEKLY SUMMARY AJAX
|--------------------------------------------------------------------------
*/

add_action( 'wp_ajax_lawnace_client_weekly_summary',        'lawnace_client_weekly_summary_handler' );
add_action( 'wp_ajax_nopriv_lawnace_client_weekly_summary', 'lawnace_client_weekly_summary_handler' );

function lawnace_client_weekly_summary_handler() {
    check_ajax_referer( 'lawnace_client_summary_nonce', 'nonce' );

    if ( ! lawnace_client_dash_is_authed() ) {
        wp_send_json_error( 'Not authorized.' );
    }

    global $wpdb;
    $table   = $wpdb->prefix . 'lawnace_chat_logs';
    $api_key = get_option( 'lawnace_anthropic_key', '' );

    if ( empty( $api_key ) ) {
        wp_send_json_error( 'API key not configured.' );
    }

    $week_ago = date( 'Y-m-d 00:00:00', strtotime( '-7 days' ) );

    $messages = $wpdb->get_col( $wpdb->prepare(
        "SELECT message FROM {$table} WHERE role = 'user' AND created_at >= %s ORDER BY created_at DESC LIMIT 150",
        $week_ago
    ) );

    $total_sessions = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM {$table} WHERE created_at >= %s", $week_ago
    ) );
    $lead_sessions = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM {$table} WHERE role = 'lead' AND created_at >= %s", $week_ago
    ) );

    $zip_counts = [];
    $complaint_count = 0;
    foreach ( $messages as $msg ) {
        if ( preg_match_all( '/\b(\d{5})\b/', $msg, $matches ) ) {
            foreach ( $matches[1] as $zip ) {
                $zip_counts[ $zip ] = ( $zip_counts[ $zip ] ?? 0 ) + 1;
            }
        }
        if ( preg_match( '/rude|complaint|unhappy|not happy|disappointed|problem|issue|didn\'t show|no show/i', $msg ) ) {
            $complaint_count++;
        }
    }
    arsort( $zip_counts );
    $top_zip = ! empty( $zip_counts ) ? array_key_first( $zip_counts ) : null;

    $competitor_counts = [];
    foreach ( $messages as $msg ) {
        foreach ( lawnace_detect_competitors( $msg ) as $name ) {
            $competitor_counts[ $name ] = ( $competitor_counts[ $name ] ?? 0 ) + 1;
        }
    }
    arsort( $competitor_counts );

    $topic_counts = [];
    foreach ( $messages as $msg ) {
        foreach ( lawnace_categorize_message( $msg ) as $t ) {
            $topic_counts[ $t ] = ( $topic_counts[ $t ] ?? 0 ) + 1;
        }
    }
    arsort( $topic_counts );

    $topic_summary = '';
    foreach ( array_slice( $topic_counts, 0, 6, true ) as $topic => $count ) {
        $topic_summary .= "- {$topic}: {$count} mentions\n";
    }

    $comp_summary = '';
    foreach ( $competitor_counts as $name => $count ) {
        $comp_summary .= "- {$name}: mentioned {$count} time(s)\n";
    }
    if ( empty( $comp_summary ) ) $comp_summary = "None mentioned this week.\n";

    $message_sample = implode( "\n---\n", array_slice( $messages, 0, 80 ) );

    $prompt = "You are writing a weekly chat summary for the Lawn Ace management team. Lawn Ace is a locally owned lawn care company in Augusta, GA serving the CSRA area.

WEEK IN NUMBERS:
- Total chat sessions: {$total_sessions}
- New leads captured: {$lead_sessions}
- Customer complaints or service concerns mentioned: {$complaint_count}
" . ( $top_zip ? "- Most active ZIP code: {$top_zip}\n" : '' ) . "
TOP TOPICS THIS WEEK:
{$topic_summary}
COMPETITORS MENTIONED:
{$comp_summary}
SAMPLE CUSTOMER MESSAGES FROM THIS WEEK:
---
{$message_sample}
---

Write a plain-English weekly summary for the sales and service team. It should read like a manager's Monday morning brief. Use specific numbers. Keep it to 4-6 sentences total. Do not use bullet points. Do not give recommendations. Just describe what happened this week in the chat, what customers are asking about, where they are located, and flag anything that needs attention from the team. Write naturally, no em dashes.";

    $response = wp_remote_post(
        'https://api.anthropic.com/v1/messages',
        [
            'timeout' => 60,
            'headers' => [
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'      => LAWNACE_MODEL,
                'max_tokens' => 400,
                'messages'   => [ [ 'role' => 'user', 'content' => $prompt ] ],
            ] ),
        ]
    );

    if ( is_wp_error( $response ) ) {
        wp_send_json_error( 'API connection failed.' );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( empty( $body['content'][0]['text'] ) ) {
        wp_send_json_error( 'No response from API.' );
    }

    $summary = [
        'text'      => $body['content'][0]['text'],
        'generated' => current_time( 'mysql' ),
        'sessions'  => $total_sessions,
    ];

    update_option( 'lawnace_client_summary_cache', $summary );
    wp_send_json_success( $summary );
}

/*
|--------------------------------------------------------------------------
| LOGIN PAGE
|--------------------------------------------------------------------------
*/

function lawnace_render_client_login( $error = false ) {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lawn Ace Dashboard</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif;background:#12103a;min-height:100vh;display:flex;align-items:center;justify-content:center;}
.wrap{width:100%;max-width:380px;padding:20px;}
.card{background:#fff;border-radius:16px;padding:40px 36px;box-shadow:0 24px 64px rgba(0,0,0,.5);}
.logo{text-align:center;margin-bottom:28px;}
.logo-mark{width:52px;height:52px;background:linear-gradient(135deg,#5b4fbd,#8b7de0);border-radius:14px;display:inline-flex;align-items:center;justify-content:center;}
.title{font-size:21px;font-weight:700;color:#12103a;text-align:center;margin-bottom:6px;}
.sub{font-size:13px;color:#999;text-align:center;margin-bottom:28px;}
label{display:block;font-size:11px;font-weight:700;color:#555;margin-bottom:6px;letter-spacing:.6px;text-transform:uppercase;}
input[type=password]{width:100%;padding:12px 16px;border:2px solid #e8e8e8;border-radius:8px;font-size:16px;outline:none;transition:border-color .2s;}
input[type=password]:focus{border-color:#5b4fbd;}
.error{background:#fff0f0;border:1px solid #f5c2c2;color:#c0392b;border-radius:6px;padding:10px 14px;font-size:13px;margin-top:14px;text-align:center;}
.btn{width:100%;margin-top:18px;padding:13px;background:#5b4fbd;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;transition:background .2s;}
.btn:hover{background:#4a3f99;}
.foot{text-align:center;margin-top:20px;font-size:11px;color:#666;}
</style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <div class="logo">
            <div class="logo-mark">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="-42 -42 84 84" width="26" height="26">
                    <g fill="white" transform="rotate(45)">
                        <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z"/>
                        <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z" transform="rotate(90)"/>
                        <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z" transform="rotate(180)"/>
                        <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z" transform="rotate(270)"/>
                    </g>
                </svg>
            </div>
        </div>
        <div class="title">Lawn Ace Dashboard</div>
        <div class="sub">Sales &amp; Service Team Portal</div>
        <form method="post" action="<?php echo esc_url( home_url( '/lawnace-client/' ) ); ?>">
            <?php wp_nonce_field( 'lawnace_client_dash_login' ); ?>
            <label for="lawnace_client_pin">Password</label>
            <input type="password" id="lawnace_client_pin" name="lawnace_client_pin"
                   autocomplete="current-password" autofocus required maxlength="40"
                   placeholder="Enter your password">
            <?php if ( $error ) : ?>
                <div class="error"><?php echo esc_html( $error ); ?></div>
            <?php endif; ?>
            <button class="btn" type="submit">Sign In</button>
        </form>
    </div>
    <div class="foot">Lawn Ace &mdash; Augusta &amp; CSRA</div>
</div>
</body>
</html>
    <?php
}

/*
|--------------------------------------------------------------------------
| NOT CONFIGURED
|--------------------------------------------------------------------------
*/

function lawnace_render_client_not_configured() {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Dashboard Not Configured</title>
<style>
body{font-family:system-ui,sans-serif;background:#12103a;min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff;}
.card{background:#1e1a4a;border:1px solid #3b3294;border-radius:12px;padding:40px;max-width:420px;text-align:center;}
h2{margin-bottom:12px;font-size:20px;}
p{color:#aaa;font-size:14px;line-height:1.6;}
</style>
</head>
<body>
<div class="card">
    <h2>Dashboard Not Configured</h2>
    <p>A client dashboard password has not been set yet. Please contact your administrator.</p>
</div>
</body>
</html>
    <?php
}

/*
|--------------------------------------------------------------------------
| MAIN DASHBOARD PAGE
|--------------------------------------------------------------------------
*/

function lawnace_render_client_dashboard_page() {
    global $wpdb;
    lawnace_chatbot_ensure_log_table();
    $table = $wpdb->prefix . 'lawnace_chat_logs';

    $range = isset( $_GET['range'] ) ? sanitize_text_field( wp_unslash( $_GET['range'] ) ) : 'month';
    switch ( $range ) {
        case 'week':
            $since = date( 'Y-m-d 00:00:00', strtotime( '-7 days' ) );
            $label = 'Last 7 Days';
            break;
        case 'all':
            $since = '2000-01-01 00:00:00';
            $label = 'All Time';
            break;
        default:
            $since = date( 'Y-m-d 00:00:00', strtotime( '-30 days' ) );
            $label = 'Last 30 Days';
            $range = 'month';
    }

    // ── Core stats ─────────────────────────────────────────────────────

    $total_sessions = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM {$table} WHERE created_at >= %s", $since
    ) );
    $lead_sessions = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM {$table} WHERE role = 'lead' AND created_at >= %s", $since
    ) );
    $conversion = $total_sessions > 0 ? round( ( $lead_sessions / $total_sessions ) * 100, 1 ) : 0;
    $total_messages = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE role = 'user' AND created_at >= %s", $since
    ) );

    // ── Ratings ────────────────────────────────────────────────────────

    $ratings_table = $wpdb->prefix . 'lawnace_ratings';
    $ratings_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$ratings_table}'" ) === $ratings_table;
    $thumbs_up = $thumbs_down = 0;
    if ( $ratings_exist ) {
        $thumbs_up   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$ratings_table} WHERE rating = 1  AND created_at >= %s", $since ) );
        $thumbs_down = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$ratings_table} WHERE rating = -1 AND created_at >= %s", $since ) );
    }
    $total_ratings = $thumbs_up + $thumbs_down;
    $approval_rate = $total_ratings > 0 ? round( ( $thumbs_up / $total_ratings ) * 100 ) : 0;

    // ── User messages ──────────────────────────────────────────────────

    $user_message_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT session_id, message, created_at FROM {$table} WHERE role = 'user' AND created_at >= %s ORDER BY created_at DESC", $since
    ) );
    $user_messages = wp_list_pluck( $user_message_rows, 'message' );

    // ── Topics ─────────────────────────────────────────────────────────

    $topic_counts = [];
    foreach ( $user_messages as $msg ) {
        foreach ( lawnace_categorize_message( $msg ) as $t ) {
            $topic_counts[ $t ] = ( $topic_counts[ $t ] ?? 0 ) + 1;
        }
    }
    arsort( $topic_counts );
    $total_topic_hits = array_sum( $topic_counts ) ?: 1;

    // ── Competitors ────────────────────────────────────────────────────

    $competitor_counts = [];
    foreach ( $user_message_rows as $row ) {
        foreach ( lawnace_detect_competitors( $row->message ) as $name ) {
            $competitor_counts[ $name ] = ( $competitor_counts[ $name ] ?? 0 ) + 1;
        }
    }
    arsort( $competitor_counts );

    // ── ZIP codes ──────────────────────────────────────────────────────

    $zip_counts = [];
    foreach ( $user_messages as $msg ) {
        if ( preg_match_all( '/\b(\d{5})\b/', $msg, $matches ) ) {
            foreach ( $matches[1] as $zip ) {
                $zip_counts[ $zip ] = ( $zip_counts[ $zip ] ?? 0 ) + 1;
            }
        }
    }
    arsort( $zip_counts );
    $zip_counts = array_slice( $zip_counts, 0, 10, true );

    // ── Leads ──────────────────────────────────────────────────────────

    $recent_leads = $wpdb->get_results( $wpdb->prepare(
        "SELECT session_id, message, created_at FROM {$table}
         WHERE role = 'lead' AND created_at >= %s
         ORDER BY created_at DESC LIMIT 50", $since
    ) );

    // ── Sessions ───────────────────────────────────────────────────────

    $sessions = $wpdb->get_results( $wpdb->prepare(
        "SELECT session_id, MIN(created_at) AS started, COUNT(*) AS messages,
                MAX(CASE WHEN role = 'lead' THEN 1 ELSE 0 END) AS has_lead
         FROM {$table} WHERE created_at >= %s
         GROUP BY session_id ORDER BY started DESC LIMIT 200", $since
    ) );

    // ── Drop-offs ──────────────────────────────────────────────────────

    $dropoffs = $wpdb->get_results( $wpdb->prepare(
        "SELECT session_id, COUNT(*) AS msg_count, MIN(created_at) AS started
         FROM {$table} WHERE role = 'user' AND created_at >= %s
         GROUP BY session_id HAVING msg_count <= 2
         ORDER BY started DESC LIMIT 20", $since
    ) );

    // ── Complaints ─────────────────────────────────────────────────────

    $complaint_sessions = $wpdb->get_results( $wpdb->prepare(
        "SELECT DISTINCT session_id, MIN(created_at) AS started
         FROM {$table}
         WHERE role = 'user' AND created_at >= %s
         AND (message LIKE '%rude%' OR message LIKE '%complaint%' OR message LIKE '%unhappy%'
              OR message LIKE '%not happy%' OR message LIKE '%disappointed%'
              OR message LIKE '%didn''t show%' OR message LIKE '%no show%')
         GROUP BY session_id ORDER BY started DESC LIMIT 20", $since
    ) );

    $base_url       = home_url( '/lawnace-client/' );
    $logout_url     = add_query_arg( 'logout', '1', $base_url );
    $summary_nonce  = wp_create_nonce( 'lawnace_client_summary_nonce' );
    $ajax_url       = admin_url( 'admin-ajax.php' );
    $cached_summary = get_option( 'lawnace_client_summary_cache', null );

    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lawn Ace Dashboard</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif;background:#f4f5f8;color:#1a1a2e;font-size:14px;}

/* Header */
.la-header{background:linear-gradient(135deg,#12103a,#3b3294,#5b4fbd);color:#fff;padding:0 28px;display:flex;align-items:center;justify-content:space-between;height:62px;position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(18,16,58,.4);}
.la-brand{display:flex;align-items:center;gap:10px;font-size:17px;font-weight:700;letter-spacing:-.2px;}
.la-header-right{display:flex;align-items:center;gap:16px;}
.la-header-right a{color:rgba(255,255,255,.75);font-size:12px;text-decoration:none;font-weight:600;padding:6px 14px;border:1px solid rgba(255,255,255,.3);border-radius:6px;transition:all .2s;}
.la-header-right a:hover{background:rgba(255,255,255,.15);color:#fff;}
.la-version{font-size:11px;color:rgba(255,255,255,.4);background:rgba(0,0,0,.2);padding:3px 8px;border-radius:4px;}

/* Layout */
.la-main{max-width:1160px;margin:0 auto;padding:28px 20px;}

/* Tabs */
.la-tabs{display:flex;gap:4px;margin-bottom:24px;background:#fff;padding:5px;border-radius:12px;box-shadow:0 1px 4px rgba(0,0,0,.08);width:fit-content;}
.la-tab{padding:9px 24px;border-radius:8px;border:none;background:none;font-size:13px;font-weight:600;color:#888;cursor:pointer;transition:all .2s;}
.la-tab:hover{color:#5b4fbd;}
.la-tab.active{background:#5b4fbd;color:#fff;box-shadow:0 2px 8px rgba(91,79,189,.35);}
.la-tab-panel{display:none;}
.la-tab-panel.active{display:block;}

/* Range bar */
.la-range-bar{display:flex;align-items:center;gap:8px;margin-bottom:22px;flex-wrap:wrap;}
.la-range-bar strong{color:#666;font-size:12px;margin-right:4px;}
.la-range-btn{text-decoration:none;padding:5px 14px;border-radius:20px;border:1px solid #d8d8e8;background:#fff;color:#555;font-size:12px;font-weight:600;transition:all .15s;}
.la-range-btn:hover{border-color:#5b4fbd;color:#5b4fbd;}
.la-range-btn.active{background:#5b4fbd;border-color:#5b4fbd;color:#fff;}
.la-range-label{font-size:12px;color:#999;margin-left:4px;}

/* Stat grid */
.la-stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:22px;}
.la-stat{background:#fff;border:1px solid #e8e8f0;border-radius:10px;padding:18px 20px;box-shadow:0 1px 4px rgba(0,0,0,.05);}
.la-stat-num{font-size:30px;font-weight:800;color:#5b4fbd;line-height:1.1;}
.la-stat-num.green{color:#16a34a;}
.la-stat-num.amber{color:#d97706;}
.la-stat-num.red{color:#dc2626;}
.la-stat-label{font-size:11px;color:#999;margin-top:5px;font-weight:500;text-transform:uppercase;letter-spacing:.4px;}

/* Panels */
.la-panels{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:20px;}
@media(max-width:720px){.la-panels{grid-template-columns:1fr;}}
.la-panel{background:#fff;border:1px solid #e8e8f0;border-radius:10px;padding:20px 22px;box-shadow:0 1px 4px rgba(0,0,0,.05);}
.la-panel h3{margin:0 0 14px;font-size:12px;font-weight:800;color:#5b4fbd;text-transform:uppercase;letter-spacing:.6px;}
.la-panel-sub{font-size:11px;color:#bbb;margin-top:-10px;margin-bottom:12px;}

/* Bar chart */
.la-bar-row{display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:12px;}
.la-bar-label{width:170px;flex-shrink:0;color:#333;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.la-bar-track{flex:1;background:#f0f0f8;border-radius:4px;height:13px;overflow:hidden;}
.la-bar-fill{height:100%;background:#5b4fbd;border-radius:4px;}
.la-bar-fill.green{background:#16a34a;}
.la-bar-fill.red{background:#dc2626;}
.la-bar-pct{width:36px;text-align:right;color:#999;font-size:11px;}

/* Table */
.la-table{width:100%;border-collapse:collapse;font-size:12px;}
.la-table th{text-align:left;padding:7px 10px;border-bottom:2px solid #eee;color:#999;font-size:11px;text-transform:uppercase;letter-spacing:.4px;font-weight:600;}
.la-table td{padding:8px 10px;border-bottom:1px solid #f5f5fa;color:#333;vertical-align:top;}
.la-table tr:last-child td{border-bottom:none;}
.la-table tr:hover td{background:#fafafe;}
.la-table a{color:#5b4fbd;text-decoration:none;font-weight:600;}
.la-table a:hover{text-decoration:underline;}
.la-lead-badge{color:#16a34a;font-weight:700;font-size:11px;}
.la-flag-badge{color:#dc2626;font-weight:700;font-size:11px;}
code{background:#f0f0f8;padding:2px 6px;border-radius:3px;font-size:11px;color:#666;}

/* Summary panel */
.la-summary-panel{border-left:4px solid #5b4fbd;}
.la-summary-header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px;}
.la-summary-meta{font-size:11px;color:#bbb;margin-top:3px;}
.la-summary-btn{padding:9px 20px;background:#5b4fbd;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:background .2s;}
.la-summary-btn:hover{background:#4a3f99;}
.la-summary-btn:disabled{opacity:.6;cursor:not-allowed;}
.la-summary-text{font-size:14px;line-height:1.8;color:#1a1a2e;background:#f8f8fc;border-radius:8px;padding:18px 20px;}

/* Empty */
.la-empty{color:#bbb;font-size:13px;padding:10px 0;}
</style>
</head>
<body>

<header class="la-header">
    <div class="la-brand">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="-42 -42 84 84" width="26" height="26">
            <g fill="white" transform="rotate(45)">
                <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z"/>
                <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z" transform="rotate(90)"/>
                <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z" transform="rotate(180)"/>
                <path d="M0,3 C-3,-8 -17,-19 -17,-29 C-17,-38 -7,-43 0,-36 C7,-43 17,-38 17,-29 C17,-19 3,-8 0,3Z" transform="rotate(270)"/>
            </g>
        </svg>
        Lawn Ace Dashboard
    </div>
    <div class="la-header-right">
        <span class="la-version">v<?php echo esc_html( LAWNACE_VERSION ); ?></span>
        <a href="<?php echo esc_url( $logout_url ); ?>">Sign Out</a>
    </div>
</header>

<main class="la-main">

    <!-- Tabs -->
    <div class="la-tabs">
        <button class="la-tab active" data-tab="sales">Sales</button>
        <button class="la-tab" data-tab="service">Service</button>
        <button class="la-tab" data-tab="insights">Insights</button>
    </div>

    <!-- Range bar (shared) -->
    <div class="la-range-bar">
        <strong>Range:</strong>
        <?php foreach ( [ 'week' => 'Last 7 Days', 'month' => 'Last 30 Days', 'all' => 'All Time' ] as $key => $lbl ) : ?>
        <a href="<?php echo esc_url( add_query_arg( 'range', $key, $base_url ) ); ?>"
           class="la-range-btn <?php echo $range === $key ? 'active' : ''; ?>">
            <?php echo esc_html( $lbl ); ?>
        </a>
        <?php endforeach; ?>
        <span class="la-range-label">Showing: <strong><?php echo esc_html( $label ); ?></strong></span>
    </div>

    <!-- ================================================================
         SALES TAB
    ================================================================ -->
    <div id="tab-sales" class="la-tab-panel active">

        <div class="la-stat-grid">
            <div class="la-stat">
                <div class="la-stat-num"><?php echo esc_html( $lead_sessions ); ?></div>
                <div class="la-stat-label">Leads Captured</div>
            </div>
            <div class="la-stat">
                <div class="la-stat-num"><?php echo esc_html( $total_sessions ); ?></div>
                <div class="la-stat-label">Total Conversations</div>
            </div>
            <div class="la-stat">
                <div class="la-stat-num <?php echo $conversion >= 20 ? 'green' : ( $conversion >= 10 ? 'amber' : '' ); ?>">
                    <?php echo esc_html( $conversion ); ?>%
                </div>
                <div class="la-stat-label">Conversion Rate</div>
            </div>
            <div class="la-stat">
                <div class="la-stat-num"><?php echo esc_html( $total_messages ); ?></div>
                <div class="la-stat-label">Customer Messages</div>
            </div>
        </div>

        <!-- Leads table -->
        <div class="la-panel" style="margin-bottom:20px;">
            <h3>Recent Leads</h3>
            <?php if ( empty( $recent_leads ) ) : ?>
                <p class="la-empty">No leads captured in this period yet.</p>
            <?php else : ?>
                <table class="la-table">
                    <thead><tr><th>Contact Info</th><th>Captured</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ( $recent_leads as $lead ) : ?>
                    <tr>
                        <td><?php echo esc_html( $lead->message ); ?></td>
                        <td style="white-space:nowrap;color:#999"><?php echo esc_html( $lead->created_at ); ?></td>
                        <td><a href="<?php echo esc_url( add_query_arg( [ 'session' => $lead->session_id, 'range' => $range ], $base_url ) ); ?>">View chat</a></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- ZIP + Topics side by side -->
        <div class="la-panels">
            <div class="la-panel">
                <h3>Top ZIP Codes</h3>
                <p class="la-panel-sub">Where customers are located based on their messages</p>
                <?php if ( empty( $zip_counts ) ) : ?>
                    <p class="la-empty">No ZIP codes detected yet.</p>
                <?php else : ?>
                    <?php $max_zip = max( $zip_counts ) ?: 1; ?>
                    <?php foreach ( $zip_counts as $zip => $cnt ) :
                        $pct = round( ( $cnt / $max_zip ) * 100 );
                    ?>
                    <div class="la-bar-row">
                        <span class="la-bar-label" style="width:60px;font-weight:700;"><?php echo esc_html( $zip ); ?></span>
                        <div class="la-bar-track"><div class="la-bar-fill green" style="width:<?php echo esc_attr( $pct ); ?>%"></div></div>
                        <span class="la-bar-pct"><?php echo esc_html( $cnt ); ?></span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="la-panel">
                <h3>What Customers Are Asking About</h3>
                <p class="la-panel-sub">Topics detected across all conversations</p>
                <?php if ( empty( $topic_counts ) ) : ?>
                    <p class="la-empty">No data yet.</p>
                <?php else : ?>
                    <?php foreach ( $topic_counts as $topic => $count ) :
                        $pct = round( ( $count / $total_topic_hits ) * 100 );
                    ?>
                    <div class="la-bar-row">
                        <span class="la-bar-label" title="<?php echo esc_attr( $topic ); ?>"><?php echo esc_html( $topic ); ?></span>
                        <div class="la-bar-track"><div class="la-bar-fill" style="width:<?php echo esc_attr( $pct ); ?>%"></div></div>
                        <span class="la-bar-pct"><?php echo esc_html( $pct ); ?>%</span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- ================================================================
         SERVICE TAB
    ================================================================ -->
    <div id="tab-service" class="la-tab-panel">

        <div class="la-stat-grid">
            <div class="la-stat">
                <div class="la-stat-num <?php echo $total_ratings > 0 ? ( $approval_rate >= 70 ? 'green' : ( $approval_rate >= 40 ? 'amber' : 'red' ) ) : ''; ?>">
                    <?php echo $total_ratings > 0 ? $approval_rate . '%' : 'No data'; ?>
                </div>
                <div class="la-stat-label">Customer Approval (<?php echo esc_html( $thumbs_up ); ?> up / <?php echo esc_html( $thumbs_down ); ?> down)</div>
            </div>
            <div class="la-stat">
                <div class="la-stat-num <?php echo count( $complaint_sessions ) > 0 ? 'amber' : 'green'; ?>">
                    <?php echo count( $complaint_sessions ); ?>
                </div>
                <div class="la-stat-label">Flagged Conversations</div>
            </div>
            <div class="la-stat">
                <div class="la-stat-num"><?php echo count( $dropoffs ); ?></div>
                <div class="la-stat-label">Drop-off Sessions</div>
            </div>
            <div class="la-stat">
                <div class="la-stat-num"><?php echo esc_html( $total_sessions ); ?></div>
                <div class="la-stat-label">Total Sessions</div>
            </div>
        </div>

        <!-- Flagged conversations -->
        <div class="la-panel" style="margin-bottom:20px;">
            <h3>Flagged Conversations</h3>
            <p class="la-panel-sub">Customers who mentioned complaints, rude service, or no-shows</p>
            <?php if ( empty( $complaint_sessions ) ) : ?>
                <p class="la-empty">No flagged conversations in this period.</p>
            <?php else : ?>
                <table class="la-table">
                    <thead><tr><th>Session</th><th>Started</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ( $complaint_sessions as $s ) : ?>
                    <tr>
                        <td><code><?php echo esc_html( substr( $s->session_id, 0, 16 ) ); ?>&hellip;</code></td>
                        <td style="color:#999"><?php echo esc_html( $s->started ); ?></td>
                        <td><a href="<?php echo esc_url( add_query_arg( [ 'session' => $s->session_id, 'range' => $range ], $base_url ) ); ?>">Review</a></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="la-panels">

            <!-- Drop-offs -->
            <div class="la-panel">
                <h3>Drop-off Sessions</h3>
                <p class="la-panel-sub">Customers who left after 2 or fewer messages</p>
                <?php if ( empty( $dropoffs ) ) : ?>
                    <p class="la-empty">None found.</p>
                <?php else : ?>
                    <table class="la-table">
                        <thead><tr><th>Session</th><th>Msgs</th><th>Started</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ( $dropoffs as $s ) : ?>
                        <tr>
                            <td><code><?php echo esc_html( substr( $s->session_id, 0, 12 ) ); ?>&hellip;</code></td>
                            <td><?php echo esc_html( $s->msg_count ); ?></td>
                            <td style="color:#999;white-space:nowrap"><?php echo esc_html( $s->started ); ?></td>
                            <td><a href="<?php echo esc_url( add_query_arg( [ 'session' => $s->session_id, 'range' => $range ], $base_url ) ); ?>">View</a></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- All sessions -->
            <div class="la-panel">
                <h3>All Conversations</h3>
                <p class="la-panel-sub">Most recent 200 sessions</p>
                <?php if ( empty( $sessions ) ) : ?>
                    <p class="la-empty">No sessions in this period.</p>
                <?php else : ?>
                    <table class="la-table">
                        <thead><tr><th>Started</th><th>Msgs</th><th>Lead</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ( $sessions as $s ) : ?>
                        <tr>
                            <td style="color:#999;white-space:nowrap;font-size:11px"><?php echo esc_html( $s->started ); ?></td>
                            <td><?php echo esc_html( $s->messages ); ?></td>
                            <td><?php echo $s->has_lead ? '<span class="la-lead-badge">Yes</span>' : '<span style="color:#ddd">No</span>'; ?></td>
                            <td><a href="<?php echo esc_url( add_query_arg( [ 'session' => $s->session_id, 'range' => $range ], $base_url ) ); ?>">View</a></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

        </div>

    </div>

    <!-- ================================================================
         INSIGHTS TAB
    ================================================================ -->
    <div id="tab-insights" class="la-tab-panel">

        <!-- Weekly AI Summary -->
        <div class="la-panel la-summary-panel" style="margin-bottom:22px;">
            <div class="la-summary-header">
                <div>
                    <h3 style="margin-bottom:4px;">This Week in the Chat</h3>
                    <div class="la-summary-meta">
                        <?php if ( $cached_summary ) : ?>
                            Last updated: <?php echo esc_html( $cached_summary['generated'] ); ?>
                        <?php else : ?>
                            No summary generated yet.
                        <?php endif; ?>
                    </div>
                </div>
                <button id="la-summary-btn" class="la-summary-btn"
                    data-nonce="<?php echo esc_attr( $summary_nonce ); ?>"
                    data-ajax="<?php echo esc_url( $ajax_url ); ?>">
                    <?php echo $cached_summary ? 'Refresh Summary' : 'Generate Summary'; ?>
                </button>
            </div>
            <div id="la-summary-loading" style="display:none;color:#5b4fbd;font-size:13px;padding:10px 0;">
                Analyzing this week's conversations, give it about 10 seconds...
            </div>
            <div id="la-summary-output">
                <?php if ( $cached_summary ) : ?>
                    <div class="la-summary-text"><?php echo esc_html( $cached_summary['text'] ); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="la-panels">

            <!-- Topics -->
            <div class="la-panel">
                <h3>What Customers Are Talking About</h3>
                <?php if ( empty( $topic_counts ) ) : ?>
                    <p class="la-empty">No data yet.</p>
                <?php else : ?>
                    <?php foreach ( $topic_counts as $topic => $count ) :
                        $pct = round( ( $count / $total_topic_hits ) * 100 );
                    ?>
                    <div class="la-bar-row">
                        <span class="la-bar-label"><?php echo esc_html( $topic ); ?></span>
                        <div class="la-bar-track"><div class="la-bar-fill" style="width:<?php echo esc_attr( $pct ); ?>%"></div></div>
                        <span class="la-bar-pct"><?php echo esc_html( $pct ); ?>%</span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Competitors -->
            <div class="la-panel">
                <h3>Competitors Mentioned</h3>
                <?php if ( empty( $competitor_counts ) ) : ?>
                    <p class="la-empty">No competitors mentioned in this period.</p>
                <?php else : ?>
                    <?php $max_comp = max( $competitor_counts ) ?: 1; ?>
                    <?php foreach ( $competitor_counts as $comp => $cnt ) :
                        $pct = round( ( $cnt / $max_comp ) * 100 );
                    ?>
                    <div class="la-bar-row">
                        <span class="la-bar-label" style="color:#dc2626;font-weight:700;"><?php echo esc_html( $comp ); ?></span>
                        <div class="la-bar-track"><div class="la-bar-fill red" style="width:<?php echo esc_attr( $pct ); ?>%"></div></div>
                        <span class="la-bar-pct"><?php echo esc_html( $cnt ); ?></span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </div>

        <!-- Geographic activity -->
        <div class="la-panel">
            <h3>Geographic Activity</h3>
            <p class="la-panel-sub">Top ZIP codes appearing in customer conversations</p>
            <?php if ( empty( $zip_counts ) ) : ?>
                <p class="la-empty">No ZIP codes detected yet.</p>
            <?php else : ?>
                <?php $max_zip = max( $zip_counts ) ?: 1; ?>
                <?php foreach ( $zip_counts as $zip => $cnt ) :
                    $pct = round( ( $cnt / $max_zip ) * 100 );
                ?>
                <div class="la-bar-row">
                    <span class="la-bar-label" style="width:65px;font-weight:700;"><?php echo esc_html( $zip ); ?></span>
                    <div class="la-bar-track"><div class="la-bar-fill green" style="width:<?php echo esc_attr( $pct ); ?>%"></div></div>
                    <span class="la-bar-pct"><?php echo esc_html( $cnt ); ?></span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>

</main>

<script>
(function(){
    // Tab switching
    var tabs   = document.querySelectorAll('.la-tab');
    var panels = document.querySelectorAll('.la-tab-panel');

    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            tabs.forEach(function(t){ t.classList.remove('active'); });
            panels.forEach(function(p){ p.classList.remove('active'); });
            tab.classList.add('active');
            document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
        });
    });

    // Weekly summary
    var btn     = document.getElementById('la-summary-btn');
    var loading = document.getElementById('la-summary-loading');
    var output  = document.getElementById('la-summary-output');
    if (!btn) return;

    btn.addEventListener('click', function(){
        btn.disabled = true;
        btn.textContent = 'Analyzing...';
        loading.style.display = 'block';
        output.innerHTML = '';

        var fd = new FormData();
        fd.append('action', 'lawnace_client_weekly_summary');
        fd.append('nonce', btn.dataset.nonce);

        fetch(btn.dataset.ajax, {method:'POST', credentials:'same-origin', body:fd})
        .then(function(r){ return r.json(); })
        .then(function(res){
            loading.style.display = 'none';
            if (res.success && res.data && res.data.text) {
                output.innerHTML = '<div class="la-summary-text">' + escHtml(res.data.text) + '</div>';
                btn.textContent = 'Refresh Summary';
            } else {
                output.innerHTML = '<p style="color:#dc2626;font-size:13px;">Error: ' + escHtml(res.data || 'Something went wrong.') + '</p>';
                btn.textContent = 'Try Again';
            }
            btn.disabled = false;
        })
        .catch(function(){
            loading.style.display = 'none';
            output.innerHTML = '<p style="color:#dc2626;font-size:13px;">Request failed. Please try again.</p>';
            btn.textContent = 'Try Again';
            btn.disabled = false;
        });
    });

    function escHtml(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
})();
</script>

</body>
</html>
    <?php
}

/*
|--------------------------------------------------------------------------
| SESSION DETAIL
|--------------------------------------------------------------------------
*/

add_action( 'template_redirect', 'lawnace_maybe_render_client_session', 9 );

function lawnace_maybe_render_client_session() {
    if ( ! get_query_var( 'lawnace_client_dashboard' ) ) return;
    if ( ! lawnace_client_dash_is_authed() ) return;
    if ( empty( $_GET['session'] ) ) return;

    global $wpdb;
    $table      = $wpdb->prefix . 'lawnace_chat_logs';
    $session_id = sanitize_text_field( wp_unslash( $_GET['session'] ) );
    $range      = isset( $_GET['range'] ) ? sanitize_text_field( wp_unslash( $_GET['range'] ) ) : 'month';
    $back_url   = esc_url( add_query_arg( 'range', $range, remove_query_arg( 'session', home_url( '/lawnace-client/' ) ) ) );

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT role, message, created_at FROM {$table} WHERE session_id = %s ORDER BY created_at ASC",
        $session_id
    ) );

    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Conversation Detail &mdash; Lawn Ace Dashboard</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif;background:#f4f5f8;color:#1a1a2e;font-size:14px;}
.la-header{background:linear-gradient(135deg,#12103a,#3b3294,#5b4fbd);color:#fff;padding:0 28px;display:flex;align-items:center;height:62px;}
.la-brand{font-size:16px;font-weight:700;}
.la-main{max-width:900px;margin:0 auto;padding:28px 20px;}
.la-back{display:inline-flex;align-items:center;gap:5px;color:#5b4fbd;text-decoration:none;font-size:13px;font-weight:600;margin-bottom:20px;}
.la-back:hover{text-decoration:underline;}
h1{font-size:20px;margin-bottom:6px;}
.session-meta{font-size:12px;color:#999;margin-bottom:22px;}
code{background:#f0f0f8;padding:2px 6px;border-radius:3px;font-size:11px;}
.la-table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.06);}
.la-table th{text-align:left;padding:10px 14px;background:#f8f8fc;border-bottom:2px solid #eee;font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:#999;font-weight:600;}
.la-table td{padding:10px 14px;border-bottom:1px solid #f0f0f8;vertical-align:top;font-size:13px;line-height:1.5;}
.la-table tr:last-child td{border-bottom:none;}
.role-user{color:#1a1a2e;font-weight:700;}
.role-assistant{color:#5b4fbd;font-weight:700;}
.role-lead{color:#16a34a;font-weight:700;}
</style>
</head>
<body>
<header class="la-header">
    <div class="la-brand">Lawn Ace Dashboard &mdash; Conversation Detail</div>
</header>
<main class="la-main">
    <a class="la-back" href="<?php echo $back_url; ?>">&larr; Back to Dashboard</a>
    <h1>Conversation Transcript</h1>
    <div class="session-meta">Session ID: <code><?php echo esc_html( $session_id ); ?></code></div>
    <table class="la-table">
        <thead><tr>
            <th style="width:90px">Speaker</th>
            <th>Message</th>
            <th style="width:150px">Time</th>
        </tr></thead>
        <tbody>
        <?php foreach ( $rows as $row ) : ?>
        <tr>
            <td><span class="role-<?php echo esc_attr( $row->role ); ?>"><?php echo esc_html( ucfirst( $row->role ) ); ?></span></td>
            <td style="white-space:pre-wrap"><?php echo esc_html( $row->message ); ?></td>
            <td style="color:#bbb;font-size:11px"><?php echo esc_html( $row->created_at ); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</main>
</body>
</html>
    <?php
    exit;
}
