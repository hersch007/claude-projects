<?php
/**
 * Plugin Name: LawnAce Chatbot
 * Plugin URI:  https://startadvertising.com
 * Description: AI-powered lawn care chat widget for LawnAce, powered by Claude.
 * Version:     3.73.0
 * Author:      Start Performance | Richard Brashear
 * Author URI:  https://startadvertising.com
 * License:     GPL-2.0-or-later
 * Text Domain: lawnace-chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'LAWNACE_VERSION',    '3.73.0' );
define( 'LAWNACE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LAWNACE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

define( 'LAWNACE_MODEL',       'claude-sonnet-4-6' );
define( 'LAWNACE_MAX_TOKENS',  700 );
define( 'LAWNACE_MAX_HISTORY', 12 );
define( 'LAWNACE_RATE_LIMIT',  40 );

require_once LAWNACE_PLUGIN_DIR . 'includes/logging.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/rate-limit.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/system-prompt.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/lead.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/ajax.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/admin.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/public-dashboard.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/client-dashboard.php';

register_activation_hook( __FILE__, 'lawnace_activate' );

function lawnace_activate() {
    lawnace_chatbot_ensure_log_table();
    lawnace_register_dashboard_rewrite();
    lawnace_register_client_dashboard_rewrite();
    flush_rewrite_rules();
}

// Flush rewrite rules whenever the plugin version changes (i.e. after every zip upload)
add_action( 'init', 'lawnace_maybe_flush_rewrites', 20 );

function lawnace_maybe_flush_rewrites() {
    if ( get_option( 'lawnace_flushed_version' ) !== LAWNACE_VERSION ) {
        lawnace_register_dashboard_rewrite();
        lawnace_register_client_dashboard_rewrite();
        flush_rewrite_rules();
        update_option( 'lawnace_flushed_version', LAWNACE_VERSION );
    }
}

/*
|--------------------------------------------------------------------------
| FRONTEND ASSETS + WIDGET HTML
|--------------------------------------------------------------------------
*/

add_action( 'wp_enqueue_scripts', 'lawnace_enqueue_assets' );

function lawnace_enqueue_assets() {
    wp_enqueue_style(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/css/widget.css',
        array(),
        LAWNACE_VERSION
    );

    wp_enqueue_script(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/js/widget.js',
        array(),
        LAWNACE_VERSION,
        true
    );

    wp_localize_script(
        'lawnace-widget',
        'lawnaceChat',
        array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'lawnace_chat_nonce' ),
            'sessionId' => wp_generate_uuid4(),
        )
    );
}

add_action( 'wp_footer', 'lawnace_render_widget' );

function lawnace_render_widget() {
    ?>
    <div id="la-nudge" style="display:none;" aria-live="polite">
        <button id="la-nudge-close" aria-label="Dismiss">&times;</button>
        <div id="la-nudge-text">🌿 Have a lawn question? I'm Lawnie — ask me anything.</div>
    </div>

    <div id="lawnace-ai-widget">
        <button id="la-launcher" aria-label="Open Lawn Ace AI chat">
            <span id="la-launcher-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="-22 -14 94 104" width="36" height="40" aria-hidden="true" style="display:block;">
                    <path d="M14 0 L58 0 Q72 0 72 14 L72 56 Q72 70 58 70 L42 70 L36 84 L30 70 L14 70 Q0 70 0 56 L0 14 Q0 0 14 0 Z" fill="#1b4d1e"/>
                    <path d="M10 66 C9 54 11 42 16 33 C17 42 17 54 16 66 Z" fill="#68c844"/>
                    <path d="M20 66 C19 51 22 37 28 27 C29 38 28 52 27 66 Z" fill="#52a83a"/>
                    <path d="M31 66 C30 48 34 34 36 22 C38 34 38 50 37 66 Z" fill="#7ed44e"/>
                    <path d="M42 66 C41 51 44 38 50 28 C51 39 50 53 49 66 Z" fill="#52a83a"/>
                    <path d="M52 66 C51 54 55 43 62 34 C63 44 62 55 61 66 Z" fill="#68c844"/>
                    <rect x="8" y="64" width="56" height="4" rx="2" fill="#2d6e1e"/>
                    <!-- Sun overlapping top-left corner of pin -->
                    <circle cx="0" cy="-2" r="12" fill="#e8b84b"/>
                    <line x1="0"  y1="-16" x2="0"  y2="-13" stroke="#e8b84b" stroke-width="2.5" stroke-linecap="round"/>
                    <line x1="-11" y1="-13" x2="-9" y2="-11" stroke="#e8b84b" stroke-width="2.5" stroke-linecap="round"/>
                    <line x1="-14" y1="-2" x2="-11" y2="-2" stroke="#e8b84b" stroke-width="2.5" stroke-linecap="round"/>
                    <line x1="11" y1="-13" x2="9"  y2="-11" stroke="#e8b84b" stroke-width="2.5" stroke-linecap="round"/>
                    <line x1="14" y1="-2" x2="11"  y2="-2" stroke="#e8b84b" stroke-width="2.5" stroke-linecap="round"/>
                </svg>
            </span>
            <span id="la-dot"></span>
        </button>

        <div id="la-panel" aria-label="Lawn Ace AI chat window">
            <div id="la-header">
                <div id="la-avatar">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 90" width="22" height="28" aria-hidden="true" style="display:block;">
                        <path d="M14 0 L58 0 Q72 0 72 14 L72 56 Q72 70 58 70 L42 70 L36 84 L30 70 L14 70 Q0 70 0 56 L0 14 Q0 0 14 0 Z" fill="white"/>
                        <path d="M10 66 C9 54 11 42 16 33 C17 42 17 54 16 66 Z" fill="#52a83a"/>
                        <path d="M20 66 C19 51 22 37 28 27 C29 38 28 52 27 66 Z" fill="#68c844"/>
                        <path d="M31 66 C30 48 34 34 36 22 C38 34 38 50 37 66 Z" fill="#52a83a"/>
                        <path d="M42 66 C41 51 44 38 50 28 C51 39 50 53 49 66 Z" fill="#68c844"/>
                        <path d="M52 66 C51 54 55 43 62 34 C63 44 62 55 61 66 Z" fill="#52a83a"/>
                        <rect x="8" y="64" width="56" height="4" rx="2" fill="#3d8a25" opacity="0.5"/>
                        <circle cx="63" cy="11" r="8" fill="#e8b84b"/>
                    </svg>
                </div>
                <div>
                    <div id="la-header-title">Lawnie &mdash; Your Lawn Expert</div>
                    <div id="la-header-sub"><span id="la-online-dot"></span>Online now &middot; Augusta &amp; CSRA</div>
                </div>
                <button id="la-close" aria-label="Close chat">&times;</button>
            </div>

            <div id="la-body"></div>

            <div id="la-input-wrap">
                <button id="la-photo-btn" aria-label="Attach photo" title="Send a photo of your lawn"></button>
                <input type="file" id="la-photo-input" accept="image/*" style="display:none;">
                <textarea id="la-input" rows="1" maxlength="600" placeholder="Type your message..."></textarea>
                <button id="la-send" aria-label="Send message">&#10148;</button>
            </div>

            <div id="la-footer">Local. Trusted. Here to help. &middot; <a href="tel:7063642338" id="la-footer-phone">706-364-2338</a></div>
        </div>
    </div>
    <?php
}
