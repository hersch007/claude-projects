<?php
/**
 * Plugin Name: LawnAce Chatbot
 * Plugin URI:  https://startadvertising.com
 * Description: AI-powered lawn care chat widget for LawnAce, powered by Claude.
 * Version:     3.7.0
 * Author:      Start Performance | Richard Brashear
 * Author URI:  https://startadvertising.com
 * License:     GPL-2.0-or-later
 * Text Domain: lawnace-chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'LAWNACE_VERSION',    '3.7.0' );
define( 'LAWNACE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LAWNACE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

define( 'LAWNACE_MODEL',       'claude-sonnet-4-6' );
define( 'LAWNACE_MAX_TOKENS',  700 );
define( 'LAWNACE_MAX_HISTORY', 12 );
define( 'LAWNACE_RATE_LIMIT',  40 );

require_once LAWNACE_PLUGIN_DIR . 'includes/logging.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/rate-limit.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/system-prompt.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/lead.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/ajax.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/admin.php';

register_activation_hook( __FILE__, 'lawnace_activate' );

function lawnace_activate() {
    lawnace_chatbot_ensure_log_table();
}

/*
|--------------------------------------------------------------------------
| FRONTEND ASSETS + WIDGET HTML
|--------------------------------------------------------------------------
*/

add_action( 'wp_enqueue_scripts', 'lawnace_enqueue_assets' );

function lawnace_enqueue_assets() {
    wp_enqueue_style(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/css/widget.css',
        array(),
        LAWNACE_VERSION
    );

    wp_enqueue_script(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/js/widget.js',
        array(),
        LAWNACE_VERSION,
        true
    );

    wp_localize_script(
        'lawnace-widget',
        'lawnaceChat',
        array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'lawnace_chat_nonce' ),
            'sessionId' => wp_generate_uuid4(),
        )
    );
}

add_action( 'wp_footer', 'lawnace_render_widget' );

function lawnace_render_widget() {
    ?>
    <div id="la-nudge" style="display:none;" aria-live="polite">
        <button id="la-nudge-close" aria-label="Dismiss">&times;</button>
        <div id="la-nudge-text">👋 Have a lawn question? I can help right now.</div>
    </div>

    <div id="lawnace-ai-widget">
        <button id="la-launcher" aria-label="Open Lawn Ace AI chat">
            <span id="la-launcher-icon">
                <svg width="30" height="30" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <!-- Paper airplane matching Start Performance logo -->
                    <path d="M4 44 L60 6 L46 60 L30 38 Z" fill="white" fill-opacity="0.18" stroke="white" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>
                    <path d="M30 38 L46 60 L37 46 Z" fill="white" fill-opacity="0.45" stroke="white" stroke-width="2.5" stroke-linejoin="round"/>
                    <line x1="4" y1="44" x2="30" y2="38" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
                </svg>
            </span>
            <span id="la-dot"></span>
        </button>

        <div id="la-panel" aria-label="Lawn Ace AI chat window">
            <div id="la-header">
                <div id="la-avatar">
                    <svg width="22" height="22" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M4 44 L60 6 L46 60 L30 38 Z" fill="white" fill-opacity="0.2" stroke="white" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>
                        <path d="M30 38 L46 60 L37 46 Z" fill="white" fill-opacity="0.5" stroke="white" stroke-width="2.5" stroke-linejoin="round"/>
                        <line x1="4" y1="44" x2="30" y2="38" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
                    </svg>
                </div>
                <div>
                    <div id="la-header-title">Ace &mdash; Your Lawn Expert</div>
                    <div id="la-header-sub">Local lawn help for Augusta &amp; the CSRA.</div>
                </div>
                <button id="la-close" aria-label="Close chat">&times;</button>
            </div>

            <div id="la-body"></div>

            <div id="la-input-wrap">
                <button id="la-photo-btn" aria-label="Attach photo" title="Send a photo of your lawn">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M23 19C23 19.5304 22.7893 20.0391 22.4142 20.4142C22.0391 20.7893 21.5304 21 21 21H3C2.46957 21 1.96086 20.7893 1.58579 20.4142C1.21071 20.0391 1 19.5304 1 19V8C1 7.46957 1.21071 6.96086 1.58579 6.58579C1.96086 6.21071 2.46957 6 3 6H7L9 3H15L17 6H21C21.5304 6 22.0391 6.21071 22.4142 6.58579C22.7893 6.96086 23 7.46957 23 8V19Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="12" cy="13" r="4" stroke="currentColor" stroke-width="2"/>
                    </svg>
                </button>
                <input type="file" id="la-photo-input" accept="image/*" style="display:none;">
                <textarea id="la-input" rows="1" maxlength="600" placeholder="Type your message..."></textarea>
                <button id="la-send" aria-label="Send message">&#10148;</button>
            </div>

            <div id="la-footer">Local. Trusted. Here to help. &middot; <a href="tel:7063642338" id="la-footer-phone">706-364-2338</a></div>
        </div>
    </div>
    <?php
}
