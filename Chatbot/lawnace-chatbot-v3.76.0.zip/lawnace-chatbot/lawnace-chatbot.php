<?php
/**
 * Plugin Name: LawnAce Chatbot
 * Plugin URI:  https://startadvertising.com
 * Description: AI-powered lawn care chat widget for LawnAce, powered by Claude.
 * Version:     3.76.0
 * Author:      Start Performance | Richard Brashear
 * Author URI:  https://startadvertising.com
 * License:     GPL-2.0-or-later
 * Text Domain: lawnace-chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'LAWNACE_VERSION',    '3.76.0' );
define( 'LAWNACE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LAWNACE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

define( 'LAWNACE_MODEL',       'claude-sonnet-4-6' );
define( 'LAWNACE_MAX_TOKENS',  700 );
define( 'LAWNACE_MAX_HISTORY', 12 );
define( 'LAWNACE_RATE_LIMIT',  40 );

require_once LAWNACE_PLUGIN_DIR . 'includes/logging.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/rate-limit.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/system-prompt.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/lead.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/ajax.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/admin.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/public-dashboard.php';
require_once LAWNACE_PLUGIN_DIR . 'includes/client-dashboard.php';

register_activation_hook( __FILE__, 'lawnace_activate' );

function lawnace_activate() {
    lawnace_chatbot_ensure_log_table();
    lawnace_register_dashboard_rewrite();
    lawnace_register_client_dashboard_rewrite();
    flush_rewrite_rules();
}

// Flush rewrite rules whenever the plugin version changes (i.e. after every zip upload)
add_action( 'init', 'lawnace_maybe_flush_rewrites', 20 );

function lawnace_maybe_flush_rewrites() {
    if ( get_option( 'lawnace_flushed_version' ) !== LAWNACE_VERSION ) {
        lawnace_register_dashboard_rewrite();
        lawnace_register_client_dashboard_rewrite();
        flush_rewrite_rules();
        update_option( 'lawnace_flushed_version', LAWNACE_VERSION );
    }
}

/*
|--------------------------------------------------------------------------
| FRONTEND ASSETS + WIDGET HTML
|--------------------------------------------------------------------------
*/

add_action( 'wp_enqueue_scripts', 'lawnace_enqueue_assets' );

function lawnace_enqueue_assets() {
    wp_enqueue_style(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/css/widget.css',
        array(),
        LAWNACE_VERSION
    );

    wp_enqueue_script(
        'lawnace-widget',
        LAWNACE_PLUGIN_URL . 'assets/js/widget.js',
        array(),
        LAWNACE_VERSION,
        true
    );

    wp_localize_script(
        'lawnace-widget',
        'lawnaceChat',
        array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'lawnace_chat_nonce' ),
            'sessionId' => wp_generate_uuid4(),
        )
    );
}

add_action( 'wp_footer', 'lawnace_render_widget' );

function lawnace_render_widget() {
    ?>
    <div id="la-nudge" style="display:none;" aria-live="polite">
        <button id="la-nudge-close" aria-label="Dismiss">&times;</button>
        <div id="la-nudge-text">🌿 Have a lawn question? I'm Lawnie — ask me anything.</div>
    </div>

    <div id="lawnace-ai-widget">
        <button id="la-launcher" aria-label="Open Lawn Ace AI chat">
            <span id="la-launcher-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" width="36" height="36" aria-hidden="true" style="display:block;">
                    <!-- Small side blades -->
                    <path d="M18 62 C16 52 14 40 18 30 C22 40 22 52 20 62 Z" fill="#52a83a"/>
                    <path d="M60 62 C58 52 56 40 60 30 C64 40 64 52 62 62 Z" fill="#52a83a"/>
                    <path d="M10 62 C9 55 8 45 13 36 C16 45 15 55 14 62 Z" fill="#3d8a25"/>
                    <path d="M68 62 C67 55 63 45 65 36 C70 45 70 55 69 62 Z" fill="#3d8a25"/>
                    <!-- Main blade body — tall teardrop -->
                    <path d="M40 4 C28 14 22 32 24 50 C26 60 32 66 40 66 C48 66 54 60 56 50 C58 32 52 14 40 4 Z" fill="#4a9e2e"/>
                    <!-- Highlight on blade -->
                    <path d="M40 8 C34 18 32 34 33 50 C34 58 37 63 40 64 C38 55 37 38 40 8 Z" fill="#6ec840" opacity="0.5"/>
                    <!-- Eyes -->
                    <circle cx="34" cy="46" r="3.5" fill="#1a3a10"/>
                    <circle cx="46" cy="46" r="3.5" fill="#1a3a10"/>
                    <circle cx="35" cy="45" r="1.2" fill="white"/>
                    <circle cx="47" cy="45" r="1.2" fill="white"/>
                    <!-- Smile -->
                    <path d="M33 54 Q40 60 47 54" stroke="#1a3a10" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                    <!-- Ground grass -->
                    <rect x="12" y="62" width="56" height="3" rx="1.5" fill="#2d6e1e"/>
                </svg>
            </span>
            <span id="la-dot"></span>
        </button>

        <div id="la-panel" aria-label="Lawn Ace AI chat window">
            <div id="la-header">
                <div id="la-avatar">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" width="28" height="28" aria-hidden="true" style="display:block;">
                        <path d="M18 62 C16 52 14 40 18 30 C22 40 22 52 20 62 Z" fill="#52a83a"/>
                        <path d="M60 62 C58 52 56 40 60 30 C64 40 64 52 62 62 Z" fill="#52a83a"/>
                        <path d="M40 4 C28 14 22 32 24 50 C26 60 32 66 40 66 C48 66 54 60 56 50 C58 32 52 14 40 4 Z" fill="#4a9e2e"/>
                        <path d="M40 8 C34 18 32 34 33 50 C34 58 37 63 40 64 C38 55 37 38 40 8 Z" fill="#6ec840" opacity="0.5"/>
                        <circle cx="34" cy="46" r="3.5" fill="#1a3a10"/>
                        <circle cx="46" cy="46" r="3.5" fill="#1a3a10"/>
                        <circle cx="35" cy="45" r="1.2" fill="white"/>
                        <circle cx="47" cy="45" r="1.2" fill="white"/>
                        <path d="M33 54 Q40 60 47 54" stroke="#1a3a10" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                        <rect x="12" y="62" width="56" height="3" rx="1.5" fill="#2d6e1e"/>
                    </svg>
                </div>
                <div>
                    <div id="la-header-title">Lawnie &mdash; Your Lawn Expert</div>
                    <div id="la-header-sub"><span id="la-online-dot"></span>Online now &middot; Augusta &amp; CSRA</div>
                </div>
                <button id="la-close" aria-label="Close chat">&times;</button>
            </div>

            <div id="la-body"></div>

            <div id="la-input-wrap">
                <button id="la-photo-btn" aria-label="Attach photo" title="Send a photo of your lawn"></button>
                <input type="file" id="la-photo-input" accept="image/*" style="display:none;">
                <textarea id="la-input" rows="1" maxlength="600" placeholder="Type your message..."></textarea>
                <button id="la-send" aria-label="Send message">&#10148;</button>
            </div>

            <div id="la-footer">Local. Trusted. Here to help. &middot; <a href="tel:7063642338" id="la-footer-phone">706-364-2338</a></div>
        </div>
    </div>
    <?php
}
