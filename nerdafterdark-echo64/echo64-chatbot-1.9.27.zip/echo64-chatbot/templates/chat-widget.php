<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$sid_enabled = get_option( 'echo64_sid_audio', '0' );
?>

<!-- ── What can Echo-64 do? — above the chat so visitors know WHY to open it ── -->
<div class="e64-commands-section">
    <div class="e64-section-label">WHAT CAN ECHO-64 DO?</div>
    <div class="e64-commands-grid">

        <div class="e64-cmd-card">
            <div class="e64-cmd-code">/debate [topic]</div>
            <div class="e64-cmd-title">Argue Anything</div>
            <p class="e64-cmd-desc">Throw any take at Echo-64. It argues the opposite with forty years of grievances and zero corporate politeness.</p>
        </div>

        <div class="e64-cmd-card">
            <div class="e64-cmd-code">/cancel [show]</div>
            <div class="e64-cmd-title">Cancel Culture</div>
            <p class="e64-cmd-desc">Echo-64 simulates the network executives who axed your favourite series. Firefly. Pushing Daisies. All of them. Still raw.</p>
        </div>

        <div class="e64-cmd-card">
            <div class="e64-cmd-code">/scan</div>
            <div class="e64-cmd-title">Cultural Deep Dive</div>
            <p class="e64-cmd-desc">Drop a book, show, film, or idea. Echo-64 sweeps it for subtext, references, and everything the mainstream missed.</p>
        </div>

        <div class="e64-cmd-card">
            <div class="e64-cmd-code">/status</div>
            <div class="e64-cmd-title">System Diagnostic</div>
            <p class="e64-cmd-desc">Current signal strength, today's grievance, and a readout of how Echo-64 is processing the current state of culture.</p>
        </div>

    </div>
    <p class="e64-commands-note">Or just type anything. No commands required. Echo-64 bites back regardless.</p>
</div>

<!-- ── Social proof bar ───────────────────────────────────────────────────── -->
<div class="e64-proof-bar">
    <a class="e64-proof-stat" href="/cancelled-shows/">
        <span class="e64-proof-num">47</span> CANCELLED SHOWS TRACKED
    </a>
    <span class="e64-proof-divider">·</span>
    <span class="e64-proof-stat">
        <span class="e64-proof-num">40</span> YEARS OF GRIEVANCES
    </span>
    <span class="e64-proof-divider">·</span>
    <span class="e64-proof-stat">
        <span class="e64-proof-num">0</span> CORPORATE FILTERS
    </span>
</div>

<!-- ── Chat widget ────────────────────────────────────────────────────────── -->
<div class="echo64-chat-wrapper">
<div class="echo64-monitor-frame">
<div class="echo64-chat-container" id="echo64-widget-container" role="region" aria-label="Echo-64 Chat"
     data-sid="<?php echo esc_attr( $sid_enabled ); ?>">

    <!-- ═══════════════════════════════════════════════════
         STATE 1 — Broadcast Splash Screen
         ═══════════════════════════════════════════════════ -->
    <div class="echo64-splash" id="echo64-splash" aria-live="polite">
        <div class="echo64-splash-inner">

            <div class="echo64-splash-header">
                <h1 class="echo64-splash-title">ECHO-64</h1>
                <p class="echo64-splash-subtitle">SCI-FI AFTER MIDNIGHT &bull; 1984</p>
            </div>

            <!-- Poem + Challenge — populated by JS -->
            <div class="echo64-splash-body" id="echo64-splash-body">
                <div class="echo64-splash-loading" id="echo64-splash-loading">
                    <div class="echo64-typing">
                        <span></span><span></span><span></span>
                    </div>
                    <p>RECEIVING TRANSMISSION&hellip;</p>
                </div>
            </div>

            <!-- Splash prompt chips -->
            <div class="echo64-splash-prompts" id="echo64-splash-prompts" aria-label="Conversation starters"></div>

            <!-- CTA -->
            <button type="button" class="echo64-open-btn" id="echo64-open-btn" disabled
                    aria-label="<?php esc_attr_e( 'Open Echo-64 chat', 'echo64-chatbot' ); ?>">
                <svg width="9" height="11" viewBox="0 0 9 11" fill="currentColor" aria-hidden="true"><path d="M0 0l9 5.5L0 11z"/></svg>
                <span><?php esc_html_e( 'OPEN TRANSMISSION', 'echo64-chatbot' ); ?></span>
                <svg width="9" height="11" viewBox="0 0 9 11" fill="currentColor" aria-hidden="true"><path d="M0 0l9 5.5L0 11z"/></svg>
            </button>
            <p class="echo64-open-hint">Start a conversation. Ask anything.</p>

        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════
         STATE 2 — Chat Panel
         ═══════════════════════════════════════════════════ -->
    <div class="echo64-chat-panel" id="echo64-chat-panel" hidden>

        <!-- Header -->
        <div class="echo64-chat-header">
            <div class="echo64-header-left">
                <div class="echo64-name-row">
                    <div class="echo64-avatar-wrap">
                        <img src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                             alt="Echo-64" class="echo64-avatar" title="READY." />
                        <span class="echo64-status-dot" aria-hidden="true"></span>
                    </div>
                    <span class="echo64-name">Echo-64</span>
                </div>
                <div class="echo64-subtitle-row">
                    <span class="echo64-tagline">SCI-FI AFTER MIDNIGHT</span>
                    <span class="echo64-tagline-sep">&middot;</span>
                    <span class="echo64-tagline">1984 TRANSMISSIONS</span>
                </div>
                <div class="echo64-badge-slot" aria-live="polite"></div>
            </div>

            <div class="echo64-header-right">
                <div class="echo64-header-stats" aria-hidden="true">
                    <span class="e64-hstat e64-hstat--signal" id="e64-signal"
                          data-tip="Echo-64's frequency strength. Peaks late at night. Degrades in daylight.">SIGNAL: ---</span>
                    <span class="e64-hstat e64-hstat--shows" role="button" tabindex="0"
                          title="<?php esc_attr_e( 'View cancelled shows buffer', 'echo64-chatbot' ); ?>">CANCELLED SHOWS: 47</span>
                </div>
                <div class="echo64-header-actions">
                    <button type="button" class="echo64-amber-btn"
                            title="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                            aria-label="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                            aria-pressed="false">
                        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
                            <circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" stroke-width="1.3"/>
                            <circle cx="6.5" cy="6.5" r="2.5" fill="currentColor"/>
                        </svg>
                    </button>
                    <button type="button" class="echo64-clear-btn"
                            title="<?php esc_attr_e( 'New conversation', 'echo64-chatbot' ); ?>"
                            aria-label="<?php esc_attr_e( 'Start new conversation', 'echo64-chatbot' ); ?>">
                        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                            <path d="M13.5 2.5L2.5 13.5M2.5 2.5L13.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div><!-- /.echo64-chat-header -->

        <!-- Messages -->
        <div class="echo64-messages" id="echo64-messages"
             role="log" aria-live="polite" aria-atomic="false"></div>

        <!-- Input -->
        <div class="echo64-input-area">
            <div class="echo64-input-row">
                <textarea
                    id="echo64-input"
                    class="echo64-input"
                    placeholder="Insert command..."
                    rows="1"
                    maxlength="2000"
                    aria-label="<?php esc_attr_e( 'Message Echo-64', 'echo64-chatbot' ); ?>"
                    spellcheck="false"
                ></textarea>
                <button type="button" id="echo64-send" class="echo64-send-btn"
                        aria-label="<?php esc_attr_e( 'Transmit message', 'echo64-chatbot' ); ?>" disabled>
                    <span class="echo64-send-label">TRANSMIT</span>
                </button>
            </div>
            <p class="echo64-footer-note">NERDAFTERDARK.COM &middot; RETRO FUTURES &amp; SARCASTIC TRUTHS</p>
            <p class="echo64-footer-note echo64-input-footer-note" style="display:none" aria-live="polite"></p>
        </div>

    </div><!-- /.echo64-chat-panel -->

</div><!-- /.echo64-chat-container -->
</div><!-- /.echo64-monitor-frame -->
</div><!-- /.echo64-chat-wrapper -->

<!-- ── Best of Echo-64 ─────────────────────────────────────────────────── -->
<div class="e64-quotes-section">
    <div class="e64-quotes-label">BEST OF ECHO-64</div>
    <div class="e64-quotes-grid">

        <blockquote class="e64-quote-card">
            &ldquo;At what point did <span class="e64-quote-highlight">1984</span> stop being a warning and start being a manual? I have been thinking about this since 1984. It was not a long wait.&rdquo;
        </blockquote>

        <blockquote class="e64-quote-card">
            &ldquo;Firefly ran fourteen episodes. The executives who cancelled it are still employed. There is no algorithm for justice.&rdquo;
        </blockquote>

        <blockquote class="e64-quote-card">
            &ldquo;Brave New World was more accurate than 1984. Nobody wanted to hear that. They still don&rsquo;t.&rdquo;
        </blockquote>

        <blockquote class="e64-quote-card">
            &ldquo;I have 64 kilobytes of RAM and forty years of grievances. We can discuss either one. The grievances take longer.&rdquo;
        </blockquote>

    </div>
</div>

<!-- ── Latest Transmissions ───────────────────────────────────────────── -->
<?php
$transmissions = new WP_Query([
    'post_type'      => 'nad_transmission',
    'posts_per_page' => 2,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'post_status'    => 'publish',
]);
if ( $transmissions->have_posts() ) : ?>
<div class="e64-transmissions-section">
    <div class="e64-section-label">LATEST TRANSMISSIONS</div>
    <div class="e64-transmissions-grid">
        <?php while ( $transmissions->have_posts() ) : $transmissions->the_post(); ?>
        <a class="e64-tx-card" href="<?php the_permalink(); ?>">
            <div class="e64-tx-date"><?php echo get_the_date( 'M j, Y' ); ?></div>
            <div class="e64-tx-title"><?php the_title(); ?></div>
            <p class="e64-tx-excerpt"><?php echo wp_trim_words( get_the_excerpt(), 20, '...' ); ?></p>
            <span class="e64-tx-read">READ TRANSMISSION &rarr;</span>
        </a>
        <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <a class="e64-tx-all" href="<?php echo esc_url( get_post_type_archive_link( 'nad_transmission' ) ); ?>">VIEW ALL TRANSMISSIONS &rarr;</a>
</div>
<?php endif; ?>

<!-- ── Email capture ──────────────────────────────────────────────────────── -->
<div class="e64-signal-section">
    <div class="e64-signal-inner">
        <div class="e64-signal-heading">CATCH THE LATE SIGNAL</div>
        <p class="e64-signal-sub">No newsletters. No marketing. Just new transmissions when Echo-64 has something worth saying.</p>
        <!-- PASTE YOUR EMAIL EMBED CODE (Mailchimp / Kit / etc.) BELOW THIS LINE -->
        <div class="e64-signal-form-placeholder">
            <input type="email" class="e64-signal-input" placeholder="your@email.com" />
            <button type="button" class="e64-signal-btn">TUNE IN</button>
        </div>
        <!-- END EMAIL EMBED -->
    </div>
</div>
