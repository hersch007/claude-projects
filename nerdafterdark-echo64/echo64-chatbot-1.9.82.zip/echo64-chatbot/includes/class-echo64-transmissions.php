<?php
if ( ! defined( 'ABSPATH' ) ) exit;

final class Echo64_Transmissions {

    private static ?Echo64_Transmissions $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'pre_get_posts', [ $this, 'transmission_archive_query' ] );
    }

    public function transmission_archive_query( \WP_Query $query ): void {
        if ( is_admin() || ! $query->is_main_query() ) {
            return;
        }
        if ( $query->is_post_type_archive( 'nad_transmission' ) ) {
            $query->set( 'orderby', 'date' );
            $query->set( 'order', 'DESC' );
            if ( get_option( 'echo64_transmissions_unlimited', '0' ) === '1' ) {
                $query->set( 'posts_per_page', -1 );
            }
        }
    }
}
