<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$home = home_url( '/' );

$shows = [
    [ 'title' => 'Firefly',                              'network' => 'Fox',            'year' => '2002', 'verdict' => 'Fourteen episodes. A complete universe. The executives are still employed.' ],
    [ 'title' => 'Pushing Daisies',                      'network' => 'ABC',            'year' => '2009', 'verdict' => 'A show about death that was more alive than anything else on television.' ],
    [ 'title' => 'Freaks and Geeks',                     'network' => 'NBC',            'year' => '2000', 'verdict' => 'Every cast member became a star. The network still cancelled it.' ],
    [ 'title' => 'Carnivàle',                            'network' => 'HBO',            'year' => '2005', 'verdict' => 'Two seasons into a six-season story. We will never know the ending.' ],
    [ 'title' => 'Deadwood',                             'network' => 'HBO',            'year' => '2006', 'verdict' => 'The best dialogue ever written for television. Ended mid-sentence.' ],
    [ 'title' => 'Farscape',                             'network' => 'Sci-Fi Channel', 'year' => '2003', 'verdict' => 'Cancelled the week after a cliffhanger. The fans screamed loud enough for a miniseries.' ],
    [ 'title' => 'My So-Called Life',                    'network' => 'ABC',            'year' => '1995', 'verdict' => 'One perfect season. Claire Danes was never better. ABC disagreed.' ],
    [ 'title' => 'Dark Angel',                           'network' => 'Fox',            'year' => '2002', 'verdict' => 'James Cameron created it. Fox cancelled it. Fox was wrong.' ],
    [ 'title' => 'Terminator: The Sarah Connor Chronicles', 'network' => 'Fox',         'year' => '2009', 'verdict' => 'Season two was extraordinary. Ended on the best cliffhanger Fox ever cancelled.' ],
    [ 'title' => 'Dollhouse',                            'network' => 'Fox',            'year' => '2010', 'verdict' => 'Joss Whedon\'s most ambitious idea. Fox gave it two seasons to confuse people.' ],
    [ 'title' => 'Sense8',                               'network' => 'Netflix',        'year' => '2018', 'verdict' => 'Eight characters. Eight cities. One of the most expensive cancellations in streaming history.' ],
    [ 'title' => 'The OA',                               'network' => 'Netflix',        'year' => '2019', 'verdict' => 'People cried in the street when this was cancelled. That is not a metaphor.' ],
    [ 'title' => 'Mindhunter',                           'network' => 'Netflix',        'year' => '2020', 'verdict' => 'David Fincher\'s best work since Zodiac. Netflix put it on indefinite hold. Same thing.' ],
    [ 'title' => 'Dark Matter',                          'network' => 'Syfy',           'year' => '2017', 'verdict' => 'Three seasons in, the plot was finally paying off. Syfy cancelled it that week.' ],
    [ 'title' => 'Caprica',                              'network' => 'Syfy',           'year' => '2011', 'verdict' => 'A prequel to Battlestar Galactica that was better than most of its competition.' ],
    [ 'title' => 'FlashForward',                         'network' => 'ABC',            'year' => '2010', 'verdict' => 'Everyone saw six months into the future. ABC saw only one season.' ],
    [ 'title' => 'The Event',                            'network' => 'NBC',            'year' => '2011', 'verdict' => 'They called it the next Lost. NBC cancelled it before anyone could find out.' ],
    [ 'title' => 'Almost Human',                         'network' => 'Fox',            'year' => '2014', 'verdict' => 'Karl Urban and a robot. Fox aired the episodes out of order then cancelled it.' ],
    [ 'title' => 'Revolution',                           'network' => 'NBC',            'year' => '2014', 'verdict' => 'A world without electricity had more power than NBC gave it credit for.' ],
    [ 'title' => 'Alcatraz',                             'network' => 'Fox',            'year' => '2012', 'verdict' => 'Time-travelling prisoners. One season. Fox ran out of patience before the mystery did.' ],
    [ 'title' => 'Terra Nova',                           'network' => 'Fox',            'year' => '2012', 'verdict' => 'Dinosaurs and time travel and Fox killed it before the second season breathed.' ],
    [ 'title' => 'Constantine',                          'network' => 'NBC',            'year' => '2015', 'verdict' => 'The perfect casting. The perfect tone. Thirteen episodes and NBC called it done.' ],
    [ 'title' => 'Forever',                              'network' => 'ABC',            'year' => '2015', 'verdict' => 'A man who cannot die, cancelled before his story had one.' ],
    [ 'title' => 'Agent Carter',                         'network' => 'ABC',            'year' => '2016', 'verdict' => 'Peggy Carter deserved more than two seasons. ABC disagreed with everyone.' ],
    [ 'title' => 'Limitless',                            'network' => 'CBS',            'year' => '2016', 'verdict' => 'The pill gave you infinite intelligence. CBS gave the show one season.' ],
    [ 'title' => 'Timeless',                             'network' => 'NBC',            'year' => '2018', 'verdict' => 'Cancelled twice. Uncancelled once. Cancelled for good. The timeline did not survive.' ],
    [ 'title' => 'Defiance',                             'network' => 'Syfy',           'year' => '2015', 'verdict' => 'A show tied to a video game. Both were cancelled. Neither deserved it.' ],
    [ 'title' => 'Continuum',                            'network' => 'Showcase',       'year' => '2015', 'verdict' => 'Got a proper ending only because the showrunner begged for six extra episodes.' ],
    [ 'title' => 'Stargate Universe',                    'network' => 'Syfy',           'year' => '2011', 'verdict' => 'The darkest and most ambitious Stargate. Cancelled on a cliffhanger. Obviously.' ],
    [ 'title' => 'Rubicon',                              'network' => 'AMC',            'year' => '2011', 'verdict' => 'The smartest conspiracy show ever made. AMC cancelled it for something louder.' ],
    [ 'title' => 'Lodge 49',                             'network' => 'AMC',            'year' => '2020', 'verdict' => 'A gentle, strange masterpiece about belonging. AMC cancelled it during a pandemic.' ],
    [ 'title' => 'The Get Down',                         'network' => 'Netflix',        'year' => '2017', 'verdict' => 'Baz Luhrmann\'s love letter to the Bronx in the 1970s. One season.' ],
    [ 'title' => 'Patriot',                              'network' => 'Amazon',         'year' => '2018', 'verdict' => 'The funniest show about espionage ever made. Amazon cancelled it quietly.' ],
    [ 'title' => 'Max Headroom',                         'network' => 'ABC',            'year' => '1988', 'verdict' => 'Set twenty minutes into the future. We are living in it now. They cancelled it in 1988.' ],
    [ 'title' => 'Jericho',                              'network' => 'CBS',            'year' => '2008', 'verdict' => 'Fans sent 40,000 pounds of nuts to CBS to save it. Got one more season. Then nothing.' ],
    [ 'title' => 'Kings',                                'network' => 'NBC',            'year' => '2009', 'verdict' => 'A modern retelling of King David with Ian McShane. NBC buried it on Saturdays.' ],
    [ 'title' => 'Journeyman',                           'network' => 'NBC',            'year' => '2008', 'verdict' => 'Time travel done quietly and beautifully. NBC saw the ratings and said no.' ],
    [ 'title' => 'Drive',                                'network' => 'Fox',            'year' => '2007', 'verdict' => 'Nathan Fillion in a cross-country race thriller. Fox cancelled it after four episodes.' ],
    [ 'title' => 'The Tick',                             'network' => 'Amazon',         'year' => '2019', 'verdict' => 'The best superhero comedy since The Incredibles. Amazon cancelled it in year two.' ],
    [ 'title' => 'Travelers',                            'network' => 'Netflix',        'year' => '2018', 'verdict' => 'Three perfect seasons of time travel ethics. Netflix ended it without warning.' ],
    [ 'title' => 'Blood Drive',                          'network' => 'Syfy',           'year' => '2017', 'verdict' => 'A grindhouse road race with cars fuelled by human blood. Too weird to survive.' ],
    [ 'title' => 'Daybreak',                             'network' => 'Netflix',        'year' => '2019', 'verdict' => 'Post-apocalyptic high school. Clever and strange and gone before episode ten.' ],
    [ 'title' => 'Studio 60 on the Sunset Strip',        'network' => 'NBC',            'year' => '2007', 'verdict' => 'Aaron Sorkin at his most Aaron Sorkin. NBC wanted something cheaper.' ],
    [ 'title' => 'Wonderfalls',                          'network' => 'Fox',            'year' => '2004', 'verdict' => 'A gift shop employee gets instructions from animal figurines. Fox aired four episodes.' ],
    [ 'title' => 'Brimstone',                            'network' => 'Fox',            'year' => '1999', 'verdict' => 'A dead cop hunts escaped souls from Hell. Fox cancelled it at Christmas.' ],
    [ 'title' => 'Surface',                              'network' => 'NBC',            'year' => '2006', 'verdict' => 'Sea monsters and government cover-ups. One season. The ocean kept its secrets.' ],
    [ 'title' => 'The Middleman',                        'network' => 'ABC Family',     'year' => '2008', 'verdict' => 'The most fun twelve episodes of television in 2008. Twelve episodes total.' ],
];
?>

<div class="e64-shows-page">

    <div class="e64-shows-header">
        <div class="e64-shows-eyebrow">ECHO-64 BUFFER · <?php echo count( $shows ); ?> ENTRIES</div>
        <h1 class="e64-shows-title">THE CANCELLED SHOWS BUFFER</h1>
        <p class="e64-shows-intro">
            Every show here deserved more time. Every network made the wrong call.
            Click any show to open a conversation with Echo-64 about it.
        </p>
    </div>

    <div class="e64-shows-grid">
        <?php foreach ( $shows as $i => $show ) :
            $slug    = urlencode( '/scan ' . $show['title'] );
            $link    = esc_url( home_url( '/echo-64/' ) . '?e64q=' . $slug );
            $num     = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
        ?>
        <a class="e64-show-card" href="<?php echo $link; ?>">
            <div class="e64-show-num"><?php echo $num; ?></div>
            <div class="e64-show-title"><?php echo esc_html( $show['title'] ); ?></div>
            <div class="e64-show-meta"><?php echo esc_html( $show['network'] ); ?> &middot; <?php echo esc_html( $show['year'] ); ?></div>
            <p class="e64-show-verdict"><?php echo esc_html( $show['verdict'] ); ?></p>
            <span class="e64-show-cta">ASK ECHO-64 &rarr;</span>
        </a>
        <?php endforeach; ?>
    </div>

</div>
