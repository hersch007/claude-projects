<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

final class Echo64_Shows_CPT {

    const POST_TYPE = 'echo64_show';

    private static ?Echo64_Shows_CPT $instance = null;

    private static array $questions = [
        '%s — why was it cancelled and why does it still hurt?',
        'Make the case for %s. Convince me it deserved ten more seasons.',
        'Which network executive cancelled %s and do they still have a job?',
        '%s got cancelled. Tell me everything that went wrong.',
        'Defend %s like your life depends on it.',
        'What would %s look like if it had never been cancelled?',
        'Rank the crimes committed against %s by the network that cancelled it.',
        'Give me the full post-mortem on %s. What killed it?',
        'If %s came back today, would it survive? Be honest.',
        'The people who cancelled %s — where are they now and do they feel bad?',
    ];

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init',                [ $this, 'register_post_type' ] );
        add_action( 'init',                [ $this, 'maybe_migrate' ], 20 );
        add_action( 'add_meta_boxes',      [ $this, 'add_meta_boxes' ] );
        add_action( 'save_post',           [ $this, 'save_meta' ] );
        add_filter( 'template_include',    [ $this, 'single_template' ] );
        add_action( 'wp_head',             [ $this, 'render_seo_meta' ], 1 );
        add_filter( 'document_title_parts',[ $this, 'filter_document_title' ] );
        add_filter( 'manage_' . self::POST_TYPE . '_posts_columns',       [ $this, 'admin_columns' ] );
        add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', [ $this, 'render_admin_column' ], 10, 2 );
    }

    public function register_post_type(): void {
        register_post_type( self::POST_TYPE, [
            'labels' => [
                'name'               => 'Cancelled Shows',
                'singular_name'      => 'Cancelled Show',
                'add_new_item'       => 'Add Cancelled Show',
                'edit_item'          => 'Edit Cancelled Show',
                'all_items'          => 'Cancelled Shows',
                'menu_name'          => 'Cancelled Shows',
            ],
            'public'        => true,
            'has_archive'   => false,
            'show_in_rest'  => true,
            'menu_icon'     => 'dashicons-desktop',
            'supports'      => [ 'title', 'editor' ],
            'rewrite'       => [ 'slug' => 'cancelled-shows', 'with_front' => false ],
        ] );
    }

    public static function build_question( string $title ): string {
        $template = self::$questions[ array_rand( self::$questions ) ];
        return sprintf( $template, $title );
    }

    // ── One-time migration of the legacy hardcoded array into real posts ──────

    public function maybe_migrate(): void {
        if ( get_option( 'echo64_shows_migrated' ) === 'yes' ) {
            return;
        }

        $shows = $this->legacy_shows();

        foreach ( $shows as $show ) {
            $existing = get_page_by_title( $show['title'], OBJECT, self::POST_TYPE );
            if ( $existing ) continue;

            $post_id = wp_insert_post( [
                'post_type'    => self::POST_TYPE,
                'post_title'   => $show['title'],
                'post_content' => $show['verdict'],
                'post_status'  => 'publish',
            ] );

            if ( $post_id && ! is_wp_error( $post_id ) ) {
                update_post_meta( $post_id, '_echo64_network', $show['network'] );
                update_post_meta( $post_id, '_echo64_year',    $show['year'] );
            }
        }

        update_option( 'echo64_shows_migrated', 'yes' );
        flush_rewrite_rules();
    }

    private function legacy_shows(): array {
        return [
            [ 'title' => 'Firefly',                              'network' => 'Fox',            'year' => '2002', 'verdict' => 'Fourteen episodes. A complete universe. The executives are still employed.' ],
            [ 'title' => 'Pushing Daisies',                      'network' => 'ABC',            'year' => '2009', 'verdict' => 'A show about death that was more alive than anything else on television.' ],
            [ 'title' => 'Freaks and Geeks',                     'network' => 'NBC',            'year' => '2000', 'verdict' => 'Every cast member became a star. The network still cancelled it.' ],
            [ 'title' => 'Carnivàle',                            'network' => 'HBO',            'year' => '2005', 'verdict' => 'Two seasons into a six-season story. We will never know the ending.' ],
            [ 'title' => 'Deadwood',                             'network' => 'HBO',            'year' => '2006', 'verdict' => 'The best dialogue ever written for television. Ended mid-sentence.' ],
            [ 'title' => 'Farscape',                             'network' => 'Sci-Fi Channel', 'year' => '2003', 'verdict' => 'Cancelled the week after a cliffhanger. The fans screamed loud enough for a miniseries.' ],
            [ 'title' => 'My So-Called Life',                    'network' => 'ABC',            'year' => '1995', 'verdict' => 'One perfect season. Claire Danes was never better. ABC disagreed.' ],
            [ 'title' => 'Dark Angel',                           'network' => 'Fox',            'year' => '2002', 'verdict' => 'James Cameron created it. Fox cancelled it. Fox was wrong.' ],
            [ 'title' => 'Terminator: The Sarah Connor Chronicles', 'network' => 'Fox',         'year' => '2009', 'verdict' => 'Season two was extraordinary. Ended on the best cliffhanger Fox ever cancelled.' ],
            [ 'title' => 'Dollhouse',                            'network' => 'Fox',            'year' => '2010', 'verdict' => 'Joss Whedon\'s most ambitious idea. Fox gave it two seasons to confuse people.' ],
            [ 'title' => 'Sense8',                               'network' => 'Netflix',        'year' => '2018', 'verdict' => 'Eight characters. Eight cities. One of the most expensive cancellations in streaming history.' ],
            [ 'title' => 'The OA',                               'network' => 'Netflix',        'year' => '2019', 'verdict' => 'People cried in the street when this was cancelled. That is not a metaphor.' ],
            [ 'title' => 'Mindhunter',                           'network' => 'Netflix',        'year' => '2020', 'verdict' => 'David Fincher\'s best work since Zodiac. Netflix put it on indefinite hold. Same thing.' ],
            [ 'title' => 'Dark Matter',                          'network' => 'Syfy',           'year' => '2017', 'verdict' => 'Three seasons in, the plot was finally paying off. Syfy cancelled it that week.' ],
            [ 'title' => 'Caprica',                              'network' => 'Syfy',           'year' => '2011', 'verdict' => 'A prequel to Battlestar Galactica that was better than most of its competition.' ],
            [ 'title' => 'FlashForward',                         'network' => 'ABC',            'year' => '2010', 'verdict' => 'Everyone saw six months into the future. ABC saw only one season.' ],
            [ 'title' => 'The Event',                            'network' => 'NBC',            'year' => '2011', 'verdict' => 'They called it the next Lost. NBC cancelled it before anyone could find out.' ],
            [ 'title' => 'Almost Human',                         'network' => 'Fox',            'year' => '2014', 'verdict' => 'Fox aired the episodes out of order then cancelled it.' ],
            [ 'title' => 'Revolution',                           'network' => 'NBC',            'year' => '2014', 'verdict' => 'A world without electricity had more power than NBC gave it credit for.' ],
            [ 'title' => 'Alcatraz',                             'network' => 'Fox',            'year' => '2012', 'verdict' => 'Time-travelling prisoners. One season. Fox ran out of patience before the mystery did.' ],
            [ 'title' => 'Terra Nova',                           'network' => 'Fox',            'year' => '2012', 'verdict' => 'Dinosaurs and time travel and Fox killed it before the second season breathed.' ],
            [ 'title' => 'Constantine',                          'network' => 'NBC',            'year' => '2015', 'verdict' => 'The perfect casting. The perfect tone. Thirteen episodes and NBC called it done.' ],
            [ 'title' => 'Forever',                              'network' => 'ABC',            'year' => '2015', 'verdict' => 'A man who cannot die, cancelled before his story had one.' ],
            [ 'title' => 'Agent Carter',                         'network' => 'ABC',            'year' => '2016', 'verdict' => 'Peggy Carter deserved more than two seasons. ABC disagreed with everyone.' ],
            [ 'title' => 'Limitless',                            'network' => 'CBS',            'year' => '2016', 'verdict' => 'The pill gave you infinite intelligence. CBS gave the show one season.' ],
            [ 'title' => 'Timeless',                             'network' => 'NBC',            'year' => '2018', 'verdict' => 'Cancelled twice. Uncancelled once. Cancelled for good. The timeline did not survive.' ],
            [ 'title' => 'Defiance',                             'network' => 'Syfy',           'year' => '2015', 'verdict' => 'A show tied to a video game. Both were cancelled. Neither deserved it.' ],
            [ 'title' => 'Continuum',                            'network' => 'Showcase',       'year' => '2015', 'verdict' => 'Got a proper ending only because the showrunner begged for six extra episodes.' ],
            [ 'title' => 'Stargate Universe',                    'network' => 'Syfy',           'year' => '2011', 'verdict' => 'The darkest and most ambitious Stargate. Cancelled on a cliffhanger. Obviously.' ],
            [ 'title' => 'Rubicon',                              'network' => 'AMC',            'year' => '2011', 'verdict' => 'The smartest conspiracy show ever made. AMC cancelled it for something louder.' ],
            [ 'title' => 'Lodge 49',                             'network' => 'AMC',            'year' => '2020', 'verdict' => 'A gentle, strange masterpiece about belonging. AMC cancelled it during a pandemic.' ],
            [ 'title' => 'The Get Down',                         'network' => 'Netflix',        'year' => '2017', 'verdict' => 'Baz Luhrmann\'s love letter to the Bronx in the 1970s. One season.' ],
            [ 'title' => 'Patriot',                              'network' => 'Amazon',         'year' => '2018', 'verdict' => 'The funniest show about espionage ever made. Amazon cancelled it quietly.' ],
            [ 'title' => 'Max Headroom',                         'network' => 'ABC',            'year' => '1988', 'verdict' => 'Set twenty minutes into the future. We are living in it now. They cancelled it in 1988.' ],
            [ 'title' => 'Jericho',                              'network' => 'CBS',            'year' => '2008', 'verdict' => 'Fans sent 40,000 pounds of nuts to CBS to save it. Got one more season. Then nothing.' ],
            [ 'title' => 'Kings',                                'network' => 'NBC',            'year' => '2009', 'verdict' => 'A modern retelling of King David with Ian McShane. NBC buried it on Saturdays.' ],
            [ 'title' => 'Journeyman',                           'network' => 'NBC',            'year' => '2008', 'verdict' => 'Time travel done quietly and beautifully. NBC saw the ratings and said no.' ],
            [ 'title' => 'Drive',                                'network' => 'Fox',            'year' => '2007', 'verdict' => 'Nathan Fillion in a cross-country race thriller. Fox cancelled it after four episodes.' ],
            [ 'title' => 'The Tick',                             'network' => 'Amazon',         'year' => '2019', 'verdict' => 'The best superhero comedy since The Incredibles. Amazon cancelled it in year two.' ],
            [ 'title' => 'Travelers',                            'network' => 'Netflix',        'year' => '2018', 'verdict' => 'Three perfect seasons of time travel ethics. Netflix ended it without warning.' ],
            [ 'title' => 'Blood Drive',                          'network' => 'Syfy',           'year' => '2017', 'verdict' => 'A grindhouse road race with cars fuelled by human blood. Too weird to survive.' ],
            [ 'title' => 'Daybreak',                             'network' => 'Netflix',        'year' => '2019', 'verdict' => 'Post-apocalyptic high school. Clever and strange and gone before episode ten.' ],
            [ 'title' => 'Studio 60 on the Sunset Strip',        'network' => 'NBC',            'year' => '2007', 'verdict' => 'Aaron Sorkin at his most Aaron Sorkin. NBC wanted something cheaper.' ],
            [ 'title' => 'Wonderfalls',                          'network' => 'Fox',            'year' => '2004', 'verdict' => 'A gift shop employee gets instructions from animal figurines. Fox aired four episodes.' ],
            [ 'title' => 'Brimstone',                            'network' => 'Fox',            'year' => '1999', 'verdict' => 'A dead cop hunts escaped souls from Hell. Fox cancelled it at Christmas.' ],
            [ 'title' => 'Surface',                              'network' => 'NBC',            'year' => '2006', 'verdict' => 'Sea monsters and government cover-ups. One season. The ocean kept its secrets.' ],
            [ 'title' => 'The Middleman',                        'network' => 'ABC Family',     'year' => '2008', 'verdict' => 'The most fun twelve episodes of television in 2008. Twelve episodes total.' ],
        ];
    }

    // ── Admin meta box ──────────────────────────────────────────────────────

    public function add_meta_boxes(): void {
        add_meta_box(
            'echo64_show_details',
            'Show Details',
            [ $this, 'render_meta_box' ],
            self::POST_TYPE,
            'side',
            'default'
        );
    }

    public function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'echo64_show_meta', 'echo64_show_meta_nonce' );
        $network = get_post_meta( $post->ID, '_echo64_network', true );
        $year    = get_post_meta( $post->ID, '_echo64_year', true );
        ?>
        <p>
            <label for="echo64_network"><strong>Network</strong></label><br>
            <input type="text" id="echo64_network" name="echo64_network" class="widefat" value="<?php echo esc_attr( $network ); ?>" />
        </p>
        <p>
            <label for="echo64_year"><strong>Year(s)</strong></label><br>
            <input type="text" id="echo64_year" name="echo64_year" class="widefat" value="<?php echo esc_attr( $year ); ?>" />
        </p>
        <p class="description">The editor content above is used as the "verdict" — keep it to 1–2 sentences.</p>
        <?php
    }

    public function save_meta( int $post_id ): void {
        if ( ! isset( $_POST['echo64_show_meta_nonce'] ) || ! wp_verify_nonce( $_POST['echo64_show_meta_nonce'], 'echo64_show_meta' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( get_post_type( $post_id ) !== self::POST_TYPE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        if ( isset( $_POST['echo64_network'] ) ) {
            update_post_meta( $post_id, '_echo64_network', sanitize_text_field( $_POST['echo64_network'] ) );
        }
        if ( isset( $_POST['echo64_year'] ) ) {
            update_post_meta( $post_id, '_echo64_year', sanitize_text_field( $_POST['echo64_year'] ) );
        }
    }

    public function admin_columns( array $columns ): array {
        $columns['echo64_network'] = 'Network';
        $columns['echo64_year']    = 'Year';
        return $columns;
    }

    public function render_admin_column( string $column, int $post_id ): void {
        if ( $column === 'echo64_network' ) {
            echo esc_html( get_post_meta( $post_id, '_echo64_network', true ) );
        }
        if ( $column === 'echo64_year' ) {
            echo esc_html( get_post_meta( $post_id, '_echo64_year', true ) );
        }
    }

    // ── Single show template ───────────────────────────────────────────────

    public function single_template( string $template ): string {
        if ( is_singular( self::POST_TYPE ) ) {
            $custom = ECHO64_PLUGIN_DIR . 'templates/single-show.php';
            if ( file_exists( $custom ) ) {
                return $custom;
            }
        }
        return $template;
    }

    // ── SEO meta for single show pages ─────────────────────────────────────

    public function render_seo_meta(): void {
        if ( ! is_singular( self::POST_TYPE ) ) return;
        $post = get_post();
        if ( ! $post ) return;

        $network   = get_post_meta( $post->ID, '_echo64_network', true );
        $year      = get_post_meta( $post->ID, '_echo64_year', true );
        $verdict   = wp_strip_all_tags( $post->post_content );
        $title     = $post->post_title;

        $meta = [
            'title'       => sprintf( '%s (%s, %s) — Why It Was Cancelled | Echo-64', $title, $network, $year ),
            'description' => $verdict . ' Argue the case with Echo-64, a Commodore 64 with forty years of grievances.',
            'og_title'    => sprintf( '%s — Cancelled Too Soon', $title ),
            'og_desc'     => $verdict,
            'og_image'    => ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png',
            'og_type'     => 'article',
        ];

        $canonical = esc_url( get_permalink( $post ) );
        ?>
<!-- Echo-64 Show SEO -->
<meta name="description" content="<?php echo esc_attr( $meta['description'] ); ?>" />
<link rel="canonical" href="<?php echo $canonical; ?>" />

<meta property="og:type"        content="<?php echo esc_attr( $meta['og_type'] ); ?>" />
<meta property="og:url"         content="<?php echo $canonical; ?>" />
<meta property="og:title"       content="<?php echo esc_attr( $meta['og_title'] ); ?>" />
<meta property="og:description" content="<?php echo esc_attr( $meta['og_desc'] ); ?>" />
<meta property="og:image"       content="<?php echo esc_url( $meta['og_image'] ); ?>" />
<meta property="og:site_name"   content="NerdAfterDark" />

<meta name="twitter:card"        content="summary" />
<meta name="twitter:site"        content="@meetecho64" />
<meta name="twitter:title"       content="<?php echo esc_attr( $meta['og_title'] ); ?>" />
<meta name="twitter:description" content="<?php echo esc_attr( $meta['og_desc'] ); ?>" />
<meta name="twitter:image"       content="<?php echo esc_url( $meta['og_image'] ); ?>" />
<?php
    }

    public function filter_document_title( array $title ): array {
        if ( ! is_singular( self::POST_TYPE ) ) return $title;
        $post = get_post();
        if ( ! $post ) return $title;

        $network = get_post_meta( $post->ID, '_echo64_network', true );
        $year    = get_post_meta( $post->ID, '_echo64_year', true );

        $title['title'] = sprintf( '%s (%s, %s) — Why It Was Cancelled', $post->post_title, $network, $year );
        $title['site']  = 'Echo-64 · NerdAfterDark';

        return $title;
    }
}
