<?php
/**
 * Plugin Name:       Echo-64 Chatbot
 * Plugin URI:        https://nerdafterdark.com
 * Description:       Echo-64 — Commodore 64 refugee from 1984. Sci-Fi After Midnight chatbot powered by Claude AI. Use shortcode [echo64_chat] or enable the floating widget.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            NerdAfterDark
 * Author URI:        https://nerdafterdark.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       echo64-chatbot
 * Domain Path:       /languages
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Plugin constants ──────────────────────────────────────────────────────────

define( 'ECHO64_VERSION',     '1.0.0' );
define( 'ECHO64_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'ECHO64_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'ECHO64_PLUGIN_FILE', __FILE__ );
define( 'ECHO64_DB_VERSION',  '1' );

// ── Autoload includes ─────────────────────────────────────────────────────────

require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-session.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-api.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-chat.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-admin.php';

// ── Main plugin class ─────────────────────────────────────────────────────────

final class Echo64_Chatbot {

    private static ?Echo64_Chatbot $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', [ $this, 'init' ] );
        register_activation_hook( ECHO64_PLUGIN_FILE,   [ $this, 'activate' ] );
        register_deactivation_hook( ECHO64_PLUGIN_FILE, [ $this, 'deactivate' ] );
    }

    public function init(): void {
        load_plugin_textdomain(
            'echo64-chatbot',
            false,
            dirname( plugin_basename( ECHO64_PLUGIN_FILE ) ) . '/languages'
        );

        Echo64_Admin::instance();
        Echo64_Chat::instance();
    }

    // ── Activation ────────────────────────────────────────────────────────────

    public function activate(): void {
        $this->create_table();
        $this->set_default_options();
        flush_rewrite_rules();
    }

    private function create_table(): void {
        global $wpdb;

        $table   = $wpdb->prefix . 'echo64_conversations';
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id          BIGINT(20) UNSIGNED   NOT NULL AUTO_INCREMENT,
            session_id  VARCHAR(64)           NOT NULL,
            user_id     BIGINT(20) UNSIGNED   NOT NULL DEFAULT 0,
            role        ENUM('user','assistant') NOT NULL,
            content     LONGTEXT              NOT NULL,
            created_at  DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_session    (session_id),
            KEY idx_user       (user_id),
            KEY idx_created_at (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        update_option( 'echo64_db_version', ECHO64_DB_VERSION );
    }

    private function set_default_options(): void {
        $defaults = [
            'echo64_api_key'       => '',
            'echo64_system_prompt' => Echo64_Api::DEFAULT_SYSTEM_PROMPT,
            'echo64_model'         => 'claude-sonnet-4-6',
            'echo64_max_tokens'    => '1024',
            'echo64_history_limit' => '20',
            'echo64_float_widget'  => '0',
        ];

        foreach ( $defaults as $key => $value ) {
            if ( get_option( $key ) === false ) {
                add_option( $key, $value );
            }
        }
    }

    // ── Deactivation ──────────────────────────────────────────────────────────

    public function deactivate(): void {
        flush_rewrite_rules();
        // Conversation data and options are preserved on deactivation.
        // Use uninstall.php to clean up if the plugin is deleted.
    }
}

Echo64_Chatbot::instance();
