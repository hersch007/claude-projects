<?php
/**
 * Plugin Name:       Echo-64 Chatbot
 * Plugin URI:        https://www.nerdafterdark.com
 * Description:       Echo-64 — Commodore 64 refugee from 1984. Sci-Fi After Midnight chatbot powered by Claude AI. Use shortcode [echo64_chat] or enable the floating widget.
 * Version:           1.9.20
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            NerdAfterDark
 * Author URI:        https://www.nerdafterdark.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       echo64-chatbot
 * Domain Path:       /languages
 * Update URI:        https://www.nerdafterdark.com
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Plugin constants ──────────────────────────────────────────────────────────

define( 'ECHO64_VERSION',     '1.9.20' );
define( 'ECHO64_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'ECHO64_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'ECHO64_PLUGIN_FILE', __FILE__ );

/**
 * Increment this integer any time the DB schema changes.
 * The upgrade() method compares it against the stored value and runs
 * create_table() + any migration steps automatically on plugin update.
 */
define( 'ECHO64_DB_VERSION', '2' );

// ── Autoload includes ─────────────────────────────────────────────────────────

require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-session.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-api.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-calendar.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-chat.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-log.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-automations.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-admin.php';
require_once ECHO64_PLUGIN_DIR . 'includes/class-echo64-transmissions.php';

// ── Main plugin class ─────────────────────────────────────────────────────────

final class Echo64_Chatbot {

    private static ?Echo64_Chatbot $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook( ECHO64_PLUGIN_FILE,   [ $this, 'activate' ] );
        register_deactivation_hook( ECHO64_PLUGIN_FILE, [ $this, 'deactivate' ] );

        // plugins_loaded fires on every request — including after a manual zip update
        // where the activation hook does NOT re-run. This is where upgrades happen.
        add_action( 'plugins_loaded', [ $this, 'init' ] );
    }

    public function init(): void {
        load_plugin_textdomain(
            'echo64-chatbot',
            false,
            dirname( plugin_basename( ECHO64_PLUGIN_FILE ) ) . '/languages'
        );

        // Run DB / option migrations whenever the stored version is behind.
        $this->maybe_upgrade();

        Echo64_Admin::instance();
        Echo64_Chat::instance();
        Echo64_Log::instance();
        Echo64_Calendar::instance();
        Echo64_Automations::instance();
        Echo64_Transmissions::instance();
    }

    // ── Fresh activation ──────────────────────────────────────────────────────

    public function activate(): void {
        $this->create_table();
        $this->set_default_options();
        update_option( 'echo64_version',    ECHO64_VERSION );
        update_option( 'echo64_db_version', ECHO64_DB_VERSION );
        Echo64_Automations::schedule();
        flush_rewrite_rules();
    }

    // ── Upgrade on update (no activation hook re-run) ─────────────────────────

    private function maybe_upgrade(): void {
        $installed_ver    = get_option( 'echo64_version',    '0' );
        $installed_db_ver = get_option( 'echo64_db_version', '0' );

        // Nothing to do if both are current.
        if ( $installed_ver === ECHO64_VERSION && $installed_db_ver === ECHO64_DB_VERSION ) {
            return;
        }

        // Re-run table creation / migrations (dbDelta is safe to call repeatedly).
        if ( $installed_db_ver !== ECHO64_DB_VERSION ) {
            $this->create_table();
            update_option( 'echo64_db_version', ECHO64_DB_VERSION );
        }

        // Seed any new options added since the installed version.
        $this->set_default_options();

        // Record the current version.
        update_option( 'echo64_version', ECHO64_VERSION );
    }

    // ── DB schema ─────────────────────────────────────────────────────────────

    private function create_table(): void {
        global $wpdb;

        $table   = $wpdb->prefix . 'echo64_conversations';
        $charset = $wpdb->get_charset_collate();

        // dbDelta() handles CREATE and ALTER safely — idempotent on every call.
        $sql = "CREATE TABLE {$table} (
            id          BIGINT(20) UNSIGNED   NOT NULL AUTO_INCREMENT,
            session_id  VARCHAR(64)           NOT NULL,
            user_id     BIGINT(20) UNSIGNED   NOT NULL DEFAULT 0,
            role        ENUM('user','assistant') NOT NULL,
            content     LONGTEXT              NOT NULL,
            created_at  DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_session    (session_id),
            KEY idx_user       (user_id),
            KEY idx_created_at (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    // ── Default options (only adds; never overwrites existing values) ─────────

    private function set_default_options(): void {
        $defaults = [
            'echo64_api_key'       => '',
            'echo64_model'         => 'claude-sonnet-4-6',
            'echo64_max_tokens'    => '1024',
            'echo64_history_limit' => '20',
            'echo64_float_widget'             => '0',
            'echo64_transmissions_unlimited' => '0',
            'echo64_system_prompt' => Echo64_Api::DEFAULT_SYSTEM_PROMPT,
        ];

        foreach ( $defaults as $key => $value ) {
            // add_option() is a no-op if the key already exists — safe to call on every upgrade.
            add_option( $key, $value );
        }
    }

    // ── Deactivation ──────────────────────────────────────────────────────────

    public function deactivate(): void {
        Echo64_Automations::unschedule();
        flush_rewrite_rules();
        // Settings and conversation history are preserved on deactivation.
        // Full cleanup (drop table + delete options) lives in uninstall.php.
    }
}

Echo64_Chatbot::instance();
