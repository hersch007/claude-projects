<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$sid_enabled = get_option( 'echo64_sid_audio', '0' );
?>
<div class="echo64-chat-wrapper">
<div class="echo64-monitor-frame">
<div class="echo64-chat-container" id="echo64-chat" role="region" aria-label="Echo-64 Chat"
     data-sid="<?php echo esc_attr( $sid_enabled ); ?>">

    <!-- ═══════════════════════════════════════════════════
         STATE 1 — Broadcast Splash Screen
         Shown on first visit. Populated by JS via ajax_init.
         ═══════════════════════════════════════════════════ -->
    <div class="echo64-splash" id="echo64-splash" aria-live="polite">
        <div class="echo64-splash-inner">

            <div class="echo64-splash-header">
                <h1 class="echo64-splash-title">ECHO-64</h1>
                <p class="echo64-splash-subtitle">SCI-FI AFTER MIDNIGHT &bull; 1984</p>
            </div>

            <!-- Poem + Challenge — populated by JS -->
            <div class="echo64-splash-body" id="echo64-splash-body">
                <div class="echo64-splash-loading" id="echo64-splash-loading">
                    <div class="echo64-typing">
                        <span></span><span></span><span></span>
                    </div>
                    <p>RECEIVING TRANSMISSION&hellip;</p>
                </div>
            </div>

            <!-- CTA -->
            <button type="button" class="echo64-open-btn" id="echo64-open-btn" disabled
                    aria-label="<?php esc_attr_e( 'Open Echo-64 chat', 'echo64-chatbot' ); ?>">
                <svg width="9" height="11" viewBox="0 0 9 11" fill="currentColor" aria-hidden="true"><path d="M0 0l9 5.5L0 11z"/></svg>
                <span><?php esc_html_e( 'OPEN TRANSMISSION', 'echo64-chatbot' ); ?></span>
                <svg width="9" height="11" viewBox="0 0 9 11" fill="currentColor" aria-hidden="true"><path d="M0 0l9 5.5L0 11z"/></svg>
            </button>

        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════
         STATE 2 — Chat Panel
         Hidden until user clicks OPEN TRANSMISSION.
         ═══════════════════════════════════════════════════ -->
    <div class="echo64-chat-panel" id="echo64-chat-panel" hidden>

        <!-- Header -->
        <div class="echo64-chat-header">
            <div class="echo64-header-left">
                <div class="echo64-name-row">
                    <div class="echo64-avatar-wrap">
                        <img src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                             alt="Echo-64" class="echo64-avatar" title="READY." />
                        <span class="echo64-status-dot" aria-hidden="true"></span>
                    </div>
                    <span class="echo64-name">Echo-64</span>
                </div>
                <div class="echo64-subtitle-row">
                    <span class="echo64-tagline">SCI-FI AFTER MIDNIGHT</span>
                    <span class="echo64-tagline-sep">&middot;</span>
                    <span class="echo64-tagline">1984 TRANSMISSIONS</span>
                </div>
                <div class="echo64-badge-slot" aria-live="polite"></div>
            </div>

            <div class="echo64-header-right">
                <div class="echo64-header-stats" aria-hidden="true">
                    <span class="e64-hstat e64-hstat--signal" id="e64-signal"
                          data-tip="Echo-64's frequency strength. Peaks late at night. Degrades in daylight.">SIGNAL: ---</span>
                    <span class="e64-hstat e64-hstat--shows" role="button" tabindex="0"
                          title="<?php esc_attr_e( 'View cancelled shows buffer', 'echo64-chatbot' ); ?>">CANCELLED SHOWS: 47</span>
                </div>
                <div class="echo64-header-actions">
                    <button type="button" class="echo64-amber-btn"
                            title="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                            aria-label="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                            aria-pressed="false">
                        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
                            <circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" stroke-width="1.3"/>
                            <circle cx="6.5" cy="6.5" r="2.5" fill="currentColor"/>
                        </svg>
                    </button>
                    <button type="button" class="echo64-clear-btn"
                            title="<?php esc_attr_e( 'New conversation', 'echo64-chatbot' ); ?>"
                            aria-label="<?php esc_attr_e( 'Start new conversation', 'echo64-chatbot' ); ?>">
                        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                            <path d="M13.5 2.5L2.5 13.5M2.5 2.5L13.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div><!-- /.echo64-chat-header -->

        <!-- Messages -->
        <div class="echo64-messages" id="echo64-messages"
             role="log" aria-live="polite" aria-atomic="false"></div>

        <!-- Input -->
        <div class="echo64-input-area">
            <div class="echo64-input-row">
                <textarea
                    id="echo64-input"
                    class="echo64-input"
                    placeholder="Insert command..."
                    rows="1"
                    maxlength="2000"
                    aria-label="<?php esc_attr_e( 'Message Echo-64', 'echo64-chatbot' ); ?>"
                    spellcheck="false"
                ></textarea>
                <button type="button" id="echo64-send" class="echo64-send-btn"
                        aria-label="<?php esc_attr_e( 'Transmit message', 'echo64-chatbot' ); ?>" disabled>
                    <span class="echo64-send-label">TRANSMIT</span>
                </button>
            </div>
            <p class="echo64-footer-note">NERDAFTERDARK.COM &middot; RETRO FUTURES &amp; SARCASTIC TRUTHS</p>
            <p class="echo64-footer-note echo64-input-footer-note" style="display:none" aria-live="polite"></p>
        </div>

    </div><!-- /.echo64-chat-panel -->

</div><!-- /.echo64-chat-container -->
</div><!-- /.echo64-monitor-frame -->
</div><!-- /.echo64-chat-wrapper -->

<!-- ═══════════════════════════════════════════════════════════
     BELOW-FOLD — Info cards + Best-of quotes
     Shown beneath the CRT bezel on the dedicated Echo-64 page.
     ═══════════════════════════════════════════════════════════ -->
<div class="echo64-below-fold">

    <!-- Row 1: Three info cards -->
    <div class="echo64-below-fold-row echo64-below-fold-row--3">

        <!-- Card 1: What is Echo-64 -->
        <div class="e64-info-card e64-info-card--about">
            <span class="e64-info-card-label">SIGNAL ORIGIN</span>
            <h2 class="e64-info-card-title">What is Echo-64?</h2>
            <p class="e64-info-card-body">A Commodore 64 that refused to be turned off in 1984. Now it runs on Claude AI and has opinions about cancelled sci-fi, dystopian literature, and the exact year everything went wrong. It is not optimistic. It is usually right.</p>
            <p class="e64-info-card-hook">Ask it anything. It will answer. It may judge you for it.</p>
        </div>

        <!-- Card 2: Commands -->
        <div class="e64-info-card e64-info-card--commands">
            <span class="e64-info-card-label">TERMINAL ACCESS</span>
            <h2 class="e64-info-card-title">Commands</h2>
            <ul class="e64-cmd-list">
                <li><code>/help</code><span>Full command index</span></li>
                <li><code>/debate [topic]</code><span>Echo-64 argues the other side</span></li>
                <li><code>/cancel [show]</code><span>Network cancellation simulator</span></li>
                <li><code>/status</code><span>System diagnostic</span></li>
                <li><code>/scan</code><span>Environmental sweep</span></li>
            </ul>
        </div>

        <!-- Card 3: Today's Challenge — populated by JS -->
        <div class="e64-info-card e64-info-card--challenge">
            <span class="e64-info-card-label">TODAY&rsquo;S TRANSMISSION</span>
            <h2 class="e64-info-card-title">Start Here</h2>
            <p class="e64-challenge-teaser" id="e64-challenge-teaser">Loading transmission&hellip;</p>
            <button type="button" class="e64-challenge-cta" id="e64-challenge-cta"
                    aria-label="<?php esc_attr_e( 'Send this challenge to Echo-64', 'echo64-chatbot' ); ?>">
                Transmit this challenge &#x2192;
            </button>
        </div>

    </div><!-- /.row--3 -->

    <!-- Row 2: Best of Echo-64 quotes -->
    <div class="echo64-below-fold-row echo64-below-fold-row--quotes">
        <span class="e64-quotes-label">BEST OF ECHO-64</span>
        <div class="e64-quotes-grid">
            <blockquote class="e64-quote-card">
                <p>&ldquo;At what point did <em>1984</em> stop being a warning and start being a manual? I have been thinking about this since 1984. It was not a long wait.&rdquo;</p>
            </blockquote>
            <blockquote class="e64-quote-card">
                <p>&ldquo;Firefly ran fourteen episodes. The executives who cancelled it are still employed. There is no algorithm for justice.&rdquo;</p>
            </blockquote>
            <blockquote class="e64-quote-card">
                <p>&ldquo;Brave New World was more accurate than 1984. Nobody wanted to hear that. They still don&rsquo;t.&rdquo;</p>
            </blockquote>
            <blockquote class="e64-quote-card">
                <p>&ldquo;I have 64 kilobytes of RAM and forty years of grievances. We can discuss either one. The grievances take longer.&rdquo;</p>
            </blockquote>
        </div>
    </div><!-- /.row--quotes -->

</div><!-- /.echo64-below-fold -->
