<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class Echo64_Chat {

    private static ?Echo64_Chat $instance = null;
    private Echo64_Api $api;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = new Echo64_Api();
        add_shortcode( 'echo64_chat',           [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts',        [ $this, 'enqueue_assets' ] );
        add_action( 'wp_footer',                 [ $this, 'maybe_render_floating_widget' ] );
        add_action( 'wp_ajax_echo64_send',        [ $this, 'ajax_send' ] );
        add_action( 'wp_ajax_nopriv_echo64_send', [ $this, 'ajax_send' ] );
        add_action( 'wp_ajax_echo64_clear',        [ $this, 'ajax_clear' ] );
        add_action( 'wp_ajax_nopriv_echo64_clear', [ $this, 'ajax_clear' ] );
        add_action( 'wp_ajax_echo64_init',         [ $this, 'ajax_init' ] );
        add_action( 'wp_ajax_nopriv_echo64_init',  [ $this, 'ajax_init' ] );
    }

    public function enqueue_assets(): void {
        wp_enqueue_style(
            'echo64-chat',
            ECHO64_PLUGIN_URL . 'assets/css/echo64-chat.css',
            [],
            ECHO64_VERSION
        );

        wp_enqueue_script(
            'echo64-chat',
            ECHO64_PLUGIN_URL . 'assets/js/echo64-chat.js',
            [ 'jquery' ],
            ECHO64_VERSION,
            true
        );

        wp_localize_script( 'echo64-chat', 'echo64Config', [
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'echo64_nonce' ),
            'avatarUrl'  => ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png',
            'isFloating' => get_option( 'echo64_float_widget', '0' ),
        ] );
    }

    public function render_shortcode( array $atts ): string {
        ob_start();
        include ECHO64_PLUGIN_DIR . 'templates/chat-widget.php';
        return ob_get_clean();
    }

    public function maybe_render_floating_widget(): void {
        if ( get_option( 'echo64_float_widget', '0' ) !== '1' ) {
            return;
        }
        echo '<div id="echo64-float-launcher" aria-label="Open Echo-64 Chat">';
        echo '<img src="' . esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ) . '" alt="Echo-64" />';
        echo '</div>';
        echo '<div id="echo64-float-panel" role="dialog" aria-modal="true" aria-label="Echo-64 Chat" hidden>';
        include ECHO64_PLUGIN_DIR . 'templates/chat-widget.php';
        echo '</div>';
    }

    public function ajax_init(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );

        $session_id = Echo64_Session::get_session_id();
        $is_new     = Echo64_Session::is_new_session( $session_id );

        if ( ! $is_new ) {
            $needs_daily_refresh = Echo64_Session::needs_daily_refresh( $session_id );
            $last_topic          = Echo64_Session::get_last_user_message( $session_id );
            wp_send_json_success( [
                'new_session'   => false,
                'daily_refresh' => $needs_daily_refresh,
                'last_topic'    => $last_topic,
            ] );
            return;
        }

        $system_prompt = get_option( 'echo64_system_prompt', Echo64_Api::DEFAULT_SYSTEM_PROMPT );

        // No prefill — just a plain user request ending in a user turn (API requirement).
        // The fixed opening line is rendered by the frontend from OPENING_LINE directly.
        // This call fetches only the poem + daily challenge.
        $messages = [
            [
                'role'    => 'user',
                'content' => Echo64_Api::INIT_TRIGGER,
            ],
        ];

        $poem_and_challenge = $this->api->send_message( $messages, $system_prompt );

        if ( is_wp_error( $poem_and_challenge ) ) {
            wp_send_json_error( [ 'message' => $poem_and_challenge->get_error_message() ] );
            return;
        }

        // Store both the fixed opening line and the poem as the assistant's first turn
        // so future context includes a clean conversation start.
        $full_opening = Echo64_Api::OPENING_LINE . "\n\n" . $poem_and_challenge;
        Echo64_Session::save_message( $session_id, 'user',      Echo64_Api::INIT_TRIGGER );
        Echo64_Session::save_message( $session_id, 'assistant', $full_opening );
        Echo64_Session::mark_daily_refresh( $session_id );

        wp_send_json_success( [
            'new_session'  => true,
            'opening_line' => Echo64_Api::OPENING_LINE,
            'poem'         => $poem_and_challenge,
        ] );
    }

    public function ajax_send(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );

        $user_message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );

        if ( empty( $user_message ) ) {
            wp_send_json_error( [ 'message' => 'Empty message.' ] );
            return;
        }

        if ( mb_strlen( $user_message ) > 2000 ) {
            wp_send_json_error( [ 'message' => 'Message too long.' ] );
            return;
        }

        $session_id    = Echo64_Session::get_session_id();
        $limit         = (int) get_option( 'echo64_history_limit', 20 );
        $history       = Echo64_Session::get_history( $session_id, $limit );
        $system_prompt = get_option( 'echo64_system_prompt', Echo64_Api::DEFAULT_SYSTEM_PROMPT );

        $messages   = $history;
        $messages[] = [ 'role' => 'user', 'content' => $user_message ];

        $reply = $this->api->send_message( $messages, $system_prompt );

        if ( is_wp_error( $reply ) ) {
            wp_send_json_error( [ 'message' => $reply->get_error_message() ] );
            return;
        }

        Echo64_Session::save_message( $session_id, 'user',      $user_message );
        Echo64_Session::save_message( $session_id, 'assistant', $reply );

        wp_send_json_success( [ 'message' => $reply ] );
    }

    public function ajax_clear(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );
        $session_id = Echo64_Session::get_session_id();
        Echo64_Session::clear_session( $session_id );
        wp_send_json_success();
    }
}
