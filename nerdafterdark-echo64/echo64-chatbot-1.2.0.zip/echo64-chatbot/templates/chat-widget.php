<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$sid_enabled = get_option( 'echo64_sid_audio', '0' );
?>
<div class="echo64-chat-wrapper">
<div class="echo64-chat-container" id="echo64-chat" role="region" aria-label="Echo-64 Chat"
     data-sid="<?php echo esc_attr( $sid_enabled ); ?>">

    <div class="echo64-chat-header">
        <div class="echo64-header-left">
            <div class="echo64-avatar-wrap">
                <img src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                     alt="Echo-64" class="echo64-avatar" title="READY." />
                <span class="echo64-status-dot" aria-hidden="true"></span>
            </div>
            <div class="echo64-header-info">
                <span class="echo64-name">Echo-64</span>
                <span class="echo64-tagline">Sci-Fi After Midnight</span>
                <span class="echo64-tagline-sub">ALSO RUNS D&amp;D MODULES IN BASIC</span>
            </div>
            <!-- #21 Achievement badge slot — populated by JS -->
            <div class="echo64-badge-slot" aria-live="polite"></div>
        </div>
        <div class="echo64-header-actions">
            <!-- Roll for Initiative — loads a random D&D/sci-fi prompt -->
            <button type="button" class="echo64-roll-btn"
                    title="Roll for Initiative — random D&amp;D/sci-fi prompt"
                    aria-label="<?php esc_attr_e( 'Roll for Initiative — random prompt', 'echo64-chatbot' ); ?>">
                <!-- SVG d6 die — avoids WordPress Twemoji emoji replacement -->
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true" style="flex-shrink:0">
                    <rect x="1" y="1" width="12" height="12" rx="2.5" stroke="currentColor" stroke-width="1.4" fill="none"/>
                    <circle cx="4"  cy="4"  r="1.1" fill="currentColor"/>
                    <circle cx="10" cy="4"  r="1.1" fill="currentColor"/>
                    <circle cx="4"  cy="10" r="1.1" fill="currentColor"/>
                    <circle cx="10" cy="10" r="1.1" fill="currentColor"/>
                    <circle cx="4"  cy="7"  r="1.1" fill="currentColor"/>
                    <circle cx="10" cy="7"  r="1.1" fill="currentColor"/>
                </svg>
                <span><?php esc_html_e( 'Roll', 'echo64-chatbot' ); ?></span>
            </button>
            <!-- Phosphor colour toggle: cyan ↔ amber — plain text avoids Twemoji -->
            <button type="button" class="echo64-amber-btn"
                    title="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                    aria-label="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                    aria-pressed="false">
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
                    <circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" stroke-width="1.3"/>
                    <circle cx="6.5" cy="6.5" r="2.5" fill="currentColor"/>
                </svg>
            </button>
            <button type="button" class="echo64-clear-btn"
                    title="<?php esc_attr_e( 'New conversation', 'echo64-chatbot' ); ?>"
                    aria-label="<?php esc_attr_e( 'Start new conversation', 'echo64-chatbot' ); ?>">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M13.5 2.5L2.5 13.5M2.5 2.5L13.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span><?php esc_html_e( 'New Chat', 'echo64-chatbot' ); ?></span>
            </button>
        </div>
    </div>

    <!-- Live metrics bar — populated + animated by JS -->
    <div class="echo64-status-bar" aria-hidden="true" id="echo64-status-bar">
        <span class="e64-stat" id="e64-signal">SIGNAL: ---</span>
        <span class="e64-stat-sep">·</span>
        <span class="e64-stat">CANCELLED SHOWS IN BUFFER: 47</span>
        <span class="e64-stat-sep">·</span>
        <span class="e64-stat" id="e64-d20">D20 ROLLS TODAY: 0</span>
    </div>

    <div class="echo64-messages" id="echo64-messages" role="log" aria-live="polite" aria-atomic="false"></div>

    <div class="echo64-input-area">
        <div class="echo64-input-row">
            <textarea
                id="echo64-input"
                class="echo64-input"
                placeholder="READY."
                rows="1"
                maxlength="2000"
                aria-label="<?php esc_attr_e( 'Message Echo-64', 'echo64-chatbot' ); ?>"
                spellcheck="false"
            ></textarea>
            <button type="button" id="echo64-send" class="echo64-send-btn"
                    aria-label="<?php esc_attr_e( 'Send message', 'echo64-chatbot' ); ?>" disabled>
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                    <path d="M3 10L17 10M17 10L11 4M17 10L11 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
        <p class="echo64-footer-note"><?php esc_html_e( 'NerdAfterDark.com · Retro Futures &amp; Sarcastic Truths', 'echo64-chatbot' ); ?></p>
    </div>

</div><!-- /.echo64-chat-container -->
</div><!-- /.echo64-chat-wrapper -->
