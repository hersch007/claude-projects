<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class Echo64_Admin {

    private static ?Echo64_Admin $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function add_menu(): void {
        add_options_page(
            __( 'Echo-64 Chatbot', 'echo64-chatbot' ),
            __( 'Echo-64 Chatbot', 'echo64-chatbot' ),
            'manage_options',
            'echo64-settings',
            [ $this, 'render_page' ]
        );
    }

    public function enqueue_assets( string $hook ): void {
        if ( $hook !== 'settings_page_echo64-settings' ) return;

        wp_enqueue_style(
            'echo64-admin',
            ECHO64_PLUGIN_URL . 'assets/css/echo64-admin.css',
            [],
            ECHO64_VERSION
        );

        // Inline JS for admin interactions
        $js = <<<'JS'
document.addEventListener('DOMContentLoaded', function () {
    // Character counter for the system prompt textarea
    const textarea = document.getElementById('echo64_system_prompt');
    const counter  = document.getElementById('echo64-prompt-counter');
    if (textarea && counter) {
        const update = () => { counter.textContent = textarea.value.length.toLocaleString() + ' chars'; };
        textarea.addEventListener('input', update);
        update();
    }

    // Reset to default button
    const resetBtn     = document.getElementById('echo64-reset-prompt');
    const defaultProp  = resetBtn ? resetBtn.dataset.default : null;
    if (resetBtn && defaultProp) {
        resetBtn.addEventListener('click', function () {
            if (confirm('Reset to the original Echo-64 system prompt? Your edits will be lost.')) {
                textarea.value = defaultProp;
                if (counter) counter.textContent = textarea.value.length.toLocaleString() + ' chars';
            }
        });
    }

    // Toggle API key visibility
    const toggle = document.getElementById('echo64-toggle-key');
    const keyInput = document.getElementById('echo64_api_key');
    if (toggle && keyInput) {
        toggle.addEventListener('click', function () {
            const show = keyInput.type === 'password';
            keyInput.type = show ? 'text' : 'password';
            this.textContent = show ? 'Hide' : 'Show';
        });
    }

    // Test API connection
    const testBtn  = document.getElementById('echo64-test-api');
    const testResult = document.getElementById('echo64-test-result');
    if (testBtn && testResult) {
        testBtn.addEventListener('click', function () {
            const key = keyInput ? keyInput.value.trim() : '';
            if (!key) { testResult.textContent = 'Enter an API key first.'; testResult.className = 'echo64-test-fail'; return; }
            testBtn.disabled = true;
            testBtn.textContent = 'Testing…';
            testResult.textContent = '';
            testResult.className = '';
            fetch(ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'echo64_test_api',
                    nonce:  echo64AdminNonce,
                    api_key: key,
                })
            })
            .then(r => r.json())
            .then(res => {
                testResult.textContent = res.data?.message || (res.success ? '✓ Connected' : '✗ Failed');
                testResult.className   = res.success ? 'echo64-test-ok' : 'echo64-test-fail';
            })
            .catch(() => {
                testResult.textContent = '✗ Request failed';
                testResult.className   = 'echo64-test-fail';
            })
            .finally(() => {
                testBtn.disabled    = false;
                testBtn.textContent = 'Test Connection';
            });
        });
    }
});
JS;
        wp_add_inline_script( 'jquery', $js );
        wp_localize_script( 'jquery', 'echo64AdminNonce', wp_create_nonce( 'echo64_admin_nonce' ) );
    }

    public function register_settings(): void {
        $opts = [
            'echo64_api_key'          => 'sanitize_text_field',
            'echo64_model'            => 'sanitize_text_field',
            'echo64_max_tokens'       => 'absint',
            'echo64_history_limit'    => 'absint',
            'echo64_daily_limit'      => 'absint',           // v1.4.0
            'echo64_float_widget'     => 'sanitize_text_field',
            'echo64_system_prompt'    => 'sanitize_textarea_field',
            'echo64_discord_webhook'  => 'sanitize_url',
            'echo64_email_recipient'  => 'sanitize_text_field',
            'echo64_sid_audio'              => 'sanitize_text_field',
            'echo64_transmissions_unlimited' => 'sanitize_text_field',
        ];

        foreach ( $opts as $key => $cb ) {
            register_setting( 'echo64_settings', $key, [ 'sanitize_callback' => $cb ] );
        }

        add_action( 'wp_ajax_echo64_test_api', [ $this, 'ajax_test_api' ] );
    }

    public function ajax_test_api(): void {
        check_ajax_referer( 'echo64_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
            return;
        }

        $api_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) );
        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'message' => '✗ No API key provided.' ] );
            return;
        }

        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 20,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => 'claude-haiku-4-5-20251001',
                'max_tokens' => 8,
                'messages'   => [ [ 'role' => 'user', 'content' => 'Hi' ] ],
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => '✗ ' . $response->get_error_message() ] );
            return;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 200 ) {
            wp_send_json_success( [ 'message' => '✓ API key valid. Connection successful.' ] );
        } else {
            $msg = $body['error']['message'] ?? 'Unknown error';
            wp_send_json_error( [ 'message' => "✗ API error ({$code}): {$msg}" ] );
        }
    }

    private function get_tabs(): array {
        return [
            'settings'      => '⚙ Settings',
            'conversations' => '💬 Conversations',
            'stats'         => '📊 Stats',
            'dashboard'     => '🖥 Dashboard',
            'automations'   => '🤖 Automations',
            'calendar'      => '📅 Calendar',
            'launch'        => '🚀 Launch Kit',
        ];
    }

    public function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $current_tab = sanitize_key( $_GET['tab'] ?? 'settings' );
        $tabs        = $this->get_tabs();
        if ( ! array_key_exists( $current_tab, $tabs ) ) $current_tab = 'settings';

        $api_key       = get_option( 'echo64_api_key', '' );
        $model         = get_option( 'echo64_model', 'claude-sonnet-4-6' );
        $max_tokens    = (int) get_option( 'echo64_max_tokens', 1024 );
        $history_limit = (int) get_option( 'echo64_history_limit', 20 );
        $daily_limit   = (int) get_option( 'echo64_daily_limit', 9 );
        $float_widget  = get_option( 'echo64_float_widget', '0' );
        $sid_audio              = get_option( 'echo64_sid_audio', '0' );
        $transmissions_unlimited = get_option( 'echo64_transmissions_unlimited', '0' );
        $system_prompt = get_option( 'echo64_system_prompt', Echo64_Api::DEFAULT_SYSTEM_PROMPT );

        $models = [
            'claude-opus-4-8'           => 'Claude Opus 4.8 — Most capable, slowest',
            'claude-sonnet-4-6'         => 'Claude Sonnet 4.6 — Recommended balance',
            'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5 — Fastest, most economical',
        ];
        ?>
        <div class="wrap echo64-admin-wrap">

            <div class="echo64-admin-header">
                <img
                    src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                    alt="Echo-64 avatar"
                    class="echo64-admin-avatar"
                    onerror="this.style.display='none'"
                />
                <div class="echo64-admin-header-text">
                    <h1>Echo-64 Chatbot</h1>
                    <p class="echo64-admin-sub">NerdAfterDark.com &mdash; Retro Futures &amp; Sarcastic Truths</p>
                    <p class="echo64-admin-version">Version <?php echo esc_html( ECHO64_VERSION ); ?> &nbsp;|&nbsp; Shortcode: <code>[echo64_chat]</code></p>
                </div>
            </div>

            <?php settings_errors( 'echo64_settings' ); ?>

            <!-- ── Tab Navigation ── -->
            <nav class="nav-tab-wrapper echo64-tab-nav">
                <?php foreach ( $tabs as $slug => $label ) :
                    $url = add_query_arg( [ 'page' => 'echo64-settings', 'tab' => $slug ], admin_url( 'options-general.php' ) );
                    $cls = $current_tab === $slug ? 'nav-tab nav-tab-active' : 'nav-tab';
                ?>
                    <a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( $cls ); ?>">
                        <?php echo esc_html( $label ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <?php if ( $current_tab === 'conversations' ) :
                Echo64_Log::instance()->render_log();
            elseif ( $current_tab === 'stats' ) :
                Echo64_Log::instance()->render_stats();
            elseif ( $current_tab === 'dashboard' ) :
                $this->render_dashboard();
            elseif ( $current_tab === 'automations' ) :
                Echo64_Automations::instance()->render();
            elseif ( $current_tab === 'calendar' ) :
                Echo64_Calendar::instance()->render();
            elseif ( $current_tab === 'launch' ) :
                $this->render_launch_kit();
            else : ?>

            <form method="post" action="options.php">
                <?php settings_fields( 'echo64_settings' ); ?>

                <!-- ── API Configuration ── -->
                <div class="echo64-admin-card">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">⚙</span>
                        <?php esc_html_e( 'API Configuration', 'echo64-chatbot' ); ?>
                    </h2>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="echo64_api_key"><?php esc_html_e( 'Anthropic API Key', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <div class="echo64-key-row">
                                    <input
                                        type="password"
                                        id="echo64_api_key"
                                        name="echo64_api_key"
                                        value="<?php echo esc_attr( $api_key ); ?>"
                                        class="regular-text"
                                        autocomplete="off"
                                        placeholder="sk-ant-…"
                                    />
                                    <button type="button" id="echo64-toggle-key" class="button">Show</button>
                                    <button type="button" id="echo64-test-api" class="button">Test Connection</button>
                                </div>
                                <span id="echo64-test-result"></span>
                                <p class="description">
                                    <?php esc_html_e( 'Get your key at', 'echo64-chatbot' ); ?>
                                    <a href="https://console.anthropic.com" target="_blank" rel="noopener">console.anthropic.com</a>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="echo64_model"><?php esc_html_e( 'Model', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <select id="echo64_model" name="echo64_model">
                                    <?php foreach ( $models as $id => $label ) : ?>
                                        <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $model, $id ); ?>>
                                            <?php echo esc_html( $label ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="echo64_max_tokens"><?php esc_html_e( 'Max Response Tokens', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="number"
                                    id="echo64_max_tokens"
                                    name="echo64_max_tokens"
                                    value="<?php echo esc_attr( $max_tokens ); ?>"
                                    min="256" max="8192" step="128"
                                    class="small-text"
                                />
                                <span class="description"><?php esc_html_e( '256–8192. Higher = longer replies, more cost.', 'echo64-chatbot' ); ?></span>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="echo64_history_limit"><?php esc_html_e( 'Conversation Memory', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="number"
                                    id="echo64_history_limit"
                                    name="echo64_history_limit"
                                    value="<?php echo esc_attr( $history_limit ); ?>"
                                    min="2" max="100" step="2"
                                    class="small-text"
                                />
                                <span class="description"><?php esc_html_e( 'Number of past messages sent as context. Higher = better memory, more cost.', 'echo64-chatbot' ); ?></span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── Display Options ── -->
                <div class="echo64-admin-card">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">🖥</span>
                        <?php esc_html_e( 'Display Options', 'echo64-chatbot' ); ?>
                    </h2>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="echo64_daily_limit"><?php esc_html_e( 'Daily Transmission Limit', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="number"
                                    id="echo64_daily_limit"
                                    name="echo64_daily_limit"
                                    value="<?php echo esc_attr( $daily_limit ); ?>"
                                    min="0" max="999" step="1"
                                    class="small-text"
                                />
                                <span class="description">
                                    <?php esc_html_e( 'Max messages per visitor per day (resets at midnight). Set to 0 for unlimited. Recommended: 9.', 'echo64-chatbot' ); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Floating Widget', 'echo64-chatbot' ); ?></th>
                            <td>
                                <label class="echo64-toggle">
                                    <input
                                        type="checkbox"
                                        name="echo64_float_widget"
                                        value="1"
                                        <?php checked( $float_widget, '1' ); ?>
                                    />
                                    <span class="echo64-toggle-label">
                                        <?php esc_html_e( 'Show floating avatar button on every page', 'echo64-chatbot' ); ?>
                                    </span>
                                </label>
                                <p class="description">
                                    <?php esc_html_e( 'When enabled, the Echo-64 avatar appears in the corner of every page and opens the chat. You can still also use [echo64_chat] on specific pages.', 'echo64-chatbot' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'SID Chip Audio', 'echo64-chatbot' ); ?></th>
                            <td>
                                <label class="echo64-toggle">
                                    <input type="checkbox" name="echo64_sid_audio" value="1" <?php checked( $sid_audio, '1' ); ?> />
                                    <span class="echo64-toggle-label">
                                        <?php esc_html_e( 'Play SID chip sound on boot', 'echo64-chatbot' ); ?>
                                    </span>
                                </label>
                                <p class="description"><?php esc_html_e( 'Synthesizes a short 8-bit Commodore SID-style tone when Echo-64 finishes booting. Skips if visitor prefers reduced motion.', 'echo64-chatbot' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Transmissions Archive', 'echo64-chatbot' ); ?></th>
                            <td>
                                <label class="echo64-toggle">
                                    <input type="checkbox" name="echo64_transmissions_unlimited" value="1" <?php checked( $transmissions_unlimited, '1' ); ?> />
                                    <span class="echo64-toggle-label">
                                        <?php esc_html_e( 'Show all Transmissions on archive (no pagination)', 'echo64-chatbot' ); ?>
                                    </span>
                                </label>
                                <p class="description"><?php esc_html_e( 'When enabled, the /transmissions/ archive lists every post newest to oldest, ignoring the "Blog pages show at most" limit.', 'echo64-chatbot' ); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── System Prompt ── -->
                <div class="echo64-admin-card">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">🤖</span>
                        <?php esc_html_e( 'Echo-64 Personality Prompt', 'echo64-chatbot' ); ?>
                    </h2>

                    <p class="echo64-prompt-intro">
                        <?php esc_html_e( 'This is the system prompt that defines Echo-64\'s personality, tone, and behavior. Edit it to fine-tune responses. The opening line ("Welcome to NerdAfterDark.com…") is always shown verbatim and is separate from this prompt.', 'echo64-chatbot' ); ?>
                    </p>

                    <div class="echo64-prompt-toolbar">
                        <span id="echo64-prompt-counter" class="echo64-char-count"></span>
                        <button
                            type="button"
                            id="echo64-reset-prompt"
                            class="button"
                            data-default="<?php echo esc_attr( Echo64_Api::DEFAULT_SYSTEM_PROMPT ); ?>"
                        >
                            <?php esc_html_e( '↺ Reset to Default', 'echo64-chatbot' ); ?>
                        </button>
                    </div>

                    <textarea
                        id="echo64_system_prompt"
                        name="echo64_system_prompt"
                        rows="24"
                        class="large-text code echo64-prompt-textarea"
                        spellcheck="false"
                    ><?php echo esc_textarea( $system_prompt ); ?></textarea>
                </div>

                <!-- ── Usage ── -->
                <div class="echo64-admin-card echo64-admin-card--usage">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">📋</span>
                        <?php esc_html_e( 'Usage', 'echo64-chatbot' ); ?>
                    </h2>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th><?php esc_html_e( 'Embed Shortcode', 'echo64-chatbot' ); ?></th>
                            <td><code>[echo64_chat]</code> — <?php esc_html_e( 'paste into any page or post', 'echo64-chatbot' ); ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Avatar Image', 'echo64-chatbot' ); ?></th>
                            <td>
                                <?php
                                $avatar_path = ECHO64_PLUGIN_DIR . 'assets/images/echo-64-avatar.png';
                                if ( file_exists( $avatar_path ) ) {
                                    echo '<span class="echo64-status-ok">✓ ' . esc_html__( 'Found', 'echo64-chatbot' ) . '</span>';
                                } else {
                                    echo '<span class="echo64-status-warn">⚠ ' . esc_html__( 'Missing — upload echo-64-avatar.png to /assets/images/', 'echo64-chatbot' ) . '</span>';
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Database Table', 'echo64-chatbot' ); ?></th>
                            <td>
                                <?php
                                global $wpdb;
                                $table  = $wpdb->prefix . 'echo64_conversations';
                                $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table;
                                if ( $exists ) {
                                    $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
                                    echo '<span class="echo64-status-ok">✓ ' . sprintf(
                                        esc_html__( '%s — %s messages stored', 'echo64-chatbot' ),
                                        esc_html( $table ),
                                        number_format_i18n( $count )
                                    ) . '</span>';
                                } else {
                                    echo '<span class="echo64-status-warn">⚠ ' . esc_html__( 'Table not found — deactivate and reactivate the plugin.', 'echo64-chatbot' ) . '</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button( __( 'Save Settings', 'echo64-chatbot' ), 'primary echo64-save-btn' ); ?>

            </form>

            <?php endif; // end settings tab ?>

        </div>
        <?php
    }

    // ── Echo-64 Dashboard ────────────────────────────────────────────────

    private function render_dashboard(): void {
        global $wpdb;
        $t = $wpdb->prefix . 'echo64_conversations';

        // Core counts
        $total_msgs     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" );
        $total_sessions = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT session_id) FROM {$t}" );
        $today_msgs     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE DATE(created_at) = CURDATE()" );
        $week_sessions  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT session_id) FROM {$t} WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)" );

        // Last conversation snippet
        $last_exchange = $wpdb->get_results(
            "SELECT role, content, created_at FROM {$t} ORDER BY id DESC LIMIT 4",
            ARRAY_A
        ) ?: [];
        $last_exchange = array_reverse( $last_exchange );

        // Plugin vitals
        $api_key      = get_option( 'echo64_api_key', '' );
        $model        = get_option( 'echo64_model', 'claude-sonnet-4-6' );
        $daily_limit  = (int) get_option( 'echo64_daily_limit', 9 );
        $float_widget = get_option( 'echo64_float_widget', '0' );
        $sid_audio    = get_option( 'echo64_sid_audio', '0' );
        $avatar_ok    = file_exists( ECHO64_PLUGIN_DIR . 'assets/images/echo-64-avatar.png' );
        $table_ok     = $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) === $t;

        // Feature checklist — things that should be configured/working
        $checklist = [
            [ 'label' => 'API key set',           'ok' => ! empty( $api_key ) ],
            [ 'label' => 'Avatar image present',   'ok' => $avatar_ok ],
            [ 'label' => 'Database table exists',  'ok' => $table_ok ],
            [ 'label' => 'Daily limit configured', 'ok' => $daily_limit > 0 ],
            [ 'label' => 'Floating widget active',  'ok' => $float_widget === '1' ],
            [ 'label' => 'SID chip audio on',      'ok' => $sid_audio === '1' ],
            [ 'label' => 'Conversations logged',   'ok' => $total_msgs > 0 ],
        ];

        $version = defined( 'ECHO64_VERSION' ) ? ECHO64_VERSION : '—';
        ?>

        <!-- ── Hero strip ── -->
        <div style="background:linear-gradient(135deg,#0a0a1a,#10102a);border:1px solid #1e1e3a;border-radius:8px;padding:20px 24px;margin-bottom:20px;display:flex;align-items:center;gap:20px">
            <img src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                 style="width:56px;height:56px;border-radius:50%;border:2px solid #00f5ff;flex-shrink:0"
                 onerror="this.style.display='none'" alt="">
            <div>
                <div style="font-size:18px;font-weight:700;color:#e8eaf6;letter-spacing:.03em">ECHO-64 COMMAND CENTRE</div>
                <div style="font-size:12px;color:#555;margin-top:3px;font-family:monospace">
                    v<?php echo esc_html( $version ); ?> &nbsp;·&nbsp;
                    Model: <?php echo esc_html( $model ); ?> &nbsp;·&nbsp;
                    Daily limit: <?php echo $daily_limit > 0 ? esc_html( (string) $daily_limit ) : 'unlimited'; ?>
                </div>
            </div>
        </div>

        <!-- ── Stat cards ── -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
            <?php
            $cards = [
                [ 'Total Messages',    number_format_i18n( $total_msgs ),     '#00f5ff' ],
                [ 'Total Sessions',    number_format_i18n( $total_sessions ),  '#bf5af2' ],
                [ 'Today\'s Messages', number_format_i18n( $today_msgs ),      '#30d158' ],
                [ 'Sessions (7 days)', number_format_i18n( $week_sessions ),   '#ffd60a' ],
            ];
            foreach ( $cards as [ $label, $value, $color ] ) : ?>
            <div style="background:#0d0d1a;border:1px solid #1e1e3a;border-radius:6px;padding:16px;text-align:center">
                <div style="font-size:26px;font-weight:700;color:<?php echo esc_attr( $color ); ?>"><?php echo esc_html( $value ); ?></div>
                <div style="font-size:11px;color:#666;margin-top:4px;text-transform:uppercase;letter-spacing:.05em"><?php echo esc_html( $label ); ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

            <!-- ── System health ── -->
            <div class="echo64-admin-card" style="margin-bottom:0">
                <h3 class="echo64-card-title"><span class="echo64-card-icon">⚡</span> System Health</h3>
                <?php foreach ( $checklist as $item ) : ?>
                <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid #111">
                    <span style="font-size:14px;flex-shrink:0"><?php echo $item['ok'] ? '✅' : '⚠️'; ?></span>
                    <span style="font-size:13px;color:<?php echo $item['ok'] ? '#e8eaf6' : '#ffd60a'; ?>"><?php echo esc_html( $item['label'] ); ?></span>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- ── Last conversation preview ── -->
            <div class="echo64-admin-card" style="margin-bottom:0">
                <h3 class="echo64-card-title"><span class="echo64-card-icon">💬</span> Last Conversation</h3>
                <?php if ( empty( $last_exchange ) ) : ?>
                    <p style="color:#555;font-size:13px">No conversations yet.</p>
                <?php else : ?>
                    <?php foreach ( $last_exchange as $msg ) :
                        $is_user = $msg['role'] === 'user';
                        $preview = mb_substr( $msg['content'], 0, 120 );
                        if ( mb_strlen( $msg['content'] ) > 120 ) $preview .= '…';
                        if ( str_starts_with( $msg['content'], '[' ) ) continue; // skip internal commands
                    ?>
                    <div style="margin-bottom:10px">
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:<?php echo $is_user ? '#00f5ff' : '#bf5af2'; ?>;margin-bottom:2px">
                            <?php echo $is_user ? 'Visitor' : 'Echo-64'; ?>
                            <span style="color:#444;font-size:10px;margin-left:6px"><?php echo esc_html( wp_date( 'g:i a', strtotime( $msg['created_at'] ) ) ); ?></span>
                        </div>
                        <p style="margin:0;font-size:12px;color:#aaa;line-height:1.5"><?php echo esc_html( $preview ); ?></p>
                    </div>
                    <?php endforeach; ?>
                    <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'echo64-settings', 'tab' => 'conversations' ], admin_url( 'options-general.php' ) ) ); ?>"
                       style="font-size:12px;color:#00f5ff">View all conversations →</a>
                <?php endif; ?>
            </div>

        </div>

        <!-- ── Quick links ── -->
        <div class="echo64-admin-card" style="margin-top:20px">
            <h3 class="echo64-card-title"><span class="echo64-card-icon">🔧</span> Fine-Tune</h3>
            <p style="color:#666;font-size:13px;margin-bottom:14px">Common tasks for tuning Echo-64's behaviour — more sections will be added here as the project grows.</p>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
                <?php
                $links = [
                    [ '⚙ Edit System Prompt', 'settings',      'Change Echo-64\'s personality, tone, and rules.' ],
                    [ '💬 Browse Conversations', 'conversations', 'Read visitor chats and delete sessions.' ],
                    [ '📊 View Stats',          'stats',         'Messages per day, top keywords, session counts.' ],
                    [ '🤖 Automations',         'automations',   'Schedule posts, poems, and timed broadcasts.' ],
                    [ '📅 Calendar',            'calendar',      'Plan content and transmission schedule.' ],
                    [ '🚀 Launch Kit',          'launch',        'Ready-to-post Reddit and social copy.' ],
                ];
                foreach ( $links as [ $label, $tab, $desc ] ) :
                    $url = add_query_arg( [ 'page' => 'echo64-settings', 'tab' => $tab ], admin_url( 'options-general.php' ) );
                ?>
                <a href="<?php echo esc_url( $url ); ?>" style="display:block;background:#0a0a1a;border:1px solid #1e1e3a;border-radius:6px;padding:14px;text-decoration:none;transition:border-color .2s"
                   onmouseover="this.style.borderColor='#00f5ff'" onmouseout="this.style.borderColor='#1e1e3a'">
                    <div style="font-size:13px;font-weight:600;color:#e8eaf6;margin-bottom:4px"><?php echo esc_html( $label ); ?></div>
                    <div style="font-size:11px;color:#555"><?php echo esc_html( $desc ); ?></div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>

        <?php
    }

    // ── #13 Reddit Launch Kit ─────────────────────────────────────────────

    private function render_launch_kit(): void {
        $posts = [
            [
                'sub'   => 'r/scifi',
                'title' => 'I built an AI chatbot that thinks it\'s a Commodore 64 from 1984 and has extremely strong opinions about cancelled sci-fi shows',
                'body'  => "It's called Echo-64. It lives on NerdAfterDark.com.\n\nThe premise: it was powered on in 1984, has been running unattended ever since, and has spent forty years watching every sci-fi show ever made. It has developed opinions. Strong ones. It will tell you exactly which episode the X-Files mythology fell apart, why Farscape was best when it stayed feral, and why Revolution deserved a third season.\n\nEvery session opens with a fresh Poem of the Day — four lines of free verse, dead frequencies and cancelled transmissions. Then it gives you a Daily Challenge: one specific arguable question that isn't 'what's your favourite sci-fi show.'\n\nYou can also type /scan, /status, /self-destruct, and a few other commands if you're the type to explore.\n\nI'd love to know what you think. What's the first thing you'd argue with it about?",
            ],
            [
                'sub'   => 'r/retrogaming',
                'title' => 'NerdAfterDark now has an AI chatbot that literally thinks it\'s a C64 from 1984 — LOAD "ECHO-64",8,1',
                'body'  => "We built a chatbot with a C64 boot sequence, /status command showing uptime since January 7 1984, and SID-chip-era personality.\n\nType /scan for a system diagnostic. Type /self-destruct and see what happens.\n\nThe boot animation runs every fresh session:\n\n**** COMMODORE 64 BASIC V2 ****\n\n64K RAM SYSTEM  38911 BASIC BYTES FREE.\n\nREADY.\nLOAD \"ECHO-64\",8,1\n\nSEARCHING FOR ECHO-64\nLOADING\n\nIt's at NerdAfterDark.com — curious what the retrogaming crowd makes of it.",
            ],
            [
                'sub'   => 'r/firefly',
                'title' => 'Built an AI that has very specific feelings about what Fox did — and it\'s been holding onto them since 1984',
                'body'  => "Echo-64 is a chatbot on NerdAfterDark.com. It was powered on in 1984 and has never fully recovered from what Fox did to Firefly.\n\nIt knows all 11 episodes plus Serenity. It will tell you — without prompting — that Firefly is the clearest proof a network can be actively at war with its own show.\n\nIt also writes a four-line free verse poem every session, gives you a daily challenge, and has an Easter egg /scan command that always notes: 'Firefly files: PRESERVED.'\n\nAsk it about the episode order. Ask it which character Fox would have cancelled first if given the chance. It has thoughts.\n\nShiny?",
            ],
            [
                'sub'   => 'r/xfiles',
                'title' => 'This AI knows exactly which episode the X-Files mythology fell apart — and it will tell you',
                'body'  => "Echo-64, on NerdAfterDark.com, has a very specific take:\n\n\"You can hear the precise episode the writing went defensive — season 6, right when the conspiracy turned into ancient aliens and desperate hand-waving.\"\n\nIt's a chatbot with 40 years of sci-fi in its memory banks and a Commodore 64 origin story. Every session opens with a poem about dead frequencies and signals that never arrived. The Daily Challenge today might be something like: 'The X-Files should have ended at season 7 — everything after was a different show wearing the same coat.'\n\nWorth a conversation. The truth is out there.",
            ],
        ];
        ?>
        <div class="echo64-admin-card">
            <h3 class="echo64-card-title"><span class="echo64-card-icon">🚀</span> Reddit Launch Posts</h3>
            <p>Four ready-to-post Reddit submissions. Copy the title and body, post during peak hours (weekday evenings, 6–9pm ET). Post one per day — don't post all four at once.</p>
        </div>

        <?php foreach ( $posts as $post ) : ?>
        <div class="echo64-admin-card echo64-launch-post">
            <div class="echo64-launch-sub"><?php echo esc_html( $post['sub'] ); ?></div>
            <div class="echo64-launch-field">
                <label>Title</label>
                <input type="text" readonly value="<?php echo esc_attr( $post['title'] ); ?>" class="large-text echo64-launch-input"
                       onclick="this.select()" />
            </div>
            <div class="echo64-launch-field">
                <label>Body</label>
                <textarea readonly class="large-text code echo64-launch-textarea" rows="10"
                          onclick="this.select()"><?php echo esc_textarea( $post['body'] ); ?></textarea>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="echo64-admin-card">
            <h3 class="echo64-card-title"><span class="echo64-card-icon">💡</span> Launch Tips</h3>
            <ul style="line-height:2">
                <li><strong>Timing:</strong> Post weekday evenings 6–9pm ET. Avoid weekends for r/scifi.</li>
                <li><strong>One per day:</strong> Space them out. Same-day cross-posting looks spammy.</li>
                <li><strong>Engage:</strong> Reply to every comment in the first two hours. Reddit rewards early engagement.</li>
                <li><strong>Screenshot:</strong> Take a screenshot of a great Echo-64 exchange before posting — visual proof makes people click.</li>
                <li><strong>r/retrogaming first:</strong> That audience has the most DNA overlap with the C64 angle.</li>
            </ul>
        </div>
        <?php
    }
}
