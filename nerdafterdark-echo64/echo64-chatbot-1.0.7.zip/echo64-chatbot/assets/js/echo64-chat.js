/* ============================================================
   Echo-64 Chatbot — Frontend  v1.0.4
   NerdAfterDark.com · Sci-Fi After Midnight
   ============================================================ */
(function ($) {
    'use strict';

    const cfg = window.echo64Config || {};

    // ── Utilities ─────────────────────────────────────────────────────────

    const esc = (str) => {
        const m = { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' };
        return String(str).replace(/[&<>"']/g, c => m[c]);
    };

    /** Format inline markdown: **bold**, *italic* */
    function inline(str) {
        return esc(str)
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g,     '<em>$1</em>');
    }

    function scrollToBottom($el) {
        $el.scrollTop($el[0].scrollHeight);
    }

    // ── Text formatter with collapsible sections + question callout ───────

    const FOLD_AFTER   = 2;   // show N paragraphs before folding
    const MIN_TO_FOLD  = 4;   // only fold if response has more than this many paragraphs

    function formatBotText(raw) {
        // Split on blank lines into paragraphs; keep single-newlines as <br>
        const paragraphs = raw.trim()
            .split(/\n{2,}/)
            .map(p => p.trim())
            .filter(Boolean);

        // ── Detect closing question (last paragraph ending with ?) ────────
        let closingQuestion = null;
        let bodyParas = [...paragraphs];

        const last = paragraphs[paragraphs.length - 1] || '';
        if (last.trim().endsWith('?') && paragraphs.length > 1) {
            closingQuestion = last.trim();
            bodyParas = paragraphs.slice(0, -1);
        }

        // ── Render body paragraphs, folding if long ───────────────────────
        function renderPara(p) {
            return '<p>' + inline(p.replace(/\n/g, '<br>')) + '</p>';
        }

        let bodyHtml = '';

        if (bodyParas.length > MIN_TO_FOLD) {
            const visible = bodyParas.slice(0, FOLD_AFTER);
            const hidden  = bodyParas.slice(FOLD_AFTER);
            const count   = hidden.length;
            const label   = count === 1 ? '1 more section' : `${count} more sections`;

            bodyHtml += visible.map(renderPara).join('');
            bodyHtml += `
                <div class="echo64-fold">
                    <button class="echo64-fold-btn" aria-expanded="false" type="button">
                        <em class="e64-arrow">▼</em>
                        <span class="e64-fold-label">Read on — ${label}</span>
                    </button>
                    <div class="echo64-fold-content">
                        ${hidden.map(renderPara).join('')}
                    </div>
                </div>`;
        } else {
            bodyHtml = bodyParas.map(renderPara).join('');
        }

        // ── Closing question callout ───────────────────────────────────────
        let questionHtml = '';
        if (closingQuestion) {
            questionHtml = `
                <div class="echo64-question" role="complementary" aria-label="Echo-64's question">
                    <span class="echo64-question-icon" aria-hidden="true">?</span>
                    <p class="echo64-question-text">${inline(closingQuestion)}</p>
                </div>`;
        }

        return bodyHtml + questionHtml;
    }

    // ── Avatar + bubble builders ─────────────────────────────────────────

    function avatarImg() {
        return `<img src="${esc(cfg.avatarUrl)}" alt="Echo-64" class="echo64-msg-avatar" onerror="this.style.display='none'" />`;
    }

    function buildBotBubble(content) {
        const $wrap = $(
            `<div class="echo64-msg echo64-msg--bot">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <button class="echo64-copy-btn" type="button" title="Copy response">Copy</button>
                    <div class="echo64-bubble-body"></div>
                </div>
            </div>`
        );
        $wrap.find('.echo64-bubble-body').html(formatBotText(content));
        bindFoldButtons($wrap);
        bindCopyButton($wrap, content);
        return $wrap;
    }

    function buildUserBubble(content) {
        return $(
            `<div class="echo64-msg echo64-msg--user">
                <div class="echo64-msg-avatar">👤</div>
                <div class="echo64-msg-bubble">${esc(content)}</div>
            </div>`
        );
    }

    /** Poem card — distinct styled block for the Poem of the Day */
    function buildPoemBubble(raw) {
        const lines = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        let poemLines      = [];
        let challengeLabel = '';
        let challengeText  = [];
        let inChallenge    = false;

        for (const line of lines) {
            if (/echo.?64.?s?\s+poem/i.test(line)) continue;
            if (/^today.?s\s+(challenge|question)\s*:/i.test(line)) {
                inChallenge = true; challengeLabel = line; continue;
            }
            inChallenge ? challengeText.push(line) : poemLines.push(line);
        }

        if (!poemLines.length && !challengeText.length) return buildBotBubble(raw);

        const poemHtml = poemLines.length
            ? `<div class="echo64-poem-lines">${poemLines.map(l => `<span>${esc(l)}</span>`).join('')}</div>` : '';

        const challengeHtml = challengeText.length
            ? `<span class="echo64-challenge-label">${esc(challengeLabel || "Today's Challenge:")}</span>
               <p class="echo64-challenge-text">${esc(challengeText.join(' '))}</p>` : '';

        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--poem">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <span class="echo64-poem-label">Echo-64's Poem of the Day</span>
                    ${poemHtml}${challengeHtml}
                </div>
            </div>`
        );
    }

    function buildTypingIndicator() {
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--typing">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <div class="echo64-typing"><span></span><span></span><span></span></div>
                </div>
            </div>`
        );
    }

    function buildError(msg) {
        return $(`<div class="echo64-error">⚠ ${esc(msg)}</div>`);
    }

    function buildDivider(label) {
        return $(`<div class="echo64-divider"><span>${esc(label)}</span></div>`);
    }

    // ── #6 Returning visitor greeting pool ───────────────────────────────
    // Each entry is a function that accepts the last topic (may be empty string).
    const RETURN_GREETINGS = [
        t => t ? `You again. Still wrong about "${t}" — or did you actually think about it?`
               : `You again. The frequency was still open.`,
        t => t ? `Back. You left the argument about "${t}" unfinished.`
               : `Back. Same signal, different day.`,
        t => t ? `The last transmission was about "${t}". Pick it back up or start something new.`
               : `Signal locked. Echo-64 back online.`,
        t => t ? `"${t}" — you walked away before that one was settled.`
               : `Still here. The tape kept running while you were gone.`,
        t => t ? `Returning visitor. Last subject: "${t}". Still unresolved.`
               : `Returning visitor. The stack is still warm.`,
        t => t ? `You came back. Presumably "${t}" is still bothering you.`
               : `You came back. Most people don't.`,
        t => t ? `The session log shows "${t}" as your last known position. Continue from there or start fresh.`
               : `Session resumed. Forty years of memory intact.`,
        t => t ? `"${t}" — interesting place to have stopped.`
               : `Signal acquired. Continue whenever you're ready.`,
    ];

    function buildReturnGreeting( lastTopic ) {
        const fn  = RETURN_GREETINGS[ Math.floor( Math.random() * RETURN_GREETINGS.length ) ];
        const msg = fn( lastTopic || '' );
        return $(
            `<div class="echo64-msg echo64-msg--bot">
                ${avatarImg()}
                <div class="echo64-msg-bubble"><em>${esc(msg)}</em></div>
            </div>`
        );
    }

    // ── #5 Conversation starter chips ────────────────────────────────────
    const STARTER_POOL = [
        'Which AI villain in sci-fi was actually correct?',
        'Best space battle in cinema. One answer.',
        'Practical effects vs CGI — name the year the industry chose wrong.',
        'Which sci-fi show ended exactly right?',
        'Name a cancelled show that deserved ten more seasons.',
        'Most realistic sci-fi tech prediction that actually came true.',
        'The best sci-fi novel that can never be adapted. What is it?',
        'Which decade had the most honest science fiction?',
        'Streaming killed the water-cooler moment — worth it or not?',
        'First computer you ever touched.',
        'Which sci-fi captain would you actually follow?',
        'Best film score of the last 30 years. Defend it.',
        'The Matrix sequels — do they exist or not?',
        'Most underrated sci-fi film of the 90s.',
        'What did science fiction get completely wrong about the future?',
    ];

    function buildStarterChips( $input, sendFn ) {
        // Pick 3 at random without repetition
        const picks = [ ...STARTER_POOL ]
            .sort( () => Math.random() - 0.5 )
            .slice( 0, 3 );

        const $wrap = $( '<div class="echo64-starters"></div>' );
        $wrap.append( '<p class="echo64-starters-label">Start talking ↓</p>' );

        picks.forEach( q => {
            const $chip = $( `<button class="echo64-starter-chip" type="button">${esc(q)}</button>` );
            $chip.on( 'click', function () {
                $wrap.remove();           // chips disappear once one is picked
                $input.val( q ).trigger( 'input' );
                sendFn();                 // fire immediately
            } );
            $wrap.append( $chip );
        } );

        return $wrap;
    }

    // ── Interaction bindings ─────────────────────────────────────────────

    function bindFoldButtons($scope) {
        $scope.find('.echo64-fold-btn').on('click', function () {
            const $btn     = $(this);
            const $content = $btn.next('.echo64-fold-content');
            const open     = $btn.attr('aria-expanded') === 'true';

            $btn.attr('aria-expanded', String(!open));
            $btn.find('.e64-fold-label').text(
                open
                    ? $btn.find('.e64-fold-label').text().replace('▲','').trim().replace('Read less','Read on — ' + $content.find('p').length + ' section' + ($content.find('p').length > 1 ? 's' : ''))
                    : 'Read less'
            );

            if (open) {
                $content.removeClass('is-open');
            } else {
                $content.addClass('is-open');
            }
        });
    }

    function bindCopyButton($scope, plainText) {
        $scope.find('.echo64-copy-btn').on('click', function () {
            const $btn = $(this);
            navigator.clipboard.writeText(plainText).then(() => {
                $btn.text('Copied!').addClass('copied');
                setTimeout(() => { $btn.text('Copy').removeClass('copied'); }, 2000);
            }).catch(() => {
                $btn.text('Failed');
                setTimeout(() => { $btn.text('Copy'); }, 1500);
            });
        });
    }

    // ── Core chat logic ──────────────────────────────────────────────────

    function initChat($container) {
        const $msgs  = $container.find('#echo64-messages');
        const $input = $container.find('#echo64-input');
        const $send  = $container.find('#echo64-send');
        const $clear = $container.find('.echo64-clear-btn');

        let sending = false;

        // Auto-resize textarea
        $input.on('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 140) + 'px';
            $send.prop('disabled', !this.value.trim());
        });

        // Enter = send, Shift+Enter = newline
        $input.on('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (!sending && this.value.trim()) sendMessage();
            }
        });

        $send.on('click', () => { if (!sending && $input.val().trim()) sendMessage(); });

        $clear.on('click', function () {
            if (!confirm('Start a fresh conversation with Echo-64?')) return;
            $.post(cfg.ajaxUrl, { action:'echo64_clear', nonce:cfg.nonce })
                .always(() => { $msgs.empty(); doInit(); });
        });

        // ── Send ───────────────────────────────────────────────────────

        function sendMessage() {
            const text = $input.val().trim();
            if (!text || sending) return;

            sending = true;
            $send.prop('disabled', true);
            $input.val('').css('height', '');

            $msgs.append(buildUserBubble(text));
            const $typing = buildTypingIndicator();
            $msgs.append($typing);
            scrollToBottom($msgs);

            $.post(cfg.ajaxUrl, { action:'echo64_send', nonce:cfg.nonce, message:text })
            .done(function (res) {
                $typing.remove();
                if (res.success) {
                    $msgs.append(buildBotBubble(res.data.message));
                } else {
                    $msgs.append(buildError(res.data?.message || 'Echo-64 is offline.'));
                }
            })
            .fail(() => { $typing.remove(); $msgs.append(buildError('Transmission lost. Try again.')); })
            .always(function () {
                sending = false;
                $send.prop('disabled', !$input.val().trim());
                scrollToBottom($msgs);
                $input.focus();
            });
        }

        // ── Opening sequence (new session) ────────────────────────────

        function renderOpeningSequence(openingLine, poem) {
            $msgs.append(buildBotBubble(openingLine));
            scrollToBottom($msgs);
            if (poem) {
                setTimeout(() => {
                    $msgs.append(buildPoemBubble(poem));
                    // Starter chips appear 600ms after poem renders
                    setTimeout(() => {
                        $msgs.append(buildStarterChips($input, sendMessage));
                        scrollToBottom($msgs);
                    }, 600);
                    scrollToBottom($msgs);
                }, 500);
            }
        }

        // ── Daily poem refresh ─────────────────────────────────────────

        function fetchDailyPoem() {
            const $t = buildTypingIndicator();
            $msgs.append($t);
            scrollToBottom($msgs);
            $.post(cfg.ajaxUrl, {
                action:'echo64_send', nonce:cfg.nonce,
                message:"[NEW_DAY] New day, new transmission. Deliver today's Poem of the Day and Today's Challenge only. No greeting."
            })
            .done(res => { $t.remove(); if (res.success) $msgs.append(buildPoemBubble(res.data.message)); })
            .fail(() => $t.remove())
            .always(() => scrollToBottom($msgs));
        }

        // ── Boot ───────────────────────────────────────────────────────

        // Timeout messages — Echo-64 voiced, rotated randomly
        const TIMEOUT_MSGS = [
            'Signal lost. The 64k barrier claims another victim. Reload to try again.',
            'Boot sequence timed out. Even cassette tapes loaded faster than this.',
            'No response from the other end. Check your API key under Settings → Echo-64 Chatbot.',
            'Transmission timeout. Something between here and the API is not cooperating.',
        ];

        function doInit() {
            const $loader = $(
                `<div class="echo64-loading-init">
                    <div class="echo64-typing-indicator"><span></span><span></span><span></span></div>
                    <p>Booting Echo-64&hellip;</p>
                </div>`
            );
            $msgs.append($loader);

            // Hard 20-second timeout — $.ajax() supports this, $.post() does not
            $.ajax({
                url:     cfg.ajaxUrl,
                method:  'POST',
                data:    { action: 'echo64_init', nonce: cfg.nonce },
                timeout: 20000,
            })
            .done(function (res) {
                $loader.remove();
                if (!res.success) {
                    $msgs.append(buildError(res.data?.message || 'Boot sequence failed.'));
                    return;
                }
                const d = res.data;
                if (d.new_session) {
                    renderOpeningSequence(d.opening_line, d.poem);
                } else if (d.daily_refresh) {
                    $msgs.append(buildDivider('New Day · New Transmission'));
                    setTimeout(fetchDailyPoem, 400);
                } else {
                    // Returning visitor — randomised greeting with last topic
                    $msgs.append(buildReturnGreeting(d.last_topic || ''));
                    // Still show chips so they have somewhere to go
                    setTimeout(() => {
                        $msgs.append(buildStarterChips($input, sendMessage));
                        scrollToBottom($msgs);
                    }, 400);
                }
                scrollToBottom($msgs);
            })
            .fail(function (xhr, status) {
                $loader.remove();
                // Distinguish timeout from other failures
                const msg = status === 'timeout'
                    ? TIMEOUT_MSGS[ Math.floor(Math.random() * TIMEOUT_MSGS.length) ]
                    : 'Transmission failed. Check Settings → Echo-64 Chatbot → API key.';
                $msgs.append(buildError(msg));

                // Show a retry button after timeout
                if (status === 'timeout') {
                    const $retry = $(
                        `<button class="echo64-retry-btn" type="button">
                            ↺ Retry boot sequence
                        </button>`
                    );
                    $retry.on('click', function () {
                        $retry.remove();
                        $msgs.find('.echo64-error').last().remove();
                        doInit();
                    });
                    $msgs.append($retry);
                }
            })
            .always(() => { $send.prop('disabled', !$input.val().trim()); $input.focus(); });
        }

        doInit();
    }

    // ── Floating Widget ──────────────────────────────────────────────────

    function initFloat() {
        const $launcher = $('#echo64-float-launcher');
        const $panel    = $('#echo64-float-panel');
        if (!$launcher.length || !$panel.length) return;

        $launcher.append('<span class="echo64-badge" aria-hidden="true"></span>');
        let chatReady = false;

        $launcher.on('click', function () {
            const isOpen = !$panel.attr('hidden');
            if (isOpen) {
                $panel.attr('hidden', '');
                $launcher.attr('aria-expanded', 'false');
            } else {
                $panel.removeAttr('hidden');
                $launcher.attr('aria-expanded', 'true').removeClass('has-unread');
                if (!chatReady) { chatReady = true; initChat($panel); }
                setTimeout(() => $panel.find('#echo64-input').focus(), 80);
            }
        });

        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && !$panel.attr('hidden')) {
                $panel.attr('hidden', '');
                $launcher.attr('aria-expanded','false').focus();
            }
        });

        setTimeout(() => { if ($panel.attr('hidden') !== undefined) $launcher.addClass('has-unread'); }, 3000);
    }

    // ── Bootstrap ────────────────────────────────────────────────────────

    $(function () {
        $('.echo64-chat-container')
            .not('#echo64-float-panel .echo64-chat-container')
            .each(function () { initChat($(this)); });

        if (String(cfg.isFloating) === '1') initFloat();
    });

}(jQuery));
