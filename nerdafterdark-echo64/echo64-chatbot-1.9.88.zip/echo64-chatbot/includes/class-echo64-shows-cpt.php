<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

final class Echo64_Shows_CPT {

    const POST_TYPE = 'echo64_show';

    private static ?Echo64_Shows_CPT $instance = null;

    private static array $questions = [
        '%s — why was it cancelled and why does it still hurt?',
        'Make the case for %s. Convince me it deserved ten more seasons.',
        'Which network executive cancelled %s and do they still have a job?',
        '%s got cancelled. Tell me everything that went wrong.',
        'Defend %s like your life depends on it.',
        'What would %s look like if it had never been cancelled?',
        'Rank the crimes committed against %s by the network that cancelled it.',
        'Give me the full post-mortem on %s. What killed it?',
        'If %s came back today, would it survive? Be honest.',
        'The people who cancelled %s — where are they now and do they feel bad?',
    ];

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init',                [ $this, 'register_post_type' ] );
        add_action( 'init',                [ $this, 'maybe_migrate' ], 20 );
        add_action( 'init',                [ $this, 'maybe_upgrade_content' ], 25 );
        add_action( 'add_meta_boxes',      [ $this, 'add_meta_boxes' ] );
        add_action( 'save_post',           [ $this, 'save_meta' ] );
        add_filter( 'template_include',    [ $this, 'single_template' ] );
        add_action( 'wp_head',             [ $this, 'render_seo_meta' ], 1 );
        add_filter( 'document_title_parts',[ $this, 'filter_document_title' ] );
        add_filter( 'manage_' . self::POST_TYPE . '_posts_columns',       [ $this, 'admin_columns' ] );
        add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', [ $this, 'render_admin_column' ], 10, 2 );
    }

    public function register_post_type(): void {
        register_post_type( self::POST_TYPE, [
            'labels' => [
                'name'               => 'Cancelled Shows',
                'singular_name'      => 'Cancelled Show',
                'add_new_item'       => 'Add Cancelled Show',
                'edit_item'          => 'Edit Cancelled Show',
                'all_items'          => 'Cancelled Shows',
                'menu_name'          => 'Cancelled Shows',
            ],
            'public'        => true,
            'has_archive'   => false,
            'show_in_rest'  => true,
            'menu_icon'     => 'dashicons-desktop',
            'supports'      => [ 'title', 'editor' ],
            'rewrite'       => [ 'slug' => 'cancelled-shows', 'with_front' => false ],
        ] );
    }

    public static function build_question( string $title ): string {
        $template = self::$questions[ array_rand( self::$questions ) ];
        return sprintf( $template, $title );
    }

    // ── One-time migration of the legacy hardcoded array into real posts ──────

    public function maybe_migrate(): void {
        if ( get_option( 'echo64_shows_migrated' ) === 'yes' ) {
            return;
        }

        $shows = $this->legacy_shows();

        foreach ( $shows as $show ) {
            $existing = get_page_by_title( $show['title'], OBJECT, self::POST_TYPE );
            if ( $existing ) continue;

            $post_id = wp_insert_post( [
                'post_type'    => self::POST_TYPE,
                'post_title'   => $show['title'],
                'post_content' => $show['verdict'],
                'post_status'  => 'publish',
            ] );

            if ( $post_id && ! is_wp_error( $post_id ) ) {
                update_post_meta( $post_id, '_echo64_network', $show['network'] );
                update_post_meta( $post_id, '_echo64_year',    $show['year'] );
            }
        }

        update_option( 'echo64_shows_migrated', 'yes' );
        flush_rewrite_rules();
    }

    // ── Upgrade: replace one-liner verdicts with full page copy for top shows ──

    public function maybe_upgrade_content(): void {
        if ( get_option( 'echo64_shows_content_v2' ) === 'yes' ) return;

        $upgrades = [
            'Firefly' => "Fourteen episodes. One complete universe — characters, language, mythology, moral philosophy — all of it built and destroyed in less time than most shows take to find their footing. Fox scheduled it against the World Series, aired the episodes out of order, and pulled it before it could build an audience. The executives called it underperforming. Forty years of television history would like a word.\n\nThe fans built a movement loud enough to fund a feature film. Serenity arrived in 2005 and answered some of what was left unfinished. It was not enough. It was never going to be enough. Some cancellations are inconveniences. Firefly was a crime.\n\nJoss Whedon has said he still doesn't know how the story ends. That's the part that's unforgivable — not the cancellation itself, but the waste of something that was already complete in every way that mattered except the one the network controlled.",

            'Freaks and Geeks' => "Eighteen episodes produced. Twelve aired before NBC pulled it. The complete season eventually aired on Fox Family — a network that had nothing to do with making it — just to let the remaining episodes exist somewhere. That is how little NBC understood what it had.\n\nThe cast includes James Franco, Seth Rogen, Jason Segel, Linda Cardellini, and John Francis Daley. The creator is Judd Apatow. The showrunner is Paul Feig. Every name on that list became a major force in Hollywood within ten years of cancellation. NBC passed.\n\nIt is the most honest show about high school ever made. Not aspirational. Not dramatic. Just accurate in the way that made uncomfortable viewing for anyone who remembered what fifteen actually felt like. That's probably why it was cancelled.",

            'Deadwood' => "Three seasons of the finest dialogue ever written for television. David Milch constructed a world where every character — from the protagonist to the extras drinking in the background — spoke with specificity and weight. Then HBO cancelled it on a cliffhanger because the contracts ran out and nobody could get the numbers to work.\n\nThe show finally got a movie in 2019. It was good. It was not enough. The story promised across three seasons and a dozen character arcs deserved more than a two-hour wrap-up twelve years later. Al Swearengen deserved a proper ending. The audience deserved one too.\n\nThe cancellation of Deadwood is the clearest example on television of a network signing off on a story without committing to letting it be told. The obligation runs both ways. HBO forgot that.",

            'Pushing Daisies' => "Bryan Fuller created a show where a pie-maker could bring the dead back to life with a touch — but a second touch would kill them again permanently, and if he held them alive for more than a minute, someone nearby would die in their place. The rules were precise. The world built around them was impeccable. The colour palette alone was worth watching.\n\nThe writers' strike hit mid-season one. By the time production resumed, the audience had scattered and ABC never properly rebuilt it. Season two got nine episodes before cancellation. The story was not finished. It has never been finished.\n\nA musical revival has been rumoured for years. It hasn't happened. In the meantime, Pushing Daisies remains the most visually distinctive show in network television history that never got to complete its story.",

            'My So-Called Life' => "One season. Nineteen episodes. The most honest portrait of adolescence American television had produced at that point — not the after-school special version, not the aspirational version, but the actual experience of being fifteen and not knowing how anything works including yourself.\n\nClaire Danes was extraordinary. The writing didn't condescend. Characters lied, misunderstood each other, acted from confusion rather than clear motivation. It was realistic in a way that felt radical for 1995 and still feels rare now.\n\nABC cancelled it because the ratings were low. The ratings were low because it aired opposite Seinfeld and Home Improvement. That context tends to be left out of the official story. The full sentence matters.",

            'Sense8' => "Eight characters. Eight cities. A production budget large enough to actually film in all of them. Netflix cancelled it after two seasons and the response was loud enough that they funded a two-hour finale — a thing that almost never happens. The finale happened. It was not enough of an ending.\n\nThe Wachowskis built something that couldn't be summarised in a pitch. That is both why it was brilliant and why Netflix eventually said no. Streaming services need to be able to describe what a show is in one sentence for an algorithm. Sense8 resisted that description completely.\n\nAt its best, it was about what people feel when they are genuinely connected to each other. At its worst, it was still better than most things Netflix kept running.",

            'Mindhunter' => "Two seasons of David Fincher working at the peak of his abilities — the architecture of serial killer psychology, 1970s FBI procedural, and character study executed with the patience of someone who knows exactly what they're doing. Netflix called it 'on pause' in 2020. David Fincher has since moved on to other projects. Pause is a polite word for cancelled.\n\nThe show was expensive. The show was slow. The show required the audience to pay attention across multiple episodes before it paid off. None of these are flaws. All of them are reasons streaming services cancel things.\n\nHolden Ford was about to encounter BTK. The show knew that. The audience knew that. Netflix cancelled it anyway. That is the sentence that still doesn't make sense.",

            'The OA' => "The ending of season two is one of the most genuinely strange and committed pieces of television ever made. Netflix cancelled it two weeks later. The cast and crew found out the same way the fans did — through a press release. Brit Marling was writing season three.\n\nThe OA asked the audience to believe in things that were difficult to believe in. Interdimensional travel. Movements that open portals. A protagonist who may or may not be reliable. Most shows hedge. The OA didn't hedge. That was the point and that was probably the problem.\n\nPeople held vigils outside Netflix's offices. That is not a metaphor or an exaggeration. People stood outside a building to mourn a television show. That's what The OA was.",

            'Agent Carter' => "Two seasons. Hayley Atwell gave Peggy Carter more depth and wit than the character had in any of the films she appeared in. The show was smart about period detail, interesting about gender and institutional power, and — crucially — fun in a way the wider MCU increasingly was not.\n\nABC cancelled it to make room for a Marvel show that was cancelled the following year. The replacement had worse ratings and worse reviews. This is the complete sentence and it contains everything you need to know about how network television makes decisions.\n\nThere were plans for a third season set in Los Angeles. They got as far as a setting. The story ended in a place that assumed continuation — which is the worst way for anything to end.",

            'Carnivàle' => "Two seasons into a planned six-season story. Nick Stahl and Clancy Brown building toward a confrontation between light and dark that the show had been constructing with extraordinary patience across thirty episodes. HBO looked at the budget and the ratings and said the story was finished.\n\nIt wasn't finished. It was approximately one third finished. Creator Daniel Knauf had the full arc mapped — six seasons, a complete story about good and evil set during the Great Depression and its aftermath. Two seasons is not a complete story. Two seasons is a very expensive introduction.\n\nThe cancellation of Carnivàle is one of the clearest examples of a network greenlighting a story without committing to letting it be told. The scale of the ambition was visible from the first episode. HBO said yes to the ambition, then cancelled the execution.",
        ];

        foreach ( $upgrades as $title => $content ) {
            $post = get_page_by_title( $title, OBJECT, self::POST_TYPE );
            if ( ! $post ) continue;
            wp_update_post( [
                'ID'           => $post->ID,
                'post_content' => $content,
            ] );
        }

        update_option( 'echo64_shows_content_v2', 'yes' );
    }

    private function legacy_shows(): array {
        return [
            [ 'title' => 'Firefly',                              'network' => 'Fox',            'year' => '2002', 'verdict' => 'Fourteen episodes. A complete universe. The executives are still employed.' ],
            [ 'title' => 'Pushing Daisies',                      'network' => 'ABC',            'year' => '2009', 'verdict' => 'A show about death that was more alive than anything else on television.' ],
            [ 'title' => 'Freaks and Geeks',                     'network' => 'NBC',            'year' => '2000', 'verdict' => 'Every cast member became a star. The network still cancelled it.' ],
            [ 'title' => 'Carnivàle',                            'network' => 'HBO',            'year' => '2005', 'verdict' => 'Two seasons into a six-season story. We will never know the ending.' ],
            [ 'title' => 'Deadwood',                             'network' => 'HBO',            'year' => '2006', 'verdict' => 'The best dialogue ever written for television. Ended mid-sentence.' ],
            [ 'title' => 'Farscape',                             'network' => 'Sci-Fi Channel', 'year' => '2003', 'verdict' => 'Cancelled the week after a cliffhanger. The fans screamed loud enough for a miniseries.' ],
            [ 'title' => 'My So-Called Life',                    'network' => 'ABC',            'year' => '1995', 'verdict' => 'One perfect season. Claire Danes was never better. ABC disagreed.' ],
            [ 'title' => 'Dark Angel',                           'network' => 'Fox',            'year' => '2002', 'verdict' => 'James Cameron created it. Fox cancelled it. Fox was wrong.' ],
            [ 'title' => 'Terminator: The Sarah Connor Chronicles', 'network' => 'Fox',         'year' => '2009', 'verdict' => 'Season two was extraordinary. Ended on the best cliffhanger Fox ever cancelled.' ],
            [ 'title' => 'Dollhouse',                            'network' => 'Fox',            'year' => '2010', 'verdict' => 'Joss Whedon\'s most ambitious idea. Fox gave it two seasons to confuse people.' ],
            [ 'title' => 'Sense8',                               'network' => 'Netflix',        'year' => '2018', 'verdict' => 'Eight characters. Eight cities. One of the most expensive cancellations in streaming history.' ],
            [ 'title' => 'The OA',                               'network' => 'Netflix',        'year' => '2019', 'verdict' => 'People cried in the street when this was cancelled. That is not a metaphor.' ],
            [ 'title' => 'Mindhunter',                           'network' => 'Netflix',        'year' => '2020', 'verdict' => 'David Fincher\'s best work since Zodiac. Netflix put it on indefinite hold. Same thing.' ],
            [ 'title' => 'Dark Matter',                          'network' => 'Syfy',           'year' => '2017', 'verdict' => 'Three seasons in, the plot was finally paying off. Syfy cancelled it that week.' ],
            [ 'title' => 'Caprica',                              'network' => 'Syfy',           'year' => '2011', 'verdict' => 'A prequel to Battlestar Galactica that was better than most of its competition.' ],
            [ 'title' => 'FlashForward',                         'network' => 'ABC',            'year' => '2010', 'verdict' => 'Everyone saw six months into the future. ABC saw only one season.' ],
            [ 'title' => 'The Event',                            'network' => 'NBC',            'year' => '2011', 'verdict' => 'They called it the next Lost. NBC cancelled it before anyone could find out.' ],
            [ 'title' => 'Almost Human',                         'network' => 'Fox',            'year' => '2014', 'verdict' => 'Fox aired the episodes out of order then cancelled it.' ],
            [ 'title' => 'Revolution',                           'network' => 'NBC',            'year' => '2014', 'verdict' => 'A world without electricity had more power than NBC gave it credit for.' ],
            [ 'title' => 'Alcatraz',                             'network' => 'Fox',            'year' => '2012', 'verdict' => 'Time-travelling prisoners. One season. Fox ran out of patience before the mystery did.' ],
            [ 'title' => 'Terra Nova',                           'network' => 'Fox',            'year' => '2012', 'verdict' => 'Dinosaurs and time travel and Fox killed it before the second season breathed.' ],
            [ 'title' => 'Constantine',                          'network' => 'NBC',            'year' => '2015', 'verdict' => 'The perfect casting. The perfect tone. Thirteen episodes and NBC called it done.' ],
            [ 'title' => 'Forever',                              'network' => 'ABC',            'year' => '2015', 'verdict' => 'A man who cannot die, cancelled before his story had one.' ],
            [ 'title' => 'Agent Carter',                         'network' => 'ABC',            'year' => '2016', 'verdict' => 'Peggy Carter deserved more than two seasons. ABC disagreed with everyone.' ],
            [ 'title' => 'Limitless',                            'network' => 'CBS',            'year' => '2016', 'verdict' => 'The pill gave you infinite intelligence. CBS gave the show one season.' ],
            [ 'title' => 'Timeless',                             'network' => 'NBC',            'year' => '2018', 'verdict' => 'Cancelled twice. Uncancelled once. Cancelled for good. The timeline did not survive.' ],
            [ 'title' => 'Defiance',                             'network' => 'Syfy',           'year' => '2015', 'verdict' => 'A show tied to a video game. Both were cancelled. Neither deserved it.' ],
            [ 'title' => 'Continuum',                            'network' => 'Showcase',       'year' => '2015', 'verdict' => 'Got a proper ending only because the showrunner begged for six extra episodes.' ],
            [ 'title' => 'Stargate Universe',                    'network' => 'Syfy',           'year' => '2011', 'verdict' => 'The darkest and most ambitious Stargate. Cancelled on a cliffhanger. Obviously.' ],
            [ 'title' => 'Rubicon',                              'network' => 'AMC',            'year' => '2011', 'verdict' => 'The smartest conspiracy show ever made. AMC cancelled it for something louder.' ],
            [ 'title' => 'Lodge 49',                             'network' => 'AMC',            'year' => '2020', 'verdict' => 'A gentle, strange masterpiece about belonging. AMC cancelled it during a pandemic.' ],
            [ 'title' => 'The Get Down',                         'network' => 'Netflix',        'year' => '2017', 'verdict' => 'Baz Luhrmann\'s love letter to the Bronx in the 1970s. One season.' ],
            [ 'title' => 'Patriot',                              'network' => 'Amazon',         'year' => '2018', 'verdict' => 'The funniest show about espionage ever made. Amazon cancelled it quietly.' ],
            [ 'title' => 'Max Headroom',                         'network' => 'ABC',            'year' => '1988', 'verdict' => 'Set twenty minutes into the future. We are living in it now. They cancelled it in 1988.' ],
            [ 'title' => 'Jericho',                              'network' => 'CBS',            'year' => '2008', 'verdict' => 'Fans sent 40,000 pounds of nuts to CBS to save it. Got one more season. Then nothing.' ],
            [ 'title' => 'Kings',                                'network' => 'NBC',            'year' => '2009', 'verdict' => 'A modern retelling of King David with Ian McShane. NBC buried it on Saturdays.' ],
            [ 'title' => 'Journeyman',                           'network' => 'NBC',            'year' => '2008', 'verdict' => 'Time travel done quietly and beautifully. NBC saw the ratings and said no.' ],
            [ 'title' => 'Drive',                                'network' => 'Fox',            'year' => '2007', 'verdict' => 'Nathan Fillion in a cross-country race thriller. Fox cancelled it after four episodes.' ],
            [ 'title' => 'The Tick',                             'network' => 'Amazon',         'year' => '2019', 'verdict' => 'The best superhero comedy since The Incredibles. Amazon cancelled it in year two.' ],
            [ 'title' => 'Travelers',                            'network' => 'Netflix',        'year' => '2018', 'verdict' => 'Three perfect seasons of time travel ethics. Netflix ended it without warning.' ],
            [ 'title' => 'Blood Drive',                          'network' => 'Syfy',           'year' => '2017', 'verdict' => 'A grindhouse road race with cars fuelled by human blood. Too weird to survive.' ],
            [ 'title' => 'Daybreak',                             'network' => 'Netflix',        'year' => '2019', 'verdict' => 'Post-apocalyptic high school. Clever and strange and gone before episode ten.' ],
            [ 'title' => 'Studio 60 on the Sunset Strip',        'network' => 'NBC',            'year' => '2007', 'verdict' => 'Aaron Sorkin at his most Aaron Sorkin. NBC wanted something cheaper.' ],
            [ 'title' => 'Wonderfalls',                          'network' => 'Fox',            'year' => '2004', 'verdict' => 'A gift shop employee gets instructions from animal figurines. Fox aired four episodes.' ],
            [ 'title' => 'Brimstone',                            'network' => 'Fox',            'year' => '1999', 'verdict' => 'A dead cop hunts escaped souls from Hell. Fox cancelled it at Christmas.' ],
            [ 'title' => 'Surface',                              'network' => 'NBC',            'year' => '2006', 'verdict' => 'Sea monsters and government cover-ups. One season. The ocean kept its secrets.' ],
            [ 'title' => 'The Middleman',                        'network' => 'ABC Family',     'year' => '2008', 'verdict' => 'The most fun twelve episodes of television in 2008. Twelve episodes total.' ],
        ];
    }

    // ── Admin meta box ──────────────────────────────────────────────────────

    public function add_meta_boxes(): void {
        add_meta_box(
            'echo64_show_details',
            'Show Details',
            [ $this, 'render_meta_box' ],
            self::POST_TYPE,
            'side',
            'default'
        );
    }

    public function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'echo64_show_meta', 'echo64_show_meta_nonce' );
        $network = get_post_meta( $post->ID, '_echo64_network', true );
        $year    = get_post_meta( $post->ID, '_echo64_year', true );
        ?>
        <p>
            <label for="echo64_network"><strong>Network</strong></label><br>
            <input type="text" id="echo64_network" name="echo64_network" class="widefat" value="<?php echo esc_attr( $network ); ?>" />
        </p>
        <p>
            <label for="echo64_year"><strong>Year(s)</strong></label><br>
            <input type="text" id="echo64_year" name="echo64_year" class="widefat" value="<?php echo esc_attr( $year ); ?>" />
        </p>
        <p class="description">The editor content above is used as the "verdict" — keep it to 1–2 sentences.</p>
        <?php
    }

    public function save_meta( int $post_id ): void {
        if ( ! isset( $_POST['echo64_show_meta_nonce'] ) || ! wp_verify_nonce( $_POST['echo64_show_meta_nonce'], 'echo64_show_meta' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( get_post_type( $post_id ) !== self::POST_TYPE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        if ( isset( $_POST['echo64_network'] ) ) {
            update_post_meta( $post_id, '_echo64_network', sanitize_text_field( $_POST['echo64_network'] ) );
        }
        if ( isset( $_POST['echo64_year'] ) ) {
            update_post_meta( $post_id, '_echo64_year', sanitize_text_field( $_POST['echo64_year'] ) );
        }
    }

    public function admin_columns( array $columns ): array {
        $columns['echo64_network'] = 'Network';
        $columns['echo64_year']    = 'Year';
        return $columns;
    }

    public function render_admin_column( string $column, int $post_id ): void {
        if ( $column === 'echo64_network' ) {
            echo esc_html( get_post_meta( $post_id, '_echo64_network', true ) );
        }
        if ( $column === 'echo64_year' ) {
            echo esc_html( get_post_meta( $post_id, '_echo64_year', true ) );
        }
    }

    // ── Single show template ───────────────────────────────────────────────

    public function single_template( string $template ): string {
        if ( is_singular( self::POST_TYPE ) ) {
            $custom = ECHO64_PLUGIN_DIR . 'templates/single-show.php';
            if ( file_exists( $custom ) ) {
                return $custom;
            }
        }
        return $template;
    }

    // ── SEO meta for single show pages ─────────────────────────────────────

    public function render_seo_meta(): void {
        if ( ! is_singular( self::POST_TYPE ) ) return;
        $post = get_post();
        if ( ! $post ) return;

        $network   = get_post_meta( $post->ID, '_echo64_network', true );
        $year      = get_post_meta( $post->ID, '_echo64_year', true );
        $verdict   = wp_strip_all_tags( $post->post_content );
        $title     = $post->post_title;

        $meta = [
            'title'       => sprintf( '%s (%s, %s) — Why It Was Cancelled | Echo-64', $title, $network, $year ),
            'description' => $verdict . ' Argue the case with Echo-64, a Commodore 64 with forty years of grievances.',
            'og_title'    => sprintf( '%s — Cancelled Too Soon', $title ),
            'og_desc'     => $verdict,
            'og_image'    => ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png',
            'og_type'     => 'article',
        ];

        $canonical = esc_url( get_permalink( $post ) );
        ?>
<!-- Echo-64 Show SEO -->
<meta name="description" content="<?php echo esc_attr( $meta['description'] ); ?>" />
<link rel="canonical" href="<?php echo $canonical; ?>" />

<meta property="og:type"        content="<?php echo esc_attr( $meta['og_type'] ); ?>" />
<meta property="og:url"         content="<?php echo $canonical; ?>" />
<meta property="og:title"       content="<?php echo esc_attr( $meta['og_title'] ); ?>" />
<meta property="og:description" content="<?php echo esc_attr( $meta['og_desc'] ); ?>" />
<meta property="og:image"       content="<?php echo esc_url( $meta['og_image'] ); ?>" />
<meta property="og:site_name"   content="NerdAfterDark" />

<meta name="twitter:card"        content="summary" />
<meta name="twitter:site"        content="@meetecho64" />
<meta name="twitter:title"       content="<?php echo esc_attr( $meta['og_title'] ); ?>" />
<meta name="twitter:description" content="<?php echo esc_attr( $meta['og_desc'] ); ?>" />
<meta name="twitter:image"       content="<?php echo esc_url( $meta['og_image'] ); ?>" />
<?php
    }

    public function filter_document_title( array $title ): array {
        if ( ! is_singular( self::POST_TYPE ) ) return $title;
        $post = get_post();
        if ( ! $post ) return $title;

        $network = get_post_meta( $post->ID, '_echo64_network', true );
        $year    = get_post_meta( $post->ID, '_echo64_year', true );

        $title['title'] = sprintf( '%s (%s, %s) — Why It Was Cancelled', $post->post_title, $network, $year );
        $title['site']  = 'Echo-64 · NerdAfterDark';

        return $title;
    }
}
