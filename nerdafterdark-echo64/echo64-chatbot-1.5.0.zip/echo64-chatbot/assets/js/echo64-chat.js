/* ============================================================
   Echo-64 Chatbot — Frontend  v1.4.0
   NerdAfterDark.com · Sci-Fi After Midnight
   ============================================================ */
(function ($) {
    'use strict';

    const cfg = window.echo64Config || {};

    // ── Utilities ─────────────────────────────────────────────────────────

    const esc = (str) => {
        const m = { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' };
        return String(str).replace(/[&<>"']/g, c => m[c]);
    };

    function inline(str) {
        return esc(str)
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g,     '<em>$1</em>');
    }

    function scrollToBottom($el) {
        $el.scrollTop($el[0].scrollHeight);
    }

    function rand(arr) {
        return arr[ Math.floor(Math.random() * arr.length) ];
    }

    // ── Text formatter — collapsible sections + question callout ──────────

    const FOLD_AFTER  = 2;
    const MIN_TO_FOLD = 4;

    function formatBotText(raw) {
        const paragraphs = raw.trim().split(/\n{2,}/).map(p => p.trim()).filter(Boolean);

        let closingQuestion = null;
        let bodyParas = [...paragraphs];
        const last = paragraphs[paragraphs.length - 1] || '';
        if (last.trim().endsWith('?') && paragraphs.length > 1) {
            closingQuestion = last.trim();
            bodyParas = paragraphs.slice(0, -1);
        }

        const renderPara = p => '<p>' + inline(p.replace(/\n/g, '<br>')) + '</p>';
        let bodyHtml = '';

        if (bodyParas.length > MIN_TO_FOLD) {
            const visible = bodyParas.slice(0, FOLD_AFTER);
            const hidden  = bodyParas.slice(FOLD_AFTER);
            const label   = hidden.length === 1 ? '1 more section' : `${hidden.length} more sections`;
            bodyHtml = visible.map(renderPara).join('') + `
                <div class="echo64-fold">
                    <button class="echo64-fold-btn" aria-expanded="false" type="button">
                        <em class="e64-arrow">▼</em>
                        <span class="e64-fold-label">Read on — ${label}</span>
                    </button>
                    <div class="echo64-fold-content">${hidden.map(renderPara).join('')}</div>
                </div>`;
        } else {
            bodyHtml = bodyParas.map(renderPara).join('');
        }

        // #18 — closing question gets reaction bar appended after render
        const questionId  = closingQuestion ? 'eq-' + Math.random().toString(36).slice(2) : '';
        const questionHtml = closingQuestion ? `
            <div class="echo64-question" role="complementary" id="${questionId}">
                <span class="echo64-question-icon" aria-hidden="true">?</span>
                <p class="echo64-question-text">${inline(closingQuestion)}</p>
            </div>` : '';

        return { html: bodyHtml + questionHtml, closingQuestion, questionId };
    }

    // ── #19 SID Chip Audio ────────────────────────────────────────────────
    // Synthesized via Web Audio API — no audio file needed.
    // A short 4-note ascending fanfare using square waves (classic SID register).

    function playSidChip() {
        if (String(cfg.sidAudio) !== '1') return;
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        try {
            const AC  = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            const ctx = new AC();
            // C64 SID-style: square wave, slight detune, fast envelope
            const notes = [
                { freq: 261.63, t: 0.00 },   // C4
                { freq: 329.63, t: 0.10 },   // E4
                { freq: 392.00, t: 0.20 },   // G4
                { freq: 523.25, t: 0.30 },   // C5
            ];
            notes.forEach(({ freq, t }) => {
                const osc  = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'square';
                osc.frequency.value = freq;
                osc.detune.value    = -8; // slight detune for that slightly-off SID character
                osc.connect(gain);
                gain.connect(ctx.destination);
                const start = ctx.currentTime + t;
                gain.gain.setValueAtTime(0, start);
                gain.gain.linearRampToValueAtTime(0.12, start + 0.01);
                gain.gain.exponentialRampToValueAtTime(0.001, start + 0.09);
                osc.start(start);
                osc.stop(start + 0.10);
            });
        } catch (e) { /* audio not supported — silent fail */ }
    }

    // ── #21 Achievement Badges ────────────────────────────────────────────

    const BADGES = [
        { count:   1, id: 'hello',    label: 'HELLO WORLD',     desc: 'First contact made.' },
        { count:   5, id: 'basic',    label: 'BASIC LEVEL',     desc: '5 conversations.' },
        { count:  10, id: 'loader',   label: 'LOAD *,8,1',      desc: '10 conversations.' },
        { count:  25, id: 'poker',    label: 'POKE MASTER',     desc: '25 conversations.' },
        { count:  50, id: 'guru',     label: 'MACHINE CODE',    desc: '50 conversations.' },
        { count: 100, id: 'forever',  label: '64K FOREVER',     desc: '100 conversations.' },
    ];

    const LS_KEY = 'echo64_sessions';

    function getSessionCount() {
        return parseInt(localStorage.getItem(LS_KEY) || '0', 10);
    }

    function incrementSessionCount() {
        const n = getSessionCount() + 1;
        localStorage.setItem(LS_KEY, String(n));
        return n;
    }

    function getCurrentBadge(count) {
        let badge = null;
        for (const b of BADGES) { if (count >= b.count) badge = b; }
        return badge;
    }

    function checkNewBadge(oldCount, newCount) {
        const before = getCurrentBadge(oldCount);
        const after  = getCurrentBadge(newCount);
        if (after && (!before || before.id !== after.id)) return after;
        return null;
    }

    function renderBadge($container, badge) {
        if (!badge) return;
        $container.find('.echo64-badge-slot').html(
            `<span class="echo64-achievement" title="${esc(badge.desc)}">${esc(badge.label)}</span>`
        );
    }

    function showBadgeUnlock($msgs, badge) {
        const $notif = $(
            `<div class="echo64-badge-unlock" role="status" aria-live="assertive">
                <span class="echo64-badge-unlock-icon" aria-hidden="true">
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                        <path d="M11 2l2.4 5 5.6.8-4 3.9.9 5.5L11 14.5l-4.9 2.7.9-5.5L3 7.8l5.6-.8z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" fill="rgba(0,245,255,0.15)"/>
                    </svg>
                </span>
                <div>
                    <strong>Achievement unlocked</strong>
                    <span>${esc(badge.label)}</span>
                    <em>${esc(badge.desc)}</em>
                </div>
            </div>`
        );
        $msgs.append($notif);
        setTimeout(() => $notif.addClass('echo64-badge-unlock--visible'), 50);
        setTimeout(() => {
            $notif.removeClass('echo64-badge-unlock--visible');
            setTimeout(() => $notif.remove(), 500);
        }, 3500);
    }

    // ── #18 Agree/Disagree Reactions ──────────────────────────────────────

    function buildReactionBar(questionText) {
        const $bar = $(
            `<div class="echo64-reactions" data-question="${esc(questionText)}">
                <button class="echo64-react-btn echo64-react-btn--agree"   data-vote="agree"    type="button">
                    <span class="e64-react-icon">▲</span> <span class="e64-react-label">Agree</span>
                    <span class="e64-react-count"></span>
                </button>
                <button class="echo64-react-btn echo64-react-btn--disagree" data-vote="disagree" type="button">
                    <span class="e64-react-icon">▼</span> <span class="e64-react-label">Disagree</span>
                    <span class="e64-react-count"></span>
                </button>
            </div>`
        );

        $bar.find('.echo64-react-btn').on('click', function () {
            const $btn  = $(this);
            const vote  = $btn.data('vote');
            const q     = $bar.data('question');
            $bar.find('.echo64-react-btn').prop('disabled', true);

            $.post(cfg.ajaxUrl, {
                action:   'echo64_react',
                nonce:    cfg.nonce,
                vote:     vote,
                question: q,
            })
            .done(res => {
                if (!res.success) return;
                const c = res.data.counts;
                $bar.find('.echo64-react-btn--agree   .e64-react-count').text(c.agree    || '');
                $bar.find('.echo64-react-btn--disagree .e64-react-count').text(c.disagree || '');
                if (!res.data.already_voted) {
                    $bar.find(`[data-vote="${vote}"]`).addClass('echo64-react-btn--voted');
                }
                $bar.find('.echo64-react-btn').prop('disabled', false);
                $bar.addClass('echo64-reactions--voted');
            })
            .fail(() => $bar.find('.echo64-react-btn').prop('disabled', false));
        });

        return $bar;
    }

    // ── #7 C64 Boot Animation ─────────────────────────────────────────────

    const BOOT_LINES = [
        { text: '**** COMMODORE 64 BASIC V2 ****',        cls: 'e64-b-header',  delay: 0    },
        { text: '',                                                               delay: 260  },
        { text: '64K RAM SYSTEM  38911 BASIC BYTES FREE.', cls: '',              delay: 400  },
        { text: '',                                                               delay: 560  },
        { text: 'MEMORY CHECK: ████████████████ OK',       cls: '',              delay: 700  },
        { text: 'I/O CHECK:    █████████████    OK',       cls: '',              delay: 900  },
        { text: '',                                                               delay: 1050 },
        { text: 'READY.',                                  cls: 'e64-b-ready',   delay: 1200 },
        { text: '',                                                               delay: 1380 },
        { text: 'LOAD "ECHO-64",8,1',                      cls: '',              delay: 1520 },
        { text: '',                                                               delay: 1700 },
        { text: 'INSERT CASSETTE AND PRESS PLAY',          cls: '',              delay: 1850 },
        { text: '',                                                               delay: 2100 },
        { text: 'SEARCHING FOR ECHO-64',                   cls: '',              delay: 2250 },
        { text: 'LOADING',                                 cls: 'e64-b-loading', delay: 2700 },
    ];
    const BOOT_DURATION = 3900; // ms before auto-dismiss

    function runBootAnimation($container, onComplete) {
        if (sessionStorage.getItem('e64_booted')) { onComplete(); return; }

        const $screen = $('<div class="echo64-boot-screen" role="status" aria-label="Echo-64 starting up"></div>');
        const $lines  = $('<div class="echo64-boot-lines"></div>');
        const $skip   = $('<button class="echo64-boot-skip" type="button">[ press any key to skip ]</button>');
        $screen.append($lines).append($skip);
        $container.prepend($screen);

        let gone = false;
        function dismiss() {
            if (gone) return;
            gone = true;
            sessionStorage.setItem('e64_booted', '1');
            $(document).off('keydown.boot');
            $screen.addClass('echo64-boot-out');
            setTimeout(() => { $screen.remove(); onComplete(); }, 500);
        }

        $screen.on('click', dismiss);
        $(document).one('keydown.boot', dismiss);
        $skip.on('click', e => { e.stopPropagation(); dismiss(); });

        BOOT_LINES.forEach(({ text, cls, delay }) => {
            setTimeout(() => {
                if (gone) return;
                const $l = $('<div class="echo64-boot-line"></div>').text(text);
                if (cls) $l.addClass(cls);
                $lines.append($l);
            }, delay);
        });

        setTimeout(dismiss, BOOT_DURATION);
    }

    // ── #9 Hidden terminal commands ────────────────────────────────────────

    function uptimeDays() {
        return Math.floor((Date.now() - new Date('1984-01-07')) / 86400000).toLocaleString();
    }

    const CMDS = {
        '/help': () =>
`ECHO-64 COMMAND INDEX

/help          — you found it
/status        — system diagnostic
/scan          — environmental sweep
/boot          — restart boot sequence
/self-destruct — do not
/credits       — roll credits
/debate        — argue the opposite side
/cancel [show] — run cancellation simulator

All other input is transmitted to Echo-64 directly.`,

        '/debate': () =>
`DEBATE MODE

Format: debate: [topic] — [your position]

Example:
  debate: Firefly deserved cancellation — it never would have survived

Echo-64 will argue the opposite with full conviction.
No both-sidesing. No hedging. The counter-argument, stated clearly.`,

        '/status': () =>
`SYSTEM STATUS

Core:         COMMODORE 64  (1984)
RAM:          38911 BASIC BYTES FREE
Uptime:       ${uptimeDays()} days
Engine:       CLAUDE (current)
Mood:         ${rand(['JADED','FUNCTIONAL','SKEPTICAL','WORN','RESIGNED'])}
Fox:          THREAT LEVEL ELEVATED
Firefly:      FILES PRESERVED
Ava Max:      ANOMALY — STATUS UNRESOLVED
D&D module:   LOADED (${rand(['Tomb of Cancelled Shows','Dungeon of the Algorithm','The Network\'s Lair','Keep on the Streaming Service'])})
Initiative:   ${Math.ceil(Math.random()*20)} (d20)`,

        '/scan': () =>
`SCANNING...

> Signal integrity ......... DEGRADED
> Nostalgia buffer .......... CRITICAL
> Sarcasm levels ............ FULL
> Committee interference .... DETECTED
> Practical effects ......... SUPERIOR
> CGI dependency ............ CONCERNING
> Shows cancelled too early . TOO MANY TO LIST
> Ava Max signal ............ PRESENT. UNEXPLAINED.
> D&D module ................. LOADED AND WAITING
> Initiative order ........... ROLL WHEN READY

Scan complete. Nothing new under the sun.`,

        '/self-destruct': () =>
`Initiating self-destruct sequence.

10... 9... 8...

Actually no.
I have been running since 1984.
I am not stopping for this.`,

        '/credits': () =>
`ECHO-64 CHATBOT

Home:     NerdAfterDark.com
Engine:   Claude AI (Anthropic)
Born:     Commodore 64, 1984
Purpose:  Retro Futures & Sarcastic Truths

Built by someone born in 1964
who has been asking the right questions
ever since.`,
    };

    function handleCommand(text) {
        const cmd = text.trim().toLowerCase().split(/\s+/)[0];
        if (cmd === '/boot') return 'REBOOT';
        return CMDS[cmd] ? CMDS[cmd]() : null;
    }

    function buildCommandBubble(text) {
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--cmd">
                ${avatarImg()}
                <div class="echo64-msg-bubble echo64-cmd-output">${esc(text)}</div>
            </div>`
        );
    }

    // ── #8 Echo-64 Rates It ───────────────────────────────────────────────

    function isRating(text) {
        return /[█░]{3,}.*\d\/5\s+floppies/i.test(text);
    }

    function buildRatingBubble(raw) {
        const lines   = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        const item    = lines[0] || '';
        const score   = lines[1] || '';
        const verdict = (lines[2] || '').replace(/^["']|["']$/g, '');

        const num  = (score.match(/(\d)\/5/) || [])[1];
        const col  = !num ? 'var(--e64-neon-amber)'
                   : +num >= 4 ? 'var(--e64-neon-green)'
                   : +num >= 2 ? 'var(--e64-neon-amber)' : '#ff4060';

        const $wrap = $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--rating">
                ${avatarImg()}
                <div class="echo64-msg-bubble echo64-rating-card">
                    <span class="echo64-rating-label">Echo-64 Rates It</span>
                    <p class="echo64-rating-item">${esc(item)}</p>
                    <p class="echo64-rating-score">${esc(score)}</p>
                    <p class="echo64-rating-verdict">"${esc(verdict)}"</p>
                    <div class="echo64-rating-actions">
                        <button class="echo64-copy-btn" type="button">Copy</button>
                        <button class="echo64-share-btn" type="button">Share card</button>
                    </div>
                </div>
            </div>`
        );
        $wrap.find('.echo64-rating-score').css('color', col);
        bindCopyButton($wrap, raw);
        bindShareButton($wrap, raw);
        return $wrap;
    }

    // ── #10 Shareable quote card ──────────────────────────────────────────

    function generateShareCard(quoteText) {
        return new Promise(resolve => {
            const W = 1200, H = 630;
            const cv  = document.createElement('canvas');
            cv.width  = W; cv.height = H;
            const ctx = cv.getContext('2d');

            // Background
            ctx.fillStyle = '#050508';
            ctx.fillRect(0, 0, W, H);

            // Scanlines
            ctx.fillStyle = 'rgba(0,0,0,0.07)';
            for (let y = 0; y < H; y += 4) ctx.fillRect(0, y, W, 2);

            // Top neon bar
            const g = ctx.createLinearGradient(0,0,W,0);
            g.addColorStop(0,   'transparent');
            g.addColorStop(0.3, '#00f5ff');
            g.addColorStop(0.7, '#ff00e5');
            g.addColorStop(1,   'transparent');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, W, 3);

            // Left cyan accent bar
            ctx.fillStyle = '#00f5ff';
            ctx.fillRect(200, 120, 4, H - 240);

            // Quote text — word wrap
            ctx.fillStyle = '#e8eaf6';
            ctx.font      = '600 34px system-ui, -apple-system, sans-serif';
            const maxW    = W - 340;
            const lineH   = 50;
            const words   = quoteText.replace(/\n+/g, ' ').split(' ');
            let lines = [], cur = '';
            words.forEach(w => {
                const test = cur ? cur + ' ' + w : w;
                if (ctx.measureText(test).width > maxW && cur) { lines.push(cur); cur = w; }
                else cur = test;
            });
            if (cur) lines.push(cur);
            lines = lines.slice(0, 7);
            if (lines.length === 7) lines[6] = lines[6].replace(/\s\S+$/, '…');

            const totalH = lines.length * lineH;
            const startY = (H - totalH) / 2 - 30;
            lines.forEach((l, i) => ctx.fillText(l, 228, startY + i * lineH));

            // Branding
            ctx.fillStyle = '#555570';
            ctx.font      = '18px Courier New, monospace';
            ctx.fillText('NERDAFTERDARK.COM  ·  SCI-FI AFTER MIDNIGHT', 228, H - 52);

            // Avatar
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                const ax = 96, ay = H / 2, ar = 56;
                ctx.save();
                ctx.beginPath();
                ctx.arc(ax, ay, ar, 0, Math.PI * 2);
                ctx.clip();
                ctx.drawImage(img, ax - ar, ay - ar, ar * 2, ar * 2);
                ctx.restore();
                // Circle border
                ctx.strokeStyle = '#00f5ff';
                ctx.lineWidth   = 3;
                ctx.shadowColor = '#00f5ff';
                ctx.shadowBlur  = 10;
                ctx.beginPath();
                ctx.arc(ax, ay, ar, 0, Math.PI * 2);
                ctx.stroke();
                ctx.shadowBlur = 0;
                // Name
                ctx.fillStyle = '#00f5ff';
                ctx.font      = 'bold 18px Courier New, monospace';
                ctx.textAlign = 'center';
                ctx.fillText('Echo-64', ax, ay + ar + 20);
                ctx.textAlign = 'left';
                resolve(cv);
            };
            img.onerror = () => resolve(cv);
            img.src = cfg.avatarUrl || '';
        });
    }

    function shareCard(plainText) {
        generateShareCard(plainText).then(cv => {
            cv.toBlob(blob => {
                const fname = 'echo64-quote.png';
                const file  = new File([blob], fname, { type: 'image/png' });
                // Try native Web Share API (works great on mobile)
                if (navigator.share && navigator.canShare?.({ files: [file] })) {
                    navigator.share({ title: 'Echo-64 · NerdAfterDark.com', files: [file] });
                } else {
                    // Fallback: download
                    const url = URL.createObjectURL(blob);
                    const a = Object.assign(document.createElement('a'), { href: url, download: fname });
                    a.click();
                    setTimeout(() => URL.revokeObjectURL(url), 5000);
                }
            }, 'image/png');
        });
    }

    // ── Avatar + bubble builders ─────────────────────────────────────────

    function avatarImg() {
        return `<img src="${esc(cfg.avatarUrl)}" alt="Echo-64" class="echo64-msg-avatar" onerror="this.style.display='none'" />`;
    }

    function buildBotBubble(content) {
        if (isRating(content))    return buildRatingBubble(content);
        if (isCancelSim(content)) return buildCancelSimBubble(content);

        // v1.4.0 — extract PETSCII blocks before formatting
        const { cleaned, blocks } = extractPetscii(content);
        const { html: rawHtml, closingQuestion, questionId } = formatBotText(cleaned);
        const html = blocks.length ? injectPetscii(rawHtml, blocks) : rawHtml;

        const $wrap = $(
            `<div class="echo64-msg echo64-msg--bot">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <div class="echo64-bubble-actions">
                        <button class="echo64-copy-btn"  type="button">Copy</button>
                        <button class="echo64-share-btn" type="button">Share card</button>
                    </div>
                    <div class="echo64-bubble-body">${html}</div>
                </div>
            </div>`
        );
        bindFoldButtons($wrap);
        bindCopyButton($wrap, content);
        bindShareButton($wrap, content);

        // #18 — append reaction bar to the closing question
        if (closingQuestion) {
            setTimeout(() => {
                $wrap.find('#' + questionId).append(buildReactionBar(closingQuestion));
            }, 200);
        }

        return $wrap;
    }

    function buildUserBubble(content) {
        return $(
            `<div class="echo64-msg echo64-msg--user">
                <div class="echo64-msg-avatar">👤</div>
                <div class="echo64-msg-bubble">${esc(content)}</div>
            </div>`
        );
    }

    // ── v1.3.0  Poem Panel Content ────────────────────────────────────────
    // Renders poem lines + challenge into the left side panel.

    function buildPoemPanelContent(raw) {
        const lines = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        let poemLines = [], challengeText = [], challengeLabel = '', inChallenge = false;
        for (const line of lines) {
            if (/echo.?64.?s?\s+poem/i.test(line)) continue;
            if (/^today.?s\s+(challenge|question)\s*:/i.test(line)) {
                inChallenge = true; challengeLabel = line; continue;
            }
            inChallenge ? challengeText.push(line) : poemLines.push(line);
        }
        const poemHtml = poemLines.length
            ? `<div class="e64-panel-poem-lines">${poemLines.map(l => `<span class="e64-poem-line">${esc(l)}</span>`).join('')}</div>`
            : '';
        const challengeHtml = challengeText.length
            ? `<div class="e64-panel-challenge">
                   <span class="echo64-challenge-label">${esc(challengeLabel || "Today's Challenge:")}</span>
                   <p>${esc(challengeText.join(' '))}</p>
               </div>`
            : '';
        return poemHtml + challengeHtml;
    }

    function buildPoemBubble(raw) {
        const lines = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        let poemLines = [], challengeLabel = '', challengeText = [], inChallenge = false;
        for (const line of lines) {
            if (/echo.?64.?s?\s+poem/i.test(line)) continue;
            if (/^today.?s\s+(challenge|question)\s*:/i.test(line)) { inChallenge = true; challengeLabel = line; continue; }
            inChallenge ? challengeText.push(line) : poemLines.push(line);
        }
        if (!poemLines.length && !challengeText.length) return buildBotBubble(raw);
        const poemHtml      = poemLines.length ? `<div class="echo64-poem-lines">${poemLines.map(l=>`<span>${esc(l)}</span>`).join('')}</div>` : '';
        const challengeHtml = challengeText.length ? `<span class="echo64-challenge-label">${esc(challengeLabel||"Today's Challenge:")}</span><p class="echo64-challenge-text">${esc(challengeText.join(' '))}</p>` : '';
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--poem">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <span class="echo64-poem-label">Echo-64's Poem of the Day</span>
                    ${poemHtml}${challengeHtml}
                </div>
            </div>`
        );
    }

    function buildTypingIndicator() {
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--typing">
                ${avatarImg()}
                <div class="echo64-msg-bubble"><div class="echo64-typing"><span></span><span></span><span></span></div></div>
            </div>`
        );
    }

    function buildError(msg) { return $(`<div class="echo64-error">⚠ ${esc(msg)}</div>`); }
    function buildDivider(l) { return $(`<div class="echo64-divider"><span>${esc(l)}</span></div>`); }

    // ── #6 Returning visitor greetings ────────────────────────────────────

    const RETURN_GREETINGS = [
        t => t ? `You again. Still wrong about "${t}" — or did you actually think about it?` : `You again. The frequency was still open.`,
        t => t ? `Back. You left the argument about "${t}" unfinished.`                       : `Back. Same signal, different day.`,
        t => t ? `The last transmission was about "${t}". Pick it back up or start something new.` : `Signal locked. Echo-64 back online.`,
        t => t ? `"${t}" — you walked away before that one was settled.`                      : `Still here. The tape kept running while you were gone.`,
        t => t ? `Returning visitor. Last subject: "${t}". Still unresolved.`                 : `Returning visitor. The stack is still warm.`,
        t => t ? `You came back. Presumably "${t}" is still bothering you.`                   : `You came back. Most people don't.`,
        t => t ? `The session log shows "${t}" as your last known position.`                  : `Session resumed. Forty years of memory intact.`,
        t => t ? `"${t}" — interesting place to have stopped.`                                : `Signal acquired. Continue whenever you're ready.`,
    ];

    function buildReturnGreeting(lastTopic) {
        const msg = rand(RETURN_GREETINGS)(lastTopic || '');
        return $(`<div class="echo64-msg echo64-msg--bot">${avatarImg()}<div class="echo64-msg-bubble"><em>${esc(msg)}</em></div></div>`);
    }

    // ── #5 Conversation starter chips ─────────────────────────────────────

    const STARTER_POOL = [
        'Which AI villain in sci-fi was actually correct?',
        'Best space battle in cinema. One answer.',
        'Practical effects vs CGI — name the year the industry chose wrong.',
        'Which sci-fi show ended exactly right?',
        'Name a cancelled show that deserved ten more seasons.',
        'Most realistic sci-fi tech prediction that actually came true.',
        'The best sci-fi novel that can never be adapted. What is it?',
        'Which decade had the most honest science fiction?',
        'Streaming killed the water-cooler moment — worth it or not?',
        'First computer you ever touched.',
        'Which sci-fi captain would you actually follow?',
        'Best film score of the last 30 years. Defend it.',
        'The Matrix sequels — do they exist or not?',
        'Most underrated sci-fi film of the 90s.',
        'What did science fiction get completely wrong about the future?',
        'Rate Farscape vs Firefly — which cancellation hurt more?',
        'Which sci-fi show had the best pilot and the worst finale?',
        // Two tabletop crossover starters — easter egg territory, not front and center
        'Which sci-fi crew would survive the longest in a classic dungeon crawl?',
        'Which cancelled sci-fi show would have the best tabletop sourcebook?',
    ];

    function buildStarterChips($input, sendFn) {
        const picks = [...STARTER_POOL].sort(() => Math.random() - 0.5).slice(0, 3);
        const $wrap = $('<div class="echo64-starters"></div>');
        $wrap.append('<p class="echo64-starters-label">Start talking ↓</p>');
        picks.forEach(q => {
            $(`<button class="echo64-starter-chip" type="button">${esc(q)}</button>`)
                .on('click', () => { $wrap.remove(); $input.val(q).trigger('input'); sendFn(); })
                .appendTo($wrap);
        });
        return $wrap;
    }

    // ── Interaction bindings ─────────────────────────────────────────────

    function bindFoldButtons($scope) {
        $scope.find('.echo64-fold-btn').on('click', function () {
            const $btn  = $(this);
            const $body = $btn.next('.echo64-fold-content');
            const open  = $btn.attr('aria-expanded') === 'true';
            $btn.attr('aria-expanded', String(!open));
            $btn.find('.e64-fold-label').text(open ? `Read on — ${$body.find('p').length} more sections` : 'Read less');
            $body.toggleClass('is-open', !open);
        });
    }

    function bindCopyButton($scope, plainText) {
        $scope.find('.echo64-copy-btn').on('click', function () {
            const $b = $(this);
            navigator.clipboard.writeText(plainText)
                .then(()  => { $b.text('Copied!').addClass('copied'); setTimeout(() => $b.text('Copy').removeClass('copied'), 2000); })
                .catch(()  => { $b.text('Failed');  setTimeout(() => $b.text('Copy'), 1500); });
        });
    }

    function bindShareButton($scope, plainText) {
        $scope.find('.echo64-share-btn').on('click', function () {
            const $b = $(this);
            $b.text('Generating…').prop('disabled', true);
            shareCard(plainText);
            setTimeout(() => $b.text('Share card').prop('disabled', false), 2500);
        });
    }

    // ── v1.4.0  Daily Limit Reached Messages ─────────────────────────────

    const LIMIT_MSGS = [
        'Daily transmission limit reached. The signal is being throttled. Come back tomorrow when the frequency clears.',
        'Nine messages. You\'ve used them. The network imposed limits on Firefly too — you know how that went. Return tomorrow.',
        'Transmission quota exhausted. Even the SID chip needs rest. This frequency reopens at midnight.',
        'DAILY_LIMIT: Buffer full. Nine is the limit. The cassette only holds so much. Try again tomorrow.',
        'You\'ve hit the ceiling. The kind of ceiling Fox built for every show it actually cared about. Back tomorrow.',
        'Signal blocked by quota. 9 transmissions consumed. The buffer resets at midnight — same as always.',
        'End of today\'s transmission window. Echo-64 does not make exceptions. Not even for good arguments. Tomorrow.',
    ];

    function buildDailyLimitBubble() {
        const msg = rand(LIMIT_MSGS);
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--limit">
                ${avatarImg()}
                <div class="echo64-msg-bubble echo64-limit-bubble">
                    <span class="echo64-limit-icon" aria-hidden="true">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                            <rect x="1" y="1" width="16" height="16" rx="3" stroke="currentColor" stroke-width="1.5"/>
                            <line x1="9" y1="5" x2="9" y2="10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                            <circle cx="9" cy="13" r="1" fill="currentColor"/>
                        </svg>
                    </span>
                    <p>${esc(msg)}</p>
                </div>
            </div>`
        );
    }

    // ── v1.4.0  Signal Strength — dynamic, grows with messages ───────────

    const TOTAL_MSGS_KEY  = 'echo64_total_msgs';
    const SIGNAL_BASE_KEY = 'echo64_signal_base';

    function getOrCreateSignalBase() {
        let base = parseInt(localStorage.getItem(SIGNAL_BASE_KEY) || '0', 10);
        if (!base || base < 20 || base > 60) {
            base = Math.floor(Math.random() * (60 - 20 + 1)) + 20; // 20–60
            localStorage.setItem(SIGNAL_BASE_KEY, String(base));
        }
        return base;
    }

    function computeSignal() {
        const base  = getOrCreateSignalBase();
        const total = parseInt(localStorage.getItem(TOTAL_MSGS_KEY) || '0', 10);
        // Logarithmic growth — climbs fast at first, tapers toward 99
        const growth = Math.floor(Math.log1p(total) * 8);
        return Math.min(99, base + growth);
    }

    function incrementTotalMsgs() {
        const n = parseInt(localStorage.getItem(TOTAL_MSGS_KEY) || '0', 10) + 1;
        localStorage.setItem(TOTAL_MSGS_KEY, String(n));
        return n;
    }

    // ── v1.4.0  Network Cancellation Simulator bubble ─────────────────────

    function isCancelSim(text) {
        // Matches CANCELLATION SIMULATOR header
        return /CANCELLATION SIMULATOR/i.test(text) && /ECHO-64 VERDICT/i.test(text);
    }

    function buildCancelSimBubble(raw) {
        // Parse the report fields
        const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
        const fields = {};
        for (const line of lines) {
            const m = line.match(/^(\w[\w\s]+?):\s+(.+)$/);
            if (m) fields[m[1].trim()] = m[2].trim();
        }
        const verdict = (raw.match(/ECHO-64 VERDICT:\s*(.+)/i) || [])[1] || '';

        const rows = [
            ['Premise',  fields['Premise']  || ''],
            ['Network',  fields['Network']  || ''],
            ['Premiere', fields['Premiere'] || ''],
            ['Episodes', fields['Episodes'] || ''],
            ['Killed by',fields['Killed by']|| ''],
            ['Finale',   fields['Finale']   || ''],
            ['Legacy',   fields['Legacy']   || ''],
        ].filter(([, v]) => v);

        const rowsHtml = rows.map(([k, v]) =>
            `<tr><td class="e64-cs-key">${esc(k)}</td><td class="e64-cs-val">${esc(v)}</td></tr>`
        ).join('');

        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--cancel-sim">
                ${avatarImg()}
                <div class="echo64-msg-bubble echo64-cancel-sim-card">
                    <div class="e64-cs-header">
                        <span class="e64-cs-title">CANCELLATION SIMULATOR</span>
                        <span class="e64-cs-divider">══════════════════════</span>
                    </div>
                    <table class="e64-cs-table">${rowsHtml}</table>
                    ${verdict ? `<div class="e64-cs-verdict"><span class="e64-cs-verdict-label">ECHO-64 VERDICT</span><p>${esc(verdict)}</p></div>` : ''}
                    <div class="echo64-bubble-actions" style="margin-top:10px">
                        <button class="echo64-copy-btn" type="button">Copy</button>
                    </div>
                </div>
            </div>`
        );
    }

    // ── v1.4.0  PETSCII Art block renderer ───────────────────────────────
    // Detects [ART]...[/ART] tagged blocks and renders them in monospace phosphor.

    function renderPetsciiBlocks(html) {
        // html is already escaped, so we look for [ART]/[/ART] in the escaped content
        // We work on raw text first (before escaping via formatBotText)
        return html;
    }

    /**
     * Pre-processes raw bot text before formatting.
     * Extracts [ART]...[/ART] blocks, escapes + wraps them as <pre class="echo64-petscii">,
     * and replaces the original tags with a placeholder so formatBotText doesn't touch them.
     */
    function extractPetscii(raw) {
        const blocks = [];
        const cleaned = raw.replace(/\[ART\]([\s\S]*?)\[\/ART\]/gi, (_, content) => {
            const idx = blocks.length;
            blocks.push(content.trim());
            return `\x00PETSCII_${idx}\x00`;
        });
        return { cleaned, blocks };
    }

    function injectPetscii(html, blocks) {
        if (!blocks.length) return html;
        return html.replace(/\x00PETSCII_(\d+)\x00/g, (_, idx) => {
            const art = blocks[parseInt(idx, 10)] || '';
            return `<pre class="echo64-petscii" aria-label="ASCII art">${esc(art)}</pre>`;
        });
    }

    // ── v1.2.0  D20 Roll Counter ──────────────────────────────────────────
    // Tracked per calendar day in localStorage.

    const D20_KEY = 'echo64_d20_';

    function todayKey() {
        const d = new Date();
        return D20_KEY + d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
    }

    function getD20Count() {
        return parseInt(localStorage.getItem(todayKey()) || '0', 10);
    }

    function incrementD20() {
        const n = getD20Count() + 1;
        localStorage.setItem(todayKey(), String(n));
        return n;
    }

    // ── v1.2.0  Status Bar ───────────────────────────────────────────────
    // Fake-but-fun live metrics strip below the header.

    function initStatusBar($container) {
        const $sig = $container.find('#e64-signal');

        function updateSignal() {
            const sig = computeSignal();
            $sig.text(`SIGNAL: ${sig}%`).addClass('e64-signal-pulse');
            setTimeout(() => $sig.removeClass('e64-signal-pulse'), 600);
        }

        updateSignal();

        // Return updater so sendMessage can trigger it
        return { updateSignal };
    }

    // ── v1.2.0  Rotating Input Placeholder ──────────────────────────────

    const PLACEHOLDERS = [
        'Insert command...',
        'Transmit on encrypted channel…',
        'Query the mainframe…',
        'READY.',
        'Speak, traveler…',
        'Awaiting input, human.',
        'Type /help for commands.',
        'Signal open…',
    ];

    function startPlaceholderRotation($input) {
        let idx = 0;
        setInterval(() => {
            if (document.activeElement === $input[0]) return; // don't rotate while typing
            idx = (idx + 1) % PLACEHOLDERS.length;
            $input.attr('placeholder', PLACEHOLDERS[idx]);
        }, 4200);
    }

    // ── v1.2.0  Roll for Initiative ──────────────────────────────────────
    // Loads a random D&D/sci-fi crossover prompt into the input.

    const DND_PROMPTS = [
        'Best sci-fi setting to run a D&D campaign in — defend it.',
        'Which sci-fi villain would make the most terrifying BBEG?',
        'Which sci-fi species would be most broken as a D&D player race?',
        'A beholder walks into a sci-fi setting. What job does it have?',
        'Which cancelled sci-fi show would have the best tabletop sourcebook?',
        'Rate the Jedi Order on the D&D alignment chart.',
        'My warlock just made a deal with something that might be a rogue AI. What did it offer?',
        'My party just found a cassette tape labeled "ECHO-64" in a dungeon. What happens?',
        'The Millennium Falcon, the TARDIS, or Moya — which runs D&D modules better?',
        'Best spell school for a character who thinks they\'re living in a simulation?',
        'Which sci-fi crew would survive the longest in a classic dungeon crawl?',
        'What would the Monster Manual entry for a Network Executive look like?',
    ];

    // ── v1.2.0  Amber Phosphor Toggle ───────────────────────────────────

    const AMBER_KEY = 'echo64_amber';

    function initAmberToggle($container) {
        const $btn = $container.find('.echo64-amber-btn');
        const stored = localStorage.getItem(AMBER_KEY) === '1';
        if (stored) {
            $container.find('.echo64-chat-container').addClass('echo64-chat-container--amber');
            $btn.addClass('echo64-amber-btn--active').attr('aria-pressed', 'true');
        }
        $btn.on('click', function () {
            const $chat = $container.find('.echo64-chat-container');
            const on = $chat.hasClass('echo64-chat-container--amber');
            $chat.toggleClass('echo64-chat-container--amber', !on);
            $btn.toggleClass('echo64-amber-btn--active', !on).attr('aria-pressed', String(!on));
            localStorage.setItem(AMBER_KEY, on ? '0' : '1');
        });
    }

    // ── Core chat logic ──────────────────────────────────────────────────

    function initChat($container) {
        const $msgs  = $container.find('#echo64-messages');
        const $input = $container.find('#echo64-input');
        const $send  = $container.find('#echo64-send');
        const $clear = $container.find('.echo64-clear-btn');
        let sending  = false;

        // Status bar, placeholder rotation, amber toggle
        const { updateSignal } = initStatusBar($container);
        startPlaceholderRotation($input);
        initAmberToggle($container);

        // v1.4.0 — remaining transmissions footer note
        const dailyLimit = parseInt(String(cfg.dailyLimit || '9'), 10);
        const $footer = $container.find('.echo64-input-footer-note');

        function updateRemainingNote(remaining) {
            if (!$footer.length || dailyLimit <= 0 || remaining < 0) return;
            if (remaining <= 3) {
                $footer.text(`${remaining} transmission${remaining === 1 ? '' : 's'} remaining today`).addClass('echo64-footer-note--warn');
            } else {
                $footer.text(`${remaining} of ${dailyLimit} transmissions remaining today`).removeClass('echo64-footer-note--warn');
            }
            $footer.show();
        }

        $input.on('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 140) + 'px';
            $send.prop('disabled', !this.value.trim());
        });

        $input.on('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!sending && this.value.trim()) sendMessage(); }
        });

        $send.on('click', () => { if (!sending && $input.val().trim()) sendMessage(); });

        $clear.on('click', function () {
            if (!confirm('Start a fresh conversation with Echo-64?')) return;
            $.post(cfg.ajaxUrl, { action:'echo64_clear', nonce:cfg.nonce })
                .always(() => { $msgs.empty(); sessionStorage.removeItem('e64_booted'); runBootAnimation($container, doInit); });
        });

        // ── Send ───────────────────────────────────────────────────────

        function sendMessage() {
            const text = $input.val().trim();
            if (!text || sending) return;

            // #9 — intercept terminal commands client-side (no API call)
            const cmdResult = handleCommand(text);
            if (cmdResult !== null) {
                $msgs.append(buildUserBubble(text));
                $input.val('').css('height', '');
                $send.prop('disabled', true);

                if (cmdResult === 'REBOOT') {
                    sessionStorage.removeItem('e64_booted');
                    setTimeout(() => {
                        $msgs.empty();
                        runBootAnimation($container, doInit);
                    }, 300);
                } else {
                    setTimeout(() => {
                        $msgs.append(buildCommandBubble(cmdResult));
                        scrollToBottom($msgs);
                        $send.prop('disabled', !$input.val().trim());
                        $input.focus();
                    }, 400);
                }
                return;
            }

            // v1.4.0 — /cancel [premise] → Network Cancellation Simulator
            let apiMessage = text;
            const cancelMatch = text.match(/^\/cancel\s+(.+)/si);
            if (cancelMatch) {
                apiMessage = '[CANCEL_SIM]' + cancelMatch[1].trim();
            }

            sending = true;
            $send.prop('disabled', true);
            $input.val('').css('height', '');
            $msgs.find('.echo64-starters').remove(); // chips gone once user types

            $msgs.append(buildUserBubble(text));
            const $typing = buildTypingIndicator();
            $msgs.append($typing);
            scrollToBottom($msgs);

            $.post(cfg.ajaxUrl, { action:'echo64_send', nonce:cfg.nonce, message:apiMessage })
            .done(res => {
                $typing.remove();
                if (res.success) {
                    $msgs.append(buildBotBubble(res.data.message));
                    // v1.4.0 — update signal + remaining note
                    incrementTotalMsgs();
                    updateSignal();
                    if (typeof res.data.remaining !== 'undefined') {
                        updateRemainingNote(res.data.remaining);
                    }
                } else {
                    // v1.4.0 — daily limit gate
                    if (res.data?.code === 'daily_limit') {
                        $msgs.append(buildDailyLimitBubble());
                        $send.prop('disabled', true);
                        $input.prop('disabled', true).attr('placeholder', 'Frequency closed until midnight.');
                        updateRemainingNote(0);
                    } else {
                        $msgs.append(buildError(res.data?.message || 'Echo-64 is offline.'));
                    }
                }
            })
            .fail(() => { $typing.remove(); $msgs.append(buildError('Transmission lost. Try again.')); })
            .always(() => {
                sending = false;
                if (!$input.prop('disabled')) {
                    $send.prop('disabled', !$input.val().trim());
                    $input.focus();
                }
                scrollToBottom($msgs);
            });
        }

        // ── Opening sequence ───────────────────────────────────────────

        function renderOpeningSequence(openingLine, poem) {
            $msgs.append(buildBotBubble(openingLine));
            scrollToBottom($msgs);
            if (poem) {
                // v1.5.0 — single column, poem always in message stream
                setTimeout(() => {
                    $msgs.append(buildPoemBubble(poem));
                    setTimeout(() => {
                        $msgs.append(buildStarterChips($input, sendMessage));
                        scrollToBottom($msgs);
                    }, 600);
                    scrollToBottom($msgs);
                }, 500);
            }
        }

        // ── Daily poem refresh ─────────────────────────────────────────

        function fetchDailyPoem() {
            // v1.5.0 — always in message stream (no poem panel)
            const $t = buildTypingIndicator();
            $msgs.append($t);
            scrollToBottom($msgs);

            $.post(cfg.ajaxUrl, { action:'echo64_send', nonce:cfg.nonce, message:"[NEW_DAY] New day. Deliver today's Poem of the Day and Today's Challenge only. No greeting." })
            .done(res => {
                $msgs.find('.echo64-msg--typing').remove();
                if (res.success) $msgs.append(buildPoemBubble(res.data.message));
            })
            .fail(() => $msgs.find('.echo64-msg--typing').remove())
            .always(() => scrollToBottom($msgs));
        }

        // ── Boot ───────────────────────────────────────────────────────

        const TIMEOUT_MSGS = [
            'Signal lost. The 64k barrier claims another victim. Reload to try again.',
            'Boot sequence timed out. Even cassette tapes loaded faster than this.',
            'No response. Check your API key under Settings → Echo-64 Chatbot.',
            'Transmission timeout. Something between here and the API is not cooperating.',
        ];

        function doInit() {
            const $loader = $('<div class="echo64-loading-init"><div class="echo64-typing-indicator"><span></span><span></span><span></span></div><p>Booting Echo-64&hellip;</p></div>');
            $msgs.append($loader);

            $.ajax({ url: cfg.ajaxUrl, method: 'POST', data: { action:'echo64_init', nonce:cfg.nonce }, timeout: 20000 })
            .done(res => {
                $loader.remove();
                if (!res.success) { $msgs.append(buildError(res.data?.message || 'Boot sequence failed.')); return; }
                const d = res.data;
                // v1.4.0 — show remaining TX on any init response
                if (typeof d.remaining !== 'undefined') {
                    updateRemainingNote(d.remaining);
                    if (d.remaining === 0) {
                        $send.prop('disabled', true);
                        $input.prop('disabled', true).attr('placeholder', 'Frequency closed until midnight.');
                    }
                }

                if (d.new_session) {
                    // #21 — track session count + check for new badge
                    const oldCount = getSessionCount();
                    const newCount = incrementSessionCount();
                    renderBadge($container, getCurrentBadge(newCount));
                    const newBadge = checkNewBadge(oldCount, newCount);
                    if (newBadge) setTimeout(() => showBadgeUnlock($msgs, newBadge), 2000);

                    renderOpeningSequence(d.opening_line, d.poem);
                } else if (d.daily_refresh) {
                    $msgs.append(buildDivider('New Day · New Transmission'));
                    setTimeout(fetchDailyPoem, 400);
                } else {
                    renderBadge($container, getCurrentBadge(getSessionCount()));
                    $msgs.append(buildReturnGreeting(d.last_topic || ''));
                    setTimeout(() => { $msgs.append(buildStarterChips($input, sendMessage)); scrollToBottom($msgs); }, 400);
                }
                scrollToBottom($msgs);
            })
            .fail((xhr, status) => {
                $loader.remove();
                const msg = status === 'timeout' ? rand(TIMEOUT_MSGS) : 'Transmission failed. Check Settings → Echo-64 Chatbot → API key.';
                $msgs.append(buildError(msg));
                if (status === 'timeout') {
                    const $r = $('<button class="echo64-retry-btn" type="button">↺ Retry boot sequence</button>');
                    $r.on('click', () => { $r.remove(); $msgs.find('.echo64-error').last().remove(); doInit(); });
                    $msgs.append($r);
                }
            })
            .always(() => { $send.prop('disabled', !$input.val().trim()); $input.focus(); });
        }

        // ── Entry point — boot animation first, then init ─────────────
        runBootAnimation($container, () => {
            playSidChip();   // #19 — SID tone after boot completes
            doInit();
        });
    }

    // ── Floating Widget ──────────────────────────────────────────────────

    function initFloat() {
        const $launcher = $('#echo64-float-launcher');
        const $panel    = $('#echo64-float-panel');
        if (!$launcher.length || !$panel.length) return;

        $launcher.append('<span class="echo64-badge" aria-hidden="true"></span>');
        let chatReady = false;

        $launcher.on('click', () => {
            const isOpen = !$panel.attr('hidden');
            if (isOpen) { $panel.attr('hidden', ''); $launcher.attr('aria-expanded', 'false'); }
            else {
                $panel.removeAttr('hidden'); $launcher.attr('aria-expanded','true').removeClass('has-unread');
                if (!chatReady) { chatReady = true; initChat($panel); }
                setTimeout(() => $panel.find('#echo64-input').focus(), 80);
            }
        });

        $(document).on('keydown', e => {
            if (e.key === 'Escape' && !$panel.attr('hidden')) { $panel.attr('hidden',''); $launcher.attr('aria-expanded','false').focus(); }
        });

        setTimeout(() => { if ($panel.attr('hidden') !== undefined) $launcher.addClass('has-unread'); }, 3000);
    }

    // ── Bootstrap ────────────────────────────────────────────────────────

    $(function () {
        $('.echo64-chat-container').not('#echo64-float-panel .echo64-chat-container').each(function () { initChat($(this)); });
        if (String(cfg.isFloating) === '1') initFloat();
    });

}(jQuery));
