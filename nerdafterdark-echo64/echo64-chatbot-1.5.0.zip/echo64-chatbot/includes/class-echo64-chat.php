<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class Echo64_Chat {

    private static ?Echo64_Chat $instance = null;
    private Echo64_Api $api;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = new Echo64_Api();
        add_shortcode( 'echo64_chat',                [ $this, 'render_shortcode' ] );
        add_shortcode( 'echo64_transmissions',       [ $this, 'render_transmissions_shortcode' ] );
        add_action( 'wp_enqueue_scripts',             [ $this, 'enqueue_assets' ] );
        add_action( 'wp_footer',                      [ $this, 'maybe_render_floating_widget' ] );
        add_action( 'wp_ajax_echo64_send',            [ $this, 'ajax_send' ] );
        add_action( 'wp_ajax_nopriv_echo64_send',     [ $this, 'ajax_send' ] );
        add_action( 'wp_ajax_echo64_clear',           [ $this, 'ajax_clear' ] );
        add_action( 'wp_ajax_nopriv_echo64_clear',    [ $this, 'ajax_clear' ] );
        add_action( 'wp_ajax_echo64_init',            [ $this, 'ajax_init' ] );
        add_action( 'wp_ajax_nopriv_echo64_init',     [ $this, 'ajax_init' ] );
        add_action( 'wp_ajax_echo64_react',           [ $this, 'ajax_react' ] );
        add_action( 'wp_ajax_nopriv_echo64_react',    [ $this, 'ajax_react' ] );
    }

    public function enqueue_assets(): void {
        wp_enqueue_style(
            'echo64-chat',
            ECHO64_PLUGIN_URL . 'assets/css/echo64-chat.css',
            [],
            ECHO64_VERSION
        );

        wp_enqueue_script(
            'echo64-chat',
            ECHO64_PLUGIN_URL . 'assets/js/echo64-chat.js',
            [ 'jquery' ],
            ECHO64_VERSION,
            true
        );

        $daily_limit = (int) get_option( 'echo64_daily_limit', 9 );

        wp_localize_script( 'echo64-chat', 'echo64Config', [
            'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'echo64_nonce' ),
            'avatarUrl'   => ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png',
            'isFloating'  => get_option( 'echo64_float_widget', '0' ),
            'sidAudio'    => get_option( 'echo64_sid_audio', '0' ),
            'dailyLimit'  => $daily_limit,
        ] );
    }

    public function render_shortcode( array $atts ): string {
        ob_start();
        include ECHO64_PLUGIN_DIR . 'templates/chat-widget.php';
        return ob_get_clean();
    }

    // ── v1.4.0  Lost Transmissions shortcode ──────────────────────────────

    public function render_transmissions_shortcode( array $atts ): string {
        $essays = get_option( 'echo64_essay_archive', [] );
        if ( empty( $essays ) ) {
            return '<p style="font-family:Courier New,monospace;color:#555570">NO TRANSMISSIONS RECOVERED.</p>';
        }
        $out = '<div class="echo64-transmissions">';
        foreach ( array_reverse( $essays ) as $e ) {
            $date  = esc_html( $e['date'] ?? '' );
            $show  = esc_html( $e['show'] ?? '' );
            $essay = nl2br( esc_html( $e['essay'] ?? '' ) );
            $out  .= "<div class='echo64-transmission-entry'>
                <div class='echo64-tx-meta'>{$date} &nbsp;·&nbsp; {$show}</div>
                <div class='echo64-tx-body'>{$essay}</div>
            </div>";
        }
        $out .= '</div>';
        return $out;
    }

    public function maybe_render_floating_widget(): void {
        if ( get_option( 'echo64_float_widget', '0' ) !== '1' ) {
            return;
        }
        echo '<div id="echo64-float-launcher" aria-label="Open Echo-64 Chat">';
        echo '<img src="' . esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ) . '" alt="Echo-64" />';
        echo '</div>';
        echo '<div id="echo64-float-panel" role="dialog" aria-modal="true" aria-label="Echo-64 Chat" hidden>';
        include ECHO64_PLUGIN_DIR . 'templates/chat-widget.php';
        echo '</div>';
    }

    public function ajax_init(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );

        $session_id  = Echo64_Session::get_session_id();
        $is_new      = Echo64_Session::is_new_session( $session_id );
        $daily_limit = (int) get_option( 'echo64_daily_limit', 9 );
        $remaining   = $daily_limit > 0
            ? max( 0, $daily_limit - Echo64_Session::get_daily_tx_count( $session_id ) )
            : -1;

        if ( ! $is_new ) {
            $needs_daily_refresh = Echo64_Session::needs_daily_refresh( $session_id );
            $last_topic          = Echo64_Session::get_last_user_message( $session_id );
            wp_send_json_success( [
                'new_session'   => false,
                'daily_refresh' => $needs_daily_refresh,
                'last_topic'    => $last_topic,
                'remaining'     => $remaining,
                'limit'         => $daily_limit,
            ] );
            return;
        }

        $system_prompt = get_option( 'echo64_system_prompt', Echo64_Api::DEFAULT_SYSTEM_PROMPT )
                        . Echo64_Calendar::get_todays_context();

        $messages = [
            [ 'role' => 'user', 'content' => Echo64_Api::INIT_TRIGGER ],
        ];

        $poem_and_challenge = $this->api->send_message( $messages, $system_prompt );

        if ( is_wp_error( $poem_and_challenge ) ) {
            wp_send_json_error( [ 'message' => $poem_and_challenge->get_error_message() ] );
            return;
        }

        $full_opening = Echo64_Api::OPENING_LINE . "\n\n" . $poem_and_challenge;
        Echo64_Session::save_message( $session_id, 'user',      Echo64_Api::INIT_TRIGGER );
        Echo64_Session::save_message( $session_id, 'assistant', $full_opening );
        Echo64_Session::mark_daily_refresh( $session_id );

        wp_send_json_success( [
            'new_session'  => true,
            'opening_line' => Echo64_Api::OPENING_LINE,
            'poem'         => $poem_and_challenge,
            'remaining'    => $remaining,
            'limit'        => $daily_limit,
        ] );
    }

    public function ajax_send(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );

        $user_message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );

        if ( empty( $user_message ) ) {
            wp_send_json_error( [ 'message' => 'Empty message.' ] );
            return;
        }

        if ( mb_strlen( $user_message ) > 2000 ) {
            wp_send_json_error( [ 'message' => 'Message too long.' ] );
            return;
        }

        $session_id  = Echo64_Session::get_session_id();
        $daily_limit = (int) get_option( 'echo64_daily_limit', 9 );

        // ── v1.4.0  Daily Transmission Limit ─────────────────────────────
        if ( $daily_limit > 0 ) {
            $daily_count = Echo64_Session::get_daily_tx_count( $session_id );
            if ( $daily_count >= $daily_limit ) {
                wp_send_json_error( [
                    'code'    => 'daily_limit',
                    'message' => 'DAILY_LIMIT',
                    'limit'   => $daily_limit,
                ] );
                return;
            }
        }

        // ── v1.4.0  Cancellation Simulator ───────────────────────────────
        $is_cancel_sim = str_starts_with( $user_message, '[CANCEL_SIM]' );

        if ( $is_cancel_sim ) {
            $premise       = trim( substr( $user_message, strlen( '[CANCEL_SIM]' ) ) );
            $system_prompt = Echo64_Api::CANCEL_SIM_PROMPT;
            $messages      = [ [ 'role' => 'user', 'content' => $premise ] ];
        } else {
            $limit         = (int) get_option( 'echo64_history_limit', 20 );
            $history       = Echo64_Session::get_history( $session_id, $limit );
            $system_prompt = get_option( 'echo64_system_prompt', Echo64_Api::DEFAULT_SYSTEM_PROMPT )
                            . Echo64_Calendar::get_todays_context()
                            . Echo64_Api::PETSCII_INJECT;    // v1.4.0 PETSCII art
            $messages      = $history;
            $messages[]    = [ 'role' => 'user', 'content' => $user_message ];
        }

        $reply = $this->api->send_message( $messages, $system_prompt );

        if ( is_wp_error( $reply ) ) {
            wp_send_json_error( [ 'message' => $reply->get_error_message() ] );
            return;
        }

        // Save to history — cancel sim is ephemeral and not persisted
        if ( ! $is_cancel_sim ) {
            Echo64_Session::save_message( $session_id, 'user',      $user_message );
            Echo64_Session::save_message( $session_id, 'assistant', $reply );
        }

        // Increment counter and compute remaining
        $new_count = ( $daily_limit > 0 ) ? Echo64_Session::increment_daily_tx( $session_id ) : 0;
        $remaining = ( $daily_limit > 0 ) ? max( 0, $daily_limit - $new_count ) : -1;

        wp_send_json_success( [
            'message'    => $reply,
            'remaining'  => $remaining,
            'limit'      => $daily_limit,
            'cancel_sim' => $is_cancel_sim,
        ] );
    }

    public function ajax_clear(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );
        $session_id = Echo64_Session::get_session_id();
        Echo64_Session::clear_session( $session_id );
        wp_send_json_success();
    }

    public function ajax_react(): void {
        check_ajax_referer( 'echo64_nonce', 'nonce' );

        $question = sanitize_textarea_field( wp_unslash( $_POST['question'] ?? '' ) );
        $vote     = sanitize_key( $_POST['vote'] ?? '' );

        if ( empty( $question ) || ! in_array( $vote, [ 'agree', 'disagree' ], true ) ) {
            wp_send_json_error();
            return;
        }

        $hash     = 'echo64_rx_' . md5( $question );
        $vote_key = 'echo64_voted_' . md5( $question ) . '_' . Echo64_Session::get_session_id();

        if ( get_transient( $vote_key ) ) {
            $counts = get_option( $hash, [ 'agree' => 0, 'disagree' => 0 ] );
            wp_send_json_success( [ 'counts' => $counts, 'already_voted' => true ] );
            return;
        }

        $counts          = get_option( $hash, [ 'agree' => 0, 'disagree' => 0 ] );
        $counts[ $vote ] = ( (int) ( $counts[ $vote ] ?? 0 ) ) + 1;
        update_option( $hash, $counts, false );
        set_transient( $vote_key, '1', 30 * DAY_IN_SECONDS );

        wp_send_json_success( [ 'counts' => $counts, 'already_voted' => false ] );
    }
}
