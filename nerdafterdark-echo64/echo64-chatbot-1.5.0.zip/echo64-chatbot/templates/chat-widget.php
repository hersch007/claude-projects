<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$sid_enabled = get_option( 'echo64_sid_audio', '0' );
?>
<div class="echo64-chat-wrapper">
<div class="echo64-monitor-frame">
<div class="echo64-chat-container" id="echo64-chat" role="region" aria-label="Echo-64 Chat"
     data-sid="<?php echo esc_attr( $sid_enabled ); ?>">

    <!-- ── Header ─────────────────────────────────────────── -->
    <div class="echo64-chat-header">

        <!-- Left: title block -->
        <div class="echo64-header-left">
            <div class="echo64-name-row">
                <div class="echo64-avatar-wrap">
                    <img src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                         alt="Echo-64" class="echo64-avatar" title="READY." />
                    <span class="echo64-status-dot" aria-hidden="true"></span>
                </div>
                <span class="echo64-name">Echo-64</span>
            </div>
            <div class="echo64-subtitle-row">
                <span class="echo64-tagline">SCI-FI AFTER MIDNIGHT</span>
                <span class="echo64-tagline-sep">&middot;</span>
                <span class="echo64-tagline">1984 TRANSMISSIONS</span>
            </div>
            <!-- Achievement badge slot — populated by JS -->
            <div class="echo64-badge-slot" aria-live="polite"></div>
        </div>

        <!-- Right: live stats + controls -->
        <div class="echo64-header-right">
            <!-- Stats -->
            <div class="echo64-header-stats" aria-hidden="true">
                <span class="e64-hstat e64-hstat--signal" id="e64-signal">SIGNAL: ---</span>
                <span class="e64-hstat e64-hstat--shows">CANCELLED SHOWS: 47</span>
            </div>
            <!-- Controls -->
            <div class="echo64-header-actions">
                <button type="button" class="echo64-amber-btn"
                        title="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                        aria-label="<?php esc_attr_e( 'Toggle amber phosphor mode', 'echo64-chatbot' ); ?>"
                        aria-pressed="false">
                    <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
                        <circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" stroke-width="1.3"/>
                        <circle cx="6.5" cy="6.5" r="2.5" fill="currentColor"/>
                    </svg>
                </button>
                <button type="button" class="echo64-clear-btn"
                        title="<?php esc_attr_e( 'New conversation', 'echo64-chatbot' ); ?>"
                        aria-label="<?php esc_attr_e( 'Start new conversation', 'echo64-chatbot' ); ?>">
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                        <path d="M13.5 2.5L2.5 13.5M2.5 2.5L13.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
        </div>

    </div><!-- /.echo64-chat-header -->

    <!-- ── Messages ──────────────────────────────────────── -->
    <div class="echo64-messages" id="echo64-messages"
         role="log" aria-live="polite" aria-atomic="false"></div>

    <!-- ── Input area ─────────────────────────────────────── -->
    <div class="echo64-input-area">
        <div class="echo64-input-row">
            <textarea
                id="echo64-input"
                class="echo64-input"
                placeholder="Insert command..."
                rows="1"
                maxlength="2000"
                aria-label="<?php esc_attr_e( 'Message Echo-64', 'echo64-chatbot' ); ?>"
                spellcheck="false"
            ></textarea>
            <button type="button" id="echo64-send" class="echo64-send-btn"
                    aria-label="<?php esc_attr_e( 'Transmit message', 'echo64-chatbot' ); ?>" disabled>
                <span class="echo64-send-label">TRANSMIT</span>
            </button>
        </div>
        <p class="echo64-footer-note">NERDAFTERDARK.COM &middot; RETRO FUTURES &amp; SARCASTIC TRUTHS</p>
        <p class="echo64-footer-note echo64-input-footer-note" style="display:none" aria-live="polite"></p>
    </div>

</div><!-- /.echo64-chat-container -->
</div><!-- /.echo64-monitor-frame -->
</div><!-- /.echo64-chat-wrapper -->
