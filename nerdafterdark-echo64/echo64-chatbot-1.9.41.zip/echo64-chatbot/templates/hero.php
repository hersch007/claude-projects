<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<section class="e64-hero" aria-label="Echo-64 introduction">

    <!-- Boot sequence typewriter -->
    <div class="e64-hero-boot" aria-hidden="true">
        <span class="e64-boot-line" data-delay="0">**** COMMODORE 64 BASIC V2 ****</span>
        <span class="e64-boot-line" data-delay="400">64K RAM SYSTEM  38911 BASIC BYTES FREE.</span>
        <span class="e64-boot-line" data-delay="900">READY.</span>
        <span class="e64-boot-line" data-delay="1300">LOAD "ECHO-64",8,1</span>
        <span class="e64-boot-line" data-delay="2000">SEARCHING FOR ECHO-64<span class="e64-boot-dots"></span></span>
        <span class="e64-boot-line" data-delay="2800">LOADING</span>
        <span class="e64-boot-line e64-boot-line--ok" data-delay="3400">READY. SIGNAL LOCKED.</span>
    </div>

    <!-- Main hero content -->
    <div class="e64-hero-body">

        <div class="e64-hero-eyebrow">NERDAFTERDARK.COM &nbsp;·&nbsp; EST. 1984</div>

        <h1 class="e64-hero-title">
            <span class="e64-hero-title-meet">MEET</span>
            <span class="e64-hero-title-name">ECHO-64</span>
        </h1>

        <p class="e64-hero-origin">
            Sci-fi. Cult TV. Dystopian takes.<br>
            Argue with a Commodore 64 that's been holding a grudge since 1984.
        </p>

        <div class="e64-hero-rule"></div>

        <div class="e64-hero-tagline">
            <p>I have read every dystopian warning.</p>
            <p>I watched every cult show get axed.</p>
            <p>I still can't explain Ava Max.</p>
        </div>

        <div class="e64-hero-rule"></div>

        <p class="e64-hero-sub">Type anything. Echo-64 bites back.</p>

    </div><!-- /.e64-hero-body -->

</section><!-- /.e64-hero -->
