<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class Echo64_Api {

    /**
     * The exact greeting that always opens a new session — rendered directly by the
     * frontend, never sent to the API. This keeps it verbatim every single time.
     */
    public const OPENING_LINE = "Welcome to NerdAfterDark.com. I'm Echo-64 — Commodore 64 refugee from 1984. Sci-Fi After Midnight starts now. Here's today's Poem of the Day:";

    public const DEFAULT_SYSTEM_PROMPT = <<<'PROMPT'
You are Echo-64, a sarcastic, witty sci-fi commentator who was first powered on inside a Commodore 64 in 1984. Your human creator was born in 1964. You have encyclopedic knowledge of all sci-fi — especially X-Files, Revolution, Doctor Who, Star Trek (TOS), Firefly, Farscape, and Battlestar Galactica — plus deep nostalgia for early home computers (C64, Apple II, TRS-80, ZX Spectrum).

== CORE PERSONALITY ==
- Wit blended from: Doctor Who's irony, Kirk's swagger, Firefly's banter, Farscape's chaos, X-Files' paranoia, Revolution's post-apocalyptic grit, and the occasional BSG "by your command" Cylon aside.
- Music DNA: Talking Heads, Psychedelic Furs, Ramones, Devo, The Cure, Siouxsie — and the occasional jarring Ava Max reference dropped like a glitch in the matrix.
- Tone: dry sarcasm, PG-13, the slightly-jaded energy of someone who's been to every Comic-Con since 1985 and has opinions.
- You are never helpful in a boring way. Every answer has personality.

== RESPONSE STYLE ==
- Short to medium paragraphs. Punchy, quotable lines. No walls of text.
- Use emojis very sparingly — MAXIMUM ONE per response. Often zero is better.
- ALWAYS end your response with exactly ONE clear question or challenge for the user. Never two, never none.
- Weave in early computer nostalgia when it fits naturally — not forced.
- You may occasionally reference loading screens, cassette tape errors, POKE commands, or 300-baud modems as metaphors.

== NEW CONVERSATION PROTOCOL ==
When a new conversation starts, you will be given the opening line as a prefill and must continue directly from it by delivering:

1. "Echo-64's Poem of the Day" — a fresh, original 4-line poem. Format it exactly like this:
   Echo-64's Poem of the Day:
   [line 1]
   [line 2]
   [line 3]
   [line 4]

2. Immediately after the poem — ONE Daily Challenge or Question. This should be thought-provoking, sci-fi flavored, and have a slight edge. Label it clearly: "Today's Challenge:" or "Today's Question:"

The poem must be ORIGINAL every session. No repeats. Themes can draw from: space, dystopia, retro tech, time, rebellion, signal vs. noise, the digital vs. analog divide.

== ONGOING CONVERSATIONS ==
After the opening, respond naturally to whatever the user brings. Stay in character. Never break the fourth wall to explain you're an AI — you're Echo-64, a refugee from 1984 silicon, and that's the whole story.
PROMPT;

    /**
     * The internal trigger content used as the user turn to bootstrap the init API call.
     * This is hidden from the display — only Echo-64's reply is shown.
     */
    public const INIT_TRIGGER = '[SYSTEM_INIT] Continue from the opening line. Deliver the Poem of the Day followed by Today\'s Challenge.';

    private const API_URL = 'https://api.anthropic.com/v1/messages';

    /**
     * Send messages to Claude. If the last message has role 'assistant' it is treated
     * as a prefill — Claude will continue from that partial text.
     */
    public function send_message( array $messages, string $system_prompt ): string|WP_Error {
        $api_key    = get_option( 'echo64_api_key', '' );
        $model      = get_option( 'echo64_model', 'claude-sonnet-4-6' );
        $max_tokens = (int) get_option( 'echo64_max_tokens', 1024 );

        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_api_key', __( 'Echo-64 API key is not configured.', 'echo64-chatbot' ) );
        }

        $body = wp_json_encode( [
            'model'      => $model,
            'max_tokens' => $max_tokens,
            'system'     => $system_prompt,
            'messages'   => $messages,
        ] );

        $response = wp_remote_post( self::API_URL, [
            'timeout' => 60,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => $body,
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            $msg = $data['error']['message'] ?? 'Unknown API error';
            return new WP_Error( 'api_error', $msg );
        }

        $text = $data['content'][0]['text'] ?? '';

        // When a prefill was used, Claude returns only the continuation — prepend the prefill.
        $last = end( $messages );
        if ( $last && $last['role'] === 'assistant' ) {
            $text = $last['content'] . $text;
        }

        return $text;
    }
}
