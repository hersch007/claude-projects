/* ============================================================
   Echo-64 Chatbot — Frontend
   NerdAfterDark.com · Sci-Fi After Midnight
   ============================================================ */
(function ($) {
    'use strict';

    const cfg = window.echo64Config || {};

    // ── Utilities ─────────────────────────────────────────────────────────

    const esc = (str) => {
        const m = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(str).replace(/[&<>"']/g, c => m[c]);
    };

    function formatBotText(raw) {
        return '<p>' + esc(raw)
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g,     '<em>$1</em>')
            .replace(/\n{2,}/g, '</p><p>')
            .replace(/\n/g, '<br>')
            + '</p>';
    }

    function scrollToBottom($el) {
        $el.scrollTop($el[0].scrollHeight);
    }

    // ── Message Builders ──────────────────────────────────────────────────

    function avatarImg() {
        return `<img src="${esc(cfg.avatarUrl)}" alt="Echo-64" class="echo64-msg-avatar" />`;
    }

    function buildBotBubble(content) {
        return $(
            `<div class="echo64-msg echo64-msg--bot">
                ${avatarImg()}
                <div class="echo64-msg-bubble">${formatBotText(content)}</div>
            </div>`
        );
    }

    function buildUserBubble(content) {
        return $(
            `<div class="echo64-msg echo64-msg--user">
                <div class="echo64-msg-avatar">👤</div>
                <div class="echo64-msg-bubble">${esc(content)}</div>
            </div>`
        );
    }

    /**
     * Renders the opening poem + challenge in a distinct card bubble.
     * Tries to detect poem lines vs. the challenge section automatically.
     */
    function buildPoemBubble(raw) {
        const lines  = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        let poemLines   = [];
        let challengeLabel = '';
        let challengeText  = [];
        let inChallenge    = false;

        for (const line of lines) {
            // Skip the "Echo-64's Poem of the Day:" header if Claude echoes it
            if (/echo.?64.?s?\s+poem/i.test(line)) continue;

            if (/^today.?s\s+(challenge|question)\s*:/i.test(line)) {
                inChallenge    = true;
                challengeLabel = line;
                continue;
            }
            if (inChallenge) {
                challengeText.push(line);
            } else {
                poemLines.push(line);
            }
        }

        // Fallback: if we couldn't split, just render as normal bot bubble
        if (poemLines.length === 0 && challengeText.length === 0) {
            return buildBotBubble(raw);
        }

        const poemHtml = poemLines.length
            ? `<div class="echo64-poem-lines">${poemLines.map(l => `<span>${esc(l)}</span>`).join('')}</div>`
            : '';

        const challengeHtml = challengeText.length
            ? `<span class="echo64-challenge-label">${esc(challengeLabel || "Today's Challenge:")}</span>
               <p class="echo64-challenge-text">${esc(challengeText.join(' '))}</p>`
            : '';

        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--poem">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <span class="echo64-poem-label">Echo-64's Poem of the Day</span>
                    ${poemHtml}
                    ${challengeHtml}
                </div>
            </div>`
        );
    }

    function buildTypingIndicator() {
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--typing">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <div class="echo64-typing">
                        <span></span><span></span><span></span>
                    </div>
                </div>
            </div>`
        );
    }

    function buildError(msg) {
        return $(`<div class="echo64-error">⚠ ${esc(msg)}</div>`);
    }

    function buildDivider(label) {
        return $(
            `<div class="echo64-divider"><span>${esc(label)}</span></div>`
        );
    }

    // ── Core Chat Logic ───────────────────────────────────────────────────

    function initChat($container) {
        const $msgs  = $container.find('#echo64-messages');
        const $input = $container.find('#echo64-input');
        const $send  = $container.find('#echo64-send');
        const $clear = $container.find('.echo64-clear-btn');

        let sending = false;

        // Auto-resize textarea
        $input.on('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
            $send.prop('disabled', !this.value.trim());
        });

        // Enter to send, Shift+Enter for newline
        $input.on('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (!sending && this.value.trim()) sendMessage();
            }
        });

        $send.on('click', function () {
            if (!sending && $input.val().trim()) sendMessage();
        });

        $clear.on('click', function () {
            if (!confirm('Start a fresh conversation with Echo-64?')) return;
            $.post(cfg.ajaxUrl, { action: 'echo64_clear', nonce: cfg.nonce })
                .always(() => { $msgs.empty(); doInit(); });
        });

        // ── Send a user message ────────────────────────────────────────

        function sendMessage() {
            const text = $input.val().trim();
            if (!text || sending) return;

            sending = true;
            $send.prop('disabled', true);
            $input.val('').css('height', '');

            $msgs.append(buildUserBubble(text));
            const $typing = buildTypingIndicator();
            $msgs.append($typing);
            scrollToBottom($msgs);

            $.post(cfg.ajaxUrl, {
                action:  'echo64_send',
                nonce:   cfg.nonce,
                message: text,
            })
            .done(function (res) {
                $typing.remove();
                if (res.success) {
                    $msgs.append(buildBotBubble(res.data.message));
                } else {
                    $msgs.append(buildError(res.data?.message || 'Echo-64 is offline. Check API settings.'));
                }
            })
            .fail(function () {
                $typing.remove();
                $msgs.append(buildError('Transmission error. The 64k barrier strikes again.'));
            })
            .always(function () {
                sending = false;
                $send.prop('disabled', !$input.val().trim());
                scrollToBottom($msgs);
                $input.focus();
            });
        }

        // ── Render opening sequence (new session) ─────────────────────

        function renderOpeningSequence(openingLine, poem) {
            $msgs.append(buildBotBubble(openingLine));
            scrollToBottom($msgs);

            if (poem) {
                // Staggered delay so the poem card appears like Echo-64 typed it
                setTimeout(function () {
                    $msgs.append(buildPoemBubble(poem));
                    scrollToBottom($msgs);
                }, 480);
            }
        }

        // ── Fetch daily poem for returning sessions ────────────────────

        function fetchDailyPoem() {
            const $typing = buildTypingIndicator();
            $msgs.append($typing);
            scrollToBottom($msgs);

            $.post(cfg.ajaxUrl, {
                action:  'echo64_send',
                nonce:   cfg.nonce,
                message: "[NEW_DAY] New day, new transmission. Deliver today's Poem of the Day and Today's Challenge. No preamble.",
            })
            .done(function (res) {
                $typing.remove();
                if (res.success) {
                    $msgs.append(buildPoemBubble(res.data.message));
                }
            })
            .fail(function () { $typing.remove(); })
            .always(function () { scrollToBottom($msgs); });
        }

        // ── Boot sequence ──────────────────────────────────────────────

        function doInit() {
            const $loader = $(
                `<div class="echo64-loading-init">
                    <div class="echo64-typing-indicator">
                        <span></span><span></span><span></span>
                    </div>
                    <p>Booting Echo-64&hellip;</p>
                </div>`
            );
            $msgs.append($loader);

            $.post(cfg.ajaxUrl, { action: 'echo64_init', nonce: cfg.nonce })
            .done(function (res) {
                $loader.remove();

                if (!res.success) {
                    $msgs.append(buildError(res.data?.message || 'Echo-64 boot sequence failed.'));
                    return;
                }

                const d = res.data;

                if (d.new_session) {
                    renderOpeningSequence(d.opening_line, d.poem);

                } else if (d.daily_refresh) {
                    $msgs.append(buildDivider('New Day · New Transmission'));
                    setTimeout(fetchDailyPoem, 400);

                } else {
                    // Returning session, same day
                    $msgs.append(
                        $(`<div class="echo64-msg echo64-msg--bot">
                            ${avatarImg()}
                            <div class="echo64-msg-bubble">
                                <em>Signal locked. Echo-64 back online. Continue&hellip;</em>
                            </div>
                        </div>`)
                    );
                }

                scrollToBottom($msgs);
            })
            .fail(function () {
                $loader.remove();
                $msgs.append(buildError('Transmission failed. Go to Settings → Echo-64 Chatbot and confirm your API key.'));
            })
            .always(function () {
                $send.prop('disabled', !$input.val().trim());
                $input.focus();
            });
        }

        doInit();
    }

    // ── Floating Widget ───────────────────────────────────────────────────

    function initFloat() {
        const $launcher = $('#echo64-float-launcher');
        const $panel    = $('#echo64-float-panel');
        if (!$launcher.length || !$panel.length) return;

        // Add badge element
        $launcher.append('<span class="echo64-badge" aria-hidden="true"></span>');

        let chatReady = false;

        $launcher.on('click', function () {
            const isOpen = !$panel.attr('hidden');

            if (isOpen) {
                $panel.attr('hidden', '');
                $launcher.attr('aria-expanded', 'false');
            } else {
                $panel.removeAttr('hidden');
                $launcher.attr('aria-expanded', 'true');
                $launcher.removeClass('has-unread');

                if (!chatReady) {
                    chatReady = true;
                    initChat($panel);
                }

                // Focus the input when panel opens
                setTimeout(() => $panel.find('#echo64-input').focus(), 80);
            }
        });

        // Keyboard: close on Escape
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && !$panel.attr('hidden')) {
                $panel.attr('hidden', '');
                $launcher.attr('aria-expanded', 'false').focus();
            }
        });

        // Show unread badge 3 s after page load if panel not yet opened
        setTimeout(function () {
            if ($panel.attr('hidden') !== undefined) {
                $launcher.addClass('has-unread');
            }
        }, 3000);
    }

    // ── Bootstrap ────────────────────────────────────────────────────────

    $(function () {
        // Shortcode embed instances (not inside the float panel)
        $('.echo64-chat-container')
            .not('#echo64-float-panel .echo64-chat-container')
            .each(function () { initChat($(this)); });

        // Floating widget
        if (String(cfg.isFloating) === '1') {
            initFloat();
        }
    });

}(jQuery));
