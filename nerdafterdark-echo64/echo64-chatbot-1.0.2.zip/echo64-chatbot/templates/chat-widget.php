<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="echo64-chat-container" id="echo64-chat" role="region" aria-label="Echo-64 Chat">

    <div class="echo64-chat-header">
        <div class="echo64-header-left">
            <div class="echo64-avatar-wrap">
                <img src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                     alt="Echo-64" class="echo64-avatar" />
                <span class="echo64-status-dot" aria-hidden="true"></span>
            </div>
            <div class="echo64-header-info">
                <span class="echo64-name">Echo-64</span>
                <span class="echo64-tagline">Sci-Fi After Midnight</span>
            </div>
        </div>
        <div class="echo64-header-actions">
            <button type="button" class="echo64-clear-btn" title="<?php esc_attr_e( 'New conversation', 'echo64-chatbot' ); ?>" aria-label="<?php esc_attr_e( 'Start new conversation', 'echo64-chatbot' ); ?>">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M13.5 2.5L2.5 13.5M2.5 2.5L13.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span><?php esc_html_e( 'New Chat', 'echo64-chatbot' ); ?></span>
            </button>
        </div>
    </div>

    <div class="echo64-messages" id="echo64-messages" role="log" aria-live="polite" aria-atomic="false">
        <div class="echo64-loading-init" id="echo64-loading-init" aria-label="<?php esc_attr_e( 'Echo-64 is initializing', 'echo64-chatbot' ); ?>">
            <div class="echo64-typing-indicator">
                <span></span><span></span><span></span>
            </div>
            <p><?php esc_html_e( 'Booting Echo-64…', 'echo64-chatbot' ); ?></p>
        </div>
    </div>

    <div class="echo64-input-area">
        <div class="echo64-input-row">
            <textarea
                id="echo64-input"
                class="echo64-input"
                placeholder="<?php esc_attr_e( 'Ask Echo-64 anything…', 'echo64-chatbot' ); ?>"
                rows="1"
                maxlength="2000"
                aria-label="<?php esc_attr_e( 'Message Echo-64', 'echo64-chatbot' ); ?>"
            ></textarea>
            <button type="button" id="echo64-send" class="echo64-send-btn" aria-label="<?php esc_attr_e( 'Send message', 'echo64-chatbot' ); ?>" disabled>
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                    <path d="M3 10L17 10M17 10L11 4M17 10L11 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
        <p class="echo64-footer-note"><?php esc_html_e( 'NerdAfterDark.com · Retro Futures &amp; Sarcastic Truths', 'echo64-chatbot' ); ?></p>
    </div>

</div>
