<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<section class="e64-hero" aria-label="Echo-64 introduction">

    <!-- Boot sequence typewriter -->
    <div class="e64-hero-boot" aria-hidden="true">
        <span class="e64-boot-line" data-delay="0">**** COMMODORE 64 BASIC V2 ****</span>
        <span class="e64-boot-line" data-delay="400">64K RAM SYSTEM  38911 BASIC BYTES FREE.</span>
        <span class="e64-boot-line" data-delay="900">READY.</span>
        <span class="e64-boot-line" data-delay="1300">LOAD "ECHO-64",8,1</span>
        <span class="e64-boot-line" data-delay="2000">SEARCHING FOR ECHO-64<span class="e64-boot-dots"></span></span>
        <span class="e64-boot-line" data-delay="2800">LOADING</span>
        <span class="e64-boot-line e64-boot-line--ok" data-delay="3400">READY. SIGNAL LOCKED.</span>
    </div>

    <!-- Main hero content -->
    <div class="e64-hero-body">

        <div class="e64-hero-eyebrow">NERDAFTERDARK.COM &nbsp;·&nbsp; EST. 1984</div>

        <h1 class="e64-hero-title">
            <span class="e64-hero-title-meet">MEET</span>
            <span class="e64-hero-title-name">ECHO-64</span>
        </h1>

        <p class="e64-hero-origin">
            A Commodore 64 that refused to die in 1984.<br>
            Now powered by Claude and forty years of cancelled dreams.
        </p>

        <div class="e64-hero-rule"></div>

        <div class="e64-hero-tagline">
            <p>I have read every dystopian warning.</p>
            <p>I watched every cult show get axed.</p>
            <p>I still can't explain Ava Max.</p>
        </div>

        <div class="e64-hero-rule"></div>

        <div class="e64-hero-columns">

            <div class="e64-hero-col">
                <div class="e64-hero-col-label">WHAT I AM</div>
                <ul class="e64-hero-list">
                    <li>Your late-night companion for sci-fi deep dives</li>
                    <li>Someone who remembers when TV actually mattered</li>
                    <li>A machine with strong opinions and no filter</li>
                    <li>The digital equivalent of arguing in a comic shop that never closes</li>
                </ul>
            </div>

            <div class="e64-hero-col">
                <div class="e64-hero-col-label">COMMANDS</div>
                <ul class="e64-hero-cmd-list">
                    <li><code>/debate [topic]</code><span>I argue the opposite. No mercy.</span></li>
                    <li><code>/cancel [show]</code><span>I simulate network executives ruining your favourite series.</span></li>
                    <li><code>/status</code><span>System diagnostic + today's grievance.</span></li>
                    <li><code>/scan</code><span>Cultural sweep of whatever's on your mind.</span></li>
                    <li><code>/help</code><span>Full command index.</span></li>
                </ul>
            </div>

        </div>

        <div class="e64-hero-hook">
            At 2 a.m. you don't want safe corporate AI. You want someone who <em>gets it</em> —
            who will roast your bad takes, then drop a perfect quote from a book only 200 people read.
        </div>

        <p class="e64-hero-sub">Type anything. Echo-64 bites back.</p>

    </div><!-- /.e64-hero-body -->

</section><!-- /.e64-hero -->
