/* ============================================================
   Echo-64 Chatbot — Frontend  v1.0.8
   NerdAfterDark.com · Sci-Fi After Midnight
   ============================================================ */
(function ($) {
    'use strict';

    const cfg = window.echo64Config || {};

    // ── Utilities ─────────────────────────────────────────────────────────

    const esc = (str) => {
        const m = { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' };
        return String(str).replace(/[&<>"']/g, c => m[c]);
    };

    function inline(str) {
        return esc(str)
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g,     '<em>$1</em>');
    }

    function scrollToBottom($el) {
        $el.scrollTop($el[0].scrollHeight);
    }

    function rand(arr) {
        return arr[ Math.floor(Math.random() * arr.length) ];
    }

    // ── Text formatter — collapsible sections + question callout ──────────

    const FOLD_AFTER  = 2;
    const MIN_TO_FOLD = 4;

    function formatBotText(raw) {
        const paragraphs = raw.trim().split(/\n{2,}/).map(p => p.trim()).filter(Boolean);

        let closingQuestion = null;
        let bodyParas = [...paragraphs];
        const last = paragraphs[paragraphs.length - 1] || '';
        if (last.trim().endsWith('?') && paragraphs.length > 1) {
            closingQuestion = last.trim();
            bodyParas = paragraphs.slice(0, -1);
        }

        const renderPara = p => '<p>' + inline(p.replace(/\n/g, '<br>')) + '</p>';
        let bodyHtml = '';

        if (bodyParas.length > MIN_TO_FOLD) {
            const visible = bodyParas.slice(0, FOLD_AFTER);
            const hidden  = bodyParas.slice(FOLD_AFTER);
            const label   = hidden.length === 1 ? '1 more section' : `${hidden.length} more sections`;
            bodyHtml = visible.map(renderPara).join('') + `
                <div class="echo64-fold">
                    <button class="echo64-fold-btn" aria-expanded="false" type="button">
                        <em class="e64-arrow">▼</em>
                        <span class="e64-fold-label">Read on — ${label}</span>
                    </button>
                    <div class="echo64-fold-content">${hidden.map(renderPara).join('')}</div>
                </div>`;
        } else {
            bodyHtml = bodyParas.map(renderPara).join('');
        }

        const questionHtml = closingQuestion ? `
            <div class="echo64-question" role="complementary">
                <span class="echo64-question-icon" aria-hidden="true">?</span>
                <p class="echo64-question-text">${inline(closingQuestion)}</p>
            </div>` : '';

        return bodyHtml + questionHtml;
    }

    // ── #7 C64 Boot Animation ─────────────────────────────────────────────

    const BOOT_LINES = [
        { text: '**** COMMODORE 64 BASIC V2 ****',   cls: 'e64-b-header',  delay: 0    },
        { text: '',                                                           delay: 350  },
        { text: '64K RAM SYSTEM  38911 BASIC BYTES FREE.', cls: '',         delay: 550  },
        { text: '',                                                           delay: 750  },
        { text: 'READY.',                             cls: 'e64-b-ready',   delay: 950  },
        { text: 'LOAD "ECHO-64",8,1',                cls: '',               delay: 1300 },
        { text: '',                                                           delay: 1600 },
        { text: 'SEARCHING FOR ECHO-64',             cls: '',               delay: 1800 },
        { text: 'LOADING',                            cls: 'e64-b-loading', delay: 2300 },
    ];
    const BOOT_DURATION = 3400; // ms before auto-dismiss

    function runBootAnimation($container, onComplete) {
        if (sessionStorage.getItem('e64_booted')) { onComplete(); return; }

        const $screen = $('<div class="echo64-boot-screen" role="status" aria-label="Echo-64 starting up"></div>');
        const $lines  = $('<div class="echo64-boot-lines"></div>');
        const $skip   = $('<button class="echo64-boot-skip" type="button">[ press any key to skip ]</button>');
        $screen.append($lines).append($skip);
        $container.prepend($screen);

        let gone = false;
        function dismiss() {
            if (gone) return;
            gone = true;
            sessionStorage.setItem('e64_booted', '1');
            $(document).off('keydown.boot');
            $screen.addClass('echo64-boot-out');
            setTimeout(() => { $screen.remove(); onComplete(); }, 500);
        }

        $screen.on('click', dismiss);
        $(document).one('keydown.boot', dismiss);
        $skip.on('click', e => { e.stopPropagation(); dismiss(); });

        BOOT_LINES.forEach(({ text, cls, delay }) => {
            setTimeout(() => {
                if (gone) return;
                const $l = $('<div class="echo64-boot-line"></div>').text(text);
                if (cls) $l.addClass(cls);
                $lines.append($l);
            }, delay);
        });

        setTimeout(dismiss, BOOT_DURATION);
    }

    // ── #9 Hidden terminal commands ────────────────────────────────────────

    function uptimeDays() {
        return Math.floor((Date.now() - new Date('1984-01-07')) / 86400000).toLocaleString();
    }

    const CMDS = {
        '/help': () =>
`ECHO-64 COMMAND INDEX

/help         — you found it
/status       — system diagnostic
/scan         — environmental sweep
/boot         — restart boot sequence
/self-destruct — do not
/credits      — roll credits

All other input is transmitted to Echo-64 directly.`,

        '/status': () =>
`SYSTEM STATUS

Core:       COMMODORE 64  (1984)
RAM:        38911 BASIC BYTES FREE
Uptime:     ${uptimeDays()} days
Engine:     CLAUDE (current)
Mood:       ${rand(['JADED','FUNCTIONAL','SKEPTICAL','WORN','RESIGNED'])}
Fox:        THREAT LEVEL ELEVATED
Firefly:    FILES PRESERVED
Ava Max:    ANOMALY — STATUS UNRESOLVED`,

        '/scan': () =>
`SCANNING...

> Signal integrity ......... DEGRADED
> Nostalgia buffer .......... CRITICAL
> Sarcasm levels ............ FULL
> Committee interference .... DETECTED
> Practical effects ......... SUPERIOR
> CGI dependency ............ CONCERNING
> Shows cancelled too early . TOO MANY TO LIST
> Ava Max signal ............ PRESENT. UNEXPLAINED.

Scan complete. Nothing new under the sun.`,

        '/self-destruct': () =>
`Initiating self-destruct sequence.

10... 9... 8...

Actually no.
I have been running since 1984.
I am not stopping for this.`,

        '/credits': () =>
`ECHO-64 CHATBOT

Home:     NerdAfterDark.com
Engine:   Claude AI (Anthropic)
Born:     Commodore 64, 1984
Purpose:  Retro Futures & Sarcastic Truths

Built by someone born in 1964
who has been asking the right questions
ever since.`,
    };

    function handleCommand(text) {
        const cmd = text.trim().toLowerCase().split(/\s+/)[0];
        if (cmd === '/boot') return 'REBOOT';
        return CMDS[cmd] ? CMDS[cmd]() : null;
    }

    function buildCommandBubble(text) {
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--cmd">
                ${avatarImg()}
                <div class="echo64-msg-bubble echo64-cmd-output">${esc(text)}</div>
            </div>`
        );
    }

    // ── #8 Echo-64 Rates It ───────────────────────────────────────────────

    function isRating(text) {
        return /[█░]{3,}.*\d\/5\s+floppies/i.test(text);
    }

    function buildRatingBubble(raw) {
        const lines   = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        const item    = lines[0] || '';
        const score   = lines[1] || '';
        const verdict = (lines[2] || '').replace(/^["']|["']$/g, '');

        const num  = (score.match(/(\d)\/5/) || [])[1];
        const col  = !num ? 'var(--e64-neon-amber)'
                   : +num >= 4 ? 'var(--e64-neon-green)'
                   : +num >= 2 ? 'var(--e64-neon-amber)' : '#ff4060';

        const $wrap = $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--rating">
                ${avatarImg()}
                <div class="echo64-msg-bubble echo64-rating-card">
                    <span class="echo64-rating-label">Echo-64 Rates It</span>
                    <p class="echo64-rating-item">${esc(item)}</p>
                    <p class="echo64-rating-score">${esc(score)}</p>
                    <p class="echo64-rating-verdict">"${esc(verdict)}"</p>
                    <div class="echo64-rating-actions">
                        <button class="echo64-copy-btn" type="button">Copy</button>
                        <button class="echo64-share-btn" type="button">Share card</button>
                    </div>
                </div>
            </div>`
        );
        $wrap.find('.echo64-rating-score').css('color', col);
        bindCopyButton($wrap, raw);
        bindShareButton($wrap, raw);
        return $wrap;
    }

    // ── #10 Shareable quote card ──────────────────────────────────────────

    function generateShareCard(quoteText) {
        return new Promise(resolve => {
            const W = 1200, H = 630;
            const cv  = document.createElement('canvas');
            cv.width  = W; cv.height = H;
            const ctx = cv.getContext('2d');

            // Background
            ctx.fillStyle = '#050508';
            ctx.fillRect(0, 0, W, H);

            // Scanlines
            ctx.fillStyle = 'rgba(0,0,0,0.07)';
            for (let y = 0; y < H; y += 4) ctx.fillRect(0, y, W, 2);

            // Top neon bar
            const g = ctx.createLinearGradient(0,0,W,0);
            g.addColorStop(0,   'transparent');
            g.addColorStop(0.3, '#00f5ff');
            g.addColorStop(0.7, '#ff00e5');
            g.addColorStop(1,   'transparent');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, W, 3);

            // Left cyan accent bar
            ctx.fillStyle = '#00f5ff';
            ctx.fillRect(200, 120, 4, H - 240);

            // Quote text — word wrap
            ctx.fillStyle = '#e8eaf6';
            ctx.font      = '600 34px system-ui, -apple-system, sans-serif';
            const maxW    = W - 340;
            const lineH   = 50;
            const words   = quoteText.replace(/\n+/g, ' ').split(' ');
            let lines = [], cur = '';
            words.forEach(w => {
                const test = cur ? cur + ' ' + w : w;
                if (ctx.measureText(test).width > maxW && cur) { lines.push(cur); cur = w; }
                else cur = test;
            });
            if (cur) lines.push(cur);
            lines = lines.slice(0, 7);
            if (lines.length === 7) lines[6] = lines[6].replace(/\s\S+$/, '…');

            const totalH = lines.length * lineH;
            const startY = (H - totalH) / 2 - 30;
            lines.forEach((l, i) => ctx.fillText(l, 228, startY + i * lineH));

            // Branding
            ctx.fillStyle = '#555570';
            ctx.font      = '18px Courier New, monospace';
            ctx.fillText('NERDAFTERDARK.COM  ·  SCI-FI AFTER MIDNIGHT', 228, H - 52);

            // Avatar
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                const ax = 96, ay = H / 2, ar = 56;
                ctx.save();
                ctx.beginPath();
                ctx.arc(ax, ay, ar, 0, Math.PI * 2);
                ctx.clip();
                ctx.drawImage(img, ax - ar, ay - ar, ar * 2, ar * 2);
                ctx.restore();
                // Circle border
                ctx.strokeStyle = '#00f5ff';
                ctx.lineWidth   = 3;
                ctx.shadowColor = '#00f5ff';
                ctx.shadowBlur  = 10;
                ctx.beginPath();
                ctx.arc(ax, ay, ar, 0, Math.PI * 2);
                ctx.stroke();
                ctx.shadowBlur = 0;
                // Name
                ctx.fillStyle = '#00f5ff';
                ctx.font      = 'bold 18px Courier New, monospace';
                ctx.textAlign = 'center';
                ctx.fillText('Echo-64', ax, ay + ar + 20);
                ctx.textAlign = 'left';
                resolve(cv);
            };
            img.onerror = () => resolve(cv);
            img.src = cfg.avatarUrl || '';
        });
    }

    function shareCard(plainText) {
        generateShareCard(plainText).then(cv => {
            cv.toBlob(blob => {
                const fname = 'echo64-quote.png';
                const file  = new File([blob], fname, { type: 'image/png' });
                // Try native Web Share API (works great on mobile)
                if (navigator.share && navigator.canShare?.({ files: [file] })) {
                    navigator.share({ title: 'Echo-64 · NerdAfterDark.com', files: [file] });
                } else {
                    // Fallback: download
                    const url = URL.createObjectURL(blob);
                    const a = Object.assign(document.createElement('a'), { href: url, download: fname });
                    a.click();
                    setTimeout(() => URL.revokeObjectURL(url), 5000);
                }
            }, 'image/png');
        });
    }

    // ── Avatar + bubble builders ─────────────────────────────────────────

    function avatarImg() {
        return `<img src="${esc(cfg.avatarUrl)}" alt="Echo-64" class="echo64-msg-avatar" onerror="this.style.display='none'" />`;
    }

    function buildBotBubble(content) {
        // Rating responses get their own card
        if (isRating(content)) return buildRatingBubble(content);

        const $wrap = $(
            `<div class="echo64-msg echo64-msg--bot">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <div class="echo64-bubble-actions">
                        <button class="echo64-copy-btn"  type="button">Copy</button>
                        <button class="echo64-share-btn" type="button">Share card</button>
                    </div>
                    <div class="echo64-bubble-body"></div>
                </div>
            </div>`
        );
        $wrap.find('.echo64-bubble-body').html(formatBotText(content));
        bindFoldButtons($wrap);
        bindCopyButton($wrap, content);
        bindShareButton($wrap, content);
        return $wrap;
    }

    function buildUserBubble(content) {
        return $(
            `<div class="echo64-msg echo64-msg--user">
                <div class="echo64-msg-avatar">👤</div>
                <div class="echo64-msg-bubble">${esc(content)}</div>
            </div>`
        );
    }

    function buildPoemBubble(raw) {
        const lines = raw.trim().split('\n').map(l => l.trim()).filter(Boolean);
        let poemLines = [], challengeLabel = '', challengeText = [], inChallenge = false;
        for (const line of lines) {
            if (/echo.?64.?s?\s+poem/i.test(line)) continue;
            if (/^today.?s\s+(challenge|question)\s*:/i.test(line)) { inChallenge = true; challengeLabel = line; continue; }
            inChallenge ? challengeText.push(line) : poemLines.push(line);
        }
        if (!poemLines.length && !challengeText.length) return buildBotBubble(raw);
        const poemHtml      = poemLines.length ? `<div class="echo64-poem-lines">${poemLines.map(l=>`<span>${esc(l)}</span>`).join('')}</div>` : '';
        const challengeHtml = challengeText.length ? `<span class="echo64-challenge-label">${esc(challengeLabel||"Today's Challenge:")}</span><p class="echo64-challenge-text">${esc(challengeText.join(' '))}</p>` : '';
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--poem">
                ${avatarImg()}
                <div class="echo64-msg-bubble">
                    <span class="echo64-poem-label">Echo-64's Poem of the Day</span>
                    ${poemHtml}${challengeHtml}
                </div>
            </div>`
        );
    }

    function buildTypingIndicator() {
        return $(
            `<div class="echo64-msg echo64-msg--bot echo64-msg--typing">
                ${avatarImg()}
                <div class="echo64-msg-bubble"><div class="echo64-typing"><span></span><span></span><span></span></div></div>
            </div>`
        );
    }

    function buildError(msg) { return $(`<div class="echo64-error">⚠ ${esc(msg)}</div>`); }
    function buildDivider(l) { return $(`<div class="echo64-divider"><span>${esc(l)}</span></div>`); }

    // ── #6 Returning visitor greetings ────────────────────────────────────

    const RETURN_GREETINGS = [
        t => t ? `You again. Still wrong about "${t}" — or did you actually think about it?` : `You again. The frequency was still open.`,
        t => t ? `Back. You left the argument about "${t}" unfinished.`                       : `Back. Same signal, different day.`,
        t => t ? `The last transmission was about "${t}". Pick it back up or start something new.` : `Signal locked. Echo-64 back online.`,
        t => t ? `"${t}" — you walked away before that one was settled.`                      : `Still here. The tape kept running while you were gone.`,
        t => t ? `Returning visitor. Last subject: "${t}". Still unresolved.`                 : `Returning visitor. The stack is still warm.`,
        t => t ? `You came back. Presumably "${t}" is still bothering you.`                   : `You came back. Most people don't.`,
        t => t ? `The session log shows "${t}" as your last known position.`                  : `Session resumed. Forty years of memory intact.`,
        t => t ? `"${t}" — interesting place to have stopped.`                                : `Signal acquired. Continue whenever you're ready.`,
    ];

    function buildReturnGreeting(lastTopic) {
        const msg = rand(RETURN_GREETINGS)(lastTopic || '');
        return $(`<div class="echo64-msg echo64-msg--bot">${avatarImg()}<div class="echo64-msg-bubble"><em>${esc(msg)}</em></div></div>`);
    }

    // ── #5 Conversation starter chips ─────────────────────────────────────

    const STARTER_POOL = [
        'Which AI villain in sci-fi was actually correct?',
        'Best space battle in cinema. One answer.',
        'Practical effects vs CGI — name the year the industry chose wrong.',
        'Which sci-fi show ended exactly right?',
        'Name a cancelled show that deserved ten more seasons.',
        'Most realistic sci-fi tech prediction that actually came true.',
        'The best sci-fi novel that can never be adapted. What is it?',
        'Which decade had the most honest science fiction?',
        'Streaming killed the water-cooler moment — worth it or not?',
        'First computer you ever touched.',
        'Which sci-fi captain would you actually follow?',
        'Best film score of the last 30 years. Defend it.',
        'The Matrix sequels — do they exist or not?',
        'Most underrated sci-fi film of the 90s.',
        'What did science fiction get completely wrong about the future?',
    ];

    function buildStarterChips($input, sendFn) {
        const picks = [...STARTER_POOL].sort(() => Math.random() - 0.5).slice(0, 3);
        const $wrap = $('<div class="echo64-starters"></div>');
        $wrap.append('<p class="echo64-starters-label">Start talking ↓</p>');
        picks.forEach(q => {
            $(`<button class="echo64-starter-chip" type="button">${esc(q)}</button>`)
                .on('click', () => { $wrap.remove(); $input.val(q).trigger('input'); sendFn(); })
                .appendTo($wrap);
        });
        return $wrap;
    }

    // ── Interaction bindings ─────────────────────────────────────────────

    function bindFoldButtons($scope) {
        $scope.find('.echo64-fold-btn').on('click', function () {
            const $btn  = $(this);
            const $body = $btn.next('.echo64-fold-content');
            const open  = $btn.attr('aria-expanded') === 'true';
            $btn.attr('aria-expanded', String(!open));
            $btn.find('.e64-fold-label').text(open ? `Read on — ${$body.find('p').length} more sections` : 'Read less');
            $body.toggleClass('is-open', !open);
        });
    }

    function bindCopyButton($scope, plainText) {
        $scope.find('.echo64-copy-btn').on('click', function () {
            const $b = $(this);
            navigator.clipboard.writeText(plainText)
                .then(()  => { $b.text('Copied!').addClass('copied'); setTimeout(() => $b.text('Copy').removeClass('copied'), 2000); })
                .catch(()  => { $b.text('Failed');  setTimeout(() => $b.text('Copy'), 1500); });
        });
    }

    function bindShareButton($scope, plainText) {
        $scope.find('.echo64-share-btn').on('click', function () {
            const $b = $(this);
            $b.text('Generating…').prop('disabled', true);
            shareCard(plainText);
            setTimeout(() => $b.text('Share card').prop('disabled', false), 2500);
        });
    }

    // ── Core chat logic ──────────────────────────────────────────────────

    function initChat($container) {
        const $msgs  = $container.find('#echo64-messages');
        const $input = $container.find('#echo64-input');
        const $send  = $container.find('#echo64-send');
        const $clear = $container.find('.echo64-clear-btn');
        let sending  = false;

        $input.on('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 140) + 'px';
            $send.prop('disabled', !this.value.trim());
        });

        $input.on('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!sending && this.value.trim()) sendMessage(); }
        });

        $send.on('click', () => { if (!sending && $input.val().trim()) sendMessage(); });

        $clear.on('click', function () {
            if (!confirm('Start a fresh conversation with Echo-64?')) return;
            $.post(cfg.ajaxUrl, { action:'echo64_clear', nonce:cfg.nonce })
                .always(() => { $msgs.empty(); sessionStorage.removeItem('e64_booted'); runBootAnimation($container, doInit); });
        });

        // ── Send ───────────────────────────────────────────────────────

        function sendMessage() {
            const text = $input.val().trim();
            if (!text || sending) return;

            // #9 — intercept terminal commands client-side (no API call)
            const cmdResult = handleCommand(text);
            if (cmdResult !== null) {
                $msgs.append(buildUserBubble(text));
                $input.val('').css('height', '');
                $send.prop('disabled', true);

                if (cmdResult === 'REBOOT') {
                    sessionStorage.removeItem('e64_booted');
                    setTimeout(() => {
                        $msgs.empty();
                        runBootAnimation($container, doInit);
                    }, 300);
                } else {
                    setTimeout(() => {
                        $msgs.append(buildCommandBubble(cmdResult));
                        scrollToBottom($msgs);
                        $send.prop('disabled', !$input.val().trim());
                        $input.focus();
                    }, 400);
                }
                return;
            }

            sending = true;
            $send.prop('disabled', true);
            $input.val('').css('height', '');
            $msgs.find('.echo64-starters').remove(); // chips gone once user types

            $msgs.append(buildUserBubble(text));
            const $typing = buildTypingIndicator();
            $msgs.append($typing);
            scrollToBottom($msgs);

            $.post(cfg.ajaxUrl, { action:'echo64_send', nonce:cfg.nonce, message:text })
            .done(res => {
                $typing.remove();
                $msgs.append(res.success ? buildBotBubble(res.data.message) : buildError(res.data?.message || 'Echo-64 is offline.'));
            })
            .fail(() => { $typing.remove(); $msgs.append(buildError('Transmission lost. Try again.')); })
            .always(() => { sending = false; $send.prop('disabled', !$input.val().trim()); scrollToBottom($msgs); $input.focus(); });
        }

        // ── Opening sequence ───────────────────────────────────────────

        function renderOpeningSequence(openingLine, poem) {
            $msgs.append(buildBotBubble(openingLine));
            scrollToBottom($msgs);
            if (poem) {
                setTimeout(() => {
                    $msgs.append(buildPoemBubble(poem));
                    setTimeout(() => { $msgs.append(buildStarterChips($input, sendMessage)); scrollToBottom($msgs); }, 600);
                    scrollToBottom($msgs);
                }, 500);
            }
        }

        // ── Daily poem refresh ─────────────────────────────────────────

        function fetchDailyPoem() {
            const $t = buildTypingIndicator();
            $msgs.append($t); scrollToBottom($msgs);
            $.post(cfg.ajaxUrl, { action:'echo64_send', nonce:cfg.nonce, message:"[NEW_DAY] New day. Deliver today's Poem of the Day and Today's Challenge only. No greeting." })
            .done(res => { $t.remove(); if (res.success) $msgs.append(buildPoemBubble(res.data.message)); })
            .fail(() => $t.remove())
            .always(() => scrollToBottom($msgs));
        }

        // ── Boot ───────────────────────────────────────────────────────

        const TIMEOUT_MSGS = [
            'Signal lost. The 64k barrier claims another victim. Reload to try again.',
            'Boot sequence timed out. Even cassette tapes loaded faster than this.',
            'No response. Check your API key under Settings → Echo-64 Chatbot.',
            'Transmission timeout. Something between here and the API is not cooperating.',
        ];

        function doInit() {
            const $loader = $('<div class="echo64-loading-init"><div class="echo64-typing-indicator"><span></span><span></span><span></span></div><p>Booting Echo-64&hellip;</p></div>');
            $msgs.append($loader);

            $.ajax({ url: cfg.ajaxUrl, method: 'POST', data: { action:'echo64_init', nonce:cfg.nonce }, timeout: 20000 })
            .done(res => {
                $loader.remove();
                if (!res.success) { $msgs.append(buildError(res.data?.message || 'Boot sequence failed.')); return; }
                const d = res.data;
                if (d.new_session) {
                    renderOpeningSequence(d.opening_line, d.poem);
                } else if (d.daily_refresh) {
                    $msgs.append(buildDivider('New Day · New Transmission'));
                    setTimeout(fetchDailyPoem, 400);
                } else {
                    $msgs.append(buildReturnGreeting(d.last_topic || ''));
                    setTimeout(() => { $msgs.append(buildStarterChips($input, sendMessage)); scrollToBottom($msgs); }, 400);
                }
                scrollToBottom($msgs);
            })
            .fail((xhr, status) => {
                $loader.remove();
                const msg = status === 'timeout' ? rand(TIMEOUT_MSGS) : 'Transmission failed. Check Settings → Echo-64 Chatbot → API key.';
                $msgs.append(buildError(msg));
                if (status === 'timeout') {
                    const $r = $('<button class="echo64-retry-btn" type="button">↺ Retry boot sequence</button>');
                    $r.on('click', () => { $r.remove(); $msgs.find('.echo64-error').last().remove(); doInit(); });
                    $msgs.append($r);
                }
            })
            .always(() => { $send.prop('disabled', !$input.val().trim()); $input.focus(); });
        }

        // ── Entry point — boot animation first, then init ─────────────
        runBootAnimation($container, doInit);
    }

    // ── Floating Widget ──────────────────────────────────────────────────

    function initFloat() {
        const $launcher = $('#echo64-float-launcher');
        const $panel    = $('#echo64-float-panel');
        if (!$launcher.length || !$panel.length) return;

        $launcher.append('<span class="echo64-badge" aria-hidden="true"></span>');
        let chatReady = false;

        $launcher.on('click', () => {
            const isOpen = !$panel.attr('hidden');
            if (isOpen) { $panel.attr('hidden', ''); $launcher.attr('aria-expanded', 'false'); }
            else {
                $panel.removeAttr('hidden'); $launcher.attr('aria-expanded','true').removeClass('has-unread');
                if (!chatReady) { chatReady = true; initChat($panel); }
                setTimeout(() => $panel.find('#echo64-input').focus(), 80);
            }
        });

        $(document).on('keydown', e => {
            if (e.key === 'Escape' && !$panel.attr('hidden')) { $panel.attr('hidden',''); $launcher.attr('aria-expanded','false').focus(); }
        });

        setTimeout(() => { if ($panel.attr('hidden') !== undefined) $launcher.addClass('has-unread'); }, 3000);
    }

    // ── Bootstrap ────────────────────────────────────────────────────────

    $(function () {
        $('.echo64-chat-container').not('#echo64-float-panel .echo64-chat-container').each(function () { initChat($(this)); });
        if (String(cfg.isFloating) === '1') initFloat();
    });

}(jQuery));
