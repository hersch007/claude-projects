<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class Echo64_Admin {

    private static ?Echo64_Admin $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function add_menu(): void {
        add_options_page(
            __( 'Echo-64 Chatbot', 'echo64-chatbot' ),
            __( 'Echo-64 Chatbot', 'echo64-chatbot' ),
            'manage_options',
            'echo64-settings',
            [ $this, 'render_page' ]
        );
    }

    public function enqueue_assets( string $hook ): void {
        if ( $hook !== 'settings_page_echo64-settings' ) return;

        wp_enqueue_style(
            'echo64-admin',
            ECHO64_PLUGIN_URL . 'assets/css/echo64-admin.css',
            [],
            ECHO64_VERSION
        );

        // Inline JS for admin interactions
        $js = <<<'JS'
document.addEventListener('DOMContentLoaded', function () {
    // Character counter for the system prompt textarea
    const textarea = document.getElementById('echo64_system_prompt');
    const counter  = document.getElementById('echo64-prompt-counter');
    if (textarea && counter) {
        const update = () => { counter.textContent = textarea.value.length.toLocaleString() + ' chars'; };
        textarea.addEventListener('input', update);
        update();
    }

    // Reset to default button
    const resetBtn     = document.getElementById('echo64-reset-prompt');
    const defaultProp  = resetBtn ? resetBtn.dataset.default : null;
    if (resetBtn && defaultProp) {
        resetBtn.addEventListener('click', function () {
            if (confirm('Reset to the original Echo-64 system prompt? Your edits will be lost.')) {
                textarea.value = defaultProp;
                if (counter) counter.textContent = textarea.value.length.toLocaleString() + ' chars';
            }
        });
    }

    // Toggle API key visibility
    const toggle = document.getElementById('echo64-toggle-key');
    const keyInput = document.getElementById('echo64_api_key');
    if (toggle && keyInput) {
        toggle.addEventListener('click', function () {
            const show = keyInput.type === 'password';
            keyInput.type = show ? 'text' : 'password';
            this.textContent = show ? 'Hide' : 'Show';
        });
    }

    // Test API connection
    const testBtn  = document.getElementById('echo64-test-api');
    const testResult = document.getElementById('echo64-test-result');
    if (testBtn && testResult) {
        testBtn.addEventListener('click', function () {
            const key = keyInput ? keyInput.value.trim() : '';
            if (!key) { testResult.textContent = 'Enter an API key first.'; testResult.className = 'echo64-test-fail'; return; }
            testBtn.disabled = true;
            testBtn.textContent = 'Testing…';
            testResult.textContent = '';
            testResult.className = '';
            fetch(ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'echo64_test_api',
                    nonce:  echo64AdminNonce,
                    api_key: key,
                })
            })
            .then(r => r.json())
            .then(res => {
                testResult.textContent = res.data?.message || (res.success ? '✓ Connected' : '✗ Failed');
                testResult.className   = res.success ? 'echo64-test-ok' : 'echo64-test-fail';
            })
            .catch(() => {
                testResult.textContent = '✗ Request failed';
                testResult.className   = 'echo64-test-fail';
            })
            .finally(() => {
                testBtn.disabled    = false;
                testBtn.textContent = 'Test Connection';
            });
        });
    }
});
JS;
        wp_add_inline_script( 'jquery', $js );
        wp_localize_script( 'jquery', 'echo64AdminNonce', wp_create_nonce( 'echo64_admin_nonce' ) );
    }

    public function register_settings(): void {
        $opts = [
            'echo64_api_key'       => 'sanitize_text_field',
            'echo64_model'         => 'sanitize_text_field',
            'echo64_max_tokens'    => 'absint',
            'echo64_history_limit' => 'absint',
            'echo64_float_widget'  => 'sanitize_text_field',
            'echo64_system_prompt' => 'sanitize_textarea_field',
        ];

        foreach ( $opts as $key => $cb ) {
            register_setting( 'echo64_settings', $key, [ 'sanitize_callback' => $cb ] );
        }

        // AJAX: test API connection
        add_action( 'wp_ajax_echo64_test_api', [ $this, 'ajax_test_api' ] );
    }

    public function ajax_test_api(): void {
        check_ajax_referer( 'echo64_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
            return;
        }

        $api_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) );
        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'message' => '✗ No API key provided.' ] );
            return;
        }

        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 20,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => 'claude-haiku-4-5-20251001',
                'max_tokens' => 8,
                'messages'   => [ [ 'role' => 'user', 'content' => 'Hi' ] ],
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => '✗ ' . $response->get_error_message() ] );
            return;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 200 ) {
            wp_send_json_success( [ 'message' => '✓ API key valid. Connection successful.' ] );
        } else {
            $msg = $body['error']['message'] ?? 'Unknown error';
            wp_send_json_error( [ 'message' => "✗ API error ({$code}): {$msg}" ] );
        }
    }

    public function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $api_key       = get_option( 'echo64_api_key', '' );
        $model         = get_option( 'echo64_model', 'claude-sonnet-4-6' );
        $max_tokens    = (int) get_option( 'echo64_max_tokens', 1024 );
        $history_limit = (int) get_option( 'echo64_history_limit', 20 );
        $float_widget  = get_option( 'echo64_float_widget', '0' );
        $system_prompt = get_option( 'echo64_system_prompt', Echo64_Api::DEFAULT_SYSTEM_PROMPT );

        $models = [
            'claude-opus-4-8'           => 'Claude Opus 4.8 — Most capable, slowest',
            'claude-sonnet-4-6'         => 'Claude Sonnet 4.6 — Recommended balance',
            'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5 — Fastest, most economical',
        ];
        ?>
        <div class="wrap echo64-admin-wrap">

            <div class="echo64-admin-header">
                <img
                    src="<?php echo esc_url( ECHO64_PLUGIN_URL . 'assets/images/echo-64-avatar.png' ); ?>"
                    alt="Echo-64 avatar"
                    class="echo64-admin-avatar"
                    onerror="this.style.display='none'"
                />
                <div class="echo64-admin-header-text">
                    <h1>Echo-64 Chatbot</h1>
                    <p class="echo64-admin-sub">NerdAfterDark.com &mdash; Retro Futures &amp; Sarcastic Truths</p>
                    <p class="echo64-admin-version">Version <?php echo esc_html( ECHO64_VERSION ); ?> &nbsp;|&nbsp; Shortcode: <code>[echo64_chat]</code></p>
                </div>
            </div>

            <?php settings_errors( 'echo64_settings' ); ?>

            <form method="post" action="options.php">
                <?php settings_fields( 'echo64_settings' ); ?>

                <!-- ── API Configuration ── -->
                <div class="echo64-admin-card">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">⚙</span>
                        <?php esc_html_e( 'API Configuration', 'echo64-chatbot' ); ?>
                    </h2>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="echo64_api_key"><?php esc_html_e( 'Anthropic API Key', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <div class="echo64-key-row">
                                    <input
                                        type="password"
                                        id="echo64_api_key"
                                        name="echo64_api_key"
                                        value="<?php echo esc_attr( $api_key ); ?>"
                                        class="regular-text"
                                        autocomplete="off"
                                        placeholder="sk-ant-…"
                                    />
                                    <button type="button" id="echo64-toggle-key" class="button">Show</button>
                                    <button type="button" id="echo64-test-api" class="button">Test Connection</button>
                                </div>
                                <span id="echo64-test-result"></span>
                                <p class="description">
                                    <?php esc_html_e( 'Get your key at', 'echo64-chatbot' ); ?>
                                    <a href="https://console.anthropic.com" target="_blank" rel="noopener">console.anthropic.com</a>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="echo64_model"><?php esc_html_e( 'Model', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <select id="echo64_model" name="echo64_model">
                                    <?php foreach ( $models as $id => $label ) : ?>
                                        <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $model, $id ); ?>>
                                            <?php echo esc_html( $label ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="echo64_max_tokens"><?php esc_html_e( 'Max Response Tokens', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="number"
                                    id="echo64_max_tokens"
                                    name="echo64_max_tokens"
                                    value="<?php echo esc_attr( $max_tokens ); ?>"
                                    min="256" max="8192" step="128"
                                    class="small-text"
                                />
                                <span class="description"><?php esc_html_e( '256–8192. Higher = longer replies, more cost.', 'echo64-chatbot' ); ?></span>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="echo64_history_limit"><?php esc_html_e( 'Conversation Memory', 'echo64-chatbot' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="number"
                                    id="echo64_history_limit"
                                    name="echo64_history_limit"
                                    value="<?php echo esc_attr( $history_limit ); ?>"
                                    min="2" max="100" step="2"
                                    class="small-text"
                                />
                                <span class="description"><?php esc_html_e( 'Number of past messages sent as context. Higher = better memory, more cost.', 'echo64-chatbot' ); ?></span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── Display Options ── -->
                <div class="echo64-admin-card">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">🖥</span>
                        <?php esc_html_e( 'Display Options', 'echo64-chatbot' ); ?>
                    </h2>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Floating Widget', 'echo64-chatbot' ); ?></th>
                            <td>
                                <label class="echo64-toggle">
                                    <input
                                        type="checkbox"
                                        name="echo64_float_widget"
                                        value="1"
                                        <?php checked( $float_widget, '1' ); ?>
                                    />
                                    <span class="echo64-toggle-label">
                                        <?php esc_html_e( 'Show floating avatar button on every page', 'echo64-chatbot' ); ?>
                                    </span>
                                </label>
                                <p class="description">
                                    <?php esc_html_e( 'When enabled, the Echo-64 avatar appears in the corner of every page and opens the chat. You can still also use [echo64_chat] on specific pages.', 'echo64-chatbot' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── System Prompt ── -->
                <div class="echo64-admin-card">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">🤖</span>
                        <?php esc_html_e( 'Echo-64 Personality Prompt', 'echo64-chatbot' ); ?>
                    </h2>

                    <p class="echo64-prompt-intro">
                        <?php esc_html_e( 'This is the system prompt that defines Echo-64\'s personality, tone, and behavior. Edit it to fine-tune responses. The opening line ("Welcome to NerdAfterDark.com…") is always shown verbatim and is separate from this prompt.', 'echo64-chatbot' ); ?>
                    </p>

                    <div class="echo64-prompt-toolbar">
                        <span id="echo64-prompt-counter" class="echo64-char-count"></span>
                        <button
                            type="button"
                            id="echo64-reset-prompt"
                            class="button"
                            data-default="<?php echo esc_attr( Echo64_Api::DEFAULT_SYSTEM_PROMPT ); ?>"
                        >
                            <?php esc_html_e( '↺ Reset to Default', 'echo64-chatbot' ); ?>
                        </button>
                    </div>

                    <textarea
                        id="echo64_system_prompt"
                        name="echo64_system_prompt"
                        rows="24"
                        class="large-text code echo64-prompt-textarea"
                        spellcheck="false"
                    ><?php echo esc_textarea( $system_prompt ); ?></textarea>
                </div>

                <!-- ── Usage ── -->
                <div class="echo64-admin-card echo64-admin-card--usage">
                    <h2 class="echo64-card-title">
                        <span class="echo64-card-icon">📋</span>
                        <?php esc_html_e( 'Usage', 'echo64-chatbot' ); ?>
                    </h2>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th><?php esc_html_e( 'Embed Shortcode', 'echo64-chatbot' ); ?></th>
                            <td><code>[echo64_chat]</code> — <?php esc_html_e( 'paste into any page or post', 'echo64-chatbot' ); ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Avatar Image', 'echo64-chatbot' ); ?></th>
                            <td>
                                <?php
                                $avatar_path = ECHO64_PLUGIN_DIR . 'assets/images/echo-64-avatar.png';
                                if ( file_exists( $avatar_path ) ) {
                                    echo '<span class="echo64-status-ok">✓ ' . esc_html__( 'Found', 'echo64-chatbot' ) . '</span>';
                                } else {
                                    echo '<span class="echo64-status-warn">⚠ ' . esc_html__( 'Missing — upload echo-64-avatar.png to /assets/images/', 'echo64-chatbot' ) . '</span>';
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Database Table', 'echo64-chatbot' ); ?></th>
                            <td>
                                <?php
                                global $wpdb;
                                $table  = $wpdb->prefix . 'echo64_conversations';
                                $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table;
                                if ( $exists ) {
                                    $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
                                    echo '<span class="echo64-status-ok">✓ ' . sprintf(
                                        esc_html__( '%s — %s messages stored', 'echo64-chatbot' ),
                                        esc_html( $table ),
                                        number_format_i18n( $count )
                                    ) . '</span>';
                                } else {
                                    echo '<span class="echo64-status-warn">⚠ ' . esc_html__( 'Table not found — deactivate and reactivate the plugin.', 'echo64-chatbot' ) . '</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button( __( 'Save Settings', 'echo64-chatbot' ), 'primary echo64-save-btn' ); ?>

            </form>
        </div>
        <?php
    }
}
