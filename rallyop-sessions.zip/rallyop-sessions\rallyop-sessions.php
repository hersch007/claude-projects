<?php
/**
 * Plugin Name: RallyOP Sessions
 * Description: Schedule open-play sessions and collect player RSVPs inside the RallyOP clubhouse.
 * Version: 1.0.0
 * Author: RallyOP
 */

if (!defined('ABSPATH')) { exit; }

register_activation_hook(__FILE__, 'rallyop_sessions_activate');
function rallyop_sessions_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $sessions = $wpdb->prefix . 'rallyop_sessions';
    $rsvps = $wpdb->prefix . 'rallyop_session_rsvps';
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE $sessions (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        group_id bigint(20) unsigned NOT NULL DEFAULT 1,
        title varchar(160) NOT NULL,
        starts_at datetime NOT NULL,
        location varchar(190) NOT NULL DEFAULT '',
        notes text NOT NULL,
        capacity smallint(5) unsigned NOT NULL DEFAULT 0,
        created_by bigint(20) unsigned NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY group_starts (group_id, starts_at)
    ) $charset;");
    dbDelta("CREATE TABLE $rsvps (
        session_id bigint(20) unsigned NOT NULL,
        user_id bigint(20) unsigned NOT NULL,
        status varchar(12) NOT NULL DEFAULT 'yes',
        updated_at datetime NOT NULL,
        PRIMARY KEY (session_id, user_id),
        KEY status (status)
    ) $charset;");
}

add_action('admin_post_rallyop_create_session', 'rallyop_create_session');
function rallyop_create_session() {
    if (!is_user_logged_in()) { auth_redirect(); }
    check_admin_referer('rallyop_create_session');
    global $wpdb;
    $group_id = max(1, absint($_POST['group_id'] ?? 1));
    $title = sanitize_text_field($_POST['title'] ?? 'Open Play');
    $date = sanitize_text_field($_POST['date'] ?? '');
    $time = sanitize_text_field($_POST['time'] ?? '');
    $location = sanitize_text_field($_POST['location'] ?? '');
    $notes = sanitize_textarea_field($_POST['notes'] ?? '');
    $capacity = min(99, max(0, absint($_POST['capacity'] ?? 0)));
    $timestamp = strtotime($date . ' ' . $time);
    if ($title && $timestamp) {
        $wpdb->insert($wpdb->prefix . 'rallyop_sessions', [
            'group_id' => $group_id,
            'title' => $title,
            'starts_at' => wp_date('Y-m-d H:i:s', $timestamp),
            'location' => $location,
            'notes' => $notes,
            'capacity' => $capacity,
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
        ], ['%d','%s','%s','%s','%s','%d','%d','%s']);
        $session_id = (int) $wpdb->insert_id;
        if ($session_id) {
            $wpdb->replace($wpdb->prefix . 'rallyop_session_rsvps', [
                'session_id' => $session_id,
                'user_id' => get_current_user_id(),
                'status' => 'yes',
                'updated_at' => current_time('mysql'),
            ], ['%d','%d','%s','%s']);
        }
    }
    wp_safe_redirect(add_query_arg(['group' => $group_id, 'session_added' => 1], home_url('/')) . '#open-play-sessions');
    exit;
}

add_action('admin_post_rallyop_session_rsvp', 'rallyop_session_rsvp');
function rallyop_session_rsvp() {
    if (!is_user_logged_in()) { auth_redirect(); }
    $session_id = absint($_POST['session_id'] ?? 0);
    check_admin_referer('rallyop_session_rsvp_' . $session_id);
    global $wpdb;
    $session = $wpdb->get_row($wpdb->prepare("SELECT group_id FROM {$wpdb->prefix}rallyop_sessions WHERE id = %d", $session_id));
    $allowed = ['yes', 'maybe', 'no'];
    $status = sanitize_key($_POST['status'] ?? 'yes');
    if ($session && in_array($status, $allowed, true)) {
        $wpdb->replace($wpdb->prefix . 'rallyop_session_rsvps', [
            'session_id' => $session_id,
            'user_id' => get_current_user_id(),
            'status' => $status,
            'updated_at' => current_time('mysql'),
        ], ['%d','%d','%s','%s']);
    }
    $group_id = $session ? (int) $session->group_id : 1;
    wp_safe_redirect(add_query_arg('group', $group_id, home_url('/')) . '#open-play-sessions');
    exit;
}

function rallyop_sessions_markup() {
    if (!is_user_logged_in()) { return ''; }
    global $wpdb;
    $group_id = max(1, absint($_GET['group'] ?? 1));
    $sessions_table = $wpdb->prefix . 'rallyop_sessions';
    $rsvps_table = $wpdb->prefix . 'rallyop_session_rsvps';
    $sessions = $wpdb->get_results($wpdb->prepare(
        "SELECT s.*, SUM(r.status='yes') yes_count, SUM(r.status='maybe') maybe_count
         FROM $sessions_table s LEFT JOIN $rsvps_table r ON r.session_id=s.id
         WHERE s.group_id=%d AND s.starts_at >= DATE_SUB(%s, INTERVAL 3 HOUR)
         GROUP BY s.id ORDER BY s.starts_at ASC LIMIT 12",
        $group_id, current_time('mysql')
    ));
    $my_rsvps = [];
    if ($sessions) {
        $ids = implode(',', array_map('absint', wp_list_pluck($sessions, 'id')));
        $rows = $wpdb->get_results($wpdb->prepare("SELECT session_id,status FROM $rsvps_table WHERE user_id=%d AND session_id IN ($ids)", get_current_user_id()));
        foreach ($rows as $row) { $my_rsvps[(int)$row->session_id] = $row->status; }
    }
    ob_start(); ?>
    <section id="open-play-sessions" class="rop-sessions">
      <div class="rop-kicker">NEXT UP</div>
      <div class="rop-heading-row"><div><h2>Open Play Sessions</h2><p>Pick a time, rally the crew, and know who’s in.</p></div><button class="rop-primary" type="button" data-rop-toggle>＋ SCHEDULE</button></div>
      <?php if (!empty($_GET['session_added'])): ?><div class="rop-notice">Session scheduled. You’re marked as in.</div><?php endif; ?>
      <form class="rop-create" data-rop-form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" hidden>
        <input type="hidden" name="action" value="rallyop_create_session"><input type="hidden" name="group_id" value="<?php echo esc_attr($group_id); ?>">
        <?php wp_nonce_field('rallyop_create_session'); ?>
        <label>SESSION NAME<input name="title" value="Open Play" required maxlength="160"></label>
        <div class="rop-grid"><label>DATE<input type="date" name="date" required min="<?php echo esc_attr(wp_date('Y-m-d')); ?>"></label><label>TIME<input type="time" name="time" required></label></div>
        <label>COURT / LOCATION<input name="location" maxlength="190" placeholder="Riverside Courts"></label>
        <div class="rop-grid"><label>PLAYER LIMIT<input type="number" name="capacity" min="0" max="99" value="8"><small>Use 0 for no limit</small></label><label>NOTE<input name="notes" maxlength="300" placeholder="Bring a ball and water"></label></div>
        <button class="rop-primary" type="submit">CREATE SESSION</button>
      </form>
      <div class="rop-session-list">
      <?php if (!$sessions): ?><div class="rop-empty"><strong>No sessions scheduled yet.</strong><span>Be the first to put the next game on the calendar.</span></div><?php endif; ?>
      <?php foreach ($sessions as $session): $mine = $my_rsvps[(int)$session->id] ?? ''; $start = strtotime($session->starts_at); ?>
        <article class="rop-session-card">
          <div class="rop-date"><strong><?php echo esc_html(wp_date('M', $start)); ?></strong><b><?php echo esc_html(wp_date('j', $start)); ?></b><span><?php echo esc_html(wp_date('D', $start)); ?></span></div>
          <div class="rop-session-info"><h3><?php echo esc_html($session->title); ?></h3><p><?php echo esc_html(wp_date('g:i A', $start)); ?><?php if ($session->location): ?> · <?php echo esc_html($session->location); ?><?php endif; ?></p><?php if ($session->notes): ?><small><?php echo esc_html($session->notes); ?></small><?php endif; ?><div class="rop-count"><strong><?php echo absint($session->yes_count); ?> IN</strong><?php if ($session->capacity): ?> / <?php echo absint($session->capacity); ?> spots<?php endif; ?><?php if ($session->maybe_count): ?> · <?php echo absint($session->maybe_count); ?> maybe<?php endif; ?></div></div>
          <form class="rop-rsvp" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="rallyop_session_rsvp"><input type="hidden" name="session_id" value="<?php echo absint($session->id); ?>"><?php wp_nonce_field('rallyop_session_rsvp_' . $session->id); ?>
            <?php foreach (['yes'=>'I’M IN','maybe'=>'MAYBE','no'=>'CAN’T'] as $value=>$label): ?><button name="status" value="<?php echo esc_attr($value); ?>" class="<?php echo $mine === $value ? 'active' : ''; ?>"><?php echo esc_html($label); ?></button><?php endforeach; ?>
          </form>
        </article>
      <?php endforeach; ?>
      </div>
    </section><?php
    return ob_get_clean();
}

add_shortcode('rallyop_sessions', 'rallyop_sessions_markup');
add_filter('the_content', function($content) {
    if (is_front_page() && is_user_logged_in() && in_the_loop() && is_main_query()) { return $content . rallyop_sessions_markup(); }
    return $content;
}, 25);

add_action('wp_enqueue_scripts', function() {
    if (!is_front_page() || !is_user_logged_in()) { return; }
    wp_register_style('rallyop-sessions', false, [], '1.0.0'); wp_enqueue_style('rallyop-sessions');
    wp_add_inline_style('rallyop-sessions', '.rop-sessions{max-width:1180px;margin:28px auto 72px;padding:36px;border:1px solid #d8d3c7;background:#f7f3e8;color:#17251d;font-family:inherit}.rop-kicker{font-size:12px;font-weight:800;letter-spacing:.16em;color:#db532d}.rop-heading-row{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}.rop-heading-row h2{font-size:clamp(30px,5vw,54px);line-height:1;margin:10px 0}.rop-heading-row p{margin:0 0 24px}.rop-primary{background:#ef5a32!important;color:#fff!important;border:0!important;padding:15px 20px!important;font-weight:800!important;letter-spacing:.05em;cursor:pointer}.rop-create{margin:18px 0 28px;padding:24px;background:#19291f;color:#fff}.rop-create label{display:block;font-size:11px;font-weight:800;letter-spacing:.1em;margin-bottom:16px}.rop-create input{box-sizing:border-box;width:100%;margin-top:7px;padding:13px;border:1px solid #718078;background:#fff;color:#17251d}.rop-create small{display:block;margin-top:5px;font-weight:400;letter-spacing:0}.rop-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.rop-session-list{display:grid;gap:12px}.rop-session-card{display:grid;grid-template-columns:82px 1fr auto;gap:20px;align-items:center;padding:20px;background:#fff;border:1px solid #ded9cf}.rop-date{text-align:center;border-right:1px solid #ded9cf;padding-right:18px}.rop-date strong,.rop-date span{display:block;font-size:11px;letter-spacing:.1em}.rop-date b{display:block;font-size:34px;line-height:1.1}.rop-session-info h3{margin:0 0 5px;font-size:23px}.rop-session-info p,.rop-session-info small{display:block;margin:0 0 5px}.rop-count{margin-top:10px;font-size:12px;color:#59655e}.rop-rsvp{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.rop-rsvp button{border:1px solid #17251d;background:transparent;color:#17251d;padding:9px 11px;font-size:11px;font-weight:800;cursor:pointer}.rop-rsvp button.active{background:#17251d;color:#fff}.rop-empty{display:flex;flex-direction:column;gap:5px;padding:28px;border:1px dashed #aaa297}.rop-notice{padding:12px 16px;margin:0 0 18px;background:#dbe8cf;color:#20351c;font-weight:700}@media(max-width:700px){.rop-sessions{margin:16px 12px 50px;padding:22px}.rop-heading-row{display:block}.rop-heading-row .rop-primary{margin-bottom:18px}.rop-grid{grid-template-columns:1fr}.rop-session-card{grid-template-columns:62px 1fr}.rop-rsvp{grid-column:1/-1;justify-content:stretch}.rop-rsvp button{flex:1}.rop-date{padding-right:12px}}');
    wp_register_script('rallyop-sessions', '', [], '1.0.0', true); wp_enqueue_script('rallyop-sessions');
    wp_add_inline_script('rallyop-sessions', "document.addEventListener('click',function(e){var b=e.target.closest('[data-rop-toggle]');if(!b)return;var f=document.querySelector('[data-rop-form]');f.hidden=!f.hidden;b.textContent=f.hidden?'＋ SCHEDULE':'× CLOSE';if(!f.hidden)f.querySelector('input[name=date]').focus();});");
});
