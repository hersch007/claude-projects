<?php
/**
 * Plugin Name: Quote Builder — Print Module
 * Description: Adds customer-facing print quotes to the Quote Builder plugin. Requires Quote Builder Core (sales-quote-system).
 * Version:     1.0
 * Author:      Start Advertising | RH Brashear
 * Requires Plugins: sales-quote-system
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SQSP_VERSION', '1.0' );

/**
 * Boot only when the core plugin is present.
 */
add_action( 'plugins_loaded', 'sqsp_boot', 20 );
function sqsp_boot() {
	if ( ! defined( 'SQS_VERSION' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p><strong>Quote Builder — Print Module</strong> requires the <strong>Quote Builder Core</strong> plugin to be active.</p></div>';
		} );
		return;
	}

	// ── Hook into the three core extension points ──────────────────────────────
	add_action( 'sqs_toolbar_extra_buttons',  'sqsp_toolbar_button' );
	add_action( 'sqs_quote_info_extra_fields', 'sqsp_extra_info_fields' );
	add_action( 'sqs_bottom_stack_extra',     'sqsp_print_card' );
	add_action( 'wp_head',                    'sqsp_head_assets' );
}

// ── Admin settings (company address + quote terms) ────────────────────────────
add_action( 'admin_menu', 'sqsp_admin_menu', 20 );
function sqsp_admin_menu() {
	if ( ! defined( 'SQS_VERSION' ) ) return;
	add_submenu_page(
		'sqs-pricing-calculator',
		'Print Module Settings',
		'Print Settings',
		'manage_options',
		'sqs-print-settings',
		'sqsp_settings_page'
	);
}

function sqsp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$msg = '';
	if ( isset( $_POST['sqsp_save'] ) ) {
		check_admin_referer( 'sqsp_settings_save', 'sqsp_nonce' );
		if ( isset( $_POST['sqs_company_address'] ) ) {
			update_option( 'sqs_company_address', sanitize_textarea_field( wp_unslash( $_POST['sqs_company_address'] ) ) );
		}
		if ( isset( $_POST['sqs_quote_terms'] ) ) {
			update_option( 'sqs_quote_terms', sanitize_textarea_field( wp_unslash( $_POST['sqs_quote_terms'] ) ) );
		}
		$msg = 'Settings saved.';
	}
	$addr  = get_option( 'sqs_company_address', '' );
	$terms = get_option( 'sqs_quote_terms', '' );
	?>
	<div class="wrap">
	<h1>Quote Builder &mdash; Print Module Settings</h1>
	<?php if ( $msg ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
	<form method="post" style="max-width:560px;">
		<?php wp_nonce_field( 'sqsp_settings_save', 'sqsp_nonce' ); ?>
		<input type="hidden" name="sqsp_save" value="1" />
		<div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:24px;margin:16px 0;">
			<h2 style="margin-top:0;border-bottom:1px solid #eee;padding-bottom:10px;">&#128438; Print Settings</h2>
			<p>
				<label><strong>Company Address</strong> <span class="description">(printed top-right on every quote)</span><br>
				<textarea name="sqs_company_address" class="large-text" rows="3"
					placeholder="123 Main St&#10;City, ST 00000&#10;(555) 000-0000"
					style="margin-top:4px;"><?php echo esc_textarea( $addr ); ?></textarea></label>
			</p>
			<p>
				<label><strong>Quote Terms / Disclaimer</strong> <span class="description">(printed at the bottom of every quote)</span><br>
				<textarea name="sqs_quote_terms" class="large-text" rows="4"
					placeholder="Quotes are valid for 30 days. All orders are subject to standard terms and conditions..."
					style="margin-top:4px;"><?php echo esc_textarea( $terms ); ?></textarea></label>
			</p>
		</div>
		<p><button class="button button-primary button-large">Save Settings</button></p>
	</form>
	</div>
	<?php
}

// ── Toolbar: Print Quote button ───────────────────────────────────────────────
function sqsp_toolbar_button() {
	echo '<button id="sqsPrintBtn" type="button" class="sqs-bar-btn">&#128438; Print Quote</button>';
}

// ── Extra quote-info fields (injected into core's Quote Info grid) ────────────
function sqsp_extra_info_fields() {
	?>
	<div class="sqc-field"><label>Customer Email</label><input id="customerEmail" type="email" data-sqs-meta="customerEmail" placeholder="customer@example.com" /></div>
	<div class="sqc-field"><label>Prepared By Email</label><input id="preparedByEmail" type="email" data-sqs-meta="preparedByEmail" placeholder="rep@yourcompany.com" /></div>
	<div class="sqc-field"><label>Lead Time</label><input id="leadTime" data-sqs-meta="leadTime" placeholder="e.g. 4 weeks" /></div>
	<div class="sqc-field"><label>FOB Location</label><input id="fobLocation" data-sqs-meta="fobLocation" placeholder="e.g. Placentia, CA" /></div>
	<?php
}

// ── Print card (hidden on-screen, visible when printing) ─────────────────────
function sqsp_print_card() {
	$logo    = get_option( 'sqs_logo_url', '' );
	$company = get_option( 'sqs_company_name', 'Quote Builder' );
	$address = get_option( 'sqs_company_address', '' );
	$terms   = get_option( 'sqs_quote_terms', '' );
	?>
	<div class="sqc-card sqc-print-only">
		<div class="sqp-header">
			<?php if ( $logo ) : ?>
				<img src="<?php echo esc_url( $logo ); ?>" class="sqp-logo" alt="<?php echo esc_attr( $company ); ?>" />
			<?php else : ?>
				<div style="font-size:20px;font-weight:800;color:#1a202c;"><?php echo esc_html( $company ); ?></div>
			<?php endif; ?>
			<div class="sqp-addr"><?php echo nl2br( esc_html( $address ) ); ?></div>
		</div>

		<div class="sqp-qnum">Quote Number &nbsp;<span id="prtQnum">—</span></div>

		<div class="sqp-info">
			<div class="sqp-info-col">
				<div class="sqp-info-row"><span class="sqp-info-lbl">Account Name</span><span class="sqp-info-val" id="prtCompany">—</span></div>
				<div class="sqp-info-row"><span class="sqp-info-lbl">Contact Name</span><span class="sqp-info-val" id="prtCustomer">—</span></div>
				<div class="sqp-info-row"><span class="sqp-info-lbl">Email</span><span class="sqp-info-val" id="prtCustEmail">—</span></div>
				<div class="sqp-info-row"><span class="sqp-info-lbl">Created Date</span><span class="sqp-info-val" id="prtDate">—</span></div>
			</div>
			<div class="sqp-info-col">
				<div class="sqp-info-row"><span class="sqp-info-lbl">Prepared By</span><span class="sqp-info-val" id="prtPrepBy">—</span></div>
				<div class="sqp-info-row"><span class="sqp-info-lbl">Email</span><span class="sqp-info-val" id="prtPrepEmail">—</span></div>
			</div>
		</div>

		<table class="sqp-table">
			<thead><tr>
				<th style="width:46%;">Product Description</th>
				<th>Sales Price</th>
				<th>Quantity</th>
				<th>Total Price</th>
			</tr></thead>
			<tbody id="prtItems"></tbody>
			<tfoot id="prtTfoot"></tfoot>
		</table>

		<div class="sqp-foot-info">
			<div class="sqp-foot-row"><span class="sqp-info-lbl">Lead Time</span><span class="sqp-info-val" id="prtLeadTime">—</span></div>
			<div class="sqp-foot-row"><span class="sqp-info-lbl">FOB</span><span class="sqp-info-val" id="prtFob">—</span></div>
		</div>

		<p class="sqp-terms" id="prtTerms"><?php echo esc_html( $terms ); ?></p>
		<div class="sqp-stamp" id="prtStamp"></div>
	</div>
	<?php
}

// ── Inject CSS + JS on every frontend page (tiny payload, internal tool) ─────
function sqsp_head_assets() {
	if ( is_admin() ) return;
	?>
	<style>
	/* ── Quote Builder Print Module ── */

	/* Print button style */
	#sqsPrintBtn { color:#0369a1 !important; border-color:#7dd3fc !important; }
	#sqsPrintBtn:hover { background:#f0f9ff !important; border-color:#0284c7 !important; color:#0284c7 !important; }

	/* Hide print card on screen — core also sets this, belt-and-suspenders */
	.sqc-print-only { display:none !important; }

	/* ── @media print ── */
	/*
	 * WHY visibility instead of display:none on body > *:
	 * The .sqc-print-only div is nested several levels deep inside WordPress
	 * theme wrappers. Setting display:none on body > * hides the entire tree
	 * and no child rule can un-hide a descendant of a display:none ancestor.
	 * visibility:hidden + position:fixed sidesteps that — the element is taken
	 * out of normal flow entirely and rendered at the top of the printed page.
	 */
	@page { size:letter portrait; margin:0.65in; }
	@media print {
		/* Make everything invisible (works across all nesting levels) */
		body * { visibility:hidden !important; }

		/* Pull the print card out of the DOM flow and render it at page top */
		.sqc-print-only {
			visibility:visible !important;
			display:block !important;
			position:fixed !important;
			inset:0 !important;
			padding:0 !important;
			margin:0 !important;
			background:#fff !important;
			z-index:99999 !important;
			font-family:Arial,Helvetica,sans-serif !important;
			font-size:13px !important;
			color:#1a202c !important;
			box-sizing:border-box !important;
			overflow:visible !important;
		}
		/* Make all children of the print card visible */
		.sqc-print-only * { visibility:visible !important; }

		/* ── Inner layout styles ── */
		/* Header: logo + address */
		.sqp-header { display:flex !important; align-items:flex-start !important; justify-content:space-between !important; padding:0.65in 0.65in 12px !important; border-bottom:1px solid #c8cdd5 !important; margin-bottom:18px !important; }
		.sqp-logo { max-height:68px !important; max-width:220px !important; width:auto !important; display:block !important; }
		.sqp-addr { font-size:11px !important; color:#4a5568 !important; text-align:right !important; line-height:1.65 !important; }

		/* Body of the print card (below header) — add side padding */
		.sqp-qnum,
		.sqp-info,
		.sqp-table,
		.sqp-foot-info,
		.sqp-terms,
		.sqp-stamp { padding-left:0.65in !important; padding-right:0.65in !important; }

		/* Quote number */
		.sqp-qnum { display:block !important; font-size:13px !important; font-weight:600 !important; color:#1a202c !important; margin-bottom:16px !important; }
		.sqp-qnum span { font-weight:400 !important; }

		/* Info block */
		.sqp-info { display:grid !important; grid-template-columns:1fr 1fr !important; gap:0 !important; margin-bottom:18px !important; border:1px solid #c8cdd5 !important; border-radius:3px !important; overflow:hidden !important; font-size:12px !important; }
		.sqp-info-col { display:block !important; padding:12px 14px !important; }
		.sqp-info-col + .sqp-info-col { border-left:1px solid #c8cdd5 !important; }
		.sqp-info-row { display:flex !important; gap:6px !important; margin-bottom:5px !important; line-height:1.45 !important; }
		.sqp-info-row:last-child { margin-bottom:0 !important; }
		.sqp-info-lbl { font-weight:700 !important; color:#374151 !important; min-width:92px !important; flex-shrink:0 !important; }
		.sqp-info-val { color:#1a202c !important; }

		/* Line items table */
		.sqp-table { display:table !important; width:100% !important; border-collapse:collapse !important; font-size:12px !important; margin-bottom:16px !important; }
		.sqp-table thead { display:table-header-group !important; }
		.sqp-table thead tr { background:#374151 !important; color:#fff !important; }
		.sqp-table thead th { display:table-cell !important; padding:9px 10px !important; text-align:left !important; font-weight:700 !important; font-size:11px !important; text-transform:uppercase !important; letter-spacing:.04em !important; background:#374151 !important; color:#fff !important; border:none !important; -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; }
		.sqp-table thead th:not(:first-child) { text-align:right !important; }
		.sqp-table tbody { display:table-row-group !important; }
		.sqp-table tbody tr:nth-child(even) { background:#f7f8fa !important; -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; }
		.sqp-table tbody td { display:table-cell !important; padding:8px 10px !important; border-bottom:1px solid #e2e8f0 !important; color:#1a202c !important; vertical-align:middle !important; }
		.sqp-table tbody td:not(:first-child) { text-align:right !important; }
		.sqp-table tfoot { display:table-footer-group !important; }
		.sqp-table tfoot td { display:table-cell !important; padding:8px 10px !important; font-weight:700 !important; border-top:2px solid #374151 !important; background:#f3f4f6 !important; -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; }
		.sqp-table tfoot td:not(:first-child) { text-align:right !important; }

		/* Footer info row */
		.sqp-foot-info { display:flex !important; gap:28px !important; font-size:12px !important; margin-bottom:10px !important; }
		.sqp-foot-row { display:flex !important; gap:6px !important; align-items:baseline !important; }
		.sqp-foot-row .sqp-info-lbl { min-width:auto !important; }

		/* Terms */
		.sqp-terms { display:block !important; font-size:10.5px !important; color:#6b7280 !important; line-height:1.55 !important; margin:12px 0 0 !important; border-top:1px solid #e2e8f0 !important; padding-top:8px !important; }

		/* Stamp */
		.sqp-stamp { display:block !important; font-size:9px !important; color:#9ca3af !important; text-align:right !important; margin-top:10px !important; padding-bottom:0.65in !important; }
	}
	</style>

	<script>
	(function () {
		'use strict';

		// ── Helpers (use SQS public API once core boots) ──────────────────────
		function gv(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
		function sv(id, val) { var el = document.getElementById(id); if (el) el.textContent = val; }

		function money(v) {
			return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(v || 0));
		}
		function num(v, d) {
			d = d == null ? 2 : d;
			return Number(v || 0).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
		}
		function esc(s) {
			return String(s || '').replace(/[&<>"']/g, function (m) {
				return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
			});
		}

		// ── Print button ──────────────────────────────────────────────────────
		document.addEventListener('DOMContentLoaded', function () {
			var btn = document.getElementById('sqsPrintBtn');
			if (btn) btn.addEventListener('click', function () { window.print(); });
		});

		// ── Listen for core's sqs:update broadcast ────────────────────────────
		document.addEventListener('sqs:update', function (e) {
			renderPrintQuote(e.detail.result, e.detail.state, e.detail.quoteNumber);
		});

		function renderPrintQuote(r, state, quoteNumber) {
			var company   = gv('companyName')    || '—';
			var customer  = gv('customerName')   || '—';
			var custEmail = gv('customerEmail')  || '—';
			var prepBy    = gv('preparedBy')     || '—';
			var prepEmail = gv('preparedByEmail')|| '—';
			var leadTime  = gv('leadTime')       || '—';
			var fob       = gv('fobLocation')    || '—';
			var notes     = gv('quoteNotes');
			var rawDate   = gv('quoteDate');
			var qnum      = gv('quoteNumber') || quoteNumber || '—';

			var printDate = rawDate
				? new Date(rawDate + 'T00:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
				: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

			sv('prtQnum',     qnum);
			sv('prtCompany',  company);
			sv('prtCustomer', customer);
			sv('prtCustEmail',custEmail);
			sv('prtDate',     printDate);
			sv('prtPrepBy',   prepBy);
			sv('prtPrepEmail',prepEmail);
			sv('prtLeadTime', leadTime);
			sv('prtFob',      fob);
			sv('prtStamp',    'Generated ' + new Date().toLocaleString());

			// Override PHP-rendered terms only if the user typed notes
			var termsEl = document.getElementById('prtTerms');
			if (termsEl && notes) termsEl.textContent = notes;

			// Build line-items from price breaks
			var f    = state.forms[state.product];
			var desc = r.productName + ' — ' + r.dimensions + ' — ' + f.filmType + ' — ' + f.formula;

			var rows = r.priceBreaks.map(function (pb) {
				if (!pb.qty) return '';
				var qtyLabel = state.product === 'tubing'
					? num(pb.qty, 0) + ' rolls'
					: num(pb.qty, 0) + ' bags';
				return '<tr>'
					+ '<td>' + esc(desc) + '</td>'
					+ '<td>' + money(pb.unitPrice) + '</td>'
					+ '<td>' + esc(qtyLabel) + '</td>'
					+ '<td>' + money(pb.sales) + '</td>'
					+ '</tr>';
			}).join('');

			var itemsEl = document.getElementById('prtItems');
			if (itemsEl) {
				itemsEl.innerHTML = rows || '<tr><td colspan="4" style="color:#9ca3af;">No price breaks calculated.</td></tr>';
			}

			// Footer row: quoted quantity totals
			var tfootEl = document.getElementById('prtTfoot');
			if (tfootEl) {
				var qtyLabel = state.product === 'tubing'
					? num(r.quantity, 0) + ' rolls'
					: num(r.quantity, 0) + ' bags';
				tfootEl.innerHTML = '<tr>'
					+ '<td><strong>Quoted Quantity</strong></td>'
					+ '<td>' + money(r.unitPrice) + '</td>'
					+ '<td>' + esc(qtyLabel) + '</td>'
					+ '<td>' + money(r.salesAmount) + '</td>'
					+ '</tr>';
			}
		}

	}());
	</script>
	<?php
}
