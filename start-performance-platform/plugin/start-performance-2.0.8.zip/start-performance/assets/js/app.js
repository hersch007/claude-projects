// Auto-hide toast after 3 seconds
document.addEventListener('DOMContentLoaded', function() {
    var toast = document.querySelector('.sp-toast');
    if (toast) {
        setTimeout(function() {
            toast.style.transition = 'opacity .4s';
            toast.style.opacity = '0';
            setTimeout(function() { toast.remove(); }, 400);
        }, 3000);
    }

    // ── Collapsible nav groups ────────────────────────────────────────────────
    var nav = document.querySelector('.sp-nav');
    if (!nav) return;

    var activeSection = nav.getAttribute('data-active-section') || '';
    var STORAGE_KEY = 'sp_nav_open';

    function getSavedOpen() {
        try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch(e) { return {}; }
    }
    function saveOpen(state) {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch(e) {}
    }

    function setGroupOpen(group, open, animate) {
        var items = group.querySelector('.sp-nav-group-items');
        if (open) {
            group.classList.add('open');
            items.style.maxHeight = '1000px';
        } else {
            if (animate) {
                // measure current height first so transition starts from real height
                items.style.maxHeight = items.scrollHeight + 'px';
                requestAnimationFrame(function() { items.style.maxHeight = '0'; });
            } else {
                items.style.maxHeight = '0';
            }
            group.classList.remove('open');
        }
    }

    var savedOpen = getSavedOpen();
    // ── Mobile sidebar toggle ─────────────────────────────────────────────────
    var sidebar  = document.getElementById('sp-sidebar');
    var overlay  = document.getElementById('sp-overlay');
    var menuBtn  = document.getElementById('sp-menu-toggle');

    function openSidebar() {
        if (sidebar) sidebar.classList.add('open');
        if (overlay) overlay.classList.add('active');
    }
    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
    }
    if (menuBtn)  menuBtn.addEventListener('click', openSidebar);
    if (overlay)  overlay.addEventListener('click', closeSidebar);
    // Close sidebar when a nav link is tapped
    if (sidebar) {
        sidebar.querySelectorAll('.sp-nav-item').forEach(function(link) {
            link.addEventListener('click', closeSidebar);
        });
    }

    var groups = nav.querySelectorAll('.sp-nav-group');

    groups.forEach(function(group) {
        var key = group.getAttribute('data-section');
        var isActive = activeSection && key === activeSection;
        // Open if active section, or if user previously had it open
        var shouldOpen = isActive || (savedOpen[key] === true);
        setGroupOpen(group, shouldOpen);

        var toggle = group.querySelector('.sp-nav-section-toggle');
        if (toggle) {
            toggle.addEventListener('click', function() {
                var nowOpen = group.classList.contains('open');
                setGroupOpen(group, !nowOpen, true);
                var state = getSavedOpen();
                state[key] = !nowOpen;
                saveOpen(state);
            });
        }
    });
});

// ── Global Search ─────────────────────────────────────────────────────────────
(function(){
    var input   = document.getElementById('sp-global-search');
    var results = document.getElementById('sp-search-results');
    if (!input || !results) return;

    var ajaxUrl = (window.spData && spData.ajaxUrl) ? spData.ajaxUrl : '';
    // Build search URL from home URL
    var searchBase = window.location.origin + '/sp-app/?sp_ajax=search&q=';
    // Detect from existing links
    var firstNav = document.querySelector('.sp-nav-item');
    if (firstNav) {
        var href = firstNav.getAttribute('href') || '';
        var m = href.match(/^(https?:\/\/[^\/]+)/);
        if (m) searchBase = m[1] + '/sp-app/?sp_ajax=search&q=';
    }

    var typeLinks = {
        contact: '/sp-app/?view=contacts&action=view&id=',
        company: '/sp-app/?view=companies&action=view&id=',
        lead:    '/sp-app/?view=leads&action=view&id='
    };
    var typeLabels = { contact: 'Contact', company: 'Company', lead: 'Lead' };
    var typeColors = { contact: '#3b82f6', company: '#8b5cf6', lead: '#f59e0b' };

    var timer;
    input.addEventListener('input', function(){
        clearTimeout(timer);
        var q = input.value.trim();
        if (q.length < 2) { results.style.display = 'none'; return; }
        timer = setTimeout(function(){
            fetch(searchBase + encodeURIComponent(q), { credentials: 'same-origin' })
                .then(function(r){ return r.json(); })
                .then(function(data){
                    results.innerHTML = '';
                    if (!data.success || !data.data.length) {
                        results.innerHTML = '<div class="sp-search-empty">No results for "' + q + '"</div>';
                        results.style.display = 'block';
                        return;
                    }
                    var groups = {};
                    data.data.forEach(function(r){
                        if (!groups[r.type]) groups[r.type] = [];
                        groups[r.type].push(r);
                    });
                    Object.keys(groups).forEach(function(type){
                        var lbl = document.createElement('div');
                        lbl.className = 'sp-search-group-label';
                        lbl.textContent = typeLabels[type] || type;
                        results.appendChild(lbl);
                        groups[type].forEach(function(r){
                            var a = document.createElement('a');
                            a.className = 'sp-search-item';
                            a.href = typeLinks[type] + r.id;
                            a.innerHTML = '<div class="sp-search-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="'+typeColors[type]+'" stroke-width="2" stroke-linecap="round" width="12" height="12"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div><div style="min-width:0"><div class="sp-search-item-label">'+escHtml(r.label)+'</div><div class="sp-search-item-sub">'+escHtml(r.sub||'')+'</div></div>';
                            results.appendChild(a);
                        });
                    });
                    results.style.display = 'block';
                })
                .catch(function(){});
        }, 250);
    });

    document.addEventListener('click', function(e){
        if (!input.contains(e.target) && !results.contains(e.target)) {
            results.style.display = 'none';
        }
    });

    input.addEventListener('keydown', function(e){
        if (e.key === 'Escape') { results.style.display = 'none'; input.blur(); }
    });

    function escHtml(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
})();

// ── FAB + Quick Task Modal ────────────────────────────────────────────────────
(function(){
    var fabBtn  = document.getElementById('sp-fab-btn');
    var fabMenu = document.getElementById('sp-fab-menu');
    var taskBtn = document.getElementById('sp-fab-task-btn');
    var modal   = document.getElementById('sp-task-modal');
    var closeBtn = document.getElementById('sp-task-modal-close');
    var cancelBtn = document.getElementById('sp-task-modal-cancel');

    if (!fabBtn) return;

    var fabOpen = false;
    function setFab(open) {
        fabOpen = open;
        fabBtn.classList.toggle('open', open);
        fabMenu.classList.toggle('open', open);
    }

    fabBtn.addEventListener('click', function(){ setFab(!fabOpen); });

    document.addEventListener('click', function(e){
        if (fabOpen && !document.getElementById('sp-fab-wrap').contains(e.target)) setFab(false);
    });

    if (taskBtn) {
        taskBtn.addEventListener('click', function(){
            setFab(false);
            modal.style.display = 'flex';
            var titleInput = modal.querySelector('input[name="title"]');
            if (titleInput) setTimeout(function(){ titleInput.focus(); }, 50);
        });
    }

    function closeModal() { modal.style.display = 'none'; }
    if (closeBtn)  closeBtn.addEventListener('click',  closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) modal.addEventListener('click', function(e){ if (e.target === modal) closeModal(); });

    document.addEventListener('keydown', function(e){
        if (e.key === 'Escape' && modal && modal.style.display !== 'none') closeModal();
    });
})();

// ── Bulk Actions ──────────────────────────────────────────────────────────────
(function(){
    var form = document.getElementById('sp-bulk-form');
    if (!form) return;
    var checkAll = document.getElementById('sp-check-all');
    var bar      = document.getElementById('sp-bulk-bar');
    var counter  = document.getElementById('sp-bulk-n');
    var actionSel = document.getElementById('sp-bulk-action');
    var clearBtn = document.getElementById('sp-bulk-clear');
    var rows = function(){ return Array.prototype.slice.call(form.querySelectorAll('.sp-row-check')); };

    function refresh() {
        var checked = rows().filter(function(c){ return c.checked; });
        if (counter) counter.textContent = checked.length;
        if (bar) bar.style.display = checked.length ? 'flex' : 'none';
        rows().forEach(function(c){
            var tr = c.closest('tr');
            if (tr) tr.classList.toggle('sp-row-selected', c.checked);
        });
        if (checkAll) {
            var all = rows();
            checkAll.checked = all.length > 0 && checked.length === all.length;
            checkAll.indeterminate = checked.length > 0 && checked.length < all.length;
        }
    }

    if (checkAll) {
        checkAll.addEventListener('change', function(){
            rows().forEach(function(c){ c.checked = checkAll.checked; });
            refresh();
        });
    }
    rows().forEach(function(c){ c.addEventListener('change', refresh); });

    if (clearBtn) {
        clearBtn.addEventListener('click', function(){
            rows().forEach(function(c){ c.checked = false; });
            if (checkAll) checkAll.checked = false;
            refresh();
        });
    }

    form.addEventListener('submit', function(e){
        var checked = rows().filter(function(c){ return c.checked; });
        var action  = actionSel ? actionSel.value : '';
        if (!checked.length) { e.preventDefault(); return; }
        if (!action) { e.preventDefault(); alert('Choose a bulk action first.'); return; }
        if (action === 'delete') {
            if (!confirm('Delete ' + checked.length + ' selected record(s)? This cannot be undone.')) {
                e.preventDefault();
            }
        }
    });

    refresh();
})();
