<?php
/*
 * Plugin Name: Start Performance
 * Description: Start Performance Platform
 * Version:     1.1.4
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_VERSION',    '1.1.4' );
define( 'SP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Default PIN — change this in WordPress admin under Settings > General (or we'll add a settings page later)
define( 'SP_PIN', '1234' );

// ── Rewrite rules ────────────────────────────────────────────────────────────

function sp_add_rewrite_rules() {
    add_rewrite_rule( '^sp-login/?$', 'index.php?sp_page=login', 'top' );
    add_rewrite_tag( '%sp_page%', '([^&]+)' );
}
add_action( 'init', 'sp_add_rewrite_rules' );

register_activation_hook( __FILE__, function() {
    sp_add_rewrite_rules();
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

// ── Intercept /sp-login/ ─────────────────────────────────────────────────────

function sp_intercept_request() {
    if ( get_query_var( 'sp_page' ) !== 'login' ) return;
    require_once SP_PLUGIN_DIR . 'templates/login.php';
    exit;
}
add_action( 'template_redirect', 'sp_intercept_request', 1 );

// ── Handle PIN login POST ─────────────────────────────────────────────────────

function sp_handle_login() {
    if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) return;
    if ( empty( $_POST['sp_login_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['sp_login_nonce'], 'sp_login' ) ) {
        wp_redirect( home_url( '/sp-login/?error=invalid' ) );
        exit;
    }

    $entered_pin = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';

    if ( $entered_pin !== SP_PIN ) {
        wp_redirect( home_url( '/sp-login/?error=pin' ) );
        exit;
    }

    // PIN correct — log in the first admin user
    $admins = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
    if ( empty( $admins ) ) {
        wp_redirect( home_url( '/sp-login/?error=nouser' ) );
        exit;
    }

    wp_set_current_user( $admins[0]->ID );
    wp_set_auth_cookie( $admins[0]->ID, true );

    wp_redirect( admin_url() );
    exit;
}
add_action( 'init', 'sp_handle_login' );
