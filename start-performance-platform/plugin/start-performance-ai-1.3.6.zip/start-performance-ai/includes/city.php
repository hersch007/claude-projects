<?php
/*
 * Government Service Core integration.
 *
 * Adds AI Ticket Triage (per service request) and AI Queue Analysis (ticket
 * list) for instances running Start Performance — Government Service Core
 * (City of Clinton style installs). Loaded from sp_ai_register() only when
 * SP_CITY_VERSION is defined, and attaches to the hooks Government Service
 * Core fires in templates/views/city-tickets.php:
 *
 *   do_action( 'sp_city_ticket_edit_after', $ticket_id, $ticket );
 *   do_action( 'sp_city_tickets_after_list', $rows );
 *
 * Requires Government Service Core 1.2.35+ (the version that fires these hooks).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function sp_ai_city_register() {
    add_action( 'sp_city_ticket_edit_after',          'sp_ai_city_ticket_triage_ui', 10, 2 );
    add_action( 'wp_ajax_sp_ai_city_ticket_triage',   'sp_ai_ajax_city_ticket_triage' );
    add_action( 'sp_city_tickets_after_list',         'sp_ai_city_ticket_analysis_ui' );
    add_action( 'wp_ajax_sp_ai_city_ticket_analysis', 'sp_ai_ajax_city_ticket_analysis' );
}

// ── Access ────────────────────────────────────────────────────────────────────

// City admins, supervisors and employees (plus super admins) may use the AI
// features. Call-center roles only create tickets and never open the ticket
// detail view, so they are excluded — both from the UI and the AJAX handlers.
function sp_ai_city_can_use() {
    if ( ! sp_ai_authed() ) return false;
    if ( function_exists( 'sp_city_is_restricted' ) && sp_city_is_restricted() ) return false;
    return true;
}

// ── Shared assets ─────────────────────────────────────────────────────────────

// Markdown output styling + client-side renderer, printed once per page so the
// triage card (ticket detail) and analysis card (ticket list) both format their
// AJAX responses the same way the server-side sp_ai_render_markdown() does.
function sp_ai_city_md_assets() {
    static $done = false;
    if ( $done ) return;
    $done = true;
    ?>
    <style>
    .sp-ai-md-out h2{font-size:16px;font-weight:700;color:#0f172a;margin:20px 0 4px;display:flex;align-items:center;gap:7px}
    .sp-ai-md-out h2:first-child{margin-top:0}
    .sp-ai-md-out h3{font-size:14px;font-weight:700;color:#1e293b;margin:14px 0 3px;display:flex;align-items:center;gap:6px}
    .sp-ai-md-out p{margin:0 0 10px;color:#374151}
    .sp-ai-md-out strong{font-weight:600;color:#0f172a}
    .sp-ai-md-out ul{margin:4px 0 10px 18px;padding:0}
    .sp-ai-md-out li{margin-bottom:3px}
    .sp-ai-city-btn{background:rgba(255,255,255,.08);border:none;border-radius:6px;padding:6px 14px;cursor:pointer;color:#e2e8f0;font-size:.8rem}
    .sp-ai-city-btn:disabled{opacity:.6;cursor:default}
    </style>
    <script>
    if ( typeof spAiRenderMd === 'undefined' ) {
        window.spAiRenderMd = (function(){
            var ih2 = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15" style="flex-shrink:0;color:#6366f1"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>';
            var ih3 = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="13" height="13" style="flex-shrink:0;color:#94a3b8"><path d="M9 5l7 7-7 7"/></svg>';
            function esc(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
            function inline(t){ return esc(t).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>'); }
            return function(md){
                var lines = String(md).split('\n'), html = '', inUl = false;
                lines.forEach(function(line){
                    if (/^# /.test(line))       { if (inUl){html+='</ul>';inUl=false;} html += '<h2>'+ih2+esc(line.replace(/^# /,''))+'</h2>'; }
                    else if (/^## /.test(line)) { if (inUl){html+='</ul>';inUl=false;} html += '<h3>'+ih3+esc(line.replace(/^## /,''))+'</h3>'; }
                    else if (/^[-*] /.test(line)) { if (!inUl){html+='<ul>';inUl=true;} html += '<li>'+inline(line.replace(/^[-*] /,''))+'</li>'; }
                    else if (line.trim()==='')  { if (inUl){html+='</ul>';inUl=false;} }
                    else                        { if (inUl){html+='</ul>';inUl=false;} html += '<p>'+inline(line)+'</p>'; }
                });
                if (inUl) html += '</ul>';
                return html;
            };
        })();
    }
    // Wire a "generate" button to an AJAX action and render the markdown result.
    function spAiCityBind(btnId, outId, statusId, metaId, ajaxAction, doneLabel, extra){
        var btn = document.getElementById(btnId), out = document.getElementById(outId);
        var status = document.getElementById(statusId), meta = document.getElementById(metaId);
        if (!btn) return;
        btn.addEventListener('click', function(){
            btn.disabled = true; status.style.display = 'inline';
            var fd = new FormData();
            fd.append('action', ajaxAction);
            fd.append('nonce',  btn.dataset.nonce);
            if (extra) { Object.keys(extra).forEach(function(k){ fd.append(k, extra[k]); }); }
            fetch(btn.dataset.ajax, { method:'POST', body:fd, credentials:'same-origin' })
                .then(function(r){ return r.json(); })
                .then(function(data){
                    status.style.display = 'none'; btn.disabled = false; btn.textContent = doneLabel;
                    if (data.success) {
                        out.innerHTML = spAiRenderMd(data.data.text);
                        out.style.display = 'block';
                        if (meta) meta.textContent = 'Generated just now';
                    } else {
                        out.textContent = 'Error: ' + (data.data || 'Unknown error');
                        out.style.display = 'block';
                    }
                })
                .catch(function(){
                    status.style.display = 'none'; btn.disabled = false;
                    out.textContent = 'Request failed.'; out.style.display = 'block';
                });
        });
    }
    </script>
    <?php
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function sp_ai_city_source_label( $source ) {
    $labels = array( 'call_center' => 'Call Center', 'staff' => 'City Direct', 'public' => 'Public (online form)' );
    return isset( $labels[ $source ] ) ? $labels[ $source ] : ucfirst( $source );
}

function sp_ai_city_department_names() {
    global $wpdb;
    $names = $wpdb->get_col( "SELECT name FROM {$wpdb->prefix}sp_city_departments WHERE active = 1 ORDER BY sort_order, name" );
    return $names ? $names : array( 'Water/Sewer', 'Electric', 'Streets/Sanitation', 'Utility Billing' );
}

// ── Ticket Triage UI (ticket detail) ──────────────────────────────────────────

function sp_ai_city_ticket_triage_ui( $ticket_id, $ticket = null ) {
    if ( ! sp_ai_is_configured() || ! sp_ai_city_can_use() ) return;
    $ticket_id = (int) $ticket_id;
    $nonce     = wp_create_nonce( 'sp_ai_city_ticket_triage' );
    $cached    = get_option( 'sp_ai_city_triage_' . $ticket_id );
    $text      = $cached ? $cached['text'] : '';
    $gen_at    = $cached ? (int) $cached['generated_at'] : 0;
    $gen_label = $gen_at ? 'Generated ' . human_time_diff( $gen_at ) . ' ago' : '';
    // Flag a stale triage when the ticket has been edited since it was generated.
    if ( $gen_at && $ticket && ! empty( $ticket->updated_at ) && strtotime( $ticket->updated_at ) > $gen_at ) {
        $gen_label .= ' · ticket updated since';
    }
    $action_html = '<span id="sp-ai-ct-meta" style="margin-left:auto;font-size:11px;color:#94a3b8">' . esc_html( $gen_label ) . '</span>';
    $well        = sp_ai_content_well_style();

    sp_ai_city_md_assets();
    echo '<div style="margin-top:12px">';
    sp_ai_card_start( 'AI Ticket Triage', $action_html );
    ?>
        <div id="sp-ai-ct-output" class="sp-ai-md-out" style="<?php echo $text ? '' : 'display:none;'; ?><?php echo $well; ?>font-size:14px;line-height:1.75;color:#1e293b;margin-bottom:16px"><?php echo $text ? sp_ai_render_markdown( $text ) : ''; ?></div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <button type="button" id="sp-ai-ct-btn" class="sp-ai-city-btn"
                data-nonce="<?php echo esc_attr( $nonce ); ?>"
                data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
                <?php echo $text ? 'Retriage' : 'Triage Ticket'; ?>
            </button>
            <span id="sp-ai-ct-status" style="font-size:12px;color:#94a3b8;display:none">Analyzing…</span>
            <span style="font-size:11px;color:#64748b">Suggests departments, priority, next steps and a resident update. Staff make the final call.</span>
        </div>
    <?php
    sp_ai_card_end();
    echo '</div>';
    ?>
    <script>
    spAiCityBind('sp-ai-ct-btn', 'sp-ai-ct-output', 'sp-ai-ct-status', 'sp-ai-ct-meta', 'sp_ai_city_ticket_triage', 'Retriage', { ticket_id: <?php echo $ticket_id; ?> });
    </script>
    <?php
}

// ── Ticket Triage AJAX ────────────────────────────────────────────────────────

function sp_ai_ajax_city_ticket_triage() {
    if ( ! check_ajax_referer( 'sp_ai_city_ticket_triage', 'nonce', false ) ) {
        wp_send_json_error( 'Invalid nonce' );
    }
    if ( ! sp_ai_city_can_use() ) {
        wp_send_json_error( 'Not authorized' );
    }
    if ( ! sp_ai_is_configured() ) {
        wp_send_json_error( 'AI is not configured — add an API key under Settings → AI Integration.' );
    }

    $ticket_id = (int) ( isset( $_POST['ticket_id'] ) ? $_POST['ticket_id'] : 0 );
    if ( ! $ticket_id ) wp_send_json_error( 'No ticket ID' );

    global $wpdb;
    $p = $wpdb->prefix;

    $ticket = $wpdb->get_row( $wpdb->prepare(
        "SELECT tk.*, tm.name AS assigned_name
         FROM {$p}sp_city_tickets tk
         LEFT JOIN {$p}sp_team tm ON tm.id = tk.assigned_to
         WHERE tk.id = %d", $ticket_id
    ) );
    if ( ! $ticket ) wp_send_json_error( 'Ticket not found' );

    $ticket_depts = $wpdb->get_results( $wpdb->prepare(
        "SELECT d.name, td.status, td.acknowledged_by, td.acknowledged_at
         FROM {$p}sp_city_ticket_depts td
         LEFT JOIN {$p}sp_city_departments d ON d.id = td.dept_id
         WHERE td.ticket_id = %d ORDER BY d.sort_order", $ticket_id
    ) );
    $notes = $wpdb->get_results( $wpdb->prepare(
        "SELECT note, created_by, created_at, is_public
         FROM {$p}sp_city_ticket_notes WHERE ticket_id = %d ORDER BY created_at DESC LIMIT 6", $ticket_id
    ) );
    // Earlier requests at the same address surface recurring problems (repeat
    // water leaks, chronic outages) that change the right priority and response.
    $prior = array();
    if ( trim( (string) $ticket->address ) !== '' ) {
        $prior = $wpdb->get_results( $wpdb->prepare(
            "SELECT ticket_number, priority, status, created_at, description
             FROM {$p}sp_city_tickets
             WHERE address = %s AND id != %d ORDER BY created_at DESC LIMIT 5",
            $ticket->address, $ticket_id
        ) );
    }

    // Build the context. Reporter phone/email are deliberately left out — the
    // model does not need them and they should not leave the server.
    $lines   = array();
    $lines[] = 'Service request ' . $ticket->ticket_number;
    $lines[] = 'Address / location: ' . ( $ticket->address !== '' ? $ticket->address : '(not given)' );
    $lines[] = 'Submitted: ' . date( 'D M j, Y g:ia', strtotime( $ticket->created_at ) ) . ' (' . human_time_diff( strtotime( $ticket->created_at ) ) . ' ago) via ' . sp_ai_city_source_label( $ticket->source );
    $lines[] = 'Current priority: ' . $ticket->priority;
    $lines[] = 'Current status: ' . str_replace( '_', ' ', $ticket->status );
    $lines[] = 'Assigned to: ' . ( $ticket->assigned_name ? $ticket->assigned_name : 'unassigned' );
    $lines[] = 'Reporter: ' . ( $ticket->reporter_name !== '' ? $ticket->reporter_name : 'anonymous' );
    $lines[] = $ticket->acknowledged_at
        ? 'Acknowledged by ' . $ticket->acknowledged_by . ' on ' . date( 'M j g:ia', strtotime( $ticket->acknowledged_at ) )
        : 'Not yet acknowledged';
    if ( ! empty( $ticket->photo_ids ) ) {
        $lines[] = 'Photos attached: ' . count( array_filter( explode( ',', $ticket->photo_ids ) ) );
    }

    if ( $ticket_depts ) {
        $lines[] = '';
        $lines[] = 'Departments currently assigned:';
        foreach ( $ticket_depts as $td ) {
            $ack     = $td->acknowledged_at ? 'acknowledged by ' . $td->acknowledged_by : 'not acknowledged';
            $lines[] = '- ' . $td->name . ' (' . str_replace( '_', ' ', $td->status ) . ', ' . $ack . ')';
        }
    } else {
        $lines[] = '';
        $lines[] = 'Departments currently assigned: none';
    }

    $lines[] = '';
    $lines[] = 'Description:';
    $lines[] = trim( (string) $ticket->description ) !== '' ? $ticket->description : '(no description provided)';

    if ( $notes ) {
        $lines[] = '';
        $lines[] = 'Most recent notes (newest first):';
        foreach ( $notes as $n ) {
            $vis     = $n->is_public ? 'public' : 'internal';
            $lines[] = '- ' . date( 'M j g:ia', strtotime( $n->created_at ) ) . ' ' . $n->created_by . " ($vis): " . preg_replace( '/\s+/', ' ', $n->note );
        }
    }

    if ( $prior ) {
        $lines[] = '';
        $lines[] = 'Earlier requests at this same address:';
        foreach ( $prior as $pr ) {
            $desc    = trim( preg_replace( '/\s+/', ' ', (string) $pr->description ) );
            if ( strlen( $desc ) > 140 ) $desc = substr( $desc, 0, 137 ) . '...';
            $lines[] = '- ' . $pr->ticket_number . ' [' . $pr->priority . ', ' . str_replace( '_', ' ', $pr->status ) . '] ' . date( 'M j, Y', strtotime( $pr->created_at ) ) . ': ' . $desc;
        }
    }

    $context   = implode( "\n", $lines );
    $dept_list = implode( ', ', sp_ai_city_department_names() );
    $city      = get_option( 'sp_city_name', '' );
    $city_txt  = $city ? " for the $city" : ' for a city';

    $prompt = "You are a triage assistant$city_txt public works and utility service request desk. "
        . "Departments available: $dept_list. "
        . "Priorities: low, normal, high, emergency (emergency means an immediate risk to safety, property, or loss of an essential service — for example a water main break, a downed power line, sewer backing up into a home, or a gas smell). "
        . "Statuses: open, acknowledged, in progress, resolved, closed.\n\n"
        . "Based on the service request below, provide:\n"
        . "1. **Recommended Departments** — which of the listed departments should handle this and why. Name only departments from the list. If the currently assigned departments already look right, say so.\n"
        . "2. **Recommended Priority** — one of the four priorities with a one-line reason. Call out any safety hazard explicitly.\n"
        . "3. **Summary** — one sentence describing the core problem and where it is.\n"
        . "4. **Suggested Next Steps** — 2-3 specific actions for the crew or assignee, including anything to verify on site.\n"
        . "5. **Suggested Resident Update** — a short, plain-language note (2-3 sentences) staff could post as a public update to the reporter. No promises of exact times.\n\n"
        . "Be concise and direct. Do not invent details that are not in the request.\n\n"
        . $context;

    $result = sp_ai_call_api( $prompt );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    update_option( 'sp_ai_city_triage_' . $ticket_id, array(
        'text'         => $result,
        'generated_at' => time(),
    ), false );

    wp_send_json_success( array( 'text' => $result ) );
}

// ── Queue Analysis UI (ticket list) ───────────────────────────────────────────

function sp_ai_city_ticket_analysis_ui( $rows = array() ) {
    if ( ! sp_ai_is_configured() || ! sp_ai_city_can_use() ) return;
    $nonce     = wp_create_nonce( 'sp_ai_city_ticket_analysis' );
    $cached    = get_option( 'sp_ai_city_analysis_cache' );
    $text      = $cached ? $cached['text'] : '';
    $gen_at    = $cached ? (int) $cached['generated_at'] : 0;
    $gen_label = $gen_at ? 'Generated ' . human_time_diff( $gen_at ) . ' ago' : '';
    $action_html = '<span id="sp-ai-ca-meta" style="margin-left:auto;font-size:11px;color:#94a3b8">' . esc_html( $gen_label ) . '</span>'
        . '<span id="sp-ai-ca-status" style="font-size:12px;color:#94a3b8;display:none">Analyzing…</span>'
        . '<button type="button" id="sp-ai-ca-btn" class="sp-ai-city-btn" style="padding:4px 10px;font-size:.75rem"'
        . ' data-nonce="' . esc_attr( $nonce ) . '" data-ajax="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '">'
        . ( $text ? 'Refresh Analysis' : 'Analyze Queue' ) . '</button>';
    $well = sp_ai_content_well_style();

    sp_ai_city_md_assets();
    echo '<div style="margin-top:16px">';
    sp_ai_card_start( 'AI Queue Analysis', $action_html );
    ?>
        <div id="sp-ai-ca-output" class="sp-ai-md-out" style="<?php echo $text ? '' : 'display:none;'; ?><?php echo $well; ?>font-size:14px;line-height:1.75;color:#1e293b"><?php echo $text ? sp_ai_render_markdown( $text ) : ''; ?></div>
        <?php if ( ! $text ) : ?>
        <div style="font-size:12px;color:#94a3b8">Looks at the whole service-request queue (not just the filtered list): backlog, unacknowledged and aging requests, department workload, response times and repeat addresses.</div>
        <?php endif; ?>
    <?php
    sp_ai_card_end();
    echo '</div>';
    ?>
    <script>
    spAiCityBind('sp-ai-ca-btn', 'sp-ai-ca-output', 'sp-ai-ca-status', 'sp-ai-ca-meta', 'sp_ai_city_ticket_analysis', 'Refresh Analysis', null);
    </script>
    <?php
}

// ── Queue Analysis AJAX ───────────────────────────────────────────────────────

function sp_ai_ajax_city_ticket_analysis() {
    if ( ! check_ajax_referer( 'sp_ai_city_ticket_analysis', 'nonce', false ) ) {
        wp_send_json_error( 'Invalid nonce' );
    }
    if ( ! sp_ai_city_can_use() ) {
        wp_send_json_error( 'Not authorized' );
    }
    if ( ! sp_ai_is_configured() ) {
        wp_send_json_error( 'AI is not configured — add an API key under Settings → AI Integration.' );
    }

    global $wpdb;
    $p    = $wpdb->prefix;
    $open = "status NOT IN ('resolved','closed')";

    $by_status = $wpdb->get_results(
        "SELECT status, COUNT(*) AS count FROM {$p}sp_city_tickets GROUP BY status ORDER BY count DESC"
    );
    $by_priority = $wpdb->get_results(
        "SELECT priority, COUNT(*) AS count FROM {$p}sp_city_tickets
         WHERE $open GROUP BY priority ORDER BY FIELD(priority,'emergency','high','normal','low')"
    );
    $by_dept = $wpdb->get_results(
        "SELECT d.name, COUNT(DISTINCT td.ticket_id) AS count
         FROM {$p}sp_city_ticket_depts td
         INNER JOIN {$p}sp_city_tickets tk ON tk.id = td.ticket_id
         LEFT JOIN {$p}sp_city_departments d ON d.id = td.dept_id
         WHERE tk.$open
         GROUP BY td.dept_id ORDER BY count DESC"
    );
    $dept_unacked = $wpdb->get_results(
        "SELECT d.name, COUNT(*) AS count
         FROM {$p}sp_city_ticket_depts td
         INNER JOIN {$p}sp_city_tickets tk ON tk.id = td.ticket_id
         LEFT JOIN {$p}sp_city_departments d ON d.id = td.dept_id
         WHERE tk.$open AND td.acknowledged_at IS NULL
         GROUP BY td.dept_id ORDER BY count DESC"
    );
    $recent = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$p}sp_city_tickets WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    $prior_30 = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$p}sp_city_tickets
         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 60 DAY) AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    $no_dept = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$p}sp_city_tickets tk
         WHERE tk.$open AND NOT EXISTS (SELECT 1 FROM {$p}sp_city_ticket_depts td WHERE td.ticket_id = tk.id)"
    );
    $unassigned = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$p}sp_city_tickets WHERE $open AND assigned_to = 0"
    );
    $unacked_24h = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$p}sp_city_tickets
         WHERE $open AND acknowledged_at IS NULL AND created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
    );
    $open_emergency = $wpdb->get_results(
        "SELECT tk.ticket_number, tk.address, tk.status, tk.created_at, tk.acknowledged_at, tm.name AS assigned_name
         FROM {$p}sp_city_tickets tk
         LEFT JOIN {$p}sp_team tm ON tm.id = tk.assigned_to
         WHERE tk.$open AND tk.priority IN ('emergency','high')
         ORDER BY FIELD(tk.priority,'emergency','high'), tk.created_at ASC LIMIT 8"
    );
    $oldest = $wpdb->get_results(
        "SELECT tk.ticket_number, tk.address, tk.priority, tk.status, DATEDIFF(NOW(), tk.created_at) AS age_days,
                tm.name AS assigned_name,
                (SELECT GROUP_CONCAT(d.name SEPARATOR ', ') FROM {$p}sp_city_ticket_depts td
                   LEFT JOIN {$p}sp_city_departments d ON d.id = td.dept_id WHERE td.ticket_id = tk.id) AS depts
         FROM {$p}sp_city_tickets tk
         LEFT JOIN {$p}sp_team tm ON tm.id = tk.assigned_to
         WHERE tk.$open
         ORDER BY tk.created_at ASC LIMIT 6"
    );
    $ack_hours = $wpdb->get_var(
        "SELECT AVG(TIMESTAMPDIFF(MINUTE, created_at, acknowledged_at)) / 60
         FROM {$p}sp_city_tickets
         WHERE acknowledged_at IS NOT NULL AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    $resolve_days = $wpdb->get_var(
        "SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, resolved_at)) / 24
         FROM {$p}sp_city_tickets
         WHERE resolved_at IS NOT NULL AND resolved_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    $resolved_30 = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$p}sp_city_tickets WHERE resolved_at IS NOT NULL AND resolved_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    $repeat_addr = $wpdb->get_results(
        "SELECT address, COUNT(*) AS count
         FROM {$p}sp_city_tickets
         WHERE address != '' AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
         GROUP BY address HAVING count > 1 ORDER BY count DESC LIMIT 5"
    );
    $by_source = $wpdb->get_results(
        "SELECT source, COUNT(*) AS count FROM {$p}sp_city_tickets
         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY source ORDER BY count DESC"
    );

    $city  = get_option( 'sp_city_name', '' );
    $lines = array( ( $city ? $city : 'City' ) . ' service-request queue snapshot as of ' . date( 'F j, Y g:ia' ) . ':', '' );

    $lines[] = 'Requests by status (all time):';
    foreach ( $by_status as $r ) $lines[] = '  ' . str_replace( '_', ' ', $r->status ) . ": {$r->count}";

    if ( $by_priority ) {
        $lines[] = '';
        $lines[] = 'Open requests by priority:';
        foreach ( $by_priority as $r ) $lines[] = "  {$r->priority}: {$r->count}";
    }

    $lines[] = '';
    $lines[] = 'Open requests by department:';
    if ( $by_dept ) {
        foreach ( $by_dept as $r ) $lines[] = '  ' . ( $r->name ? $r->name : 'Unknown' ) . ": {$r->count}";
    } else {
        $lines[] = '  (none)';
    }
    if ( $no_dept ) $lines[] = "  Open requests with NO department assigned: $no_dept";

    if ( $dept_unacked ) {
        $lines[] = '';
        $lines[] = 'Open department assignments not yet acknowledged, by department:';
        foreach ( $dept_unacked as $r ) $lines[] = '  ' . ( $r->name ? $r->name : 'Unknown' ) . ": {$r->count}";
    }

    $lines[] = '';
    $lines[] = "New requests in last 30 days: $recent (previous 30 days: $prior_30)";
    $lines[] = "Resolved in last 30 days: $resolved_30";
    $lines[] = "Open requests unassigned to a staff member: $unassigned";
    $lines[] = "Open requests unacknowledged for more than 24 hours: $unacked_24h";
    $lines[] = 'Average time to acknowledge (last 30 days): ' . ( $ack_hours !== null ? round( (float) $ack_hours, 1 ) . ' hours' : 'no data' );
    $lines[] = 'Average time to resolve (last 30 days): ' . ( $resolve_days !== null ? round( (float) $resolve_days, 1 ) . ' days' : 'no data' );

    if ( $by_source ) {
        $lines[] = '';
        $lines[] = 'Request source, last 30 days:';
        foreach ( $by_source as $r ) $lines[] = '  ' . sp_ai_city_source_label( $r->source ) . ": {$r->count}";
    }

    if ( $open_emergency ) {
        $lines[] = '';
        $lines[] = 'Open emergency / high priority requests:';
        foreach ( $open_emergency as $t ) {
            $ack      = $t->acknowledged_at ? 'acknowledged' : 'NOT acknowledged';
            $assigned = $t->assigned_name ? "assigned to {$t->assigned_name}" : 'unassigned';
            $lines[]  = "  - {$t->ticket_number} at {$t->address} — " . str_replace( '_', ' ', $t->status ) . ", $ack, $assigned, opened " . human_time_diff( strtotime( $t->created_at ) ) . ' ago';
        }
    }

    if ( $oldest ) {
        $lines[] = '';
        $lines[] = 'Oldest unresolved requests:';
        foreach ( $oldest as $t ) {
            $assigned = $t->assigned_name ? "assigned to {$t->assigned_name}" : 'unassigned';
            $depts    = $t->depts ? $t->depts : 'no department';
            $lines[]  = "  - {$t->ticket_number} [{$t->priority}] at {$t->address} — {$t->age_days} days old, " . str_replace( '_', ' ', $t->status ) . ", $depts, $assigned";
        }
    }

    if ( $repeat_addr ) {
        $lines[] = '';
        $lines[] = 'Addresses with repeat requests in the last 90 days:';
        foreach ( $repeat_addr as $r ) $lines[] = "  - {$r->address}: {$r->count} requests";
    }

    $context = implode( "\n", $lines );

    $prompt = "You are an operations analyst for a city public works and utility service department. "
        . "Based on the service-request queue data below, write a concise analysis with these sections (use '# ' headings):\n"
        . "# Queue Health — overall state in 2-3 sentences, including the 30-day trend\n"
        . "# Needs Attention Now — emergency/high priority, unacknowledged, unassigned or aging requests that a supervisor should act on today\n"
        . "# Department Workload — which departments carry the load or are falling behind on acknowledgements\n"
        . "# Response Performance — time to acknowledge and resolve, and whether it is acceptable for a municipal service desk\n"
        . "# Patterns — repeat addresses, source mix, anything unusual\n"
        . "# Recommended Actions — 2-3 specific, practical actions for supervisors this week\n\n"
        . "Be direct and actionable. Refer to requests by ticket number. Do not invent data that is not provided.\n\n"
        . $context;

    $result = sp_ai_call_api( $prompt );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    update_option( 'sp_ai_city_analysis_cache', array(
        'text'         => $result,
        'generated_at' => time(),
    ), false );

    wp_send_json_success( array( 'text' => $result ) );
}
