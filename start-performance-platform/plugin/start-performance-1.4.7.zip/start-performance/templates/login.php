<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$is_vendor  = ! empty( $_GET['vendor'] );
$error      = sanitize_key( isset( $_GET['error'] ) ? $_GET['error'] : '' );

$error_msg = '';
if ( $error === 'pin' )     $error_msg = 'Incorrect PIN. Please try again.';
if ( $error === 'invalid' ) $error_msg = 'Invalid request. Please try again.';

$team_members = $wpdb->get_results(
    "SELECT id, name FROM {$wpdb->prefix}sp_team WHERE status = 'active' ORDER BY name"
);
$sp_accent      = get_option( 'sp_accent_color', '#CC1F1F' );
$sp_accent_dark = sp_darken_hex( $sp_accent, 0.15 );
$sp_icon_url    = get_option( 'sp_brand_icon_url', '' );
$sp_initials    = get_option( 'sp_brand_initials', '' );
$sp_name        = get_option( 'sp_platform_name', 'Start Performance' );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — <?php echo esc_html( $sp_name ); ?></title>
<style>:root{--sp-accent:<?php echo esc_attr( $sp_accent ); ?>;--sp-accent-dark:<?php echo esc_attr( $sp_accent_dark ); ?>}</style>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f1f5f9;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:40px;width:100%;max-width:380px;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.06)}
.logo-mark{width:60px;height:60px;border-radius:14px;background:var(--sp-accent,#CC1F1F);display:inline-flex;align-items:center;justify-content:center;margin-bottom:14px}
.logo-mark svg{width:36px;height:36px}
.logo-name{font-size:20px;font-weight:800;color:#1e293b;margin-bottom:4px}
.logo-tag{font-size:13px;color:#94a3b8;margin-bottom:36px}
h1{font-size:18px;font-weight:700;color:#1e293b;margin-bottom:4px}
p{font-size:14px;color:#94a3b8;margin-bottom:24px}
.field{margin-bottom:14px;text-align:left}
.field label{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#64748b;margin-bottom:6px}
select{width:100%;background:#f8fafc;border:2px solid #e2e8f0;border-radius:10px;padding:14px 16px;font-size:15px;color:#1e293b;outline:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2394a3b8' d='M6 8L1 3h10z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;cursor:pointer;transition:border-color .2s}
select:focus{border-color:var(--sp-accent,#CC1F1F);box-shadow:0 0 0 3px rgba(204,31,31,.1)}
.pin-input{width:100%;background:#f8fafc;border:2px solid #e2e8f0;border-radius:10px;padding:16px;font-size:28px;font-weight:700;color:#1e293b;text-align:center;letter-spacing:12px;outline:none;margin-bottom:16px;transition:border-color .2s}
.pin-input:focus{border-color:var(--sp-accent,#CC1F1F);box-shadow:0 0 0 3px rgba(204,31,31,.1)}
button{width:100%;background:var(--sp-accent,#CC1F1F);color:#fff;font-size:15px;font-weight:700;border:none;border-radius:8px;padding:14px;cursor:pointer;transition:background .2s}
button:hover{background:var(--sp-accent-dark,#b01818)}
.error{background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;padding:12px 14px;font-size:13px;color:#dc2626;margin-bottom:20px;text-align:left}
.footer{margin-top:24px;font-size:12px;color:#cbd5e1}
</style>
</head>
<body>
<div class="card">
    <div class="logo-mark">
        <?php if ( $sp_icon_url ) : ?>
            <img src="<?php echo esc_url( $sp_icon_url ); ?>" style="width:40px;height:40px;object-fit:cover;border-radius:6px" alt="">
        <?php elseif ( $sp_initials ) : ?>
            <span style="font-size:<?php echo strlen($sp_initials)>2?'14':'18'; ?>px;font-weight:800;color:#fff;letter-spacing:-.5px;line-height:1"><?php echo esc_html( strtoupper( $sp_initials ) ); ?></span>
        <?php else : ?>
        <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18" cy="18" r="3.5" fill="white"/>
            <circle cx="18" cy="5"  r="2.5" fill="white"/>
            <circle cx="18" cy="31" r="2.5" fill="white"/>
            <circle cx="5"  cy="18" r="2.5" fill="white"/>
            <circle cx="31" cy="18" r="2.5" fill="white"/>
            <circle cx="8"  cy="8"  r="2.5" fill="white"/>
            <circle cx="28" cy="8"  r="2.5" fill="white"/>
            <circle cx="8"  cy="28" r="2.5" fill="white"/>
            <circle cx="28" cy="28" r="2.5" fill="white"/>
            <line x1="18" y1="14.5" x2="18" y2="7.5"   stroke="white" stroke-width="1.8"/>
            <line x1="18" y1="21.5" x2="18" y2="28.5"  stroke="white" stroke-width="1.8"/>
            <line x1="14.5" y1="18" x2="7.5"  y2="18"  stroke="white" stroke-width="1.8"/>
            <line x1="21.5" y1="18" x2="28.5" y2="18"  stroke="white" stroke-width="1.8"/>
            <line x1="15.5" y1="15.5" x2="10" y2="10"  stroke="white" stroke-width="1.8"/>
            <line x1="20.5" y1="15.5" x2="26" y2="10"  stroke="white" stroke-width="1.8"/>
            <line x1="15.5" y1="20.5" x2="10" y2="26"  stroke="white" stroke-width="1.8"/>
            <line x1="20.5" y1="20.5" x2="26" y2="26"  stroke="white" stroke-width="1.8"/>
        </svg>
        <?php endif; ?>
    </div>
    <div class="logo-name"><?php echo esc_html( $sp_name ); ?></div>
    <div class="logo-tag">Business Operating Platform</div>

    <?php if ( $is_vendor ) : ?>
    <h1>Platform Access</h1>
    <p>Enter your vendor PIN to continue</p>

    <?php if ( $error_msg ) : ?>
        <div class="error"><?php echo esc_html( $error_msg ); ?></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( home_url( '/sp-login/?vendor=1' ) ); ?>">
        <?php wp_nonce_field( 'sp_vendor_login', 'sp_vendor_nonce' ); ?>
        <input type="hidden" name="sp_vendor_login" value="1">
        <input type="password" name="pin" class="pin-input" maxlength="20" placeholder="••••••••" autofocus required>
        <button type="submit">Access Platform &rarr;</button>
    </form>

    <?php else : ?>
    <h1>Welcome back</h1>
    <p>Select your name and enter your PIN</p>

    <?php if ( $error_msg ) : ?>
        <div class="error"><?php echo esc_html( $error_msg ); ?></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( home_url( '/sp-login/' ) ); ?>">
        <?php wp_nonce_field( 'sp_login', 'sp_login_nonce' ); ?>

        <div class="field">
            <label>Who are you?</label>
            <select name="sp_team_id" required>
                <option value="">Select your name...</option>
                <?php foreach ( $team_members as $m ) : ?>
                    <option value="<?php echo esc_attr( $m->id ); ?>"><?php echo esc_html( $m->name ); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <input type="password" name="pin" class="pin-input" maxlength="8" inputmode="numeric" pattern="[0-9]*" placeholder="••••" autofocus required>
        <button type="submit">Sign In &rarr;</button>
    </form>
    <?php endif; ?>

    <div class="footer">Start Performance v<?php echo esc_html( SP_VERSION ); ?></div>
</div>
</body>
</html>
