<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$addons = function_exists( 'sp_get_addons' ) ? sp_get_addons() : array();
?>
<div class="sp-page-header">
    <h1>Add-ons</h1>
</div>

<div class="sp-addon-grid">

<?php if ( empty( $addons ) ) : ?>
    <div class="sp-card sp-form-card">
        <p class="sp-empty">No add-ons installed yet.</p>
    </div>
<?php else : ?>
    <?php foreach ( $addons as $id => $addon ) : ?>
    <div class="sp-addon-card">
        <div class="sp-addon-card-header">
            <div class="sp-addon-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                    <path d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/>
                </svg>
            </div>
            <div>
                <div class="sp-addon-name"><?php echo esc_html( $addon['name'] ); ?></div>
                <div class="sp-addon-version">v<?php echo esc_html( $addon['version'] ); ?></div>
            </div>
            <span class="sp-badge sp-badge-active" style="margin-left:auto">Active</span>
        </div>
        <p class="sp-addon-desc"><?php echo esc_html( $addon['description'] ); ?></p>
        <?php if ( $addon['settings_url'] ) : ?>
            <a href="<?php echo esc_url( $addon['settings_url'] ); ?>" class="sp-btn sp-btn-ghost sp-btn-sm">Settings</a>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

</div>

<div class="sp-addon-discover">
    <div class="sp-addon-discover-inner">
        <div class="sp-addon-discover-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">
                <path d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/>
            </svg>
        </div>
        <div>
            <div class="sp-addon-discover-title">More Add-ons</div>
            <div class="sp-addon-discover-sub">Extend your platform with additional modules from Start Performance.</div>
        </div>
        <a href="https://startperformance.com/addons" class="sp-btn sp-btn-ghost sp-btn-sm" target="_blank">Browse &rarr;</a>
    </div>
</div>
