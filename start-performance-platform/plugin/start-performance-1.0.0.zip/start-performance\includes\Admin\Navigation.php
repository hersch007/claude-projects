<?php
namespace SP\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Manages the Start Performance admin menu.
 *
 * Core items are added directly. External modules call:
 *   Navigation::instance()->register_item([
 *     'title'      => 'Sales',
 *     'slug'       => 'sp-sales',
 *     'icon'       => 'dashicons-chart-line',
 *     'capability' => 'manage_options',
 *     'position'   => 30,
 *     'callback'   => [ $instance, 'render_page' ],
 *   ]);
 */
class Navigation {

    private static ?Navigation $instance = null;

    /** @var array[] */
    private array $items = [];

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function register_item( array $item ): void {
        $this->items[] = $item;
    }

    /**
     * Called by Dashboard::init() via admin_menu hook.
     * Registers all queued module items as WP sub-menu pages.
     */
    public function add_module_pages(): void {
        usort( $this->items, fn( $a, $b ) => ( $a['position'] ?? 50 ) <=> ( $b['position'] ?? 50 ) );

        foreach ( $this->items as $item ) {
            add_submenu_page(
                'start-performance',
                $item['title'] ?? '',
                $item['title'] ?? '',
                $item['capability'] ?? 'manage_options',
                $item['slug']  ?? '',
                $item['callback'] ?? '__return_false'
            );
        }
    }
}
