<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Simple key/value settings service backed by sp_settings table.
 * Cached in memory for the request lifetime.
 */
class SP_Settings {

    /** @var array<string, array<string, string>> */
    private static array $cache = [];

    public static function get( string $module, string $key, string $default = '' ): string {
        if ( ! isset( self::$cache[ $module ] ) ) {
            self::load( $module );
        }
        return self::$cache[ $module ][ $key ] ?? $default;
    }

    public static function set( string $module, string $key, string $value ): void {
        global $wpdb;
        $wpdb->replace(
            $wpdb->prefix . 'sp_settings',
            [
                'module'        => sanitize_key( $module ),
                'setting_key'   => sanitize_key( $key ),
                'setting_value' => $value,
            ],
            [ '%s', '%s', '%s' ]
        );
        self::$cache[ $module ][ $key ] = $value;
    }

    private static function load( string $module ): void {
        global $wpdb;
        self::$cache[ $module ] = [];
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT setting_key, setting_value FROM {$wpdb->prefix}sp_settings WHERE module = %s",
            $module
        ), ARRAY_A );
        foreach ( $rows ?? [] as $row ) {
            self::$cache[ $module ][ $row['setting_key'] ] = $row['setting_value'];
        }
    }
}
