<?php
namespace SP\Admin;

defined( 'ABSPATH' ) || exit;

class Settings {

    private static ?Settings $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init(): void {
        add_action( 'admin_post_sp_save_settings', [ $this, 'handle_save' ] );
    }

    public function render_page(): void {
        $notice = '';
        if ( isset( $_GET['saved'] ) ) {
            $notice = '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
        }

        $platform_name  = \SP\Core\SP_Settings::get( 'core', 'platform_name',  'Start Performance' );
        $admin_email    = \SP\Core\SP_Settings::get( 'core', 'admin_email',     get_option( 'admin_email' ) );
        $date_format    = \SP\Core\SP_Settings::get( 'core', 'date_format',     'M j, Y' );
        ?>
        <div class="wrap sp-wrap">
            <?php echo $notice; // phpcs:ignore ?>
            <h1>Settings</h1>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sp-form">
                <?php wp_nonce_field( 'sp_save_settings' ); ?>
                <input type="hidden" name="action" value="sp_save_settings">

                <h2 class="sp-settings-section">Platform</h2>
                <div class="sp-form-row">
                    <label>Platform Name</label>
                    <input type="text" name="platform_name" value="<?php echo esc_attr( $platform_name ); ?>">
                </div>
                <div class="sp-form-row">
                    <label>Admin Email</label>
                    <input type="email" name="admin_email" value="<?php echo esc_attr( $admin_email ); ?>">
                </div>
                <div class="sp-form-row">
                    <label>Date Format</label>
                    <input type="text" name="date_format" value="<?php echo esc_attr( $date_format ); ?>">
                    <p class="description">PHP date format string used throughout the platform.</p>
                </div>

                <div class="sp-form-actions">
                    <button type="submit" class="button button-primary">Save Settings</button>
                </div>
            </form>
        </div>
        <?php
    }

    public function handle_save(): void {
        check_admin_referer( 'sp_save_settings' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        \SP\Core\SP_Settings::set( 'core', 'platform_name', sanitize_text_field( $_POST['platform_name'] ?? 'Start Performance' ) );
        \SP\Core\SP_Settings::set( 'core', 'admin_email',   sanitize_email(      $_POST['admin_email']   ?? '' ) );
        \SP\Core\SP_Settings::set( 'core', 'date_format',   sanitize_text_field( $_POST['date_format']   ?? 'M j, Y' ) );

        wp_redirect( admin_url( 'admin.php?page=sp-settings&saved=1' ) );
        exit;
    }
}
