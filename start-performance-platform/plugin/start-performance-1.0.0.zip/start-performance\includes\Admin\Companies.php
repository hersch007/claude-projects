<?php
namespace SP\Admin;

defined( 'ABSPATH' ) || exit;

class Companies {

    private static ?Companies $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init(): void {
        add_action( 'admin_post_sp_save_company',   [ $this, 'handle_save' ] );
        add_action( 'admin_post_sp_delete_company', [ $this, 'handle_delete' ] );
    }

    public function render_page(): void {
        $action = sanitize_key( $_GET['sp_action'] ?? 'list' );
        if ( $action === 'edit' || $action === 'new' ) {
            $this->render_form( $action );
        } else {
            $this->render_list();
        }
    }

    private function render_list(): void {
        global $wpdb;
        $search = sanitize_text_field( $_GET['s'] ?? '' );
        $paged  = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $limit  = 25;
        $offset = ( $paged - 1 ) * $limit;

        $where = "WHERE deleted_at IS NULL";
        $args  = [];
        if ( $search ) {
            $where .= " AND (name LIKE %s OR industry LIKE %s)";
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = [ $like, $like ];
        }

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies $where",
            ...$args
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sp_companies $where ORDER BY name LIMIT %d OFFSET %d",
            ...array_merge( $args, [ $limit, $offset ] )
        ) );

        $add_url = admin_url( 'admin.php?page=sp-companies&sp_action=new' );
        ?>
        <div class="wrap sp-wrap">
            <div class="sp-page-header">
                <h1>Companies <a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action">Add New</a></h1>
                <form method="get" class="sp-search-form">
                    <input type="hidden" name="page" value="sp-companies">
                    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search companies…">
                    <button type="submit" class="button">Search</button>
                </form>
            </div>
            <table class="widefat sp-table">
                <thead><tr><th>Name</th><th>Industry</th><th>Phone</th><th>Website</th><th>Created</th><th></th></tr></thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="6" class="sp-empty">No companies found.</td></tr>
                <?php else : foreach ( $rows as $row ) :
                    $edit_url   = admin_url( 'admin.php?page=sp-companies&sp_action=edit&id=' . $row->id );
                    $delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=sp_delete_company&id=' . $row->id ), 'sp_delete_company_' . $row->id ); ?>
                    <tr>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $row->name ); ?></a></td>
                        <td><?php echo esc_html( $row->industry ?: '—' ); ?></td>
                        <td><?php echo esc_html( $row->phone    ?: '—' ); ?></td>
                        <td><?php echo $row->website ? '<a href="' . esc_url( $row->website ) . '" target="_blank">' . esc_html( $row->website ) . '</a>' : '—'; ?></td>
                        <td><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>">Edit</a> | <a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('Delete this company?')">Delete</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <?php sp_pagination( $total, $limit, $paged, 'admin.php?page=sp-companies' ); ?>
        </div>
        <?php
    }

    private function render_form( string $action ): void {
        global $wpdb;
        $id      = (int) ( $_GET['id'] ?? 0 );
        $company = null;
        $notice  = '';

        if ( $action === 'edit' && $id ) {
            $company = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_companies WHERE id = %d AND deleted_at IS NULL", $id
            ) );
            if ( ! $company ) wp_die( 'Company not found.' );
        }

        if ( isset( $_GET['saved'] ) ) {
            $notice = '<div class="notice notice-success is-dismissible"><p>Company saved.</p></div>';
        }

        $back_url = admin_url( 'admin.php?page=sp-companies' );
        ?>
        <div class="wrap sp-wrap">
            <?php echo $notice; // phpcs:ignore ?>
            <h1><?php echo $action === 'edit' ? 'Edit Company' : 'Add Company'; ?> <a href="<?php echo esc_url( $back_url ); ?>" class="page-title-action">← All Companies</a></h1>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sp-form">
                <?php wp_nonce_field( 'sp_save_company' ); ?>
                <input type="hidden" name="action" value="sp_save_company">
                <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">

                <div class="sp-form-row"><label>Company Name</label><input type="text" name="name" value="<?php echo esc_attr( $company->name ?? '' ); ?>" required></div>
                <div class="sp-form-row"><label>Industry</label><input type="text" name="industry" value="<?php echo esc_attr( $company->industry ?? '' ); ?>"></div>
                <div class="sp-form-row"><label>Website</label><input type="url" name="website" value="<?php echo esc_attr( $company->website ?? '' ); ?>"></div>
                <div class="sp-form-row"><label>Phone</label><input type="text" name="phone" value="<?php echo esc_attr( $company->phone ?? '' ); ?>"></div>
                <div class="sp-form-row"><label>Address</label><textarea name="address" rows="3"><?php echo esc_textarea( $company->address ?? '' ); ?></textarea></div>
                <div class="sp-form-row"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $company->notes ?? '' ); ?></textarea></div>
                <div class="sp-form-actions">
                    <button type="submit" class="button button-primary">Save Company</button>
                    <a href="<?php echo esc_url( $back_url ); ?>" class="button">Cancel</a>
                </div>
            </form>
        </div>
        <?php
    }

    public function handle_save(): void {
        check_admin_referer( 'sp_save_company' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        global $wpdb;
        $id   = (int) ( $_POST['id'] ?? 0 );
        $data = [
            'name'     => sanitize_text_field( $_POST['name']     ?? '' ),
            'industry' => sanitize_text_field( $_POST['industry'] ?? '' ),
            'website'  => esc_url_raw(         $_POST['website']  ?? '' ),
            'phone'    => sanitize_text_field( $_POST['phone']    ?? '' ),
            'address'  => sanitize_textarea_field( $_POST['address'] ?? '' ),
            'notes'    => sanitize_textarea_field( $_POST['notes']   ?? '' ),
        ];

        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_companies', $data, [ 'id' => $id ] );
            \SP\Core\ActivityLog::write( 'company', $id, 'updated' );
        } else {
            $wpdb->insert( $wpdb->prefix . 'sp_companies', $data );
            $id = $wpdb->insert_id;
            \SP\Core\ActivityLog::write( 'company', $id, 'created' );
        }

        wp_redirect( admin_url( 'admin.php?page=sp-companies&sp_action=edit&id=' . $id . '&saved=1' ) );
        exit;
    }

    public function handle_delete(): void {
        $id = (int) ( $_GET['id'] ?? 0 );
        check_admin_referer( 'sp_delete_company_' . $id );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'sp_companies', [ 'deleted_at' => current_time( 'mysql' ) ], [ 'id' => $id ] );
        \SP\Core\ActivityLog::write( 'company', $id, 'deleted' );

        wp_redirect( admin_url( 'admin.php?page=sp-companies' ) );
        exit;
    }
}
