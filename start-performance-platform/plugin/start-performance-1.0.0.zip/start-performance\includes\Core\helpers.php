<?php
defined( 'ABSPATH' ) || exit;

/**
 * Renders simple pagination links below a table.
 */
function sp_pagination( int $total, int $per_page, int $current, string $base_url ): void {
    $pages = (int) ceil( $total / $per_page );
    if ( $pages <= 1 ) {
        return;
    }
    $sep = strpos( $base_url, '?' ) !== false ? '&' : '?';
    echo '<div class="sp-pagination tablenav-pages">';
    echo '<span class="displaying-num">' . esc_html( number_format( $total ) ) . ' items</span>';

    if ( $current > 1 ) {
        printf( '<a class="button" href="%s">&#8592; Previous</a> ', esc_url( admin_url( $base_url . $sep . 'paged=' . ( $current - 1 ) ) ) );
    }
    echo '<span class="sp-page-numbers">Page ' . esc_html( $current ) . ' of ' . esc_html( $pages ) . '</span>';
    if ( $current < $pages ) {
        printf( ' <a class="button" href="%s">Next &#8594;</a>', esc_url( admin_url( $base_url . $sep . 'paged=' . ( $current + 1 ) ) ) );
    }
    echo '</div>';
}
