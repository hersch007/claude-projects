<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

class ActivityLog {

    /**
     * Write an activity event.
     *
     * @param string $object_type  e.g. 'contact', 'lead', 'ticket'
     * @param int    $object_id
     * @param string $action       e.g. 'created', 'updated', 'deleted'
     * @param array  $details      Optional key/value detail data (stored as JSON)
     */
    public static function write( string $object_type, int $object_id, string $action, array $details = [] ): void {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'sp_activity_log',
            [
                'user_id'     => get_current_user_id(),
                'object_type' => sanitize_key( $object_type ),
                'object_id'   => $object_id,
                'action'      => sanitize_key( $action ),
                'details'     => ! empty( $details ) ? wp_json_encode( $details ) : null,
                'ip_address'  => self::get_ip(),
                'created_at'  => current_time( 'mysql' ),
            ],
            [ '%d', '%s', '%d', '%s', '%s', '%s', '%s' ]
        );
    }

    private static function get_ip(): string {
        foreach ( [ 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                return sanitize_text_field( explode( ',', $_SERVER[ $key ] )[0] );
            }
        }
        return '';
    }
}
