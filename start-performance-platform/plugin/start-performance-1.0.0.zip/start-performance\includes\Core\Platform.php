<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Central bootstrap. Singleton — access via Platform::instance().
 */
class Platform {

    private static ?Platform $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function boot(): void {
        ModuleRegistry::instance();

        if ( is_admin() ) {
            Admin\Dashboard::instance()->init();
            Admin\Contacts::instance()->init();
            Admin\Companies::instance()->init();
            Admin\Leads::instance()->init();
            Admin\ActivityLog::instance()->init();
            Admin\Settings::instance()->init();
        }

        do_action( 'sp_platform_booted' );
    }
}
