<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Modules call ModuleRegistry::register() on their activation hook.
 * The registry validates dependencies and records the module in sp_modules.
 *
 * Registration payload:
 * [
 *   'slug'         => 'sp-sales',
 *   'name'         => 'Sales Core',
 *   'version'      => '1.0.0',
 *   'requires'     => [],          // slugs of required modules
 *   'nav_items'    => [],          // @see Admin\Navigation::register_item()
 * ]
 */
class ModuleRegistry {

    private static ?ModuleRegistry $instance = null;

    /** @var array<string, array> */
    private array $registered = [];

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_from_db();
    }

    /**
     * Register a module. Called by external Core plugins.
     */
    public function register( array $module ): bool {
        $slug = sanitize_key( $module['slug'] ?? '' );
        if ( ! $slug ) {
            return false;
        }

        // Validate required dependencies are already active
        foreach ( $module['requires'] ?? [] as $dep ) {
            if ( ! $this->is_active( $dep ) ) {
                // translators: %1$s module name, %2$s missing dependency
                add_action( 'admin_notices', function () use ( $module, $dep ) {
                    printf(
                        '<div class="notice notice-error"><p><strong>%s</strong> requires <strong>%s</strong> to be active.</p></div>',
                        esc_html( $module['name'] ?? $slug ),
                        esc_html( $dep )
                    );
                } );
                return false;
            }
        }

        $this->registered[ $slug ] = $module;
        $this->persist( $slug, $module );

        // Register nav items if provided
        if ( ! empty( $module['nav_items'] ) ) {
            foreach ( $module['nav_items'] as $item ) {
                Admin\Navigation::instance()->register_item( $item );
            }
        }

        do_action( 'sp_module_registered', $slug, $module );
        return true;
    }

    public function is_active( string $slug ): bool {
        return isset( $this->registered[ $slug ] );
    }

    /** @return array<string, array> */
    public function all(): array {
        return $this->registered;
    }

    private function load_from_db(): void {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT slug, name, version, status FROM {$wpdb->prefix}sp_modules WHERE status = 'active'",
            ARRAY_A
        );
        foreach ( $rows ?? [] as $row ) {
            $this->registered[ $row['slug'] ] = $row;
        }
    }

    private function persist( string $slug, array $module ): void {
        global $wpdb;
        $wpdb->replace(
            $wpdb->prefix . 'sp_modules',
            [
                'slug'         => $slug,
                'name'         => $module['name']    ?? $slug,
                'version'      => $module['version'] ?? '1.0.0',
                'status'       => 'active',
                'activated_at' => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s' ]
        );
    }
}
