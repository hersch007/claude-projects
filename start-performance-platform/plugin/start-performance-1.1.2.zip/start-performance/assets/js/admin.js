/* Start Performance — Admin JS */
(function ($) {
    'use strict';

    // Auto-dismiss success notices after 4 seconds
    $(function () {
        setTimeout(function () {
            $('.notice-success.is-dismissible').fadeOut(400);
        }, 4000);
    });

}(jQuery));
