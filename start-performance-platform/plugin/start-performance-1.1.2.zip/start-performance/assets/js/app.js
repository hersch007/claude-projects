/* ── Start Performance Platform — SPA ──────────────────────────────────────
   Vanilla JS. No framework dependencies.
   SP.apiBase and SP.nonce are set inline in app.php.
─────────────────────────────────────────────────────────────────────────── */
(function () {
'use strict';

// ── API layer ──────────────────────────────────────────────────────────────

var api = {
    _fetch: function (method, path, body) {
        return fetch(SP.apiBase + path, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': SP.nonce,
            },
            body: body ? JSON.stringify(body) : undefined,
        }).then(function (r) { return r.json(); });
    },
    get:    function (path)        { return api._fetch('GET',    path); },
    post:   function (path, body)  { return api._fetch('POST',   path, body); },
    put:    function (path, body)  { return api._fetch('PUT',    path, body); },
    del:    function (path)        { return api._fetch('DELETE', path); },
};

// ── Router ─────────────────────────────────────────────────────────────────

var routes = {};

function route(hash, fn) { routes[hash] = fn; }

function navigate(hash, push) {
    if (push !== false) { window.location.hash = hash; }
    var key = hash.split('?')[0];
    var fn  = routes[key] || views.notFound;

    // Update nav active state
    document.querySelectorAll('.sp-nav-item').forEach(function (el) {
        el.classList.toggle('active', el.dataset.view === key.replace('#', ''));
    });

    fn(parseQuery(hash));
}

function parseQuery(hash) {
    var qs = hash.split('?')[1] || '';
    var p  = {};
    qs.split('&').forEach(function (part) {
        if (!part) return;
        var kv = part.split('=');
        p[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || '');
    });
    return p;
}

window.addEventListener('hashchange', function () {
    navigate(window.location.hash || '#dashboard', false);
});

// ── DOM helpers ────────────────────────────────────────────────────────────

function el(tag, attrs, children) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
        if (k === 'class') e.className = attrs[k];
        else if (k === 'html')  e.innerHTML  = attrs[k];
        else if (k.startsWith('on')) e.addEventListener(k.slice(2), attrs[k]);
        else e.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) {
        if (typeof c === 'string') e.appendChild(document.createTextNode(c));
        else if (c) e.appendChild(c);
    });
    return e;
}

function setContent(html) {
    document.getElementById('sp-content').innerHTML = html;
}

function setBreadcrumb(html) {
    document.getElementById('sp-breadcrumb').innerHTML = html;
}

function setActions(html) {
    document.getElementById('sp-topbar-actions').innerHTML = html;
}

function loading() {
    setContent('<div class="sp-loading"><div class="sp-spinner"></div></div>');
    setActions('');
}

function esc(str) {
    var d = document.createElement('div');
    d.appendChild(document.createTextNode(str || ''));
    return d.innerHTML;
}

function badge(status) {
    return '<span class="sp-badge sp-badge-' + esc(status) + '">' + esc(capitalize(status)) + '</span>';
}

function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

function fmtDate(d) {
    if (!d) return '—';
    var dt = new Date(d);
    return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function notice(type, msg) {
    return '<div class="sp-notice sp-notice-' + type + '">' + esc(msg) + '</div>';
}

function pagination(data, baseHash) {
    if (data.total_pages <= 1) return '';
    var prev = data.page > 1
        ? '<button class="sp-btn sp-btn-secondary sp-btn-sm" onclick="navigate(\'' + baseHash + '?page=' + (data.page - 1) + '\')">← Prev</button>'
        : '<button class="sp-btn sp-btn-secondary sp-btn-sm" disabled>← Prev</button>';
    var next = data.page < data.total_pages
        ? '<button class="sp-btn sp-btn-secondary sp-btn-sm" onclick="navigate(\'' + baseHash + '?page=' + (data.page + 1) + '\')">Next →</button>'
        : '<button class="sp-btn sp-btn-secondary sp-btn-sm" disabled>Next →</button>';
    return '<div class="sp-pagination"><span>' + data.total + ' total</span><div class="sp-pagination-btns">' + prev + next + '</div></div>';
}

// ── Views ──────────────────────────────────────────────────────────────────

var views = {};

// Dashboard
route('#dashboard', views.dashboard = function () {
    setBreadcrumb('Dashboard');
    setActions('');
    loading();
    api.get('/dashboard').then(function (res) {
        if (!res.success) { setContent(notice('error', 'Failed to load dashboard.')); return; }
        var d = res.data;
        var s = d.stats;

        var activityRows = (d.recent_activity || []).map(function (a) {
            return '<li class="sp-activity-item"><div class="sp-activity-dot"></div><div><div class="sp-activity-text">' +
                esc(capitalize(a.display_name || 'System')) + ' ' + esc(a.action) + ' a ' + esc(a.object_type) + ' (#' + esc(a.object_id) + ')</div>' +
                '<div class="sp-activity-meta">' + fmtDate(a.created_at) + '</div></div></li>';
        }).join('') || '<li class="sp-activity-item"><div class="sp-activity-dot"></div><div class="sp-activity-text" style="color:#94a3b8">No activity yet.</div></li>';

        var leadRows = (d.lead_breakdown || []).map(function (l) {
            return '<tr><td>' + badge(l.status) + '</td><td style="font-weight:600">' + esc(l.count) + '</td></tr>';
        }).join('') || '<tr><td colspan="2" class="sp-table-empty">No leads yet.</td></tr>';

        setContent(
            '<div class="sp-page-header"><h1>Dashboard</h1></div>' +
            '<div class="sp-stat-grid">' +
                statCard('Contacts',           s.contacts,            'All contacts in the system') +
                statCard('Companies',          s.companies,           'All companies') +
                statCard('Leads',              s.leads,               'Total leads') +
                statCard('New Leads This Week',s.new_leads_this_week, 'Added in last 7 days') +
            '</div>' +
            '<div class="sp-dash-grid">' +
                '<div class="sp-card"><div class="sp-card-header"><span class="sp-card-title">Recent Activity</span></div><div class="sp-card-body"><ul class="sp-activity-feed">' + activityRows + '</ul></div></div>' +
                '<div class="sp-card"><div class="sp-card-header"><span class="sp-card-title">Lead Pipeline</span></div><div class="sp-card-body"><div class="sp-table-wrap"><table class="sp-table"><thead><tr><th>Status</th><th>Count</th></tr></thead><tbody>' + leadRows + '</tbody></table></div></div></div>' +
            '</div>'
        );
    });
});

function statCard(label, number, sub) {
    return '<div class="sp-stat-card"><div class="sp-stat-label">' + esc(label) + '</div><div class="sp-stat-number">' + esc(String(number || 0)) + '</div><div class="sp-stat-sub">' + esc(sub) + '</div></div>';
}

// ── Contacts ───────────────────────────────────────────────────────────────

route('#contacts', views.contactList = function (params) {
    setBreadcrumb('Contacts');
    setActions('<button class="sp-btn sp-btn-primary" onclick="navigate(\'#contacts/new\')">+ Add Contact</button>');
    loading();
    var search = params.search || '';
    var page   = params.page   || 1;
    api.get('/contacts?search=' + encodeURIComponent(search) + '&page=' + page).then(function (res) {
        if (!res.success) { setContent(notice('error', 'Failed to load contacts.')); return; }
        var d = res.data;
        var rows = (d.items || []).map(function (c) {
            var name = esc((c.first_name + ' ' + c.last_name).trim()) || esc(c.email) || '—';
            return '<tr><td><span class="sp-row-link" onclick="navigate(\'#contacts/' + c.id + '\')">' + name + '</span></td>' +
                '<td>' + esc(c.email || '—') + '</td>' +
                '<td>' + esc(c.phone || '—') + '</td>' +
                '<td>' + esc(c.company_name || '—') + '</td>' +
                '<td>' + badge(c.status) + '</td>' +
                '<td>' + fmtDate(c.created_at) + '</td>' +
                '<td class="sp-row-actions"><button class="sp-btn sp-btn-ghost sp-btn-sm" onclick="navigate(\'#contacts/' + c.id + '\')">Edit</button>' +
                '<button class="sp-btn sp-btn-ghost sp-btn-sm" style="color:#dc2626" onclick="deleteRecord(\'contacts\',' + c.id + ',\'#contacts\')">Delete</button></td></tr>';
        }).join('') || '<tr><td colspan="7" class="sp-table-empty">No contacts found.</td></tr>';

        setContent(
            '<div class="sp-page-header"><h1>Contacts</h1></div>' +
            '<div class="sp-search-bar">' +
                '<input class="sp-search-input" type="search" placeholder="Search contacts…" value="' + esc(search) + '" id="contacts-search" onkeydown="if(event.key===\'Enter\')navigate(\'#contacts?search=\'+encodeURIComponent(this.value))">' +
                '<button class="sp-btn sp-btn-secondary" onclick="navigate(\'#contacts?search=\'+encodeURIComponent(document.getElementById(\'contacts-search\').value))">Search</button>' +
            '</div>' +
            '<div class="sp-card"><div class="sp-table-wrap"><table class="sp-table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Status</th><th>Created</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
            pagination(d, '#contacts') + '</div>'
        );
    });
});

route('#contacts/new', function () {
    setBreadcrumb('<span class="sp-row-link" onclick="navigate(\'#contacts\')">Contacts</span> <span class="crumb-sep">/</span> New Contact');
    setActions('');
    renderContactForm(null);
});

route('#contacts/:id', function (params) {
    var id = window.location.hash.split('/')[1];
    if (!id || id === 'new') return;
    setBreadcrumb('<span class="sp-row-link" onclick="navigate(\'#contacts\')">Contacts</span> <span class="crumb-sep">/</span> Edit');
    setActions('');
    loading();
    Promise.all([
        api.get('/contacts/' + id),
        api.get('/companies?per_page=100'),
    ]).then(function (results) {
        renderContactForm(results[0].data, results[1].data && results[1].data.items);
    });
});

function renderContactForm(contact, companies) {
    var isNew   = !contact;
    var c       = contact || {};
    var cos     = companies || [];
    var coOpts  = '<option value="0">— None —</option>' + cos.map(function (co) {
        return '<option value="' + co.id + '"' + (c.company_id == co.id ? ' selected' : '') + '>' + esc(co.name) + '</option>';
    }).join('');
    var statusOpts = ['active','inactive','archived'].map(function (s) {
        return '<option value="' + s + '"' + (c.status === s || (!c.status && s === 'active') ? ' selected' : '') + '>' + capitalize(s) + '</option>';
    }).join('');

    if (!companies && !isNew) {
        api.get('/companies?per_page=100').then(function (res) {
            renderContactForm(contact, res.data && res.data.items);
        });
        return;
    }

    setContent(
        '<div class="sp-page-header"><h1>' + (isNew ? 'New Contact' : 'Edit Contact') + '</h1></div>' +
        '<div class="sp-card"><div class="sp-card-body">' +
        '<form class="sp-form" id="contact-form" onsubmit="submitContactForm(event,' + (c.id || 0) + ')">' +
        '<div class="sp-form-grid">' +
            field('First Name', 'first_name', c.first_name || '', 'text', true) +
            field('Last Name',  'last_name',  c.last_name  || '', 'text') +
        '</div>' +
        '<div class="sp-form-grid">' +
            field('Email', 'email', c.email || '', 'email') +
            field('Phone', 'phone', c.phone || '', 'text') +
        '</div>' +
        '<div class="sp-field"><label>Company</label><select name="company_id">' + coOpts + '</select></div>' +
        '<div class="sp-form-grid">' +
            field('Source', 'source', c.source || '', 'text', false, 'e.g. website, referral, chat') +
            '<div class="sp-field"><label>Status</label><select name="status">' + statusOpts + '</select></div>' +
        '</div>' +
        '<div class="sp-field"><label>Notes</label><textarea name="notes" placeholder="Any notes about this contact…">' + esc(c.notes || '') + '</textarea></div>' +
        '<div class="sp-form-actions">' +
            '<button type="submit" class="sp-btn sp-btn-primary" id="contact-submit">Save Contact</button>' +
            '<button type="button" class="sp-btn sp-btn-secondary" onclick="navigate(\'#contacts\')">Cancel</button>' +
        '</div></form></div></div>'
    );
}

window.submitContactForm = function (e, id) {
    e.preventDefault();
    var form = e.target;
    var data = formToObj(form);
    var btn  = document.getElementById('contact-submit');
    btn.disabled = true; btn.textContent = 'Saving…';
    var req = id ? api.put('/contacts/' + id, data) : api.post('/contacts', data);
    req.then(function (res) {
        if (res.success) {
            navigate('#contacts?saved=1');
        } else {
            btn.disabled = false; btn.textContent = 'Save Contact';
            var n = document.createElement('div');
            n.innerHTML = notice('error', res.message || 'Save failed.');
            form.prepend(n.firstChild);
        }
    });
};

// ── Companies ──────────────────────────────────────────────────────────────

route('#companies', views.companyList = function (params) {
    setBreadcrumb('Companies');
    setActions('<button class="sp-btn sp-btn-primary" onclick="navigate(\'#companies/new\')">+ Add Company</button>');
    loading();
    var search = params.search || '';
    var page   = params.page   || 1;
    api.get('/companies?search=' + encodeURIComponent(search) + '&page=' + page).then(function (res) {
        if (!res.success) { setContent(notice('error', 'Failed to load companies.')); return; }
        var d = res.data;
        var rows = (d.items || []).map(function (c) {
            var web = c.website ? '<a href="' + esc(c.website) + '" target="_blank" style="color:var(--primary)">' + esc(c.website) + '</a>' : '—';
            return '<tr><td><span class="sp-row-link" onclick="navigate(\'#companies/' + c.id + '\')">' + esc(c.name) + '</span></td>' +
                '<td>' + esc(c.industry || '—') + '</td>' +
                '<td>' + esc(c.phone    || '—') + '</td>' +
                '<td>' + web + '</td>' +
                '<td>' + fmtDate(c.created_at) + '</td>' +
                '<td class="sp-row-actions"><button class="sp-btn sp-btn-ghost sp-btn-sm" onclick="navigate(\'#companies/' + c.id + '\')">Edit</button>' +
                '<button class="sp-btn sp-btn-ghost sp-btn-sm" style="color:#dc2626" onclick="deleteRecord(\'companies\',' + c.id + ',\'#companies\')">Delete</button></td></tr>';
        }).join('') || '<tr><td colspan="6" class="sp-table-empty">No companies found.</td></tr>';

        setContent(
            '<div class="sp-page-header"><h1>Companies</h1></div>' +
            '<div class="sp-search-bar">' +
                '<input class="sp-search-input" type="search" placeholder="Search companies…" value="' + esc(search) + '" id="companies-search" onkeydown="if(event.key===\'Enter\')navigate(\'#companies?search=\'+encodeURIComponent(this.value))">' +
                '<button class="sp-btn sp-btn-secondary" onclick="navigate(\'#companies?search=\'+encodeURIComponent(document.getElementById(\'companies-search\').value))">Search</button>' +
            '</div>' +
            '<div class="sp-card"><div class="sp-table-wrap"><table class="sp-table"><thead><tr><th>Name</th><th>Industry</th><th>Phone</th><th>Website</th><th>Created</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
            pagination(d, '#companies') + '</div>'
        );
    });
});

route('#companies/new', function () {
    setBreadcrumb('<span class="sp-row-link" onclick="navigate(\'#companies\')">Companies</span> <span class="crumb-sep">/</span> New Company');
    setActions('');
    renderCompanyForm(null);
});

route('#companies/:id', function () {
    var id = window.location.hash.split('/')[1];
    if (!id || id === 'new') return;
    setBreadcrumb('<span class="sp-row-link" onclick="navigate(\'#companies\')">Companies</span> <span class="crumb-sep">/</span> Edit');
    setActions('');
    loading();
    api.get('/companies/' + id).then(function (res) { renderCompanyForm(res.data); });
});

function renderCompanyForm(company) {
    var c = company || {};
    setContent(
        '<div class="sp-page-header"><h1>' + (company ? 'Edit Company' : 'New Company') + '</h1></div>' +
        '<div class="sp-card"><div class="sp-card-body">' +
        '<form class="sp-form" id="company-form" onsubmit="submitCompanyForm(event,' + (c.id || 0) + ')">' +
        '<div class="sp-field"><label>Company Name *</label><input type="text" name="name" value="' + esc(c.name || '') + '" required></div>' +
        '<div class="sp-form-grid">' +
            field('Industry', 'industry', c.industry || '', 'text') +
            field('Phone',    'phone',    c.phone    || '', 'text') +
        '</div>' +
        '<div class="sp-field"><label>Website</label><input type="url" name="website" value="' + esc(c.website || '') + '" placeholder="https://"></div>' +
        '<div class="sp-field"><label>Address</label><textarea name="address">' + esc(c.address || '') + '</textarea></div>' +
        '<div class="sp-field"><label>Notes</label><textarea name="notes">' + esc(c.notes || '') + '</textarea></div>' +
        '<div class="sp-form-actions">' +
            '<button type="submit" class="sp-btn sp-btn-primary" id="company-submit">Save Company</button>' +
            '<button type="button" class="sp-btn sp-btn-secondary" onclick="navigate(\'#companies\')">Cancel</button>' +
        '</div></form></div></div>'
    );
}

window.submitCompanyForm = function (e, id) {
    e.preventDefault();
    var btn = document.getElementById('company-submit');
    btn.disabled = true; btn.textContent = 'Saving…';
    var req = id ? api.put('/companies/' + id, formToObj(e.target)) : api.post('/companies', formToObj(e.target));
    req.then(function (res) {
        if (res.success) navigate('#companies');
        else { btn.disabled = false; btn.textContent = 'Save Company'; }
    });
};

// ── Leads ──────────────────────────────────────────────────────────────────

route('#leads', views.leadList = function (params) {
    setBreadcrumb('Leads');
    setActions('<button class="sp-btn sp-btn-primary" onclick="navigate(\'#leads/new\')">+ Add Lead</button>');
    loading();
    var search = params.search || '';
    var status = params.status || '';
    var page   = params.page   || 1;
    api.get('/leads?search=' + encodeURIComponent(search) + '&status=' + status + '&page=' + page).then(function (res) {
        if (!res.success) { setContent(notice('error', 'Failed to load leads.')); return; }
        var d = res.data;
        var statusOpts = ['','new','contacted','qualified','unqualified','closed'].map(function (s) {
            return '<option value="' + s + '"' + (status === s ? ' selected' : '') + '>' + (s ? capitalize(s) : 'All Statuses') + '</option>';
        }).join('');

        var rows = (d.items || []).map(function (l) {
            var name = esc(((l.first_name || '') + ' ' + (l.last_name || '')).trim()) || esc(l.email) || '—';
            return '<tr><td><span class="sp-row-link" onclick="navigate(\'#leads/' + l.id + '\')">' + name + '</span></td>' +
                '<td>' + esc(l.company_name || '—') + '</td>' +
                '<td>' + esc(l.source || '—') + '</td>' +
                '<td>' + badge(l.status) + '</td>' +
                '<td>' + esc(l.score || '0') + '</td>' +
                '<td>' + fmtDate(l.created_at) + '</td>' +
                '<td class="sp-row-actions"><button class="sp-btn sp-btn-ghost sp-btn-sm" onclick="navigate(\'#leads/' + l.id + '\')">Edit</button>' +
                '<button class="sp-btn sp-btn-ghost sp-btn-sm" style="color:#dc2626" onclick="deleteRecord(\'leads\',' + l.id + ',\'#leads\')">Delete</button></td></tr>';
        }).join('') || '<tr><td colspan="7" class="sp-table-empty">No leads found.</td></tr>';

        setContent(
            '<div class="sp-page-header"><h1>Leads</h1></div>' +
            '<div class="sp-search-bar">' +
                '<select class="sp-filter-select" id="lead-status" onchange="navigate(\'#leads?status=\'+this.value)">' + statusOpts + '</select>' +
                '<input class="sp-search-input" type="search" placeholder="Search by contact…" value="' + esc(search) + '" id="leads-search" onkeydown="if(event.key===\'Enter\')navigate(\'#leads?search=\'+encodeURIComponent(this.value))">' +
                '<button class="sp-btn sp-btn-secondary" onclick="navigate(\'#leads?search=\'+encodeURIComponent(document.getElementById(\'leads-search\').value))">Search</button>' +
            '</div>' +
            '<div class="sp-card"><div class="sp-table-wrap"><table class="sp-table"><thead><tr><th>Contact</th><th>Company</th><th>Source</th><th>Status</th><th>Score</th><th>Created</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
            pagination(d, '#leads') + '</div>'
        );
    });
});

route('#leads/new', function () {
    setBreadcrumb('<span class="sp-row-link" onclick="navigate(\'#leads\')">Leads</span> <span class="crumb-sep">/</span> New Lead');
    setActions('');
    renderLeadForm(null);
});

route('#leads/:id', function () {
    var id = window.location.hash.split('/')[1];
    if (!id || id === 'new') return;
    setBreadcrumb('<span class="sp-row-link" onclick="navigate(\'#leads\')">Leads</span> <span class="crumb-sep">/</span> Edit');
    setActions('');
    loading();
    Promise.all([
        api.get('/leads/' + id),
        api.get('/contacts?per_page=100'),
        api.get('/companies?per_page=100'),
    ]).then(function (r) { renderLeadForm(r[0].data, r[1].data && r[1].data.items, r[2].data && r[2].data.items); });
});

function renderLeadForm(lead, contacts, companies) {
    var l    = lead || {};
    var cons = contacts  || [];
    var cos  = companies || [];

    if ((!contacts || !companies) && lead) {
        Promise.all([api.get('/contacts?per_page=100'), api.get('/companies?per_page=100')]).then(function (r) {
            renderLeadForm(lead, r[0].data && r[0].data.items, r[1].data && r[1].data.items);
        });
        return;
    }
    if (!contacts && !lead) {
        Promise.all([api.get('/contacts?per_page=100'), api.get('/companies?per_page=100')]).then(function (r) {
            renderLeadForm(null, r[0].data && r[0].data.items, r[1].data && r[1].data.items);
        });
        return;
    }

    var conOpts = '<option value="0">— Select Contact —</option>' + cons.map(function (c) {
        var n = ((c.first_name || '') + ' ' + (c.last_name || '')).trim() || c.email;
        return '<option value="' + c.id + '"' + (l.contact_id == c.id ? ' selected' : '') + '>' + esc(n) + '</option>';
    }).join('');
    var coOpts = '<option value="0">— None —</option>' + cos.map(function (c) {
        return '<option value="' + c.id + '"' + (l.company_id == c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>';
    }).join('');
    var statOpts = ['new','contacted','qualified','unqualified','closed'].map(function (s) {
        return '<option value="' + s + '"' + (l.status === s || (!l.status && s === 'new') ? ' selected' : '') + '>' + capitalize(s) + '</option>';
    }).join('');

    setContent(
        '<div class="sp-page-header"><h1>' + (lead ? 'Edit Lead' : 'New Lead') + '</h1></div>' +
        '<div class="sp-card"><div class="sp-card-body">' +
        '<form class="sp-form" id="lead-form" onsubmit="submitLeadForm(event,' + (l.id || 0) + ')">' +
        '<div class="sp-field"><label>Contact</label><select name="contact_id">' + conOpts + '</select></div>' +
        '<div class="sp-field"><label>Company</label><select name="company_id">' + coOpts + '</select></div>' +
        '<div class="sp-form-grid">' +
            field('Source', 'source', l.source || '', 'text', false, 'e.g. website, referral, chat') +
            '<div class="sp-field"><label>Status</label><select name="status">' + statOpts + '</select></div>' +
        '</div>' +
        '<div class="sp-field"><label>Score (0–100)</label><input type="number" name="score" min="0" max="100" value="' + esc(String(l.score || 0)) + '"></div>' +
        '<div class="sp-field"><label>Notes</label><textarea name="notes">' + esc(l.notes || '') + '</textarea></div>' +
        '<div class="sp-form-actions">' +
            '<button type="submit" class="sp-btn sp-btn-primary" id="lead-submit">Save Lead</button>' +
            '<button type="button" class="sp-btn sp-btn-secondary" onclick="navigate(\'#leads\')">Cancel</button>' +
        '</div></form></div></div>'
    );
}

window.submitLeadForm = function (e, id) {
    e.preventDefault();
    var btn = document.getElementById('lead-submit');
    btn.disabled = true; btn.textContent = 'Saving…';
    var req = id ? api.put('/leads/' + id, formToObj(e.target)) : api.post('/leads', formToObj(e.target));
    req.then(function (res) {
        if (res.success) navigate('#leads');
        else { btn.disabled = false; btn.textContent = 'Save Lead'; }
    });
};

// ── Activity Log ───────────────────────────────────────────────────────────

route('#activity', function () {
    setBreadcrumb('Activity Log');
    setActions('');
    loading();
    api.get('/dashboard').then(function (res) {
        var activity = (res.data && res.data.recent_activity) || [];
        var rows = activity.map(function (a) {
            return '<tr><td style="white-space:nowrap">' + fmtDate(a.created_at) + '</td>' +
                '<td>' + esc(a.display_name || 'System') + '</td>' +
                '<td>' + esc(capitalize(a.object_type)) + '</td>' +
                '<td>' + esc(a.object_id) + '</td>' +
                '<td>' + badge(a.action) + '</td></tr>';
        }).join('') || '<tr><td colspan="5" class="sp-table-empty">No activity yet.</td></tr>';

        setContent(
            '<div class="sp-page-header"><h1>Activity Log</h1></div>' +
            '<div class="sp-card"><div class="sp-table-wrap"><table class="sp-table"><thead><tr><th>When</th><th>User</th><th>Type</th><th>ID</th><th>Action</th></tr></thead><tbody>' + rows + '</tbody></table></div></div>'
        );
    });
});

// ── Settings ───────────────────────────────────────────────────────────────

route('#settings', function () {
    setBreadcrumb('Settings');
    setActions('');
    setContent(
        '<div class="sp-page-header"><h1>Settings</h1></div>' +
        '<div class="sp-card"><div class="sp-card-body">' +
        '<p style="color:var(--text-2);font-size:14px">Platform settings are managed via <strong>WordPress Admin → Start Performance → Settings</strong>.</p>' +
        '<p style="color:var(--text-3);font-size:13px;margin-top:8px">Full in-app settings will be available in a future release.</p>' +
        '</div></div>'
    );
});

// ── 404 ────────────────────────────────────────────────────────────────────

views.notFound = function () {
    setBreadcrumb('Not Found');
    setActions('');
    setContent('<div class="sp-empty-state"><div class="sp-empty-icon">🔍</div><div class="sp-empty-title">Page not found</div><div class="sp-empty-sub">This section doesn\'t exist yet.</div><button class="sp-btn sp-btn-primary" onclick="navigate(\'#dashboard\')">Go to Dashboard</button></div>');
};

// ── Shared helpers ─────────────────────────────────────────────────────────

window.navigate = navigate;

window.deleteRecord = function (type, id, returnHash) {
    if (!confirm('Are you sure you want to delete this record?')) return;
    api.del('/' + type + '/' + id).then(function () { navigate(returnHash, false); window.location.hash = returnHash; navigate(returnHash, false); });
};

function field(label, name, value, type, required, placeholder) {
    var req  = required ? ' required' : '';
    var ph   = placeholder ? ' placeholder="' + esc(placeholder) + '"' : '';
    return '<div class="sp-field"><label>' + esc(label) + (required ? ' *' : '') + '</label><input type="' + (type || 'text') + '" name="' + esc(name) + '" value="' + esc(value) + '"' + ph + req + '></div>';
}

function formToObj(form) {
    var obj = {};
    new FormData(form).forEach(function (v, k) { obj[k] = v; });
    return obj;
}

// ── Wild-card route matching ───────────────────────────────────────────────

function matchRoute(hash) {
    var clean = hash.split('?')[0];
    if (routes[clean]) return routes[clean];
    // Match parameterised routes like #contacts/:id
    var parts = clean.split('/');
    if (parts.length === 2) {
        var parent = parts[0];
        if (routes[parent + '/:id']) return routes[parent + '/:id'];
    }
    return null;
}

// Override navigate to use wild-card matcher
navigate = function (hash, push) {
    if (push !== false) { window.location.hash = hash; }
    var key = hash.split('?')[0];
    var fn  = routes[key] || matchRoute(hash) || views.notFound;
    document.querySelectorAll('.sp-nav-item').forEach(function (el) {
        var view  = el.dataset.view;
        var match = key.replace('#', '').split('/')[0] === view;
        el.classList.toggle('active', match);
    });
    fn(parseQuery(hash));
};
window.navigate = navigate;

// ── Boot ───────────────────────────────────────────────────────────────────

navigate(window.location.hash || '#dashboard', false);

})();
