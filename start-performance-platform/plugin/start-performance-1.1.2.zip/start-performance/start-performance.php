<?php
/*
 * Plugin Name: Start Performance
 * Plugin URI:  https://startadvertising.com
 * Description: Core System for the Start Performance Platform.
 * Version:     1.1.2
 * Author:      Richard Brashear / Start Performance
 * Author URI:  https://startadvertising.com
 * License:     GPL-2.0+
 * Text Domain: start-performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_VERSION',    '1.1.2' );
define( 'SP_PLUGIN_FILE', __FILE__ );
define( 'SP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

require_once SP_PLUGIN_DIR . 'includes/Core/helpers.php';

spl_autoload_register( function ( $class ) {
    if ( strpos( $class, 'SP\\' ) !== 0 ) return;
    $path = str_replace( array( 'SP\\', '\\' ), array( '', DIRECTORY_SEPARATOR ), $class );
    $file = SP_PLUGIN_DIR . 'includes' . DIRECTORY_SEPARATOR . $path . '.php';
    if ( file_exists( $file ) ) require_once $file;
} );

register_activation_hook(   __FILE__, array( 'SP\\Core\\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SP\\Core\\Installer', 'deactivate' ) );

add_action( 'plugins_loaded', function () {
    SP\Core\Platform::instance()->boot();
} );
