<?php
defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$nonce        = wp_create_nonce( 'wp_rest' );
$api_base     = esc_url( rest_url( 'sp/v1' ) );
$logout_url   = esc_url( \SP\Core\AppShell::login_url() . '?sp_logout=1' );
$platform_name = \SP\Core\SP_Settings::get( 'core', 'platform_name', 'Start Performance' );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo esc_html( $platform_name ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( SP_PLUGIN_URL . 'assets/css/app.css?v=' . SP_VERSION ); ?>">
</head>
<body>

<div id="sp-app">

    <!-- Sidebar -->
    <aside id="sp-sidebar">
        <div class="sp-sidebar-logo">
            <div class="sp-logo-mark">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" width="22" height="22">
                    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="#fff" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/>
                </svg>
            </div>
            <span class="sp-logo-name"><?php echo esc_html( $platform_name ); ?></span>
        </div>

        <nav id="sp-nav">
            <a href="#dashboard"    class="sp-nav-item" data-view="dashboard">
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 10a8 8 0 1116 0A8 8 0 012 10zm8-4a1 1 0 00-1 1v3H6a1 1 0 100 2h3v3a1 1 0 102 0v-3h3a1 1 0 100-2h-3V7a1 1 0 00-1-1z"/></svg>
                <span>Dashboard</span>
            </a>
            <a href="#contacts"     class="sp-nav-item" data-view="contacts">
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"/></svg>
                <span>Contacts</span>
            </a>
            <a href="#companies"    class="sp-nav-item" data-view="companies">
                <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a1 1 0 110 2H4a1 1 0 110-2V4zm3 1h2v2H7V5zm2 4H7v2h2V9zm2-4h2v2h-2V5zm2 4h-2v2h2V9z" clip-rule="evenodd"/></svg>
                <span>Companies</span>
            </a>
            <a href="#leads"        class="sp-nav-item" data-view="leads">
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"/></svg>
                <span>Leads</span>
            </a>

            <div class="sp-nav-divider"></div>

            <a href="#activity"     class="sp-nav-item" data-view="activity">
                <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
                <span>Activity Log</span>
            </a>
            <a href="#settings"     class="sp-nav-item" data-view="settings">
                <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>
                <span>Settings</span>
            </a>
        </nav>

        <div class="sp-sidebar-footer">
            <div class="sp-user-row">
                <div class="sp-user-avatar"><?php echo esc_html( strtoupper( substr( $current_user->display_name, 0, 1 ) ) ); ?></div>
                <div class="sp-user-info">
                    <div class="sp-user-name"><?php echo esc_html( $current_user->display_name ); ?></div>
                    <div class="sp-user-role">Administrator</div>
                </div>
                <a href="<?php echo $logout_url; ?>" class="sp-logout-btn" title="Sign out">
                    <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/></svg>
                </a>
            </div>
        </div>
    </aside>

    <!-- Main content -->
    <main id="sp-main">
        <header id="sp-topbar">
            <div id="sp-breadcrumb"></div>
            <div id="sp-topbar-actions"></div>
        </header>
        <div id="sp-content">
            <div class="sp-loading"><div class="sp-spinner"></div></div>
        </div>
    </main>

</div>

<script>
var SP = {
    apiBase:  '<?php echo esc_js( $api_base ); ?>',
    nonce:    '<?php echo esc_js( $nonce ); ?>',
    siteUrl:  '<?php echo esc_js( get_site_url() ); ?>',
    user: {
        name: '<?php echo esc_js( $current_user->display_name ); ?>',
        email:'<?php echo esc_js( $current_user->user_email ); ?>',
    }
};
</script>
<script src="<?php echo esc_url( SP_PLUGIN_URL . 'assets/js/app.js?v=' . SP_VERSION ); ?>"></script>
</body>
</html>
