<?php
namespace SP\REST;
if ( ! defined( 'ABSPATH' ) ) exit;

class CompaniesController extends BaseController {

    public function register_routes() {
        register_rest_route( $this->namespace, '/companies', array(
            array( 'methods' => 'GET',  'callback' => array( $this, 'get_items' ),   'permission_callback' => array( $this, 'auth_check' ) ),
            array( 'methods' => 'POST', 'callback' => array( $this, 'create_item' ), 'permission_callback' => array( $this, 'auth_check' ) ),
        ) );
        register_rest_route( $this->namespace, '/companies/(?P<id>\d+)', array(
            array( 'methods' => 'GET',    'callback' => array( $this, 'get_item' ),    'permission_callback' => array( $this, 'auth_check' ) ),
            array( 'methods' => 'PUT',    'callback' => array( $this, 'update_item' ), 'permission_callback' => array( $this, 'auth_check' ) ),
            array( 'methods' => 'DELETE', 'callback' => array( $this, 'delete_item' ), 'permission_callback' => array( $this, 'auth_check' ) ),
        ) );
    }

    public function get_items( $request ) {
        global $wpdb;
        $search   = sanitize_text_field( $request->get_param( 'search' ) ? $request->get_param( 'search' ) : '' );
        $page     = max( 1, (int) ( $request->get_param( 'page' )     ? $request->get_param( 'page' )     : 1 ) );
        $per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ? $request->get_param( 'per_page' ) : 25 ) ) );
        $offset   = ( $page - 1 ) * $per_page;

        $where = 'WHERE deleted_at IS NULL';
        $args  = array();
        if ( $search ) {
            $where .= ' AND (name LIKE %s OR industry LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = array( $like, $like );
        }

        $count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies $where";
        $total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) );

        $list_sql  = "SELECT * FROM {$wpdb->prefix}sp_companies $where ORDER BY name LIMIT %d OFFSET %d";
        $list_args = array_merge( $args, array( $per_page, $offset ) );
        $rows      = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_args ), ARRAY_A );

        return $this->ok( $this->paginate( $rows, $total, $page, $per_page ) );
    }

    public function get_item( $request ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sp_companies WHERE id = %d AND deleted_at IS NULL",
            (int) $request['id']
        ), ARRAY_A );
        return $row ? $this->ok( $row ) : $this->error( 'Company not found.', 404 );
    }

    public function create_item( $request ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sp_companies', $this->sanitize_fields( $request ) );
        $id = $wpdb->insert_id;
        \SP\Core\ActivityLog::write( 'company', $id, 'created' );
        return $this->ok( array( 'id' => $id ), 201 );
    }

    public function update_item( $request ) {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_companies', $this->sanitize_fields( $request ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'company', $id, 'updated' );
        return $this->ok( array( 'id' => $id ) );
    }

    public function delete_item( $request ) {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_companies', array( 'deleted_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'company', $id, 'deleted' );
        return $this->ok( array( 'deleted' => true ) );
    }

    private function sanitize_fields( $request ) {
        return array(
            'name'     => sanitize_text_field(     $request->get_param( 'name' )     ? $request->get_param( 'name' )     : '' ),
            'industry' => sanitize_text_field(     $request->get_param( 'industry' ) ? $request->get_param( 'industry' ) : '' ),
            'website'  => esc_url_raw(             $request->get_param( 'website' )  ? $request->get_param( 'website' )  : '' ),
            'phone'    => sanitize_text_field(     $request->get_param( 'phone' )    ? $request->get_param( 'phone' )    : '' ),
            'address'  => sanitize_textarea_field( $request->get_param( 'address' )  ? $request->get_param( 'address' )  : '' ),
            'notes'    => sanitize_textarea_field( $request->get_param( 'notes' )    ? $request->get_param( 'notes' )    : '' ),
        );
    }
}
