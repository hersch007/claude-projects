<?php
namespace SP\REST;
if ( ! defined( 'ABSPATH' ) ) exit;

class ContactsController extends BaseController {

    public function register_routes() {
        register_rest_route( $this->namespace, '/contacts', array(
            array( 'methods' => 'GET',  'callback' => array( $this, 'get_items' ),   'permission_callback' => array( $this, 'auth_check' ) ),
            array( 'methods' => 'POST', 'callback' => array( $this, 'create_item' ), 'permission_callback' => array( $this, 'auth_check' ) ),
        ) );
        register_rest_route( $this->namespace, '/contacts/(?P<id>\d+)', array(
            array( 'methods' => 'GET',    'callback' => array( $this, 'get_item' ),    'permission_callback' => array( $this, 'auth_check' ) ),
            array( 'methods' => 'PUT',    'callback' => array( $this, 'update_item' ), 'permission_callback' => array( $this, 'auth_check' ) ),
            array( 'methods' => 'DELETE', 'callback' => array( $this, 'delete_item' ), 'permission_callback' => array( $this, 'auth_check' ) ),
        ) );
    }

    public function get_items( $request ) {
        global $wpdb;
        $search   = sanitize_text_field( $request->get_param( 'search' ) ? $request->get_param( 'search' ) : '' );
        $page     = max( 1, (int) ( $request->get_param( 'page' )     ? $request->get_param( 'page' )     : 1 ) );
        $per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ? $request->get_param( 'per_page' ) : 25 ) ) );
        $offset   = ( $page - 1 ) * $per_page;

        $where = 'WHERE c.deleted_at IS NULL';
        $args  = array();
        if ( $search ) {
            $where .= ' AND (c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s OR c.phone LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = array( $like, $like, $like, $like );
        }

        $count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts c $where";
        $total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) );

        $list_sql  = "SELECT c.*, co.name AS company_name FROM {$wpdb->prefix}sp_contacts c LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id $where ORDER BY c.created_at DESC LIMIT %d OFFSET %d";
        $list_args = array_merge( $args, array( $per_page, $offset ) );
        $rows      = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_args ), ARRAY_A );

        return $this->ok( $this->paginate( $rows, $total, $page, $per_page ) );
    }

    public function get_item( $request ) {
        global $wpdb;
        $id  = (int) $request['id'];
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT c.*, co.name AS company_name FROM {$wpdb->prefix}sp_contacts c LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id WHERE c.id = %d AND c.deleted_at IS NULL",
            $id
        ), ARRAY_A );
        return $row ? $this->ok( $row ) : $this->error( 'Contact not found.', 404 );
    }

    public function create_item( $request ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sp_contacts', $this->sanitize_fields( $request ) );
        $id = $wpdb->insert_id;
        \SP\Core\ActivityLog::write( 'contact', $id, 'created' );
        return $this->ok( array( 'id' => $id ), 201 );
    }

    public function update_item( $request ) {
        global $wpdb;
        $id     = (int) $request['id'];
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sp_contacts WHERE id = %d AND deleted_at IS NULL", $id ) );
        if ( ! $exists ) return $this->error( 'Contact not found.', 404 );
        $wpdb->update( $wpdb->prefix . 'sp_contacts', $this->sanitize_fields( $request ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'contact', $id, 'updated' );
        return $this->ok( array( 'id' => $id ) );
    }

    public function delete_item( $request ) {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_contacts', array( 'deleted_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'contact', $id, 'deleted' );
        return $this->ok( array( 'deleted' => true ) );
    }

    private function sanitize_fields( $request ) {
        return array(
            'first_name' => sanitize_text_field(     $request->get_param( 'first_name' ) ? $request->get_param( 'first_name' ) : '' ),
            'last_name'  => sanitize_text_field(     $request->get_param( 'last_name' )  ? $request->get_param( 'last_name' )  : '' ),
            'email'      => sanitize_email(          $request->get_param( 'email' )      ? $request->get_param( 'email' )      : '' ),
            'phone'      => sanitize_text_field(     $request->get_param( 'phone' )      ? $request->get_param( 'phone' )      : '' ),
            'company_id' => (int) ( $request->get_param( 'company_id' ) ? $request->get_param( 'company_id' ) : 0 ),
            'source'     => sanitize_text_field(     $request->get_param( 'source' )     ? $request->get_param( 'source' )     : '' ),
            'status'     => sanitize_key(            $request->get_param( 'status' )     ? $request->get_param( 'status' )     : 'active' ),
            'notes'      => sanitize_textarea_field( $request->get_param( 'notes' )      ? $request->get_param( 'notes' )      : '' ),
        );
    }
}
