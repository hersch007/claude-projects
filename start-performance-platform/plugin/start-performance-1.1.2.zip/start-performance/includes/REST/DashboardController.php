<?php
namespace SP\REST;
if ( ! defined( 'ABSPATH' ) ) exit;

class DashboardController extends BaseController {

    public function register_routes() {
        register_rest_route( $this->namespace, '/dashboard', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'get_stats' ),
            'permission_callback' => array( $this, 'auth_check' ),
        ) );
    }

    public function get_stats( $request ) {
        global $wpdb;
        $contacts  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts  WHERE deleted_at IS NULL" );
        $companies = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies WHERE deleted_at IS NULL" );
        $leads     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads     WHERE deleted_at IS NULL" );
        $modules   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_modules   WHERE status = 'active'" );

        $new_leads_this_week = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE deleted_at IS NULL AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
        );

        $recent_activity = $wpdb->get_results(
            "SELECT a.object_type, a.object_id, a.action, a.created_at, u.display_name
             FROM {$wpdb->prefix}sp_activity_log a
             LEFT JOIN {$wpdb->users} u ON u.ID = a.user_id
             ORDER BY a.created_at DESC LIMIT 10",
            ARRAY_A
        );

        $lead_breakdown = $wpdb->get_results(
            "SELECT status, COUNT(*) as count FROM {$wpdb->prefix}sp_leads WHERE deleted_at IS NULL GROUP BY status",
            ARRAY_A
        );

        return $this->ok( array(
            'stats' => array(
                'contacts'            => $contacts,
                'companies'           => $companies,
                'leads'               => $leads,
                'active_modules'      => $modules,
                'new_leads_this_week' => $new_leads_this_week,
            ),
            'recent_activity' => $recent_activity,
            'lead_breakdown'  => $lead_breakdown,
        ) );
    }
}
