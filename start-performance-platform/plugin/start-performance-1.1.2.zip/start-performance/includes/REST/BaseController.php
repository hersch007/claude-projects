<?php
namespace SP\REST;

defined( 'ABSPATH' ) || exit;

abstract class BaseController extends \WP_REST_Controller {

    protected $namespace = 'sp/v1';

    /**
     * @return true|\WP_Error
     */
    protected function require_auth( \WP_REST_Request $request ) {
        if ( ! is_user_logged_in() ) {
            return new \WP_Error( 'sp_unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return new \WP_Error( 'sp_forbidden', 'Insufficient permissions.', array( 'status' => 403 ) );
        }
        return true;
    }

    /**
     * @return true|\WP_Error
     */
    public function auth_check() {
        if ( ! is_user_logged_in() ) {
            return new \WP_Error( 'sp_unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }
        return true;
    }

    protected function ok( $data, $status = 200 ) {
        return new \WP_REST_Response( array( 'success' => true, 'data' => $data ), $status );
    }

    protected function error( $message, $status = 400 ) {
        return new \WP_REST_Response( array( 'success' => false, 'message' => $message ), $status );
    }

    protected function paginate( $rows, $total, $page, $per_page ) {
        return array(
            'items'       => $rows,
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $per_page,
            'total_pages' => (int) ceil( $total / $per_page ),
        );
    }
}
