<?php
namespace SP\REST;
if ( ! defined( 'ABSPATH' ) ) exit;

class Router {
    public static function register() {
        $controllers = array(
            new DashboardController(),
            new ContactsController(),
            new CompaniesController(),
            new LeadsController(),
        );
        foreach ( $controllers as $controller ) {
            $controller->register_routes();
        }
    }
}
