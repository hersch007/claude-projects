<?php
namespace SP\Admin;
if ( ! defined( 'ABSPATH' ) ) exit;

class ActivityLog {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {}

    public function render_page() {
        global $wpdb;
        $paged       = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
        $type_filter = sanitize_key( isset( $_GET['type'] ) ? $_GET['type'] : '' );
        $limit       = 50;
        $offset      = ( $paged - 1 ) * $limit;

        $where = '1=1';
        $args  = array();
        if ( $type_filter ) {
            $where .= ' AND a.object_type = %s';
            $args[] = $type_filter;
        }

        $count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sp_activity_log a WHERE $where";
        $total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) );

        $list_sql  = "SELECT a.*, u.display_name FROM {$wpdb->prefix}sp_activity_log a LEFT JOIN {$wpdb->users} u ON u.ID = a.user_id WHERE $where ORDER BY a.created_at DESC LIMIT %d OFFSET %d";
        $list_args = array_merge( $args, array( $limit, $offset ) );
        $rows      = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_args ) );

        $types = $wpdb->get_col( "SELECT DISTINCT object_type FROM {$wpdb->prefix}sp_activity_log ORDER BY object_type" );
        ?>
        <div class="wrap sp-wrap">
            <div class="sp-page-header">
                <h1>Activity Log</h1>
                <form method="get" class="sp-search-form">
                    <input type="hidden" name="page" value="sp-activity-log">
                    <select name="type" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <?php foreach ( $types as $t ) : ?>
                            <option value="<?php echo esc_attr( $t ); ?>" <?php selected( $type_filter, $t ); ?>><?php echo esc_html( ucfirst( $t ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
            <table class="widefat sp-table">
                <thead><tr><th>When</th><th>User</th><th>Type</th><th>ID</th><th>Action</th><th>Details</th></tr></thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="6" class="sp-empty">No activity yet.</td></tr>
                <?php else : foreach ( $rows as $row ) : ?>
                    <tr>
                        <td style="white-space:nowrap"><?php echo esc_html( date( 'M j, Y g:i a', strtotime( $row->created_at ) ) ); ?></td>
                        <td><?php echo esc_html( $row->display_name ? $row->display_name : 'System' ); ?></td>
                        <td><?php echo esc_html( ucfirst( $row->object_type ) ); ?></td>
                        <td><?php echo esc_html( $row->object_id ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $row->action ); ?>"><?php echo esc_html( ucfirst( $row->action ) ); ?></span></td>
                        <td><code><?php echo esc_html( $row->details ? $row->details : '—' ); ?></code></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <?php sp_pagination( $total, $limit, $paged, 'admin.php?page=sp-activity-log' . ( $type_filter ? '&type=' . $type_filter : '' ) ); ?>
        </div>
        <?php
    }
}
