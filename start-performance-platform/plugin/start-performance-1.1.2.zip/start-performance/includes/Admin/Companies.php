<?php
namespace SP\Admin;
if ( ! defined( 'ABSPATH' ) ) exit;

class Companies {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'admin_post_sp_save_company',   array( $this, 'handle_save' ) );
        add_action( 'admin_post_sp_delete_company', array( $this, 'handle_delete' ) );
    }

    public function render_page() {
        $action = sanitize_key( isset( $_GET['sp_action'] ) ? $_GET['sp_action'] : 'list' );
        if ( $action === 'edit' || $action === 'new' ) {
            $this->render_form( $action );
        } else {
            $this->render_list();
        }
    }

    private function render_list() {
        global $wpdb;
        $search = sanitize_text_field( isset( $_GET['s'] ) ? $_GET['s'] : '' );
        $paged  = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
        $limit  = 25;
        $offset = ( $paged - 1 ) * $limit;

        $where = 'WHERE deleted_at IS NULL';
        $args  = array();
        if ( $search ) {
            $where .= ' AND (name LIKE %s OR industry LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = array( $like, $like );
        }

        $base_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies $where";
        $total    = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $base_sql, $args ) ) : $wpdb->get_var( $base_sql ) );

        $list_sql  = "SELECT * FROM {$wpdb->prefix}sp_companies $where ORDER BY name LIMIT %d OFFSET %d";
        $list_args = array_merge( $args, array( $limit, $offset ) );
        $rows      = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_args ) );

        $add_url = admin_url( 'admin.php?page=sp-companies&sp_action=new' );
        ?>
        <div class="wrap sp-wrap">
            <div class="sp-page-header">
                <h1>Companies <a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action">Add New</a></h1>
                <form method="get" class="sp-search-form">
                    <input type="hidden" name="page" value="sp-companies">
                    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search companies...">
                    <button type="submit" class="button">Search</button>
                </form>
            </div>
            <table class="widefat sp-table">
                <thead><tr><th>Name</th><th>Industry</th><th>Phone</th><th>Website</th><th>Created</th><th></th></tr></thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="6" class="sp-empty">No companies found.</td></tr>
                <?php else : foreach ( $rows as $row ) :
                    $edit_url   = admin_url( 'admin.php?page=sp-companies&sp_action=edit&id=' . $row->id );
                    $delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=sp_delete_company&id=' . $row->id ), 'sp_delete_company_' . $row->id ); ?>
                    <tr>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $row->name ); ?></a></td>
                        <td><?php echo esc_html( $row->industry ? $row->industry : '—' ); ?></td>
                        <td><?php echo esc_html( $row->phone    ? $row->phone    : '—' ); ?></td>
                        <td><?php echo $row->website ? '<a href="' . esc_url( $row->website ) . '" target="_blank">' . esc_html( $row->website ) . '</a>' : '—'; ?></td>
                        <td><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>">Edit</a> | <a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('Delete this company?')">Delete</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <?php sp_pagination( $total, $limit, $paged, 'admin.php?page=sp-companies' ); ?>
        </div>
        <?php
    }

    private function render_form( $action ) {
        global $wpdb;
        $id      = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
        $company = null;
        $notice  = '';

        if ( $action === 'edit' && $id ) {
            $company = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_companies WHERE id = %d AND deleted_at IS NULL", $id
            ) );
            if ( ! $company ) wp_die( 'Company not found.' );
        }

        if ( isset( $_GET['saved'] ) ) {
            $notice = '<div class="notice notice-success is-dismissible"><p>Company saved.</p></div>';
        }

        $back_url = admin_url( 'admin.php?page=sp-companies' );
        ?>
        <div class="wrap sp-wrap">
            <?php echo $notice; ?>
            <h1><?php echo $action === 'edit' ? 'Edit Company' : 'Add Company'; ?> <a href="<?php echo esc_url( $back_url ); ?>" class="page-title-action">&larr; All Companies</a></h1>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sp-form">
                <?php wp_nonce_field( 'sp_save_company' ); ?>
                <input type="hidden" name="action" value="sp_save_company">
                <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
                <div class="sp-form-row"><label>Company Name</label><input type="text" name="name" value="<?php echo esc_attr( $company ? $company->name : '' ); ?>" required></div>
                <div class="sp-form-row"><label>Industry</label><input type="text" name="industry" value="<?php echo esc_attr( $company ? $company->industry : '' ); ?>"></div>
                <div class="sp-form-row"><label>Website</label><input type="url" name="website" value="<?php echo esc_attr( $company ? $company->website : '' ); ?>"></div>
                <div class="sp-form-row"><label>Phone</label><input type="text" name="phone" value="<?php echo esc_attr( $company ? $company->phone : '' ); ?>"></div>
                <div class="sp-form-row"><label>Address</label><textarea name="address" rows="3"><?php echo esc_textarea( $company ? $company->address : '' ); ?></textarea></div>
                <div class="sp-form-row"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $company ? $company->notes : '' ); ?></textarea></div>
                <div class="sp-form-actions">
                    <button type="submit" class="button button-primary">Save Company</button>
                    <a href="<?php echo esc_url( $back_url ); ?>" class="button">Cancel</a>
                </div>
            </form>
        </div>
        <?php
    }

    public function handle_save() {
        check_admin_referer( 'sp_save_company' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        global $wpdb;
        $id   = (int) ( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
        $data = array(
            'name'     => sanitize_text_field(     isset( $_POST['name'] )     ? $_POST['name']     : '' ),
            'industry' => sanitize_text_field(     isset( $_POST['industry'] ) ? $_POST['industry'] : '' ),
            'website'  => esc_url_raw(             isset( $_POST['website'] )  ? $_POST['website']  : '' ),
            'phone'    => sanitize_text_field(     isset( $_POST['phone'] )    ? $_POST['phone']    : '' ),
            'address'  => sanitize_textarea_field( isset( $_POST['address'] )  ? $_POST['address']  : '' ),
            'notes'    => sanitize_textarea_field( isset( $_POST['notes'] )    ? $_POST['notes']    : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_companies', $data, array( 'id' => $id ) );
            \SP\Core\ActivityLog::write( 'company', $id, 'updated' );
        } else {
            $wpdb->insert( $wpdb->prefix . 'sp_companies', $data );
            $id = $wpdb->insert_id;
            \SP\Core\ActivityLog::write( 'company', $id, 'created' );
        }
        wp_redirect( admin_url( 'admin.php?page=sp-companies&sp_action=edit&id=' . $id . '&saved=1' ) );
        exit;
    }

    public function handle_delete() {
        $id = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
        check_admin_referer( 'sp_delete_company_' . $id );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'sp_companies', array( 'deleted_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'company', $id, 'deleted' );
        wp_redirect( admin_url( 'admin.php?page=sp-companies' ) );
        exit;
    }
}
