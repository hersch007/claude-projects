<?php
namespace SP\Admin;
if ( ! defined( 'ABSPATH' ) ) exit;

class Navigation {
    private static $instance = null;
    private $items = array();

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function register_item( $item ) {
        $this->items[] = $item;
    }

    public function add_module_pages() {
        usort( $this->items, function( $a, $b ) {
            $pa = isset( $a['position'] ) ? $a['position'] : 50;
            $pb = isset( $b['position'] ) ? $b['position'] : 50;
            return $pa - $pb;
        } );
        foreach ( $this->items as $item ) {
            add_submenu_page(
                'start-performance',
                isset( $item['title'] )      ? $item['title']      : '',
                isset( $item['title'] )      ? $item['title']      : '',
                isset( $item['capability'] ) ? $item['capability'] : 'manage_options',
                isset( $item['slug'] )       ? $item['slug']       : '',
                isset( $item['callback'] )   ? $item['callback']   : '__return_false'
            );
        }
    }
}
