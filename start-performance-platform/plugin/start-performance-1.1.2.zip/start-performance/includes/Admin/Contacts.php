<?php
namespace SP\Admin;
if ( ! defined( 'ABSPATH' ) ) exit;

class Contacts {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'admin_post_sp_save_contact',   array( $this, 'handle_save' ) );
        add_action( 'admin_post_sp_delete_contact', array( $this, 'handle_delete' ) );
    }

    public function render_page() {
        $action = sanitize_key( isset( $_GET['sp_action'] ) ? $_GET['sp_action'] : 'list' );
        if ( $action === 'edit' || $action === 'new' ) {
            $this->render_form( $action );
        } else {
            $this->render_list();
        }
    }

    private function render_list() {
        global $wpdb;
        $search = sanitize_text_field( isset( $_GET['s'] ) ? $_GET['s'] : '' );
        $paged  = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
        $limit  = 25;
        $offset = ( $paged - 1 ) * $limit;

        $where = 'WHERE c.deleted_at IS NULL';
        $args  = array();
        if ( $search ) {
            $where .= ' AND (c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = array( $like, $like, $like );
        }

        $base_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts c $where";
        $total    = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $base_sql, $args ) ) : $wpdb->get_var( $base_sql ) );

        $list_sql = "SELECT c.*, co.name AS company_name FROM {$wpdb->prefix}sp_contacts c LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id $where ORDER BY c.created_at DESC LIMIT %d OFFSET %d";
        $list_args = array_merge( $args, array( $limit, $offset ) );
        $rows = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_args ) );

        $add_url = admin_url( 'admin.php?page=sp-contacts&sp_action=new' );
        ?>
        <div class="wrap sp-wrap">
            <div class="sp-page-header">
                <h1>Contacts <a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action">Add New</a></h1>
                <form method="get" class="sp-search-form">
                    <input type="hidden" name="page" value="sp-contacts">
                    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search contacts...">
                    <button type="submit" class="button">Search</button>
                </form>
            </div>
            <table class="widefat sp-table">
                <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Status</th><th>Created</th><th></th></tr></thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="7" class="sp-empty">No contacts found.</td></tr>
                <?php else : foreach ( $rows as $row ) :
                    $edit_url   = admin_url( 'admin.php?page=sp-contacts&sp_action=edit&id=' . $row->id );
                    $delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=sp_delete_contact&id=' . $row->id ), 'sp_delete_contact_' . $row->id ); ?>
                    <tr>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( trim( $row->first_name . ' ' . $row->last_name ) ); ?></a></td>
                        <td><?php echo esc_html( $row->email ); ?></td>
                        <td><?php echo esc_html( $row->phone ); ?></td>
                        <td><?php echo esc_html( isset( $row->company_name ) && $row->company_name ? $row->company_name : '—' ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
                        <td><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                        <td>
                            <a href="<?php echo esc_url( $edit_url ); ?>">Edit</a> |
                            <a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('Delete this contact?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <?php sp_pagination( $total, $limit, $paged, 'admin.php?page=sp-contacts' ); ?>
        </div>
        <?php
    }

    private function render_form( $action ) {
        global $wpdb;
        $id      = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
        $contact = null;
        $notice  = '';

        if ( $action === 'edit' && $id ) {
            $contact = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_contacts WHERE id = %d AND deleted_at IS NULL", $id
            ) );
            if ( ! $contact ) wp_die( 'Contact not found.' );
        }

        if ( isset( $_GET['saved'] ) ) {
            $notice = '<div class="notice notice-success is-dismissible"><p>Contact saved.</p></div>';
        }

        $companies = $wpdb->get_results( "SELECT id, name FROM {$wpdb->prefix}sp_companies WHERE deleted_at IS NULL ORDER BY name" );
        $back_url  = admin_url( 'admin.php?page=sp-contacts' );
        ?>
        <div class="wrap sp-wrap">
            <?php echo $notice; ?>
            <h1><?php echo $action === 'edit' ? 'Edit Contact' : 'Add Contact'; ?> <a href="<?php echo esc_url( $back_url ); ?>" class="page-title-action">&larr; All Contacts</a></h1>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sp-form">
                <?php wp_nonce_field( 'sp_save_contact' ); ?>
                <input type="hidden" name="action" value="sp_save_contact">
                <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
                <div class="sp-form-row"><label>First Name</label><input type="text" name="first_name" value="<?php echo esc_attr( $contact ? $contact->first_name : '' ); ?>" required></div>
                <div class="sp-form-row"><label>Last Name</label><input type="text" name="last_name" value="<?php echo esc_attr( $contact ? $contact->last_name : '' ); ?>"></div>
                <div class="sp-form-row"><label>Email</label><input type="email" name="email" value="<?php echo esc_attr( $contact ? $contact->email : '' ); ?>"></div>
                <div class="sp-form-row"><label>Phone</label><input type="text" name="phone" value="<?php echo esc_attr( $contact ? $contact->phone : '' ); ?>"></div>
                <div class="sp-form-row">
                    <label>Company</label>
                    <select name="company_id">
                        <option value="0">— None —</option>
                        <?php foreach ( $companies as $co ) : ?>
                            <option value="<?php echo esc_attr( $co->id ); ?>" <?php selected( $contact ? $contact->company_id : 0, $co->id ); ?>><?php echo esc_html( $co->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-form-row"><label>Source</label><input type="text" name="source" value="<?php echo esc_attr( $contact ? $contact->source : '' ); ?>" placeholder="e.g. website, referral"></div>
                <div class="sp-form-row">
                    <label>Status</label>
                    <select name="status">
                        <?php foreach ( array( 'active', 'inactive', 'archived' ) as $s ) : ?>
                            <option value="<?php echo esc_attr( $s ); ?>" <?php selected( $contact ? $contact->status : 'active', $s ); ?>><?php echo esc_html( ucfirst( $s ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-form-row"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $contact ? $contact->notes : '' ); ?></textarea></div>
                <div class="sp-form-actions">
                    <button type="submit" class="button button-primary">Save Contact</button>
                    <a href="<?php echo esc_url( $back_url ); ?>" class="button">Cancel</a>
                </div>
            </form>
        </div>
        <?php
    }

    public function handle_save() {
        check_admin_referer( 'sp_save_contact' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        global $wpdb;
        $id   = (int) ( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
        $data = array(
            'first_name' => sanitize_text_field(     isset( $_POST['first_name'] ) ? $_POST['first_name'] : '' ),
            'last_name'  => sanitize_text_field(     isset( $_POST['last_name'] )  ? $_POST['last_name']  : '' ),
            'email'      => sanitize_email(          isset( $_POST['email'] )      ? $_POST['email']      : '' ),
            'phone'      => sanitize_text_field(     isset( $_POST['phone'] )      ? $_POST['phone']      : '' ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field(     isset( $_POST['source'] )     ? $_POST['source']     : '' ),
            'status'     => sanitize_key(            isset( $_POST['status'] )     ? $_POST['status']     : 'active' ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )      ? $_POST['notes']      : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_contacts', $data, array( 'id' => $id ) );
            \SP\Core\ActivityLog::write( 'contact', $id, 'updated' );
        } else {
            $wpdb->insert( $wpdb->prefix . 'sp_contacts', $data );
            $id = $wpdb->insert_id;
            \SP\Core\ActivityLog::write( 'contact', $id, 'created' );
        }
        wp_redirect( admin_url( 'admin.php?page=sp-contacts&sp_action=edit&id=' . $id . '&saved=1' ) );
        exit;
    }

    public function handle_delete() {
        $id = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
        check_admin_referer( 'sp_delete_contact_' . $id );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'sp_contacts', array( 'deleted_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'contact', $id, 'deleted' );
        wp_redirect( admin_url( 'admin.php?page=sp-contacts' ) );
        exit;
    }
}
