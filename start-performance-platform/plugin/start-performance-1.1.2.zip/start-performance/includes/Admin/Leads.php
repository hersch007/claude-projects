<?php
namespace SP\Admin;
if ( ! defined( 'ABSPATH' ) ) exit;

class Leads {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'admin_post_sp_save_lead',   array( $this, 'handle_save' ) );
        add_action( 'admin_post_sp_delete_lead', array( $this, 'handle_delete' ) );
    }

    public function render_page() {
        $action = sanitize_key( isset( $_GET['sp_action'] ) ? $_GET['sp_action'] : 'list' );
        if ( $action === 'edit' || $action === 'new' ) {
            $this->render_form( $action );
        } else {
            $this->render_list();
        }
    }

    private function render_list() {
        global $wpdb;
        $search        = sanitize_text_field( isset( $_GET['s'] )      ? $_GET['s']      : '' );
        $status_filter = sanitize_key(        isset( $_GET['status'] ) ? $_GET['status'] : '' );
        $paged         = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
        $limit         = 25;
        $offset        = ( $paged - 1 ) * $limit;

        $where = 'WHERE l.deleted_at IS NULL';
        $args  = array();
        if ( $status_filter ) {
            $where .= ' AND l.status = %s';
            $args[] = $status_filter;
        }
        if ( $search ) {
            $where .= ' AND (c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = array_merge( $args, array( $like, $like, $like ) );
        }

        $count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads l LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id $where";
        $total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) );

        $list_sql  = "SELECT l.*, c.first_name, c.last_name, c.email, co.name AS company_name FROM {$wpdb->prefix}sp_leads l LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = l.company_id $where ORDER BY l.created_at DESC LIMIT %d OFFSET %d";
        $list_args = array_merge( $args, array( $limit, $offset ) );
        $rows      = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_args ) );

        $add_url  = admin_url( 'admin.php?page=sp-leads&sp_action=new' );
        $statuses = array( '', 'new', 'contacted', 'qualified', 'unqualified', 'closed' );
        ?>
        <div class="wrap sp-wrap">
            <div class="sp-page-header">
                <h1>Leads <a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action">Add New</a></h1>
                <form method="get" class="sp-search-form">
                    <input type="hidden" name="page" value="sp-leads">
                    <select name="status">
                        <?php foreach ( $statuses as $s ) : ?>
                            <option value="<?php echo esc_attr( $s ); ?>" <?php selected( $status_filter, $s ); ?>><?php echo $s ? esc_html( ucfirst( $s ) ) : 'All Statuses'; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search by contact...">
                    <button type="submit" class="button">Filter</button>
                </form>
            </div>
            <table class="widefat sp-table">
                <thead><tr><th>Contact</th><th>Company</th><th>Source</th><th>Status</th><th>Score</th><th>Created</th><th></th></tr></thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="7" class="sp-empty">No leads found.</td></tr>
                <?php else : foreach ( $rows as $row ) :
                    $name       = trim( $row->first_name . ' ' . $row->last_name );
                    $name       = $name ? $name : ( $row->email ? $row->email : '(no contact)' );
                    $edit_url   = admin_url( 'admin.php?page=sp-leads&sp_action=edit&id=' . $row->id );
                    $delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=sp_delete_lead&id=' . $row->id ), 'sp_delete_lead_' . $row->id ); ?>
                    <tr>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $name ); ?></a></td>
                        <td><?php echo esc_html( $row->company_name ? $row->company_name : '—' ); ?></td>
                        <td><?php echo esc_html( $row->source ? $row->source : '—' ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
                        <td><?php echo esc_html( $row->score ); ?></td>
                        <td><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                        <td><a href="<?php echo esc_url( $edit_url ); ?>">Edit</a> | <a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('Delete this lead?')">Delete</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <?php sp_pagination( $total, $limit, $paged, 'admin.php?page=sp-leads' ); ?>
        </div>
        <?php
    }

    private function render_form( $action ) {
        global $wpdb;
        $id     = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
        $lead   = null;
        $notice = '';

        if ( $action === 'edit' && $id ) {
            $lead = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_leads WHERE id = %d AND deleted_at IS NULL", $id
            ) );
            if ( ! $lead ) wp_die( 'Lead not found.' );
        }

        if ( isset( $_GET['saved'] ) ) {
            $notice = '<div class="notice notice-success is-dismissible"><p>Lead saved.</p></div>';
        }

        $contacts  = $wpdb->get_results( "SELECT id, first_name, last_name, email FROM {$wpdb->prefix}sp_contacts WHERE deleted_at IS NULL ORDER BY first_name, last_name" );
        $companies = $wpdb->get_results( "SELECT id, name FROM {$wpdb->prefix}sp_companies WHERE deleted_at IS NULL ORDER BY name" );
        $back_url  = admin_url( 'admin.php?page=sp-leads' );
        ?>
        <div class="wrap sp-wrap">
            <?php echo $notice; ?>
            <h1><?php echo $action === 'edit' ? 'Edit Lead' : 'Add Lead'; ?> <a href="<?php echo esc_url( $back_url ); ?>" class="page-title-action">&larr; All Leads</a></h1>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sp-form">
                <?php wp_nonce_field( 'sp_save_lead' ); ?>
                <input type="hidden" name="action" value="sp_save_lead">
                <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
                <div class="sp-form-row">
                    <label>Contact</label>
                    <select name="contact_id">
                        <option value="0">— Select Contact —</option>
                        <?php foreach ( $contacts as $c ) :
                            $label = trim( $c->first_name . ' ' . $c->last_name );
                            $label = $label ? $label : $c->email; ?>
                            <option value="<?php echo esc_attr( $c->id ); ?>" <?php selected( $lead ? $lead->contact_id : 0, $c->id ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-form-row">
                    <label>Company</label>
                    <select name="company_id">
                        <option value="0">— None —</option>
                        <?php foreach ( $companies as $co ) : ?>
                            <option value="<?php echo esc_attr( $co->id ); ?>" <?php selected( $lead ? $lead->company_id : 0, $co->id ); ?>><?php echo esc_html( $co->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-form-row"><label>Source</label><input type="text" name="source" value="<?php echo esc_attr( $lead ? $lead->source : '' ); ?>" placeholder="e.g. website, chat, referral"></div>
                <div class="sp-form-row">
                    <label>Status</label>
                    <select name="status">
                        <?php foreach ( array( 'new', 'contacted', 'qualified', 'unqualified', 'closed' ) as $s ) : ?>
                            <option value="<?php echo esc_attr( $s ); ?>" <?php selected( $lead ? $lead->status : 'new', $s ); ?>><?php echo esc_html( ucfirst( $s ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-form-row"><label>Score (0-100)</label><input type="number" name="score" min="0" max="100" value="<?php echo esc_attr( $lead ? $lead->score : 0 ); ?>"></div>
                <div class="sp-form-row"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $lead ? $lead->notes : '' ); ?></textarea></div>
                <div class="sp-form-actions">
                    <button type="submit" class="button button-primary">Save Lead</button>
                    <a href="<?php echo esc_url( $back_url ); ?>" class="button">Cancel</a>
                </div>
            </form>
        </div>
        <?php
    }

    public function handle_save() {
        check_admin_referer( 'sp_save_lead' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        global $wpdb;
        $id   = (int) ( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
        $data = array(
            'contact_id' => (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field(     isset( $_POST['source'] ) ? $_POST['source'] : '' ),
            'status'     => sanitize_key(            isset( $_POST['status'] ) ? $_POST['status'] : 'new' ),
            'score'      => min( 100, max( 0, (int) ( isset( $_POST['score'] ) ? $_POST['score'] : 0 ) ) ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']  : '' ),
            'owner_id'   => get_current_user_id(),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_leads', $data, array( 'id' => $id ) );
            \SP\Core\ActivityLog::write( 'lead', $id, 'updated' );
        } else {
            $wpdb->insert( $wpdb->prefix . 'sp_leads', $data );
            $id = $wpdb->insert_id;
            \SP\Core\ActivityLog::write( 'lead', $id, 'created' );
        }
        wp_redirect( admin_url( 'admin.php?page=sp-leads&sp_action=edit&id=' . $id . '&saved=1' ) );
        exit;
    }

    public function handle_delete() {
        $id = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
        check_admin_referer( 'sp_delete_lead_' . $id );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'sp_leads', array( 'deleted_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
        \SP\Core\ActivityLog::write( 'lead', $id, 'deleted' );
        wp_redirect( admin_url( 'admin.php?page=sp-leads' ) );
        exit;
    }
}
