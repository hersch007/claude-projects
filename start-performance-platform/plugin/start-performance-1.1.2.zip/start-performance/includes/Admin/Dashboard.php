<?php
namespace SP\Admin;
if ( ! defined( 'ABSPATH' ) ) exit;

class Dashboard {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'admin_menu',            array( $this, 'register_menus' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    public function register_menus() {
        add_menu_page(
            'Start Performance', 'Start Performance', 'manage_options',
            'start-performance', array( $this, 'render_dashboard' ),
            SP_PLUGIN_URL . 'assets/images/sp-icon.svg', 3
        );
        add_submenu_page( 'start-performance', 'Dashboard',    'Dashboard',    'manage_options', 'start-performance',   array( $this,                    'render_dashboard' ) );
        add_submenu_page( 'start-performance', 'Contacts',     'Contacts',     'manage_options', 'sp-contacts',         array( Contacts::instance(),     'render_page' ) );
        add_submenu_page( 'start-performance', 'Companies',    'Companies',    'manage_options', 'sp-companies',        array( Companies::instance(),    'render_page' ) );
        add_submenu_page( 'start-performance', 'Leads',        'Leads',        'manage_options', 'sp-leads',            array( Leads::instance(),        'render_page' ) );
        add_submenu_page( 'start-performance', 'Activity Log', 'Activity Log', 'manage_options', 'sp-activity-log',     array( ActivityLog::instance(),  'render_page' ) );
        add_submenu_page( 'start-performance', 'Settings',     'Settings',     'manage_options', 'sp-settings',         array( Settings::instance(),     'render_page' ) );
        Navigation::instance()->add_module_pages();
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'start-performance' ) === false && strpos( $hook, 'sp-' ) === false ) return;
        wp_enqueue_style(  'sp-admin', SP_PLUGIN_URL . 'assets/css/admin.css', array(), SP_VERSION );
        wp_enqueue_script( 'sp-admin', SP_PLUGIN_URL . 'assets/js/admin.js',  array( 'jquery' ), SP_VERSION, true );
    }

    public function render_dashboard() {
        global $wpdb;
        $contact_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts WHERE deleted_at IS NULL" );
        $company_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies WHERE deleted_at IS NULL" );
        $lead_count    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE deleted_at IS NULL" );
        $modules       = \SP\Core\ModuleRegistry::instance()->all();
        ?>
        <div class="wrap sp-wrap">
            <div class="sp-header">
                <h1 class="sp-platform-title">Start Performance</h1>
                <span class="sp-version">v<?php echo esc_html( SP_VERSION ); ?></span>
            </div>
            <div class="sp-stat-row">
                <div class="sp-stat-card"><div class="sp-stat-number"><?php echo esc_html( number_format( $contact_count ) ); ?></div><div class="sp-stat-label">Contacts</div></div>
                <div class="sp-stat-card"><div class="sp-stat-number"><?php echo esc_html( number_format( $company_count ) ); ?></div><div class="sp-stat-label">Companies</div></div>
                <div class="sp-stat-card"><div class="sp-stat-number"><?php echo esc_html( number_format( $lead_count ) ); ?></div><div class="sp-stat-label">Leads</div></div>
                <div class="sp-stat-card"><div class="sp-stat-number"><?php echo esc_html( count( $modules ) ); ?></div><div class="sp-stat-label">Active Modules</div></div>
            </div>
            <div class="sp-section-title">Active Modules</div>
            <?php if ( empty( $modules ) ) : ?>
                <p class="sp-muted">No additional modules installed. Core System is active.</p>
            <?php else : ?>
                <table class="widefat sp-table">
                    <thead><tr><th>Module</th><th>Slug</th><th>Version</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ( $modules as $slug => $mod ) : ?>
                        <tr>
                            <td><?php echo esc_html( isset( $mod['name'] ) ? $mod['name'] : $slug ); ?></td>
                            <td><code><?php echo esc_html( $slug ); ?></code></td>
                            <td><?php echo esc_html( isset( $mod['version'] ) ? $mod['version'] : '—' ); ?></td>
                            <td><span class="sp-badge sp-badge-active">Active</span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }
}
