<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class Installer {

    public static function activate() {
        self::create_tables();
        update_option( 'sp_version', SP_VERSION );
        AppShell::instance()->add_rewrite_rules();
        flush_rewrite_rules();
        do_action( 'sp_activated' );
    }

    public static function deactivate() {
        flush_rewrite_rules();
        do_action( 'sp_deactivated' );
    }

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta( "CREATE TABLE {$wpdb->prefix}sp_contacts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            first_name VARCHAR(100) NOT NULL DEFAULT '',
            last_name VARCHAR(100) NOT NULL DEFAULT '',
            email VARCHAR(200) NOT NULL DEFAULT '',
            phone VARCHAR(50) NOT NULL DEFAULT '',
            company_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            source VARCHAR(100) NOT NULL DEFAULT '',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            notes TEXT,
            deleted_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY email (email(191)),
            KEY company_id (company_id),
            KEY status (status)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}sp_companies (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL DEFAULT '',
            industry VARCHAR(100) NOT NULL DEFAULT '',
            website VARCHAR(255) NOT NULL DEFAULT '',
            phone VARCHAR(50) NOT NULL DEFAULT '',
            address TEXT,
            notes TEXT,
            deleted_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY name (name(191))
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}sp_leads (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            company_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            source VARCHAR(100) NOT NULL DEFAULT '',
            status VARCHAR(50) NOT NULL DEFAULT 'new',
            score TINYINT UNSIGNED DEFAULT 0,
            owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            notes TEXT,
            deleted_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY contact_id (contact_id),
            KEY status (status)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}sp_activity_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            object_type VARCHAR(50) NOT NULL DEFAULT '',
            object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            action VARCHAR(100) NOT NULL DEFAULT '',
            details LONGTEXT,
            ip_address VARCHAR(45) DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY object (object_type, object_id),
            KEY user_id (user_id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}sp_settings (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            module VARCHAR(100) NOT NULL DEFAULT 'core',
            setting_key VARCHAR(200) NOT NULL DEFAULT '',
            setting_value LONGTEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY module_key (module, setting_key(191))
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}sp_modules (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(100) NOT NULL DEFAULT '',
            name VARCHAR(200) NOT NULL DEFAULT '',
            version VARCHAR(20) NOT NULL DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            activated_at DATETIME DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $charset;" );
    }
}
