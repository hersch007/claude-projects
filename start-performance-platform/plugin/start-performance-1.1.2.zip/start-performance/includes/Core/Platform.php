<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class Platform {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function boot() {
        ModuleRegistry::instance();
        Auth::instance()->init();
        AppShell::instance()->init();
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
        if ( is_admin() ) {
            Admin\Dashboard::instance()->init();
            Admin\Contacts::instance()->init();
            Admin\Companies::instance()->init();
            Admin\Leads::instance()->init();
            Admin\ActivityLog::instance()->init();
            Admin\Settings::instance()->init();
        }
        do_action( 'sp_platform_booted' );
    }

    public function register_rest_routes() {
        \SP\REST\Router::register();
    }
}
