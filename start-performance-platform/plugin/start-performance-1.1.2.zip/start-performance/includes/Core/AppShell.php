<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class AppShell {
    const LOGIN_SLUG = 'sp-login';
    const APP_SLUG   = 'sp-app';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'init',              array( $this, 'add_rewrite_rules' ) );
        add_action( 'template_redirect', array( $this, 'intercept_request' ), 1 );
        add_action( 'init',              array( $this, 'block_wp_admin' ) );
        add_filter( 'login_url',         array( $this, 'filter_login_url' ), 10, 3 );
        add_filter( 'logout_url',        array( $this, 'filter_logout_url' ) );
        add_filter( 'show_admin_bar',    '__return_false' );
    }

    public function add_rewrite_rules() {
        add_rewrite_rule( '^' . self::LOGIN_SLUG . '/?$', 'index.php?sp_page=login', 'top' );
        add_rewrite_rule( '^' . self::APP_SLUG   . '/?$', 'index.php?sp_page=app',   'top' );
        add_rewrite_tag( '%sp_page%', '([^&]+)' );
    }

    public function intercept_request() {
        $sp_page = get_query_var( 'sp_page' );
        if ( $sp_page === 'login' ) {
            require_once SP_PLUGIN_DIR . 'templates/login.php';
            exit;
        }
        if ( $sp_page === 'app' ) {
            if ( ! is_user_logged_in() ) {
                wp_redirect( self::login_url() );
                exit;
            }
            require_once SP_PLUGIN_DIR . 'templates/app.php';
            exit;
        }
    }

    public function block_wp_admin() {
        if ( ! is_admin() ) return;
        if ( wp_doing_ajax() ) return;
        if ( defined( 'DOING_CRON' ) && DOING_CRON ) return;
        if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) return;
        if ( is_user_logged_in() ) {
            wp_redirect( self::app_url() );
            exit;
        }
        wp_redirect( self::login_url() );
        exit;
    }

    public function filter_login_url( $login_url, $redirect, $force_reauth ) {
        $url = self::login_url();
        if ( $redirect ) $url = add_query_arg( 'redirect_to', urlencode( $redirect ), $url );
        return $url;
    }

    public function filter_logout_url( $logout_url ) {
        return self::login_url() . '?sp_logout=1';
    }

    public static function app_url() {
        return home_url( '/' . self::APP_SLUG . '/' );
    }

    public static function login_url() {
        return home_url( '/' . self::LOGIN_SLUG . '/' );
    }
}
