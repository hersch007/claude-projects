<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class ActivityLog {
    public static function write( $object_type, $object_id, $action, $details = array() ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sp_activity_log', array(
            'user_id'     => get_current_user_id(),
            'object_type' => sanitize_key( $object_type ),
            'object_id'   => (int) $object_id,
            'action'      => sanitize_key( $action ),
            'details'     => ! empty( $details ) ? wp_json_encode( $details ) : null,
            'ip_address'  => self::get_ip(),
            'created_at'  => current_time( 'mysql' ),
        ), array( '%d', '%s', '%d', '%s', '%s', '%s', '%s' ) );
    }

    private static function get_ip() {
        foreach ( array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $parts = explode( ',', $_SERVER[ $key ] );
                return sanitize_text_field( $parts[0] );
            }
        }
        return '';
    }
}
