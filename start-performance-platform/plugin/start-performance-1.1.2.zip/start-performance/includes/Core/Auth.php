<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class Auth {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'init', array( $this, 'handle_login_post' ) );
        add_action( 'init', array( $this, 'handle_logout' ) );
    }

    public function handle_login_post() {
        if ( $_SERVER['REQUEST_METHOD'] !== 'POST' || empty( $_POST['sp_login_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['sp_login_nonce'], 'sp_login' ) ) {
            wp_redirect( AppShell::login_url() . '?error=invalid' );
            exit;
        }
        $credentials = array(
            'user_login'    => sanitize_user( isset( $_POST['log'] ) ? $_POST['log'] : '' ),
            'user_password' => isset( $_POST['pwd'] ) ? $_POST['pwd'] : '',
            'remember'      => ! empty( $_POST['rememberme'] ),
        );
        $user = wp_signon( $credentials, is_ssl() );
        if ( is_wp_error( $user ) ) {
            wp_redirect( AppShell::login_url() . '?error=credentials' );
            exit;
        }
        $redirect = isset( $_POST['redirect_to'] ) ? esc_url_raw( $_POST['redirect_to'] ) : '';
        wp_redirect( $redirect ? $redirect : AppShell::app_url() );
        exit;
    }

    public function handle_logout() {
        if ( empty( $_GET['sp_logout'] ) ) return;
        wp_logout();
        wp_redirect( AppShell::login_url() );
        exit;
    }
}
