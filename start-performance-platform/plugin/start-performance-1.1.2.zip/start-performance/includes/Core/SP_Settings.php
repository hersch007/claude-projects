<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class SP_Settings {
    private static $cache = array();

    public static function get( $module, $key, $default = '' ) {
        if ( ! isset( self::$cache[ $module ] ) ) {
            self::load( $module );
        }
        return isset( self::$cache[ $module ][ $key ] ) ? self::$cache[ $module ][ $key ] : $default;
    }

    public static function set( $module, $key, $value ) {
        global $wpdb;
        $wpdb->replace( $wpdb->prefix . 'sp_settings', array(
            'module'        => sanitize_key( $module ),
            'setting_key'   => sanitize_key( $key ),
            'setting_value' => $value,
        ), array( '%s', '%s', '%s' ) );
        self::$cache[ $module ][ $key ] = $value;
    }

    private static function load( $module ) {
        global $wpdb;
        self::$cache[ $module ] = array();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT setting_key, setting_value FROM {$wpdb->prefix}sp_settings WHERE module = %s",
            $module
        ), ARRAY_A );
        if ( $rows ) {
            foreach ( $rows as $row ) {
                self::$cache[ $module ][ $row['setting_key'] ] = $row['setting_value'];
            }
        }
    }
}
