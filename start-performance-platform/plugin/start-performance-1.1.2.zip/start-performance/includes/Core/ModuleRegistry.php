<?php
namespace SP\Core;
if ( ! defined( 'ABSPATH' ) ) exit;

class ModuleRegistry {
    private static $instance = null;
    private $registered = array();

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->load_from_db();
    }

    public function register( $module ) {
        $slug = sanitize_key( isset( $module['slug'] ) ? $module['slug'] : '' );
        if ( ! $slug ) return false;
        foreach ( ( isset( $module['requires'] ) ? $module['requires'] : array() ) as $dep ) {
            if ( ! $this->is_active( $dep ) ) {
                $name = isset( $module['name'] ) ? $module['name'] : $slug;
                add_action( 'admin_notices', function() use ( $name, $dep ) {
                    echo '<div class="notice notice-error"><p><strong>' . esc_html( $name ) . '</strong> requires <strong>' . esc_html( $dep ) . '</strong> to be active.</p></div>';
                } );
                return false;
            }
        }
        $this->registered[ $slug ] = $module;
        $this->persist( $slug, $module );
        if ( ! empty( $module['nav_items'] ) ) {
            foreach ( $module['nav_items'] as $item ) {
                \SP\Admin\Navigation::instance()->register_item( $item );
            }
        }
        do_action( 'sp_module_registered', $slug, $module );
        return true;
    }

    public function is_active( $slug ) {
        return isset( $this->registered[ $slug ] );
    }

    public function all() {
        return $this->registered;
    }

    private function load_from_db() {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT slug, name, version, status FROM {$wpdb->prefix}sp_modules WHERE status = 'active'", ARRAY_A );
        if ( $rows ) {
            foreach ( $rows as $row ) {
                $this->registered[ $row['slug'] ] = $row;
            }
        }
    }

    private function persist( $slug, $module ) {
        global $wpdb;
        $wpdb->replace( $wpdb->prefix . 'sp_modules', array(
            'slug'         => $slug,
            'name'         => isset( $module['name'] )    ? $module['name']    : $slug,
            'version'      => isset( $module['version'] ) ? $module['version'] : '1.0.0',
            'status'       => 'active',
            'activated_at' => current_time( 'mysql' ),
        ), array( '%s', '%s', '%s', '%s', '%s' ) );
    }
}
