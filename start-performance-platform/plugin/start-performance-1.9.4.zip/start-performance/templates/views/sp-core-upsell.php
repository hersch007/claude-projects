<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$core_id = sanitize_key( isset( $_GET['core'] ) ? $_GET['core'] : '' );
$slots   = function_exists( 'sp_get_core_slots' ) ? sp_get_core_slots() : array();
$slot    = isset( $slots[ $core_id ] ) ? $slots[ $core_id ] : null;

if ( ! $slot ) {
    echo '<p class="sp-empty">Module not found.</p>';
    return;
}
?>
<div class="sp-page-header">
    <h1><?php echo esc_html( $slot['label'] ); ?></h1>
    <span class="sp-badge" style="background:#fef3c7;color:#92400e;font-size:12px;padding:3px 10px">Not Activated</span>
</div>

<div class="sp-card sp-form-card" style="max-width:600px">

    <div style="display:flex;align-items:flex-start;gap:16px;margin-bottom:24px">
        <div style="width:52px;height:52px;border-radius:12px;background:var(--sp-accent-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" width="26" height="26" style="color:var(--sp-accent)">
                <?php echo $slot['icon']; ?>
            </svg>
        </div>
        <div>
            <h2 style="margin:0 0 6px;font-size:18px;font-weight:700"><?php echo esc_html( $slot['label'] ); ?></h2>
            <p style="margin:0;color:#64748b;font-size:14px;line-height:1.5"><?php echo esc_html( $slot['description'] ); ?></p>
        </div>
    </div>

    <?php if ( ! empty( $slot['features'] ) ) : ?>
    <h3 style="font-size:12px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.06em;margin:0 0 12px">What's Included</h3>
    <ul style="list-style:none;padding:0;margin:0 0 24px;display:flex;flex-direction:column;gap:10px">
        <?php foreach ( $slot['features'] as $feature ) : ?>
        <li style="display:flex;align-items:center;gap:10px;font-size:14px;color:#1e293b">
            <span style="display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;background:var(--sp-accent-bg);flex-shrink:0">
                <svg viewBox="0 0 24 24" fill="none" stroke="var(--sp-accent)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" width="11" height="11"><path d="M5 13l4 4L19 7"/></svg>
            </span>
            <?php echo esc_html( $feature ); ?>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>

    <div style="padding:18px 20px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0">
        <p style="margin:0 0 14px;font-size:14px;color:#475569;line-height:1.5">
            This module is not currently activated on your platform.
            Contact your Start Performance representative to add it to your plan.
        </p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a href="mailto:sales@startperformance.com" class="sp-btn sp-btn-primary">Contact Sales</a>
            <?php if ( ! empty( $slot['learn_more'] ) ) : ?>
                <a href="<?php echo esc_url( $slot['learn_more'] ); ?>" class="sp-btn sp-btn-ghost" target="_blank">Learn More &rarr;</a>
            <?php endif; ?>
        </div>
    </div>

</div>
