<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$member    = sp_get_current_team_member();
$member_id = $member ? (int) $member->id : 0;
$today     = date( 'Y-m-d' );
$now       = current_time( 'mysql' );
$is_admin  = sp_is_admin_member();

// ── Stat counts ────────────────────────────────────────────────────────────────
$contacts  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts" );
$companies = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies" );
$leads     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads" );

// Overdue tasks (assigned to me)
$overdue_count = $member_id ? (int) $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tasks WHERE assigned_to=%d AND status='open' AND due_date IS NOT NULL AND due_date < %s",
    $member_id, $today
) ) : 0;

// Open tasks due today or overdue
$due_tasks = $member_id ? $wpdb->get_results( $wpdb->prepare(
    "SELECT tk.*, COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, l2.id, '' ) AS record_name,
     tk.record_type AS rtype, tk.record_id AS rid
     FROM {$wpdb->prefix}sp_tasks tk
     LEFT JOIN {$wpdb->prefix}sp_contacts c  ON tk.record_type='contact'  AND tk.record_id=c.id
     LEFT JOIN {$wpdb->prefix}sp_companies co ON tk.record_type='company'  AND tk.record_id=co.id
     LEFT JOIN {$wpdb->prefix}sp_leads l2     ON tk.record_type='lead'     AND tk.record_id=l2.id
     WHERE tk.assigned_to=%d AND tk.status='open' AND tk.due_date IS NOT NULL AND tk.due_date<=%s
     ORDER BY tk.due_date ASC LIMIT 10",
    $member_id, $today
) ) : array();

// Note reminders
$due_notes = $member_id ? $wpdb->get_results( $wpdb->prepare(
    "SELECT n.*, COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name
     FROM {$wpdb->prefix}sp_notes n
     LEFT JOIN {$wpdb->prefix}sp_contacts c  ON n.record_type='contact' AND n.record_id=c.id
     LEFT JOIN {$wpdb->prefix}sp_companies co ON n.record_type='company' AND n.record_id=co.id
     WHERE n.created_by=%d AND n.reminder_at IS NOT NULL AND n.reminder_at<=%s AND n.reminder_sent=0
     ORDER BY n.reminder_at ASC LIMIT 5",
    $member_id, $now
) ) : array();

// ── Pipeline funnel ────────────────────────────────────────────────────────────
$pipeline_data = $wpdb->get_results(
    "SELECT status, COUNT(*) AS cnt FROM {$wpdb->prefix}sp_leads GROUP BY status"
);
$pipeline_map = array( 'new' => 0, 'contacted' => 0, 'qualified' => 0, 'unqualified' => 0, 'closed' => 0 );
foreach ( $pipeline_data as $row ) {
    if ( isset( $pipeline_map[ $row->status ] ) ) $pipeline_map[ $row->status ] = (int) $row->cnt;
}
$pipeline_max = max( array_values( $pipeline_map ) ) ?: 1;
$pipeline_colors = array(
    'new'         => '#3b82f6',
    'contacted'   => '#f59e0b',
    'qualified'   => '#8b5cf6',
    'unqualified' => '#ef4444',
    'closed'      => '#10b981',
);

// ── Recent activity feed ───────────────────────────────────────────────────────
$recent_activity = $wpdb->get_results(
    "SELECT a.*, t.name AS actor,
     COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name
     FROM {$wpdb->prefix}sp_activity a
     LEFT JOIN {$wpdb->prefix}sp_team t ON t.id = a.created_by
     LEFT JOIN {$wpdb->prefix}sp_contacts c  ON a.record_type='contact' AND a.record_id=c.id
     LEFT JOIN {$wpdb->prefix}sp_companies co ON a.record_type='company' AND a.record_id=co.id
     ORDER BY a.created_at DESC LIMIT 12"
);

// ── Recent contacts ────────────────────────────────────────────────────────────
$recent_contacts = $wpdb->get_results(
    "SELECT * FROM {$wpdb->prefix}sp_contacts ORDER BY created_at DESC LIMIT 5"
);

// ── Activity this week (admin only) ───────────────────────────────────────────
$week_start  = date( 'Y-m-d', strtotime( 'monday this week' ) );
$week_counts = $is_admin ? $wpdb->get_results( $wpdb->prepare(
    "SELECT t.name, COUNT(*) AS total
     FROM {$wpdb->prefix}sp_activity a
     LEFT JOIN {$wpdb->prefix}sp_team t ON t.id = a.created_by
     WHERE a.created_at >= %s AND a.created_by > 0
     GROUP BY a.created_by ORDER BY total DESC LIMIT 5",
    $week_start . ' 00:00:00'
) ) : array();

$action_labels = array(
    'created'       => 'created',
    'updated'       => 'updated',
    'deleted'       => 'deleted',
    'status_change' => 'changed status on',
    'note_added'    => 'added a note to',
    'task_added'    => 'added a task to',
    'task_done'     => 'completed a task on',
    'file_uploaded' => 'uploaded a file to',
);
?>

<div class="sp-page-header">
    <h1>Dashboard</h1>
    <div class="sp-header-actions">
        <span class="sp-date"><?php echo date( 'l, F j, Y' ); ?></span>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=new' ) ); ?>" class="sp-btn sp-btn-ghost sp-btn-sm">+ Contact</a>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&action=new' ) ); ?>" class="sp-btn sp-btn-primary sp-btn-sm">+ Lead</a>
    </div>
</div>

<!-- ── Stat row ──────────────────────────────────────────────────────────────── -->
<div class="sp-stats" style="margin-bottom:20px">
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts' ) ); ?>" class="sp-stat-card sp-stat-contacts sp-stat-link">
        <div class="sp-stat-value"><?php echo number_format( $contacts ); ?></div>
        <div class="sp-stat-label">Contacts</div>
    </a>
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=companies' ) ); ?>" class="sp-stat-card sp-stat-companies sp-stat-link">
        <div class="sp-stat-value"><?php echo number_format( $companies ); ?></div>
        <div class="sp-stat-label">Companies</div>
    </a>
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads' ) ); ?>" class="sp-stat-card sp-stat-leads sp-stat-link">
        <div class="sp-stat-value"><?php echo number_format( $leads ); ?></div>
        <div class="sp-stat-label">Total Leads</div>
    </a>
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&leads_tab=pipeline' ) ); ?>" class="sp-stat-card sp-stat-link" style="border-top-color:<?php echo $overdue_count ? '#ef4444' : '#94a3b8'; ?>">
        <div class="sp-stat-value" style="color:<?php echo $overdue_count ? '#ef4444' : '#1e293b'; ?>"><?php echo number_format( $overdue_count ); ?></div>
        <div class="sp-stat-label">Overdue Tasks</div>
    </a>
</div>

<?php do_action( 'sp_dashboard_after_stats' ); ?>

<!-- ── Reminders ─────────────────────────────────────────────────────────────── -->
<?php if ( ! empty( $due_tasks ) || ! empty( $due_notes ) ) : ?>
<div class="sp-card sp-reminders-card" style="margin-bottom:20px">
    <div class="sp-card-header">
        <h2>Your Reminders</h2>
        <span class="sp-count"><?php echo count($due_tasks) + count($due_notes); ?></span>
    </div>
    <?php foreach ( $due_tasks as $tk ) :
        $overdue = $tk->due_date < $today;
        $rtype   = rtrim( $tk->rtype, 's' );
        $link    = home_url( '/sp-app/?view=' . $rtype . 's&action=view&id=' . $tk->rid . '&tab=tasks' );
    ?>
    <div class="sp-reminder-item">
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" style="display:contents">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="task">
            <input type="hidden" name="sp_id" value="0">
            <input type="hidden" name="record_type" value="<?php echo esc_attr($tk->rtype); ?>">
            <input type="hidden" name="record_id" value="<?php echo esc_attr($tk->rid); ?>">
            <input type="hidden" name="task_id" value="<?php echo esc_attr($tk->id); ?>">
            <button type="submit" class="sp-task-check sp-reminder-check" title="Mark done"></button>
        </form>
        <div class="sp-reminder-body">
            <a href="<?php echo esc_url($link); ?>" class="sp-reminder-title"><?php echo esc_html($tk->title); ?></a>
            <?php if ( trim($tk->record_name) ) : ?><span class="sp-reminder-record"><?php echo esc_html( trim($tk->record_name) ); ?></span><?php endif; ?>
        </div>
        <span class="sp-reminder-due <?php echo $overdue ? 'sp-overdue' : ''; ?>">
            <?php echo $overdue ? 'Overdue · ' . esc_html( date('M j', strtotime($tk->due_date)) ) : 'Today'; ?>
        </span>
    </div>
    <?php endforeach; ?>
    <?php foreach ( $due_notes as $n ) :
        $link = home_url( '/sp-app/?view=' . $n->record_type . 's&action=view&id=' . $n->record_id . '&tab=notes' );
    ?>
    <div class="sp-reminder-item">
        <div class="sp-reminder-note-icon">📝</div>
        <div class="sp-reminder-body">
            <a href="<?php echo esc_url($link); ?>" class="sp-reminder-title"><?php echo esc_html( substr($n->content,0,80).(strlen($n->content)>80?'…':'') ); ?></a>
            <?php if ( trim($n->record_name) ) : ?><span class="sp-reminder-record"><?php echo esc_html( trim($n->record_name) ); ?></span><?php endif; ?>
        </div>
        <span class="sp-reminder-due"><?php echo esc_html( date('M j g:ia', strtotime($n->reminder_at)) ); ?></span>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ── Main grid ──────────────────────────────────────────────────────────────── -->
<div class="sp-dash-grid">

    <!-- Pipeline funnel -->
    <div class="sp-card sp-dash-funnel">
        <div class="sp-card-header">
            <h2>Pipeline</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&leads_tab=pipeline' ) ); ?>" class="sp-btn sp-btn-ghost sp-btn-sm">View Board</a>
        </div>
        <div style="padding:16px 20px">
        <?php foreach ( $pipeline_map as $status => $cnt ) :
            $pct   = round( $cnt / $pipeline_max * 100 );
            $color = $pipeline_colors[ $status ];
        ?>
        <div class="sp-funnel-row">
            <span class="sp-funnel-label"><?php echo esc_html( ucfirst($status) ); ?></span>
            <div class="sp-funnel-track">
                <div class="sp-funnel-bar" style="width:<?php echo max(4,$pct); ?>%;background:<?php echo esc_attr($color); ?>"></div>
            </div>
            <span class="sp-funnel-count"><?php echo $cnt; ?></span>
        </div>
        <?php endforeach; ?>
        </div>
    </div>

    <!-- Recent activity feed -->
    <div class="sp-card sp-dash-activity">
        <div class="sp-card-header">
            <h2>Recent Activity</h2>
        </div>
        <?php if ( empty( $recent_activity ) ) : ?>
            <p class="sp-empty">No activity yet.</p>
        <?php else : ?>
        <div class="sp-activity-feed">
            <?php foreach ( $recent_activity as $evt ) :
                $verb      = isset( $action_labels[ $evt->action ] ) ? $action_labels[ $evt->action ] : $evt->action;
                $rname     = trim( $evt->record_name );
                $ago       = human_time_diff( strtotime( $evt->created_at ), current_time('timestamp') );
                $actor     = $evt->actor ?: 'System';
            ?>
            <div class="sp-feed-item">
                <div class="sp-feed-dot" style="background:<?php echo esc_attr( $pipeline_colors[ array_key_exists($evt->record_type, $pipeline_colors) ? $evt->record_type : 'new' ] ?? '#94a3b8' ); ?>"></div>
                <div class="sp-feed-body">
                    <span class="sp-feed-actor"><?php echo esc_html($actor); ?></span>
                    <span class="sp-feed-verb"> <?php echo esc_html($verb); ?> </span>
                    <?php if ( $rname ) : ?>
                        <span class="sp-feed-record"><?php echo esc_html($rname); ?></span>
                    <?php else : ?>
                        <span class="sp-feed-record"><?php echo esc_html( ucfirst($evt->record_type) . ' #' . $evt->record_id ); ?></span>
                    <?php endif; ?>
                    <span class="sp-feed-time"><?php echo esc_html($ago); ?> ago</span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Recent contacts -->
    <div class="sp-card">
        <div class="sp-card-header">
            <h2>Recent Contacts</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=new' ) ); ?>" class="sp-btn sp-btn-primary sp-btn-sm">+ Add</a>
        </div>
        <?php if ( empty( $recent_contacts ) ) : ?>
            <p class="sp-empty">No contacts yet.</p>
        <?php else : ?>
        <table class="sp-table">
            <tbody>
            <?php foreach ( $recent_contacts as $c ) : ?>
                <tr>
                    <td><a href="<?php echo esc_url( home_url('/sp-app/?view=contacts&action=view&id='.$c->id) ); ?>" class="sp-link"><?php echo esc_html( trim($c->first_name.' '.$c->last_name) ); ?></a></td>
                    <td class="sp-muted" style="font-size:12px"><?php echo esc_html( $c->email ); ?></td>
                    <td><span class="sp-badge sp-badge-<?php echo esc_attr($c->status); ?>"><?php echo esc_html( ucfirst($c->status) ); ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <!-- Team activity this week (admin only) -->
    <?php if ( $is_admin && ! empty( $week_counts ) ) : ?>
    <div class="sp-card">
        <div class="sp-card-header">
            <h2>Team This Week</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=activity_report' ) ); ?>" class="sp-btn sp-btn-ghost sp-btn-sm">Full Report</a>
        </div>
        <div style="padding:16px 20px">
        <?php
        $week_max = max( array_column( (array)$week_counts, 'total' ) ) ?: 1;
        foreach ( $week_counts as $wc ) : $pct = round( $wc->total / $week_max * 100 ); ?>
        <div class="sp-funnel-row" style="margin-bottom:10px">
            <span class="sp-funnel-label"><?php echo esc_html( $wc->name ?: 'Unknown' ); ?></span>
            <div class="sp-funnel-track">
                <div class="sp-funnel-bar" style="width:<?php echo max(4,$pct); ?>%;background:var(--sp-accent,#CC1F1F)"></div>
            </div>
            <span class="sp-funnel-count"><?php echo esc_html($wc->total); ?></span>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php do_action( 'sp_dashboard_after_grid' ); ?>

<style>
.sp-stat-link{text-decoration:none;display:block;transition:box-shadow .15s,transform .1s}
.sp-stat-link:hover{box-shadow:0 4px 16px rgba(0,0,0,.08);transform:translateY(-1px)}
.sp-dash-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.sp-dash-funnel,.sp-dash-activity{grid-column:span 1}
.sp-funnel-row{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.sp-funnel-row:last-child{margin-bottom:0}
.sp-funnel-label{font-size:12px;font-weight:600;color:#475569;width:90px;flex-shrink:0}
.sp-funnel-track{flex:1;height:10px;background:#f1f5f9;border-radius:5px;overflow:hidden}
.sp-funnel-bar{height:100%;border-radius:5px;transition:width .4s ease}
.sp-funnel-count{font-size:12px;font-weight:700;color:#64748b;width:24px;text-align:right;flex-shrink:0}
.sp-activity-feed{padding:8px 0;max-height:320px;overflow-y:auto}
.sp-feed-item{display:flex;align-items:flex-start;gap:10px;padding:8px 20px}
.sp-feed-item:hover{background:#fafafa}
.sp-feed-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;margin-top:5px}
.sp-feed-body{flex:1;font-size:12px;color:#64748b;line-height:1.5}
.sp-feed-actor{font-weight:700;color:#1e293b}
.sp-feed-verb{color:#64748b}
.sp-feed-record{font-weight:600;color:#475569}
.sp-feed-time{display:block;font-size:11px;color:#94a3b8;margin-top:1px}
@media(max-width:768px){
  .sp-dash-grid{grid-template-columns:1fr}
  .sp-dash-funnel,.sp-dash-activity{grid-column:span 1}
}
</style>
