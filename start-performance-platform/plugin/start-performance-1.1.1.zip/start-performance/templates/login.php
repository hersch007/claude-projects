<?php
defined( 'ABSPATH' ) || exit;

$error      = sanitize_key( $_GET['error'] ?? '' );
$redirect   = sanitize_url( $_GET['redirect_to'] ?? '' );
$login_url  = \SP\Core\AppShell::login_url();

$error_msg = match( $error ) {
    'credentials' => 'Incorrect email or password. Please try again.',
    'invalid'     => 'Invalid request. Please try again.',
    default       => '',
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — Start Performance</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;background:#0f172a;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}

.login-wrap{width:100%;max-width:420px}

.login-logo{text-align:center;margin-bottom:36px}
.login-logo-mark{width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,#0057FF,#003FC7);display:inline-flex;align-items:center;justify-content:center;margin-bottom:14px;box-shadow:0 8px 24px rgba(0,87,255,.4)}
.login-logo-mark svg{width:28px;height:28px}
.login-brand{font-size:22px;font-weight:800;color:#fff;letter-spacing:-.4px}
.login-tagline{font-size:13px;color:#64748b;margin-top:4px}

.login-card{background:#1e293b;border:1px solid #334155;border-radius:16px;padding:36px;box-shadow:0 24px 64px rgba(0,0,0,.4)}
.login-card h1{font-size:20px;font-weight:700;color:#f1f5f9;margin-bottom:6px}
.login-card p{font-size:14px;color:#64748b;margin-bottom:28px}

.form-field{margin-bottom:18px}
.form-field label{display:block;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#94a3b8;margin-bottom:8px}
.form-field input{width:100%;background:#0f172a;border:1.5px solid #334155;border-radius:8px;padding:13px 16px;font-size:15px;color:#f1f5f9;outline:none;transition:border-color .2s,box-shadow .2s}
.form-field input::placeholder{color:#475569}
.form-field input:focus{border-color:#0057FF;box-shadow:0 0 0 3px rgba(0,87,255,.2)}

.remember-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px}
.remember-label{display:flex;align-items:center;gap:8px;font-size:13px;color:#94a3b8;cursor:pointer}
.remember-label input{accent-color:#0057FF;width:15px;height:15px}

.btn-login{width:100%;background:#0057FF;color:#fff;font-size:15px;font-weight:700;border:none;border-radius:8px;padding:14px;cursor:pointer;transition:background .2s,transform .1s,box-shadow .2s;box-shadow:0 4px 14px rgba(0,87,255,.4)}
.btn-login:hover{background:#0041CC;transform:translateY(-1px);box-shadow:0 8px 24px rgba(0,87,255,.5)}
.btn-login:active{transform:translateY(0)}

.error-box{background:#450a0a;border:1px solid #7f1d1d;border-radius:8px;padding:12px 16px;font-size:13px;color:#fca5a5;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.error-icon{flex-shrink:0;font-size:16px}

.login-footer{text-align:center;margin-top:24px;font-size:12px;color:#475569}
</style>
</head>
<body>

<div class="login-wrap">

    <div class="login-logo">
        <div class="login-logo-mark">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="#fff" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="login-brand">Start Performance</div>
        <div class="login-tagline">Business Operating Platform</div>
    </div>

    <div class="login-card">
        <h1>Welcome back</h1>
        <p>Sign in to your platform</p>

        <?php if ( $error_msg ) : ?>
            <div class="error-box"><span class="error-icon">⚠</span><?php echo esc_html( $error_msg ); ?></div>
        <?php endif; ?>

        <form method="post" action="<?php echo esc_url( $login_url ); ?>">
            <?php wp_nonce_field( 'sp_login', 'sp_login_nonce' ); ?>
            <?php if ( $redirect ) : ?>
                <input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect ); ?>">
            <?php endif; ?>

            <div class="form-field">
                <label for="log">Email or Username</label>
                <input type="text" id="log" name="log" placeholder="you@example.com" autocomplete="username" required autofocus>
            </div>

            <div class="form-field">
                <label for="pwd">Password</label>
                <input type="password" id="pwd" name="pwd" placeholder="••••••••" autocomplete="current-password" required>
            </div>

            <div class="remember-row">
                <label class="remember-label">
                    <input type="checkbox" name="rememberme" value="forever">
                    Keep me signed in
                </label>
            </div>

            <button type="submit" class="btn-login">Sign In →</button>
        </form>
    </div>

    <div class="login-footer">Powered by Start Performance &copy; <?php echo date( 'Y' ); ?></div>

</div>

</body>
</html>
