<?php
/**
 * Plugin Name: Start Performance
 * Plugin URI:  https://startadvertising.com
 * Description: Core System for the Start Performance Platform. Required foundation for all modules.
 * Version:     1.1.1
 * Author:      Richard Brashear / Start Performance
 * Author URI:  https://startadvertising.com
 * License:     GPL-2.0+
 * Text Domain: start-performance
 */

defined( 'ABSPATH' ) || exit;

define( 'SP_VERSION',     '1.1.1' );
define( 'SP_PLUGIN_FILE', __FILE__ );
define( 'SP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

// Global helper functions
require_once SP_PLUGIN_DIR . 'includes/Core/helpers.php';

// Autoloader — maps SP\ namespace to includes/
spl_autoload_register( function ( $class ) {
    if ( strpos( $class, 'SP\\' ) !== 0 ) {
        return;
    }
    $relative = str_replace( 'SP\\', '', $class );
    $relative = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );
    $file     = SP_PLUGIN_DIR . 'includes' . DIRECTORY_SEPARATOR . $relative . '.php';
    if ( file_exists( $file ) ) {
        require_once $file;
    }
} );

// Activation / deactivation hooks
register_activation_hook( __FILE__,   [ 'SP\\Core\\Installer', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'SP\\Core\\Installer', 'deactivate' ] );

// Boot the platform
add_action( 'plugins_loaded', function () {
    SP\Core\Platform::instance()->boot();
} );
