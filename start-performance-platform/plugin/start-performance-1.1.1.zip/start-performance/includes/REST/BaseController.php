<?php
namespace SP\REST;

defined( 'ABSPATH' ) || exit;

abstract class BaseController extends \WP_REST_Controller {

    protected string $namespace = 'sp/v1';

    protected function require_auth( \WP_REST_Request $request ): bool|\WP_Error {
        if ( ! is_user_logged_in() ) {
            return new \WP_Error( 'sp_unauthorized', 'Authentication required.', [ 'status' => 401 ] );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return new \WP_Error( 'sp_forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );
        }
        return true;
    }

    protected function auth_check(): \WP_Error|bool {
        if ( ! is_user_logged_in() ) {
            return new \WP_Error( 'sp_unauthorized', 'Authentication required.', [ 'status' => 401 ] );
        }
        return true;
    }

    protected function ok( mixed $data, int $status = 200 ): \WP_REST_Response {
        return new \WP_REST_Response( [ 'success' => true, 'data' => $data ], $status );
    }

    protected function error( string $message, int $status = 400 ): \WP_REST_Response {
        return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], $status );
    }

    protected function paginate( array $rows, int $total, int $page, int $per_page ): array {
        return [
            'items'      => $rows,
            'total'      => $total,
            'page'       => $page,
            'per_page'   => $per_page,
            'total_pages'=> (int) ceil( $total / $per_page ),
        ];
    }
}
