<?php
namespace SP\REST;

defined( 'ABSPATH' ) || exit;

class LeadsController extends BaseController {

    public function register_routes(): void {
        register_rest_route( $this->namespace, '/leads', [
            [ 'methods' => 'GET',  'callback' => [ $this, 'get_items' ],   'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'POST', 'callback' => [ $this, 'create_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
        ] );
        register_rest_route( $this->namespace, '/leads/(?P<id>\d+)', [
            [ 'methods' => 'GET',    'callback' => [ $this, 'get_item' ],    'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'PUT',    'callback' => [ $this, 'update_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'DELETE', 'callback' => [ $this, 'delete_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
        ] );
    }

    public function get_items( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $search   = sanitize_text_field( $request->get_param( 'search' ) ?? '' );
        $status   = sanitize_key(        $request->get_param( 'status' ) ?? '' );
        $page     = max( 1, (int) ( $request->get_param( 'page' )     ?? 1 ) );
        $per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?? 25 ) ) );
        $offset   = ( $page - 1 ) * $per_page;

        $where = 'WHERE l.deleted_at IS NULL';
        $args  = [];
        if ( $status ) {
            $where .= ' AND l.status = %s';
            $args[] = $status;
        }
        if ( $search ) {
            $where .= ' AND (c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = array_merge( $args, [ $like, $like, $like ] );
        }

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads l
             LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id $where",
            ...$args
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT l.*, c.first_name, c.last_name, c.email, co.name AS company_name
             FROM {$wpdb->prefix}sp_leads l
             LEFT JOIN {$wpdb->prefix}sp_contacts c  ON c.id  = l.contact_id
             LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = l.company_id
             $where ORDER BY l.created_at DESC LIMIT %d OFFSET %d",
            ...array_merge( $args, [ $per_page, $offset ] )
        ), ARRAY_A );

        return $this->ok( $this->paginate( $rows, $total, $page, $per_page ) );
    }

    public function get_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.*, c.first_name, c.last_name, c.email, co.name AS company_name
             FROM {$wpdb->prefix}sp_leads l
             LEFT JOIN {$wpdb->prefix}sp_contacts c  ON c.id  = l.contact_id
             LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = l.company_id
             WHERE l.id = %d AND l.deleted_at IS NULL",
            (int) $request['id']
        ), ARRAY_A );

        return $row ? $this->ok( $row ) : $this->error( 'Lead not found.', 404 );
    }

    public function create_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $data = $this->sanitize_fields( $request );
        $data['owner_id'] = get_current_user_id();
        $wpdb->insert( $wpdb->prefix . 'sp_leads', $data );
        $id = $wpdb->insert_id;
        \SP\Core\ActivityLog::write( 'lead', $id, 'created' );
        return $this->ok( [ 'id' => $id ], 201 );
    }

    public function update_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_leads', $this->sanitize_fields( $request ), [ 'id' => $id ] );
        \SP\Core\ActivityLog::write( 'lead', $id, 'updated' );
        return $this->ok( [ 'id' => $id ] );
    }

    public function delete_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_leads', [ 'deleted_at' => current_time( 'mysql' ) ], [ 'id' => $id ] );
        \SP\Core\ActivityLog::write( 'lead', $id, 'deleted' );
        return $this->ok( [ 'deleted' => true ] );
    }

    private function sanitize_fields( \WP_REST_Request $request ): array {
        return [
            'contact_id' => (int) ( $request->get_param( 'contact_id' ) ?? 0 ),
            'company_id' => (int) ( $request->get_param( 'company_id' ) ?? 0 ),
            'source'     => sanitize_text_field( $request->get_param( 'source' ) ?? '' ),
            'status'     => sanitize_key(        $request->get_param( 'status' ) ?? 'new' ),
            'score'      => min( 100, max( 0, (int) ( $request->get_param( 'score' ) ?? 0 ) ) ),
            'notes'      => sanitize_textarea_field( $request->get_param( 'notes' ) ?? '' ),
        ];
    }
}
