<?php
namespace SP\REST;

defined( 'ABSPATH' ) || exit;

class Router {

    public static function register(): void {
        $controllers = [
            new DashboardController(),
            new ContactsController(),
            new CompaniesController(),
            new LeadsController(),
        ];
        foreach ( $controllers as $controller ) {
            $controller->register_routes();
        }
    }
}
