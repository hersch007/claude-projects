<?php
namespace SP\REST;

defined( 'ABSPATH' ) || exit;

class CompaniesController extends BaseController {

    public function register_routes(): void {
        register_rest_route( $this->namespace, '/companies', [
            [ 'methods' => 'GET',  'callback' => [ $this, 'get_items' ],   'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'POST', 'callback' => [ $this, 'create_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
        ] );
        register_rest_route( $this->namespace, '/companies/(?P<id>\d+)', [
            [ 'methods' => 'GET',    'callback' => [ $this, 'get_item' ],    'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'PUT',    'callback' => [ $this, 'update_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'DELETE', 'callback' => [ $this, 'delete_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
        ] );
    }

    public function get_items( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $search   = sanitize_text_field( $request->get_param( 'search' ) ?? '' );
        $page     = max( 1, (int) ( $request->get_param( 'page' )     ?? 1 ) );
        $per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?? 25 ) ) );
        $offset   = ( $page - 1 ) * $per_page;

        $where = 'WHERE deleted_at IS NULL';
        $args  = [];
        if ( $search ) {
            $where .= ' AND (name LIKE %s OR industry LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = [ $like, $like ];
        }

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies $where", ...$args
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sp_companies $where ORDER BY name LIMIT %d OFFSET %d",
            ...array_merge( $args, [ $per_page, $offset ] )
        ), ARRAY_A );

        return $this->ok( $this->paginate( $rows, $total, $page, $per_page ) );
    }

    public function get_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sp_companies WHERE id = %d AND deleted_at IS NULL",
            (int) $request['id']
        ), ARRAY_A );

        return $row ? $this->ok( $row ) : $this->error( 'Company not found.', 404 );
    }

    public function create_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $data = $this->sanitize_fields( $request );
        $wpdb->insert( $wpdb->prefix . 'sp_companies', $data );
        $id = $wpdb->insert_id;
        \SP\Core\ActivityLog::write( 'company', $id, 'created' );
        return $this->ok( [ 'id' => $id ], 201 );
    }

    public function update_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_companies', $this->sanitize_fields( $request ), [ 'id' => $id ] );
        \SP\Core\ActivityLog::write( 'company', $id, 'updated' );
        return $this->ok( [ 'id' => $id ] );
    }

    public function delete_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update( $wpdb->prefix . 'sp_companies', [ 'deleted_at' => current_time( 'mysql' ) ], [ 'id' => $id ] );
        \SP\Core\ActivityLog::write( 'company', $id, 'deleted' );
        return $this->ok( [ 'deleted' => true ] );
    }

    private function sanitize_fields( \WP_REST_Request $request ): array {
        return [
            'name'     => sanitize_text_field(    $request->get_param( 'name' )     ?? '' ),
            'industry' => sanitize_text_field(    $request->get_param( 'industry' ) ?? '' ),
            'website'  => esc_url_raw(            $request->get_param( 'website' )  ?? '' ),
            'phone'    => sanitize_text_field(    $request->get_param( 'phone' )    ?? '' ),
            'address'  => sanitize_textarea_field( $request->get_param( 'address' ) ?? '' ),
            'notes'    => sanitize_textarea_field( $request->get_param( 'notes' )   ?? '' ),
        ];
    }
}
