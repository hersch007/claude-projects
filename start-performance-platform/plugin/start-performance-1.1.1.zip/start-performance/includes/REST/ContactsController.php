<?php
namespace SP\REST;

defined( 'ABSPATH' ) || exit;

class ContactsController extends BaseController {

    public function register_routes(): void {
        register_rest_route( $this->namespace, '/contacts', [
            [ 'methods' => 'GET',  'callback' => [ $this, 'get_items' ],   'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'POST', 'callback' => [ $this, 'create_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
        ] );
        register_rest_route( $this->namespace, '/contacts/(?P<id>\d+)', [
            [ 'methods' => 'GET',    'callback' => [ $this, 'get_item' ],    'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'PUT',    'callback' => [ $this, 'update_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
            [ 'methods' => 'DELETE', 'callback' => [ $this, 'delete_item' ], 'permission_callback' => [ $this, 'auth_check' ] ],
        ] );
    }

    public function get_items( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $search   = sanitize_text_field( $request->get_param( 'search' ) ?? '' );
        $page     = max( 1, (int) ( $request->get_param( 'page' )     ?? 1 ) );
        $per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?? 25 ) ) );
        $offset   = ( $page - 1 ) * $per_page;

        $where = 'WHERE c.deleted_at IS NULL';
        $args  = [];
        if ( $search ) {
            $where .= ' AND (c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s OR c.phone LIKE %s)';
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $args   = [ $like, $like, $like, $like ];
        }

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts c $where", ...$args
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT c.*, co.name AS company_name
             FROM {$wpdb->prefix}sp_contacts c
             LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id
             $where ORDER BY c.created_at DESC LIMIT %d OFFSET %d",
            ...array_merge( $args, [ $per_page, $offset ] )
        ), ARRAY_A );

        return $this->ok( $this->paginate( $rows, $total, $page, $per_page ) );
    }

    public function get_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id  = (int) $request['id'];
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT c.*, co.name AS company_name
             FROM {$wpdb->prefix}sp_contacts c
             LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id
             WHERE c.id = %d AND c.deleted_at IS NULL",
            $id
        ), ARRAY_A );

        if ( ! $row ) {
            return $this->error( 'Contact not found.', 404 );
        }
        return $this->ok( $row );
    }

    public function create_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $data = $this->sanitize_fields( $request );

        $wpdb->insert( $wpdb->prefix . 'sp_contacts', $data );
        $id = $wpdb->insert_id;
        \SP\Core\ActivityLog::write( 'contact', $id, 'created' );

        return $this->ok( [ 'id' => $id ], 201 );
    }

    public function update_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id  = (int) $request['id'];
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}sp_contacts WHERE id = %d AND deleted_at IS NULL", $id
        ) );
        if ( ! $exists ) {
            return $this->error( 'Contact not found.', 404 );
        }

        $data = $this->sanitize_fields( $request );
        $wpdb->update( $wpdb->prefix . 'sp_contacts', $data, [ 'id' => $id ] );
        \SP\Core\ActivityLog::write( 'contact', $id, 'updated' );

        return $this->ok( [ 'id' => $id ] );
    }

    public function delete_item( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request['id'];
        $wpdb->update(
            $wpdb->prefix . 'sp_contacts',
            [ 'deleted_at' => current_time( 'mysql' ) ],
            [ 'id' => $id ]
        );
        \SP\Core\ActivityLog::write( 'contact', $id, 'deleted' );
        return $this->ok( [ 'deleted' => true ] );
    }

    private function sanitize_fields( \WP_REST_Request $request ): array {
        return [
            'first_name' => sanitize_text_field( $request->get_param( 'first_name' ) ?? '' ),
            'last_name'  => sanitize_text_field( $request->get_param( 'last_name' )  ?? '' ),
            'email'      => sanitize_email(      $request->get_param( 'email' )      ?? '' ),
            'phone'      => sanitize_text_field( $request->get_param( 'phone' )      ?? '' ),
            'company_id' => (int) ( $request->get_param( 'company_id' ) ?? 0 ),
            'source'     => sanitize_text_field( $request->get_param( 'source' )     ?? '' ),
            'status'     => sanitize_key(        $request->get_param( 'status' )     ?? 'active' ),
            'notes'      => sanitize_textarea_field( $request->get_param( 'notes' )  ?? '' ),
        ];
    }
}
