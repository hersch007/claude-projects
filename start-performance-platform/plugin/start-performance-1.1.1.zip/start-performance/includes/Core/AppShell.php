<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Registers two virtual URLs:
 *   /sp-login/  — custom branded login page
 *   /sp-app/    — the full platform SPA
 *
 * Hides wp-admin and wp-login.php from non-super-admins.
 */
class AppShell {

    const LOGIN_SLUG = 'sp-login';
    const APP_SLUG   = 'sp-app';

    private static ?AppShell $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init(): void {
        add_action( 'init',              [ $this, 'add_rewrite_rules' ] );
        add_action( 'template_redirect', [ $this, 'intercept_request' ], 1 );
        add_action( 'init',              [ $this, 'block_wp_admin' ] );
        add_filter( 'login_url',         [ $this, 'filter_login_url' ], 10, 3 );
        add_filter( 'logout_url',        [ $this, 'filter_logout_url' ] );
        add_action( 'admin_bar_menu',    '__return_false', 999 );
        add_filter( 'show_admin_bar',    '__return_false' );
    }

    public function add_rewrite_rules(): void {
        add_rewrite_rule( '^' . self::LOGIN_SLUG . '/?$', 'index.php?sp_page=login', 'top' );
        add_rewrite_rule( '^' . self::APP_SLUG   . '/?$', 'index.php?sp_page=app',   'top' );
        add_rewrite_tag( '%sp_page%', '([^&]+)' );
    }

    public function intercept_request(): void {
        $sp_page = get_query_var( 'sp_page' );

        if ( $sp_page === 'login' ) {
            $this->render_login();
            exit;
        }

        if ( $sp_page === 'app' ) {
            if ( ! is_user_logged_in() ) {
                wp_redirect( home_url( '/' . self::LOGIN_SLUG . '/' ) );
                exit;
            }
            $this->render_app();
            exit;
        }
    }

    /**
     * Block wp-admin for users who are not super admins.
     * Super admins can still reach wp-admin for plugin/theme management.
     */
    public function block_wp_admin(): void {
        if ( ! is_admin() ) {
            return;
        }
        // Allow AJAX and cron through
        if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
            return;
        }
        if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( is_user_logged_in() ) {
            wp_redirect( home_url( '/' . self::APP_SLUG . '/' ) );
            exit;
        }
        wp_redirect( home_url( '/' . self::LOGIN_SLUG . '/' ) );
        exit;
    }

    public function filter_login_url( string $login_url, string $redirect, bool $force_reauth ): string {
        $url = home_url( '/' . self::LOGIN_SLUG . '/' );
        if ( $redirect ) {
            $url = add_query_arg( 'redirect_to', urlencode( $redirect ), $url );
        }
        return $url;
    }

    public function filter_logout_url( string $logout_url ): string {
        return home_url( '/' . self::LOGIN_SLUG . '/?sp_logout=1' );
    }

    public static function app_url(): string {
        return home_url( '/' . self::APP_SLUG . '/' );
    }

    public static function login_url(): string {
        return home_url( '/' . self::LOGIN_SLUG . '/' );
    }

    // ── Renderers (content comes from separate template files) ───────────────

    private function render_login(): void {
        require_once SP_PLUGIN_DIR . 'templates/login.php';
    }

    private function render_app(): void {
        require_once SP_PLUGIN_DIR . 'templates/app.php';
    }
}
