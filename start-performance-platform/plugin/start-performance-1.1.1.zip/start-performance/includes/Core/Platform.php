<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

class Platform {

    private static ?Platform $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function boot(): void {
        // Core services
        ModuleRegistry::instance();
        Auth::instance()->init();
        AppShell::instance()->init();

        // REST API
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );

        // WP admin pages (super-admin only, for plugin management)
        if ( is_admin() ) {
            Admin\Dashboard::instance()->init();
            Admin\Contacts::instance()->init();
            Admin\Companies::instance()->init();
            Admin\Leads::instance()->init();
            Admin\ActivityLog::instance()->init();
            Admin\Settings::instance()->init();
        }

        do_action( 'sp_platform_booted' );
    }

    public function register_rest_routes(): void {
        \SP\REST\Router::register();
    }
}
