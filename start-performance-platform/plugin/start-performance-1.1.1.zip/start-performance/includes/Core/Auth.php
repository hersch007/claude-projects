<?php
namespace SP\Core;

defined( 'ABSPATH' ) || exit;

class Auth {

    private static ?Auth $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init(): void {
        add_action( 'init', [ $this, 'handle_login_post' ] );
        add_action( 'init', [ $this, 'handle_logout' ] );
    }

    public function handle_login_post(): void {
        if ( $_SERVER['REQUEST_METHOD'] !== 'POST' || empty( $_POST['sp_login_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['sp_login_nonce'], 'sp_login' ) ) {
            wp_redirect( AppShell::login_url() . '?error=invalid' );
            exit;
        }

        $credentials = [
            'user_login'    => sanitize_user( $_POST['log'] ?? '' ),
            'user_password' => $_POST['pwd'] ?? '',
            'remember'      => ! empty( $_POST['rememberme'] ),
        ];

        $user = wp_signon( $credentials, is_ssl() );

        if ( is_wp_error( $user ) ) {
            wp_redirect( AppShell::login_url() . '?error=credentials' );
            exit;
        }

        $redirect = sanitize_url( $_POST['redirect_to'] ?? '' );
        wp_redirect( $redirect ?: AppShell::app_url() );
        exit;
    }

    public function handle_logout(): void {
        if ( empty( $_GET['sp_logout'] ) ) {
            return;
        }
        wp_logout();
        wp_redirect( AppShell::login_url() );
        exit;
    }
}
