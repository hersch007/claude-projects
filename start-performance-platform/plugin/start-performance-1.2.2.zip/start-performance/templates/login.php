<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$error = sanitize_key( isset( $_GET['error'] ) ? $_GET['error'] : '' );

if ( $error === 'pin' ) {
    $error_msg = 'Incorrect PIN. Please try again.';
} elseif ( $error === 'invalid' ) {
    $error_msg = 'Invalid request. Please try again.';
} else {
    $error_msg = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — Start Performance</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f1f5f9;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:40px;width:100%;max-width:380px;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.06)}
.logo-mark{width:60px;height:60px;border-radius:14px;background:#CC1F1F;display:inline-flex;align-items:center;justify-content:center;margin-bottom:14px}
.logo-mark svg{width:36px;height:36px}
.logo-name{font-size:20px;font-weight:800;color:#1e293b;margin-bottom:4px}
.logo-tag{font-size:13px;color:#94a3b8;margin-bottom:36px}
h1{font-size:18px;font-weight:700;color:#1e293b;margin-bottom:4px}
p{font-size:14px;color:#94a3b8;margin-bottom:24px}
.pin-input{width:100%;background:#f8fafc;border:2px solid #e2e8f0;border-radius:10px;padding:16px;font-size:28px;font-weight:700;color:#1e293b;text-align:center;letter-spacing:12px;outline:none;margin-bottom:16px;transition:border-color .2s}
.pin-input:focus{border-color:#CC1F1F;box-shadow:0 0 0 3px rgba(204,31,31,.1)}
button{width:100%;background:#CC1F1F;color:#fff;font-size:15px;font-weight:700;border:none;border-radius:8px;padding:14px;cursor:pointer;transition:background .2s}
button:hover{background:#b01818}
.error{background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;padding:12px 14px;font-size:13px;color:#dc2626;margin-bottom:20px}
.footer{margin-top:24px;font-size:12px;color:#cbd5e1}
</style>
</head>
<body>
<div class="card">
    <div class="logo-mark">
        <!-- Start Performance hub-and-spoke icon -->
        <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18" cy="18" r="3.5" fill="white"/>
            <circle cx="18" cy="5"  r="2.5" fill="white"/>
            <circle cx="18" cy="31" r="2.5" fill="white"/>
            <circle cx="5"  cy="18" r="2.5" fill="white"/>
            <circle cx="31" cy="18" r="2.5" fill="white"/>
            <circle cx="8"  cy="8"  r="2.5" fill="white"/>
            <circle cx="28" cy="8"  r="2.5" fill="white"/>
            <circle cx="8"  cy="28" r="2.5" fill="white"/>
            <circle cx="28" cy="28" r="2.5" fill="white"/>
            <line x1="18" y1="14.5" x2="18" y2="7.5"   stroke="white" stroke-width="1.8"/>
            <line x1="18" y1="21.5" x2="18" y2="28.5"  stroke="white" stroke-width="1.8"/>
            <line x1="14.5" y1="18" x2="7.5"  y2="18"  stroke="white" stroke-width="1.8"/>
            <line x1="21.5" y1="18" x2="28.5" y2="18"  stroke="white" stroke-width="1.8"/>
            <line x1="15.5" y1="15.5" x2="10" y2="10"  stroke="white" stroke-width="1.8"/>
            <line x1="20.5" y1="15.5" x2="26" y2="10"  stroke="white" stroke-width="1.8"/>
            <line x1="15.5" y1="20.5" x2="10" y2="26"  stroke="white" stroke-width="1.8"/>
            <line x1="20.5" y1="20.5" x2="26" y2="26"  stroke="white" stroke-width="1.8"/>
        </svg>
    </div>
    <div class="logo-name">Start Performance</div>
    <div class="logo-tag">Business Operating Platform</div>

    <h1>Enter your PIN</h1>
    <p>Enter your PIN to access the platform</p>

    <?php if ( $error_msg ) : ?>
        <div class="error"><?php echo esc_html( $error_msg ); ?></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( home_url( '/sp-login/' ) ); ?>">
        <?php wp_nonce_field( 'sp_login', 'sp_login_nonce' ); ?>
        <input type="password" name="pin" class="pin-input" maxlength="8" inputmode="numeric" pattern="[0-9]*" placeholder="••••" autofocus required>
        <button type="submit">Sign In &rarr;</button>
    </form>

    <div class="footer">Start Performance v<?php echo esc_html( SP_VERSION ); ?></div>
</div>
</body>
</html>
