<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$current_pin = get_option( 'sp_pin', '1234' );
?>
<div class="sp-page-header">
    <h1>Settings</h1>
</div>
<div class="sp-card sp-form-card">
    <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
        <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
        <input type="hidden" name="sp_type" value="settings">
        <h2 class="sp-section-heading">Security</h2>
        <div class="sp-field">
            <label>Login PIN</label>
            <input type="text" name="sp_pin" value="<?php echo esc_attr( $current_pin ); ?>" maxlength="8" style="max-width:160px">
            <p class="sp-hint">PIN used to access the platform at /sp-login/</p>
        </div>
        <div class="sp-form-actions">
            <button type="submit" class="sp-btn sp-btn-primary">Save Settings</button>
        </div>
    </form>
</div>
