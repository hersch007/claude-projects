<?php
/*
 * Plugin Name: Start Performance
 * Description: Start Performance Platform — core
 * Version:     1.2.2
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_VERSION',    '1.2.2' );
define( 'SP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SP_PIN',        get_option( 'sp_pin', '1234' ) );

// ── Activation ───────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_activate' );
register_deactivation_hook( __FILE__, 'sp_deactivate' );

function sp_activate() {
    sp_create_tables();
    do_action( 'sp_activate' );   // addons hook here to create their own tables
    flush_rewrite_rules();
}

function sp_deactivate() {
    flush_rewrite_rules();
}

function sp_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_contacts (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL DEFAULT '',
  last_name varchar(100) NOT NULL DEFAULT '',
  email varchar(200) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  company_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(100) NOT NULL DEFAULT '',
  status varchar(50) NOT NULL DEFAULT 'active',
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY email (email(100)),
  KEY status (status)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_companies (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL DEFAULT '',
  industry varchar(100) NOT NULL DEFAULT '',
  website varchar(255) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  address text,
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY name (name(100))
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_leads (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
  company_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(100) NOT NULL DEFAULT '',
  status varchar(50) NOT NULL DEFAULT 'new',
  score tinyint(3) unsigned NOT NULL DEFAULT 0,
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY status (status),
  KEY contact_id (contact_id)
) $charset;" );
}

// ── View registry ─────────────────────────────────────────────────────────────
// Addons call sp_register_view() to make their view slugs load from their own
// plugin folder instead of the core templates/views/ directory.

$sp_view_registry = array();

function sp_register_view( $slug, $file_path ) {
    global $sp_view_registry;
    $sp_view_registry[ $slug ] = $file_path;
}

function sp_get_view_file( $slug ) {
    global $sp_view_registry;
    if ( isset( $sp_view_registry[ $slug ] ) && file_exists( $sp_view_registry[ $slug ] ) ) {
        return $sp_view_registry[ $slug ];
    }
    $core = SP_PLUGIN_DIR . 'templates/views/' . $slug . '.php';
    return file_exists( $core ) ? $core : '';
}

// ── Addon registry ────────────────────────────────────────────────────────────
// Addons call sp_register_addon() from their boot function so the Add-ons page
// can list everything that is currently installed and active.

$sp_addon_registry = array();

function sp_register_addon( $id, $data ) {
    global $sp_addon_registry;
    $sp_addon_registry[ $id ] = array_merge( array(
        'name'         => '',
        'version'      => '',
        'description'  => '',
        'settings_url' => '',
        'icon'         => '',   // SVG path d= string, or raw <path> elements
    ), $data );
}

function sp_get_addons() {
    global $sp_addon_registry;
    return $sp_addon_registry;
}

// ── URL Routing ───────────────────────────────────────────────────────────────

add_action( 'init', 'sp_route', 1 );

function sp_route() {
    $uri     = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
    $wp_path = trim( parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
    if ( $wp_path ) {
        $uri = trim( substr( $uri, strlen( $wp_path ) ), '/' );
    }

    // ── /sp-login/ ────────────────────────────────────────────────────────────
    if ( $uri === 'sp-login' ) {
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && ! empty( $_POST['sp_login_nonce'] ) ) {
            if ( ! wp_verify_nonce( $_POST['sp_login_nonce'], 'sp_login' ) ) {
                wp_redirect( home_url( '/sp-login/?error=invalid' ) ); exit;
            }
            $pin = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';
            if ( $pin !== SP_PIN ) {
                wp_redirect( home_url( '/sp-login/?error=pin' ) ); exit;
            }
            $admins = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
            if ( empty( $admins ) ) {
                wp_redirect( home_url( '/sp-login/?error=nouser' ) ); exit;
            }
            wp_set_current_user( $admins[0]->ID );
            wp_set_auth_cookie( $admins[0]->ID, true );
            wp_redirect( home_url( '/sp-app/' ) ); exit;
        }
        require SP_PLUGIN_DIR . 'templates/login.php'; exit;
    }

    // ── /sp-app/ ──────────────────────────────────────────────────────────────
    if ( $uri === 'sp-app' ) {
        if ( ! is_user_logged_in() ) {
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( isset( $_GET['sp_logout'] ) ) {
            wp_logout();
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
            sp_handle_post(); exit;
        }
        if ( isset( $_GET['sp_delete'] ) ) {
            sp_handle_delete(); exit;
        }
        require SP_PLUGIN_DIR . 'templates/app.php'; exit;
    }
}

// ── Block wp-admin for non-logged-in users ────────────────────────────────────

add_action( 'admin_init', function() {
    if ( wp_doing_ajax() ) return;
    if ( ! is_user_logged_in() ) {
        wp_redirect( home_url( '/sp-login/' ) ); exit;
    }
} );

// ── POST handler ─────────────────────────────────────────────────────────────

function sp_handle_post() {
    if ( empty( $_POST['sp_nonce'] ) || ! wp_verify_nonce( $_POST['sp_nonce'], 'sp_form' ) ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }
    global $wpdb;
    $type = isset( $_POST['sp_type'] ) ? sanitize_key( $_POST['sp_type'] ) : '';
    $id   = (int) ( isset( $_POST['sp_id'] ) ? $_POST['sp_id'] : 0 );

    if ( $type === 'contact' ) {
        $data = array(
            'first_name' => sanitize_text_field( isset( $_POST['first_name'] ) ? $_POST['first_name'] : '' ),
            'last_name'  => sanitize_text_field( isset( $_POST['last_name'] )  ? $_POST['last_name']  : '' ),
            'email'      => sanitize_email(      isset( $_POST['email'] )      ? $_POST['email']      : '' ),
            'phone'      => sanitize_text_field( isset( $_POST['phone'] )      ? $_POST['phone']      : '' ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field( isset( $_POST['source'] )     ? $_POST['source']     : '' ),
            'status'     => sanitize_key(        isset( $_POST['status'] )     ? $_POST['status']     : 'active' ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']      : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_contacts', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_contacts', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=contacts&saved=1' ) ); exit;
    }

    if ( $type === 'company' ) {
        $data = array(
            'name'     => sanitize_text_field(     isset( $_POST['name'] )     ? $_POST['name']     : '' ),
            'industry' => sanitize_text_field(     isset( $_POST['industry'] ) ? $_POST['industry'] : '' ),
            'website'  => esc_url_raw(             isset( $_POST['website'] )  ? $_POST['website']  : '' ),
            'phone'    => sanitize_text_field(     isset( $_POST['phone'] )    ? $_POST['phone']    : '' ),
            'address'  => sanitize_textarea_field( isset( $_POST['address'] )  ? $_POST['address']  : '' ),
            'notes'    => sanitize_textarea_field( isset( $_POST['notes'] )    ? $_POST['notes']    : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_companies', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_companies', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=companies&saved=1' ) ); exit;
    }

    if ( $type === 'lead' ) {
        $data = array(
            'contact_id' => (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field(     isset( $_POST['source'] ) ? $_POST['source'] : '' ),
            'status'     => sanitize_key(            isset( $_POST['status'] ) ? $_POST['status'] : 'new' ),
            'score'      => min( 100, max( 0, (int) ( isset( $_POST['score'] ) ? $_POST['score'] : 0 ) ) ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']  : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_leads', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_leads', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=leads&saved=1' ) ); exit;
    }

    if ( $type === 'settings' ) {
        update_option( 'sp_pin', sanitize_text_field( isset( $_POST['sp_pin'] ) ? $_POST['sp_pin'] : '1234' ) );
        wp_redirect( home_url( '/sp-app/?view=settings&saved=1' ) ); exit;
    }

    // Addons handle their own types — they must redirect and exit themselves
    do_action( 'sp_post_handler_' . $type, $id );

    wp_redirect( home_url( '/sp-app/' ) ); exit;
}

// ── DELETE handler ────────────────────────────────────────────────────────────

function sp_handle_delete() {
    $type  = sanitize_key( isset( $_GET['sp_delete'] ) ? $_GET['sp_delete'] : '' );
    $id    = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
    $nonce = isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '';

    if ( ! wp_verify_nonce( $nonce, 'sp_delete_' . $type . '_' . $id ) ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }

    global $wpdb;
    if ( $type === 'contact' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_contacts', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=contacts' ) ); exit;
    }
    if ( $type === 'company' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_companies', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=companies' ) ); exit;
    }
    if ( $type === 'lead' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_leads', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=leads' ) ); exit;
    }

    // Addons handle their own types — they must redirect and exit themselves
    do_action( 'sp_delete_handler_' . $type, $id );

    wp_redirect( home_url( '/sp-app/' ) ); exit;
}

// ── Helper: delete URL ────────────────────────────────────────────────────────

function sp_delete_url( $type, $id ) {
    return wp_nonce_url(
        home_url( '/sp-app/?sp_delete=' . $type . '&id=' . $id ),
        'sp_delete_' . $type . '_' . $id
    );
}

// ── Helper: pagination ────────────────────────────────────────────────────────

function sp_pagination( $total, $limit, $paged, $view ) {
    $pages = (int) ceil( $total / $limit );
    if ( $pages <= 1 ) return;
    echo '<div class="sp-pagination">';
    if ( $paged > 1 ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged - 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">&larr; Prev</a>';
    echo '<span>Page ' . $paged . ' of ' . $pages . '</span>';
    if ( $paged < $pages ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged + 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">Next &rarr;</a>';
    echo '</div>';
}
