<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$contacts  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts" );
$companies = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies" );
$leads     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads" );
$new_leads = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE status = 'new'" );

$member      = sp_get_current_team_member();
$member_id   = $member ? (int) $member->id : 0;
$today       = date( 'Y-m-d' );
$now         = current_time( 'mysql' );

$due_tasks = $member_id ? $wpdb->get_results( $wpdb->prepare(
    "SELECT tk.*, COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name,
     tk.record_type AS rtype, tk.record_id AS rid
     FROM {$wpdb->prefix}sp_tasks tk
     LEFT JOIN {$wpdb->prefix}sp_contacts c ON tk.record_type='contact' AND tk.record_id=c.id
     LEFT JOIN {$wpdb->prefix}sp_companies co ON tk.record_type='company' AND tk.record_id=co.id
     WHERE tk.assigned_to=%d AND tk.status='open' AND tk.due_date IS NOT NULL AND tk.due_date<=%s
     ORDER BY tk.due_date ASC LIMIT 10",
    $member_id, $today
) ) : array();

$due_notes = $member_id ? $wpdb->get_results( $wpdb->prepare(
    "SELECT n.*, COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name
     FROM {$wpdb->prefix}sp_notes n
     LEFT JOIN {$wpdb->prefix}sp_contacts c ON n.record_type='contact' AND n.record_id=c.id
     LEFT JOIN {$wpdb->prefix}sp_companies co ON n.record_type='company' AND n.record_id=co.id
     WHERE n.created_by=%d AND n.reminder_at IS NOT NULL AND n.reminder_at<=%s AND n.reminder_sent=0
     ORDER BY n.reminder_at ASC LIMIT 5",
    $member_id, $now
) ) : array();

$recent_contacts = $wpdb->get_results(
    "SELECT * FROM {$wpdb->prefix}sp_contacts ORDER BY created_at DESC LIMIT 5"
);
$recent_leads = $wpdb->get_results(
    "SELECT l.*, c.first_name, c.last_name FROM {$wpdb->prefix}sp_leads l
     LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id
     ORDER BY l.created_at DESC LIMIT 5"
);
?>
<div class="sp-page-header">
    <h1>Dashboard</h1>
    <span class="sp-date"><?php echo date( 'l, F j, Y' ); ?></span>
</div>

<div class="sp-stats">
    <div class="sp-stat-card sp-stat-contacts">
        <div class="sp-stat-value"><?php echo number_format( $contacts ); ?></div>
        <div class="sp-stat-label">Contacts</div>
    </div>
    <div class="sp-stat-card sp-stat-companies">
        <div class="sp-stat-value"><?php echo number_format( $companies ); ?></div>
        <div class="sp-stat-label">Companies</div>
    </div>
    <div class="sp-stat-card sp-stat-leads">
        <div class="sp-stat-value"><?php echo number_format( $leads ); ?></div>
        <div class="sp-stat-label">Total Leads</div>
    </div>
    <div class="sp-stat-card sp-stat-accent">
        <div class="sp-stat-value"><?php echo number_format( $new_leads ); ?></div>
        <div class="sp-stat-label">New Leads</div>
    </div>
</div>

<?php do_action( 'sp_dashboard_after_stats' ); ?>

<?php if ( ! empty( $due_tasks ) || ! empty( $due_notes ) ) : ?>
<div class="sp-card sp-reminders-card" style="margin-bottom:24px">
    <div class="sp-card-header">
        <h2>🔔 Your Reminders</h2>
        <span class="sp-count"><?php echo count($due_tasks) + count($due_notes); ?></span>
    </div>
    <?php foreach ( $due_tasks as $tk ) :
        $overdue = $tk->due_date < $today;
        $link    = home_url( '/sp-app/?view=' . $tk->rtype . 's&action=view&id=' . $tk->rid . '&tab=tasks' );
    ?>
    <div class="sp-reminder-item">
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" style="display:contents">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="task">
            <input type="hidden" name="sp_id" value="0">
            <input type="hidden" name="record_type" value="<?php echo esc_attr($tk->rtype); ?>">
            <input type="hidden" name="record_id" value="<?php echo esc_attr($tk->rid); ?>">
            <input type="hidden" name="task_id" value="<?php echo esc_attr($tk->id); ?>">
            <button type="submit" class="sp-task-check sp-reminder-check" title="Mark done"></button>
        </form>
        <div class="sp-reminder-body">
            <a href="<?php echo esc_url($link); ?>" class="sp-reminder-title"><?php echo esc_html($tk->title); ?></a>
            <?php if ( trim($tk->record_name) ) : ?><span class="sp-reminder-record"><?php echo esc_html( trim($tk->record_name) ); ?></span><?php endif; ?>
        </div>
        <span class="sp-reminder-due <?php echo $overdue ? 'sp-overdue' : ''; ?>">
            <?php echo $overdue ? 'Overdue · ' . esc_html( date('M j', strtotime($tk->due_date)) ) : 'Today'; ?>
        </span>
    </div>
    <?php endforeach; ?>
    <?php foreach ( $due_notes as $n ) :
        $link = home_url( '/sp-app/?view=' . $n->record_type . 's&action=view&id=' . $n->record_id . '&tab=notes' );
    ?>
    <div class="sp-reminder-item">
        <div class="sp-reminder-note-icon">📝</div>
        <div class="sp-reminder-body">
            <a href="<?php echo esc_url($link); ?>" class="sp-reminder-title"><?php echo esc_html( substr($n->content, 0, 80) . (strlen($n->content)>80?'…':'') ); ?></a>
            <?php if ( trim($n->record_name) ) : ?><span class="sp-reminder-record"><?php echo esc_html( trim($n->record_name) ); ?></span><?php endif; ?>
        </div>
        <span class="sp-reminder-due"><?php echo esc_html( date('M j g:ia', strtotime($n->reminder_at)) ); ?></span>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="sp-grid-2">
    <div class="sp-card">
        <div class="sp-card-header">
            <h2>Recent Contacts</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=new' ) ); ?>" class="sp-btn sp-btn-primary sp-btn-sm">+ Add</a>
        </div>
        <?php if ( empty( $recent_contacts ) ) : ?>
            <p class="sp-empty">No contacts yet.</p>
        <?php else : ?>
            <table class="sp-table">
                <tbody>
                <?php foreach ( $recent_contacts as $c ) : ?>
                    <tr>
                        <td><?php echo esc_html( trim( $c->first_name . ' ' . $c->last_name ) ); ?></td>
                        <td class="sp-muted"><?php echo esc_html( $c->email ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $c->status ); ?>"><?php echo esc_html( ucfirst( $c->status ) ); ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="sp-card">
        <div class="sp-card-header">
            <h2>Recent Leads</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&action=new' ) ); ?>" class="sp-btn sp-btn-primary sp-btn-sm">+ Add</a>
        </div>
        <?php if ( empty( $recent_leads ) ) : ?>
            <p class="sp-empty">No leads yet.</p>
        <?php else : ?>
            <table class="sp-table">
                <tbody>
                <?php foreach ( $recent_leads as $l ) : ?>
                    <tr>
                        <td><?php echo esc_html( trim( $l->first_name . ' ' . $l->last_name ) ); ?></td>
                        <td class="sp-muted"><?php echo esc_html( $l->source ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $l->status ); ?>"><?php echo esc_html( ucfirst( $l->status ) ); ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php do_action( 'sp_dashboard_after_grid' ); ?>
