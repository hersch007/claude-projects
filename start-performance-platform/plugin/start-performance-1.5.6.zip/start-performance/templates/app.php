<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$view    = sanitize_key( isset( $_GET['view'] ) ? $_GET['view'] : 'dashboard' );
$saved   = isset( $_GET['saved'] );
$allowed = apply_filters( 'sp_allowed_views', array( 'dashboard', 'contacts', 'companies', 'leads', 'settings', 'addons', 'team', 'import' ) );
if ( ! in_array( $view, $allowed ) ) $view = 'dashboard';

$view_file  = sp_get_view_file( $view );
$team_member = sp_get_current_team_member();
$is_admin   = sp_is_admin_member();
$logout     = esc_url( home_url( '/sp-app/?sp_logout=1' ) );
$is_super    = sp_is_super_admin();
$member_name = $team_member ? $team_member->name : ( $is_super ? 'Vendor' : 'User' );
$member_role = $team_member ? ucfirst( $team_member->role ) : ( $is_super ? 'Super Admin' : '' );
$member_init = strtoupper( substr( $member_name, 0, 1 ) );

// Reminder badge count for current user
$reminder_count = 0;
if ( $team_member && function_exists( 'sp_get_reminder_count' ) ) {
    $reminder_count = sp_get_reminder_count( $team_member->id );
}

// Core middle items — addons inject into their section via sp_nav_items filter
// Addons should use 'section_id' to identify which section they belong to
$nav_middle = apply_filters( 'sp_nav_items', array(
    array( 'view' => 'dashboard', 'label' => 'Dashboard', 'icon' => '<rect x="3" y="3" width="7" height="7" rx="1.5" fill="currentColor"/><rect x="14" y="3" width="7" height="7" rx="1.5" fill="currentColor"/><rect x="3" y="14" width="7" height="7" rx="1.5" fill="currentColor"/><rect x="14" y="14" width="7" height="7" rx="1.5" fill="currentColor"/>', 'badge' => $reminder_count ),

    array( 'section' => true, 'section_id' => 'core-system',      'label' => sp_section_label( 'core-system',      'Core System'       ) ),
    array( 'view' => 'contacts',  'label' => 'Contacts',  'icon' => '<path fill="currentColor" d="M12 12a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H5z"/>' ),
    array( 'view' => 'companies', 'label' => 'Companies', 'icon' => '<path fill="currentColor" d="M4 21V7a2 2 0 012-2h5V3h2v2h5a2 2 0 012 2v14H4zm2-2h4v-3H6v3zm6 0h4v-3h-4v3zm-6-5h4V9H6v5zm6 0h4V9h-4v5z"/>' ),
    array( 'view' => 'leads',     'label' => 'Leads',     'icon' => '<path fill="currentColor" d="M3.293 15.293a1 1 0 011.414 0L9 19.586l5.293-5.293a1 1 0 011.414 0l5 5a1 1 0 01-1.414 1.414L15 17.414l-5.293 5.293a1 1 0 01-1.414 0L3.293 16.707a1 1 0 010-1.414zM21 4h-6a1 1 0 110-2h8a1 1 0 011 1v8a1 1 0 11-2 0V4z"/>' ),

    array( 'section' => true, 'section_id' => 'chat-core',        'label' => sp_section_label( 'chat-core',        'Chat Core'         ) ),
    array( 'section' => true, 'section_id' => 'knowledge-core',   'label' => sp_section_label( 'knowledge-core',   'Knowledge Core'    ) ),
    array( 'section' => true, 'section_id' => 'sales-core',       'label' => sp_section_label( 'sales-core',       'Sales Core'        ) ),
    array( 'section' => true, 'section_id' => 'service-core',     'label' => sp_section_label( 'service-core',     'Service Core'      ) ),
    array( 'section' => true, 'section_id' => 'operations-core',  'label' => sp_section_label( 'operations-core',  'Operations Core'   ) ),
    array( 'section' => true, 'section_id' => 'intelligence-core','label' => sp_section_label( 'intelligence-core','Intelligence Core' ) ),
) );

// Bottom items — always pinned last, admin-only
$nav_bottom = array(
    array( 'section' => true, 'label' => 'Admin', 'view' => '', 'icon' => '', 'admin_only' => true ),
    array( 'view' => 'team',     'label' => 'Team',     'icon' => '<path fill="currentColor" d="M16 11a4 4 0 10-8 0 4 4 0 008 0zm-4 6c-4.418 0-8 1.79-8 4v1h16v-1c0-2.21-3.582-4-8-4zm6-10a3 3 0 015.83 1c0 1.657-1.343 3-3 3a3 3 0 01-2.83-2zm3 7c1.657 0 3 .895 3 2v.5h-3.5c.323-.607.5-1.28.5-2v-.5zm-16 0a3 3 0 01-3-3A3 3 0 016 7.83V8a3 3 0 01-3 3zm0 2v.5c0 .72.177 1.393.5 2H2v-.5c0-1.105 1.343-2 3-2z"/>', 'admin_only' => true ),
    array( 'view' => 'addons',   'label' => 'Add-ons',  'icon' => '<path fill="currentColor" d="M11 3a1 1 0 10-2 0v1H7a2 2 0 00-2 2v2H4a1 1 0 100 2h1v6H4a1 1 0 100 2h1v2a2 2 0 002 2h10a2 2 0 002-2v-2h1a1 1 0 100-2h-1V10h1a1 1 0 100-2h-1V6a2 2 0 00-2-2h-2V3a1 1 0 10-2 0v1h-2V3z"/>', 'admin_only' => true ),
    array( 'view' => 'settings', 'label' => 'Settings', 'icon' => '<path fill="currentColor" fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>', 'admin_only' => true ),
);

$nav_raw    = array_merge( $nav_middle, $nav_bottom );
$hidden_nav = get_option( 'sp_hidden_nav_items', array() );
if ( ! is_array( $hidden_nav ) ) $hidden_nav = array();

// Remove hidden views; also remove section headers that have no visible items beneath them
$nav            = array();
$pending_section = null;
foreach ( $nav_raw as $item ) {
    if ( ! empty( $item['section'] ) ) {
        $pending_section = $item;
        continue;
    }
    if ( ! empty( $item['view'] ) && in_array( $item['view'], $hidden_nav ) ) continue;
    if ( $pending_section !== null ) {
        $nav[]           = $pending_section;
        $pending_section = null;
    }
    $nav[] = $item;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Start Performance</title>
<link rel="stylesheet" href="<?php echo esc_url( SP_PLUGIN_URL . 'assets/css/app.css?v=' . SP_VERSION ); ?>">
<?php
$sp_accent         = get_option( 'sp_accent_color',      '#CC1F1F' );
$sp_accent_dark    = sp_darken_hex( $sp_accent, 0.15 );
$sp_accent_rgb     = sp_hex_to_rgb( $sp_accent );
$sp_sidebar_bg     = get_option( 'sp_sidebar_bg',        '' );
$sp_nav_color      = get_option( 'sp_nav_color',         '' );
$sp_nav_hover_color= get_option( 'sp_nav_hover_color',   '' );
$sp_nav_hover_bg   = get_option( 'sp_nav_hover_bg',      '' );
$custom_vars = '';
if ( $sp_sidebar_bg )      $custom_vars .= '--sp-sidebar-bg:' . esc_attr( $sp_sidebar_bg ) . ';';
if ( $sp_nav_color )       $custom_vars .= '--sp-nav-color:' . esc_attr( $sp_nav_color ) . ';';
if ( $sp_nav_hover_color ) $custom_vars .= '--sp-nav-hover-color:' . esc_attr( $sp_nav_hover_color ) . ';';
if ( $sp_nav_hover_bg )    $custom_vars .= '--sp-nav-hover-bg:' . esc_attr( $sp_nav_hover_bg ) . ';';
?>
<style>:root{--sp-accent:<?php echo esc_attr( $sp_accent ); ?>;--sp-accent-dark:<?php echo esc_attr( $sp_accent_dark ); ?>;--sp-accent-bg:rgba(<?php echo esc_attr( $sp_accent_rgb ); ?>,.18);<?php echo $custom_vars; ?>}</style>
</head>
<body>
<div class="sp-layout">

    <aside class="sp-sidebar">
        <div class="sp-brand">
            <?php
            $sp_icon_url   = get_option( 'sp_brand_icon_url', '' );
            $sp_initials   = get_option( 'sp_brand_initials', '' );
            $sp_brand_name = get_option( 'sp_platform_name', 'Start Performance' );
            if ( $sp_icon_url ) : ?>
                <img src="<?php echo esc_url( $sp_icon_url ); ?>" class="sp-brand-logo" alt="<?php echo esc_attr( $sp_brand_name ); ?>">
            <?php else : ?>
            <div class="sp-brand-icon">
                <?php if ( $sp_initials ) : ?>
                    <span style="font-size:<?php echo strlen( $sp_initials ) > 2 ? '10' : '13'; ?>px;font-weight:800;color:#fff;letter-spacing:-.5px;line-height:1"><?php echo esc_html( strtoupper( $sp_initials ) ); ?></span>
                <?php else : ?>
                <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="18" cy="18" r="3.5" fill="white"/>
                    <circle cx="18" cy="5"  r="2.5" fill="white"/>
                    <circle cx="18" cy="31" r="2.5" fill="white"/>
                    <circle cx="5"  cy="18" r="2.5" fill="white"/>
                    <circle cx="31" cy="18" r="2.5" fill="white"/>
                    <circle cx="8"  cy="8"  r="2.5" fill="white"/>
                    <circle cx="28" cy="8"  r="2.5" fill="white"/>
                    <circle cx="8"  cy="28" r="2.5" fill="white"/>
                    <circle cx="28" cy="28" r="2.5" fill="white"/>
                    <line x1="18" y1="14.5" x2="18" y2="7.5"   stroke="white" stroke-width="1.8"/>
                    <line x1="18" y1="21.5" x2="18" y2="28.5"  stroke="white" stroke-width="1.8"/>
                    <line x1="14.5" y1="18" x2="7.5"  y2="18"  stroke="white" stroke-width="1.8"/>
                    <line x1="21.5" y1="18" x2="28.5" y2="18"  stroke="white" stroke-width="1.8"/>
                    <line x1="15.5" y1="15.5" x2="10" y2="10"  stroke="white" stroke-width="1.8"/>
                    <line x1="20.5" y1="15.5" x2="26" y2="10"  stroke="white" stroke-width="1.8"/>
                    <line x1="15.5" y1="20.5" x2="10" y2="26"  stroke="white" stroke-width="1.8"/>
                    <line x1="20.5" y1="20.5" x2="26" y2="26"  stroke="white" stroke-width="1.8"/>
                </svg>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <span class="sp-brand-name"><?php echo esc_html( $sp_brand_name ); ?></span>
        </div>

        <?php
        // Find which section contains the active view (for auto-open)
        $active_section_key  = null;
        $current_section_key = null;
        foreach ( $nav as $item ) {
            if ( ! empty( $item['section'] ) ) {
                $current_section_key = ! empty( $item['section_id'] ) ? $item['section_id'] : sanitize_title( $item['label'] );
            } elseif ( ! empty( $item['view'] ) && $item['view'] === $view ) {
                $active_section_key = $current_section_key;
            }
        }
        ?>
        <nav class="sp-nav" data-active-section="<?php echo esc_attr( $active_section_key ); ?>">
            <?php
            $in_group = false;
            foreach ( $nav as $item ) {
                if ( ! empty( $item['admin_only'] ) && ! $is_admin ) continue;
                if ( ! empty( $item['section'] ) ) {
                    if ( $in_group ) { echo '</div></div>'; $in_group = false; }
                    $sk = ! empty( $item['section_id'] ) ? $item['section_id'] : sanitize_title( $item['label'] );
                    echo '<div class="sp-nav-group" data-section="' . esc_attr( $sk ) . '">';
                    echo '<button type="button" class="sp-nav-section-toggle" data-section="' . esc_attr( $sk ) . '">';
                    echo '<span>' . esc_html( $item['label'] ) . '</span>';
                    echo '<svg class="sp-nav-chevron" viewBox="0 0 24 24" fill="none" width="12" height="12"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    echo '</button>';
                    echo '<div class="sp-nav-group-items">';
                    $in_group = true;
                } else {
                    $icon = ! empty( $item['icon'] ) ? $item['icon'] : '';
                    $is_active = ( ! empty( $item['view'] ) && $item['view'] === $view ) ? ' active' : '';
                    echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $item['view'] ) ) . '" class="sp-nav-item' . $is_active . '">';
                    echo '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">';
                    if ( strpos( $icon, '<path' ) !== false || strpos( $icon, '<rect' ) !== false ) {
                        echo $icon;
                    } else {
                        echo '<path fill="currentColor" d="' . esc_attr( $icon ) . '"/>';
                    }
                    echo '</svg>';
                    echo esc_html( $item['label'] );
                    if ( ! empty( $item['addon'] ) ) { echo '<span class="sp-nav-addon">+</span>'; }
                    if ( ! empty( $item['badge'] ) ) { echo '<span class="sp-nav-badge">' . (int) $item['badge'] . '</span>'; }
                    echo '</a>';
                }
            }
            if ( $in_group ) { echo '</div></div>'; }
            ?>
        </nav>

        <div class="sp-sidebar-footer">
            <div class="sp-user">
                <div class="sp-avatar"><?php echo esc_html( $member_init ); ?></div>
                <div class="sp-user-info">
                    <div class="sp-user-name"><?php echo esc_html( $member_name ); ?></div>
                    <div class="sp-user-role"><?php echo esc_html( $member_role ); ?></div>
                </div>
                <a href="<?php echo $logout; ?>" class="sp-logout" title="Sign out">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                        <path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                </a>
            </div>
        </div>
    </aside>

    <main class="sp-main">
        <?php if ( $saved ) : ?>
            <div class="sp-toast">Saved successfully.</div>
        <?php endif; ?>
        <?php if ( $view_file ) require $view_file; ?>
    </main>

</div>
<script src="<?php echo esc_url( SP_PLUGIN_URL . 'assets/js/app.js?v=' . SP_VERSION ); ?>"></script>
</body>
</html>
