<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$settings  = sp_smti_get_settings();
$action    = sanitize_key( isset( $_GET['action'] ) ? $_GET['action'] : 'list' );
$ticket_id = sanitize_text_field( isset( $_GET['id'] ) ? $_GET['id'] : '' );

// ── Not configured notice ─────────────────────────────────────────────────────
if ( empty( $settings['hubspot_token'] ) ) {
    ?>
    <div class="sp-page-header"><h1>Service Requests</h1></div>
    <div class="sp-card sp-form-card">
        <p style="color:#64748b;margin:0">HubSpot is not configured. Go to <a href="<?php echo esc_url( home_url( '/sp-app/?view=settings' ) ); ?>" class="sp-link">Settings</a> and add your HubSpot Private App Token.</p>
    </div>
    <?php
    return;
}

// ── Detail view ───────────────────────────────────────────────────────────────
if ( $action === 'detail' && $ticket_id !== '' ) {

    $stage_map = sp_smti_stage_map();
    $response  = sp_smti_hs_request( 'GET', '/crm/v3/objects/tickets/' . rawurlencode( $ticket_id ) . '?properties=' . rawurlencode( implode( ',', sp_smti_ticket_properties() ) ) );

    if ( is_wp_error( $response ) || (int) $response['status'] !== 200 || empty( $response['body'] ) ) {
        echo '<div class="sp-page-header"><h1>Service Requests</h1><a href="' . esc_url( home_url( '/sp-app/?view=smti' ) ) . '" class="sp-btn sp-btn-ghost">&larr; Back</a></div>';
        echo '<p class="sp-empty">Ticket not found or HubSpot error.</p>';
        return;
    }

    $ticket  = sp_smti_ticket_summary( $response['body'], $stage_map );
    $content = $ticket['content'];

    // Fetch associated contacts, companies, notes
    $get_assoc_ids = function( $from_type, $from_id, $to_type ) {
        $r = sp_smti_hs_request( 'GET', '/crm/v4/objects/' . rawurlencode( $from_type ) . '/' . rawurlencode( $from_id ) . '/associations/' . rawurlencode( $to_type ) . '?limit=10' );
        if ( is_wp_error( $r ) || (int) $r['status'] !== 200 || empty( $r['body']['results'] ) ) return array();
        $ids = array();
        foreach ( $r['body']['results'] as $row ) { if ( isset( $row['toObjectId'] ) ) $ids[] = (string) $row['toObjectId']; }
        return array_values( array_unique( $ids ) );
    };

    $get_obj = function( $type, $id, $props ) {
        $r = sp_smti_hs_request( 'GET', '/crm/v3/objects/' . rawurlencode( $type ) . '/' . rawurlencode( $id ) . '?properties=' . rawurlencode( implode( ',', $props ) ) );
        if ( is_wp_error( $r ) || (int) $r['status'] !== 200 || empty( $r['body'] ) ) return array();
        return $r['body'];
    };

    $contact_ids = $get_assoc_ids( 'tickets', $ticket_id, 'contacts' );
    $company_ids = $get_assoc_ids( 'tickets', $ticket_id, 'companies' );
    $note_ids    = $get_assoc_ids( 'tickets', $ticket_id, 'notes' );

    $contacts = array();
    foreach ( array_slice( $contact_ids, 0, 3 ) as $cid ) {
        $obj = $get_obj( 'contacts', $cid, array( 'firstname', 'lastname', 'email', 'phone', 'company' ) );
        if ( ! empty( $obj ) ) $contacts[] = $obj;
    }
    $companies = array();
    foreach ( array_slice( $company_ids, 0, 3 ) as $coid ) {
        $obj = $get_obj( 'companies', $coid, array( 'name', 'phone', 'domain', 'city', 'state', 'zip' ) );
        if ( ! empty( $obj ) ) $companies[] = $obj;
    }
    $notes = array();
    foreach ( array_slice( $note_ids, 0, 10 ) as $nid ) {
        $obj = $get_obj( 'notes', $nid, array( 'hs_note_body', 'hs_timestamp' ) );
        if ( ! empty( $obj ) ) $notes[] = $obj;
    }
    usort( $notes, function( $a, $b ) {
        $ta = isset( $a['properties']['hs_timestamp'] ) ? $a['properties']['hs_timestamp'] : '';
        $tb = isset( $b['properties']['hs_timestamp'] ) ? $b['properties']['hs_timestamp'] : '';
        return strcmp( $tb, $ta );
    } );

    $owners  = sp_smti_is_admin_member_check() ? sp_smti_get_owners_list() : array();
    $is_adm  = sp_smti_is_admin_member_check();
    $created = $ticket['createdate']       ? date( 'M j, Y g:i a', strtotime( $ticket['createdate'] ) )       : '—';
    $updated = $ticket['lastmodifieddate'] ? date( 'M j, Y g:i a', strtotime( $ticket['lastmodifieddate'] ) ) : '—';
    ?>
    <div class="sp-page-header">
        <h1><?php echo esc_html( $ticket['service_request_number'] ? $ticket['service_request_number'] : 'Service Request' ); ?></h1>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=smti' ) ); ?>" class="sp-btn sp-btn-ghost">&larr; All Requests</a>
    </div>

    <div style="display:grid;grid-template-columns:1fr 320px;gap:16px;align-items:start">

        <div>
            <!-- Ticket info -->
            <div class="sp-card sp-form-card">
                <h2 class="sp-section-heading">Ticket Details</h2>
                <p style="font-size:15px;font-weight:600;margin:0 0 12px"><?php echo esc_html( $ticket['subject'] ); ?></p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 24px;font-size:13px;color:#64748b">
                    <div><strong style="color:#1e293b">Status</strong><br>
                        <?php if ( $ticket['status'] ) : ?><span class="sp-badge" style="background:#f1f5f9;color:#334155"><?php echo esc_html( $ticket['status'] ); ?></span><?php else : ?>—<?php endif; ?>
                    </div>
                    <div><strong style="color:#1e293b">Serial Number</strong><br><?php echo esc_html( $ticket['serial_number'] ? $ticket['serial_number'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Company / Facility</strong><br><?php echo esc_html( $ticket['company'] ? $ticket['company'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Location</strong><br><?php echo esc_html( $ticket['location_name'] ? $ticket['location_name'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Part ID</strong><br><?php echo esc_html( $ticket['part_id'] ? $ticket['part_id'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Equipment Model</strong><br><?php echo esc_html( $ticket['equipment_model'] ? $ticket['equipment_model'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Contact</strong><br><?php echo esc_html( $ticket['contact_name'] ? $ticket['contact_name'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Contact Email</strong><br><?php echo esc_html( $ticket['contact_email'] ? $ticket['contact_email'] : '—' ); ?></div>
                    <div><strong style="color:#1e293b">Created</strong><br><?php echo esc_html( $created ); ?></div>
                    <div><strong style="color:#1e293b">Last Updated</strong><br><?php echo esc_html( $updated ); ?></div>
                </div>

                <?php if ( $content ) : ?>
                <details style="margin-top:16px">
                    <summary style="cursor:pointer;font-size:13px;font-weight:600;color:#64748b">Full Ticket Body</summary>
                    <pre style="margin-top:8px;padding:12px;background:#f8fafc;border-radius:6px;font-size:12px;white-space:pre-wrap;overflow:auto;max-height:300px;color:#334155"><?php echo esc_html( $content ); ?></pre>
                </details>
                <?php endif; ?>
            </div>

            <!-- Contacts -->
            <?php if ( ! empty( $contacts ) ) : ?>
            <div class="sp-card sp-form-card" style="margin-top:16px">
                <h2 class="sp-section-heading">Associated Contacts</h2>
                <?php foreach ( $contacts as $c ) :
                    $props = isset( $c['properties'] ) ? $c['properties'] : array();
                    $fname = isset( $props['firstname'] ) ? $props['firstname'] : '';
                    $lname = isset( $props['lastname'] )  ? $props['lastname']  : '';
                    $cemail = isset( $props['email'] )    ? $props['email']     : '';
                    $cphone = isset( $props['phone'] )    ? $props['phone']     : '';
                    ?>
                    <div style="padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:13px">
                        <strong><?php echo esc_html( trim( $fname . ' ' . $lname ) ); ?></strong>
                        <?php if ( $cemail ) echo ' &mdash; ' . esc_html( $cemail ); ?>
                        <?php if ( $cphone ) echo ' &mdash; ' . esc_html( $cphone ); ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Notes -->
            <div class="sp-card sp-form-card" style="margin-top:16px">
                <h2 class="sp-section-heading">Notes &amp; Activity</h2>
                <?php if ( empty( $notes ) ) : ?>
                    <p class="sp-empty" style="margin:0">No notes yet.</p>
                <?php else : ?>
                    <?php foreach ( $notes as $note ) :
                        $np        = isset( $note['properties'] ) ? $note['properties'] : array();
                        $note_body = isset( $np['hs_note_body'] ) ? $np['hs_note_body'] : '';
                        $note_ts   = isset( $np['hs_timestamp'] ) ? date( 'M j, Y g:i a', strtotime( $np['hs_timestamp'] ) ) : '';
                        ?>
                        <div style="padding:10px 0;border-bottom:1px solid #f1f5f9">
                            <?php if ( $note_ts ) : ?><div style="font-size:11px;color:#94a3b8;margin-bottom:4px"><?php echo esc_html( $note_ts ); ?></div><?php endif; ?>
                            <div style="font-size:13px;color:#334155;line-height:1.6"><?php echo wp_kses( $note_body, array( 'br' => array() ) ); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <!-- Add note form -->
                <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" style="margin-top:16px">
                    <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
                    <input type="hidden" name="sp_type"   value="smti_note">
                    <input type="hidden" name="sp_id"     value="0">
                    <input type="hidden" name="ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>">
                    <div class="sp-field">
                        <label>Add Internal Note</label>
                        <textarea name="note" rows="3" placeholder="Enter note..."></textarea>
                    </div>
                    <button type="submit" class="sp-btn sp-btn-primary sp-btn-sm">Add Note</button>
                </form>
            </div>
        </div>

        <!-- Right sidebar: actions -->
        <div>
            <?php if ( $is_adm && ! empty( $stage_map ) ) : ?>
            <div class="sp-card sp-form-card">
                <h2 class="sp-section-heading">Update Status</h2>
                <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
                    <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
                    <input type="hidden" name="sp_type"   value="smti_stage">
                    <input type="hidden" name="sp_id"     value="0">
                    <input type="hidden" name="ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>">
                    <div class="sp-field">
                        <select name="stage_id">
                            <?php foreach ( $stage_map as $sid => $slabel ) : ?>
                                <option value="<?php echo esc_attr( $sid ); ?>" <?php selected( $ticket['stage_id'], $sid ); ?>><?php echo esc_html( $slabel ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="sp-btn sp-btn-primary" style="width:100%">Update Status</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if ( $is_adm && ! empty( $owners ) ) : ?>
            <div class="sp-card sp-form-card" style="margin-top:16px">
                <h2 class="sp-section-heading">Assign Technician</h2>
                <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
                    <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
                    <input type="hidden" name="sp_type"   value="smti_assign">
                    <input type="hidden" name="sp_id"     value="0">
                    <input type="hidden" name="ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>">
                    <div class="sp-field">
                        <select name="owner_id">
                            <option value="">— Select owner —</option>
                            <?php foreach ( $owners as $owner ) : ?>
                                <option value="<?php echo esc_attr( $owner['id'] ); ?>"><?php echo esc_html( $owner['label'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="sp-btn sp-btn-ghost" style="width:100%">Assign</button>
                </form>
            </div>
            <?php endif; ?>

            <div class="sp-card sp-form-card" style="margin-top:16px">
                <h2 class="sp-section-heading">Ticket ID</h2>
                <p style="font-size:13px;color:#64748b;margin:0;word-break:break-all"><?php echo esc_html( $ticket_id ); ?></p>
            </div>
        </div>
    </div>
    <?php
    return;
}

// ── List view ─────────────────────────────────────────────────────────────────

$filter_stage = sanitize_text_field( isset( $_GET['status'] ) ? $_GET['status'] : '' );
$search       = sanitize_text_field( isset( $_GET['q'] )      ? $_GET['q']      : '' );
$limit        = 50;
$stage_map    = sp_smti_stage_map();
$pipeline     = trim( $settings['ticket_pipeline_id'] );

$filters = array();
if ( $pipeline !== '' && $pipeline !== '0' ) {
    $filters[] = array( 'propertyName' => 'hs_pipeline', 'operator' => 'EQ', 'value' => $pipeline );
}
if ( $filter_stage !== '' && strtolower( $filter_stage ) !== 'all' ) {
    $filters[] = array( 'propertyName' => 'hs_pipeline_stage', 'operator' => 'EQ', 'value' => $filter_stage );
}
$search_body = array(
    'properties' => sp_smti_ticket_properties(),
    'sorts'      => array( '-createdate' ),
    'limit'      => $limit,
);
if ( ! empty( $filters ) ) {
    $search_body['filterGroups'] = array( array( 'filters' => $filters ) );
}
if ( $search !== '' ) {
    $search_body['query'] = $search;
}

$response = sp_smti_hs_request( 'POST', '/crm/v3/objects/tickets/search', $search_body );
$tickets  = array();
$total    = 0;
if ( ! is_wp_error( $response ) && (int) $response['status'] === 200 ) {
    $total   = isset( $response['body']['total'] ) ? (int) $response['body']['total'] : 0;
    $results = isset( $response['body']['results'] ) ? $response['body']['results'] : array();
    foreach ( $results as $t ) {
        $tickets[] = sp_smti_ticket_summary( $t, $stage_map );
    }
}
?>
<div class="sp-page-header">
    <h1>Service Requests <span class="sp-count"><?php echo number_format( $total ); ?></span></h1>
    <div class="sp-header-actions">
        <form method="get" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" class="sp-search-form">
            <input type="hidden" name="view" value="smti">
            <input type="search" name="q" value="<?php echo esc_attr( $search ); ?>" placeholder="Search...">
            <select name="status" onchange="this.form.submit()">
                <option value="">All Statuses</option>
                <?php foreach ( $stage_map as $sid => $slabel ) : ?>
                    <option value="<?php echo esc_attr( $sid ); ?>" <?php selected( $filter_stage, $sid ); ?>><?php echo esc_html( $slabel ); ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<div class="sp-card sp-table-card">
    <table class="sp-table">
        <thead>
            <tr><th>Request #</th><th>Subject</th><th>Company</th><th>Serial #</th><th>Contact</th><th>Status</th><th>Created</th></tr>
        </thead>
        <tbody>
        <?php if ( empty( $tickets ) ) : ?>
            <tr><td colspan="7" class="sp-empty">No service requests found<?php echo $search ? ' matching "' . esc_html( $search ) . '"' : ''; ?>.</td></tr>
        <?php else : foreach ( $tickets as $t ) :
            $created = $t['createdate'] ? date( 'M j, Y', strtotime( $t['createdate'] ) ) : '—';
            ?>
            <tr>
                <td><a href="<?php echo esc_url( home_url( '/sp-app/?view=smti&action=detail&id=' . $t['ticket_id'] ) ); ?>" class="sp-link"><?php echo esc_html( $t['service_request_number'] ? $t['service_request_number'] : $t['ticket_id'] ); ?></a></td>
                <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( $t['subject'] ); ?></td>
                <td class="sp-muted"><?php echo esc_html( $t['company'] ? $t['company'] : '—' ); ?></td>
                <td class="sp-muted"><?php echo esc_html( $t['serial_number'] ? $t['serial_number'] : '—' ); ?></td>
                <td class="sp-muted"><?php echo esc_html( $t['contact_name'] ? $t['contact_name'] : '—' ); ?></td>
                <td><?php if ( $t['status'] ) : ?><span class="sp-badge" style="background:#f1f5f9;color:#334155"><?php echo esc_html( $t['status'] ); ?></span><?php else : ?>—<?php endif; ?></td>
                <td class="sp-muted"><?php echo esc_html( $created ); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php if ( $total > $limit ) : ?>
        <p style="font-size:12px;color:#94a3b8;padding:12px 16px;margin:0">Showing <?php echo count( $tickets ); ?> of <?php echo number_format( $total ); ?> results. Use search or status filter to narrow down.</p>
    <?php endif; ?>
</div>
<?php

function sp_smti_is_admin_member_check() {
    return function_exists( 'sp_is_admin_member' ) && sp_is_admin_member();
}
