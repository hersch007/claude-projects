<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$error = sanitize_key( isset( $_GET['error'] ) ? $_GET['error'] : '' );

if ( $error === 'pin' ) {
    $error_msg = 'Incorrect PIN. Please try again.';
} elseif ( $error === 'invalid' ) {
    $error_msg = 'Invalid request. Please try again.';
} else {
    $error_msg = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — Start Performance</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0f172a;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#1e293b;border:1px solid #334155;border-radius:16px;padding:40px;width:100%;max-width:380px;text-align:center}
.logo-mark{width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,#0057FF,#003FC7);display:inline-flex;align-items:center;justify-content:center;margin-bottom:14px}
.logo-mark svg{width:28px;height:28px}
.logo-name{font-size:20px;font-weight:800;color:#fff;margin-bottom:6px}
.logo-tag{font-size:13px;color:#475569;margin-bottom:36px}
h1{font-size:17px;font-weight:700;color:#f1f5f9;margin-bottom:6px}
p{font-size:14px;color:#64748b;margin-bottom:28px}
.pin-input{width:100%;background:#0f172a;border:2px solid #334155;border-radius:10px;padding:18px;font-size:28px;font-weight:700;color:#f1f5f9;text-align:center;letter-spacing:12px;outline:none;margin-bottom:20px}
.pin-input:focus{border-color:#0057FF}
button{width:100%;background:#0057FF;color:#fff;font-size:15px;font-weight:700;border:none;border-radius:8px;padding:14px;cursor:pointer}
button:hover{background:#0041CC}
.error{background:#450a0a;border:1px solid #7f1d1d;border-radius:8px;padding:12px 14px;font-size:13px;color:#fca5a5;margin-bottom:20px}
.footer{margin-top:24px;font-size:12px;color:#334155}
</style>
</head>
<body>
<div class="card">
    <div class="logo-mark">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="#fff" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/>
        </svg>
    </div>
    <div class="logo-name">Start Performance</div>
    <div class="logo-tag">Business Operating Platform</div>

    <h1>Enter your PIN</h1>
    <p>Enter your 4-digit PIN to continue</p>

    <?php if ( $error_msg ) : ?>
        <div class="error"><?php echo esc_html( $error_msg ); ?></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( home_url( '/sp-login/' ) ); ?>">
        <?php wp_nonce_field( 'sp_login', 'sp_login_nonce' ); ?>
        <input type="password" name="pin" class="pin-input" maxlength="8" inputmode="numeric" pattern="[0-9]*" placeholder="••••" autofocus required>
        <button type="submit">Sign In &rarr;</button>
    </form>

    <div class="footer">Start Performance v<?php echo esc_html( SP_VERSION ); ?></div>
</div>
</body>
</html>
