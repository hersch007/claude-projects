<?php
/*
 * Plugin Name: Start Performance — Intelligence Core
 * Description: KPI dashboard and business intelligence for the Start Performance Platform
 * Version:     1.0.0
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_INTEL_VERSION',    '1.0.0' );
define( 'SP_INTEL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

add_action( 'plugins_loaded', 'sp_intel_boot', 20 );

function sp_intel_boot() {
    if ( ! function_exists( 'sp_register_view' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Start Performance — Intelligence Core</strong> requires the Start Performance core plugin.</p></div>';
        } );
        return;
    }
    sp_intel_register();
}

function sp_intel_register() {
    sp_register_addon( 'sp-intelligence', array(
        'name'        => 'Intelligence Core',
        'version'     => SP_INTEL_VERSION,
        'description' => 'KPI dashboard, business performance metrics, and pipeline insights across all active modules.',
        'icon'        => '<path fill="currentColor" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>',
        'plugin_file' => plugin_basename( __FILE__ ),
        'core_slot'   => 'intelligence-core',
    ) );

    sp_register_view( 'intelligence', SP_INTEL_PLUGIN_DIR . 'templates/views/intelligence.php' );

    add_filter( 'sp_nav_items',     'sp_intel_nav_items' );
    add_filter( 'sp_allowed_views', 'sp_intel_allowed_views' );
}

function sp_intel_nav_items( $items ) {
    $result = array();
    foreach ( $items as $item ) {
        $result[] = $item;
        if ( ! empty( $item['section'] ) && ! empty( $item['section_id'] ) && $item['section_id'] === 'intelligence-core' ) {
            $result[] = array(
                'view'  => 'intelligence',
                'label' => 'KPI Dashboard',
                'icon'  => '<path fill="currentColor" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>',
            );
        }
    }
    return $result;
}

function sp_intel_allowed_views( $views ) {
    $views[] = 'intelligence';
    return $views;
}
