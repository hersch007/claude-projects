<?php
/*
 * Plugin Name: Start Performance - SMTI Sales
 * Description: Sales quote builder for SMTI — distributor quotes, HubSpot deal sync, print output.
 * Version:     1.0.3
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_SMTI_SALES_VERSION',    '1.0.3' );
define( 'SP_SMTI_SALES_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// ── Boot ──────────────────────────────────────────────────────────────────────

add_action( 'plugins_loaded', 'sp_smti_sales_boot', 25 );

function sp_smti_sales_boot() {
    if ( ! function_exists( 'sp_register_view' ) ) {
        add_action( 'admin_notices', 'sp_smti_sales_dependency_notice' );
        return;
    }
    sp_smti_sales_register();
}

function sp_smti_sales_dependency_notice() {
    echo '<div class="notice notice-error"><p><strong>Start Performance — SMTI Sales</strong> requires the Start Performance core plugin.</p></div>';
}

// ── Registration ──────────────────────────────────────────────────────────────

function sp_smti_sales_register() {
    sp_register_addon( 'sp-smti-sales', array(
        'name'        => 'SMTI Sales',
        'version'     => SP_SMTI_SALES_VERSION,
        'description' => 'Distributor quote builder with HubSpot deal sync and print output.',
        'icon'        => '<path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>',
    ) );

    sp_register_view( 'smti-sales', SP_SMTI_SALES_PLUGIN_DIR . 'templates/views/smti-sales.php' );

    add_filter( 'sp_nav_items',     'sp_smti_sales_nav_items', 12 );
    add_filter( 'sp_allowed_views', 'sp_smti_sales_allowed_views' );
    add_action( 'sp_settings_sections', 'sp_smti_sales_settings_section' );
    add_action( 'sp_post_handler_smti_sales_settings', 'sp_smti_sales_save_settings' );

    // AJAX handlers (work for non-WP-logged-in SP users)
    add_action( 'wp_ajax_nopriv_sp_smti_sales_search',      'sp_smti_sales_ajax_search' );
    add_action( 'wp_ajax_sp_smti_sales_search',             'sp_smti_sales_ajax_search' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_contact',     'sp_smti_sales_ajax_contact' );
    add_action( 'wp_ajax_sp_smti_sales_contact',            'sp_smti_sales_ajax_contact' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_save_quote',  'sp_smti_sales_ajax_save_quote' );
    add_action( 'wp_ajax_sp_smti_sales_save_quote',         'sp_smti_sales_ajax_save_quote' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_load_quote',  'sp_smti_sales_ajax_load_quote' );
    add_action( 'wp_ajax_sp_smti_sales_load_quote',         'sp_smti_sales_ajax_load_quote' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_revisions',   'sp_smti_sales_ajax_revisions' );
    add_action( 'wp_ajax_sp_smti_sales_revisions',          'sp_smti_sales_ajax_revisions' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_compare',     'sp_smti_sales_ajax_compare' );
    add_action( 'wp_ajax_sp_smti_sales_compare',            'sp_smti_sales_ajax_compare' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_sync',        'sp_smti_sales_ajax_sync' );
    add_action( 'wp_ajax_sp_smti_sales_sync',               'sp_smti_sales_ajax_sync' );
    add_action( 'wp_ajax_nopriv_sp_smti_sales_quotes_list', 'sp_smti_sales_ajax_quotes_list' );
    add_action( 'wp_ajax_sp_smti_sales_quotes_list',        'sp_smti_sales_ajax_quotes_list' );
}

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_smti_sales_activate' );
add_action( 'sp_activate', 'sp_smti_sales_create_tables' );

function sp_smti_sales_activate() {
    sp_smti_sales_create_tables();
}

function sp_smti_sales_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_smti_products (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  product_code varchar(50) NOT NULL DEFAULT '',
  product_title varchar(255) NOT NULL DEFAULT '',
  category varchar(100) NOT NULL DEFAULT '',
  product_description text,
  unit_price decimal(10,4) NOT NULL DEFAULT 0.0000,
  dealer_price decimal(10,4) NOT NULL DEFAULT 0.0000,
  location varchar(10) NOT NULL DEFAULT 'us',
  active tinyint(1) NOT NULL DEFAULT 1,
  allow_discount tinyint(1) NOT NULL DEFAULT 1,
  max_discount_percent int(11) NOT NULL DEFAULT 10,
  collateral_file varchar(500) NOT NULL DEFAULT '',
  sort_order int(11) NOT NULL DEFAULT 0,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY product_code (product_code),
  KEY location (location)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_smti_distributors (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  slug varchar(100) NOT NULL DEFAULT '',
  name varchar(255) NOT NULL DEFAULT '',
  company varchar(255) NOT NULL DEFAULT '',
  title varchar(255) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  email varchar(100) NOT NULL DEFAULT '',
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY slug (slug)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_smti_quotes (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  quote_number varchar(50) NOT NULL DEFAULT '',
  deal_id varchar(50) NOT NULL DEFAULT '',
  contact_id varchar(50) NOT NULL DEFAULT '',
  customer_name varchar(255) NOT NULL DEFAULT '',
  company_name varchar(255) NOT NULL DEFAULT '',
  pricing_region varchar(10) NOT NULL DEFAULT 'us',
  subtotal decimal(12,2) NOT NULL DEFAULT 0.00,
  discount_amount decimal(12,2) NOT NULL DEFAULT 0.00,
  freight_amount decimal(12,2) NOT NULL DEFAULT 0.00,
  total decimal(12,2) NOT NULL DEFAULT 0.00,
  status varchar(30) NOT NULL DEFAULT 'Draft',
  created_by varchar(100) NOT NULL DEFAULT '',
  quote_json longtext,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY quote_number (quote_number),
  KEY deal_id (deal_id),
  KEY status (status),
  KEY updated_at (updated_at)
) $charset;" );
}

// ── Nav filter ────────────────────────────────────────────────────────────────

function sp_smti_sales_nav_items( $items ) {
    $items[] = array( 'section' => true, 'label' => 'Sales', 'view' => '', 'icon' => '' );
    $items[] = array(
        'view'  => 'smti-sales',
        'label' => 'Quotes',
        'icon'  => '<path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>',
        'addon' => true,
    );
    return $items;
}

// ── Allowed views ─────────────────────────────────────────────────────────────

function sp_smti_sales_allowed_views( $views ) {
    $views[] = 'smti-sales';
    return $views;
}

// ── Settings section ──────────────────────────────────────────────────────────

function sp_smti_sales_settings_section() {
    $api_base    = get_option( 'sp_smti_sales_api_base',    'https://startwebservicesbackup.com/smti/wp-json/smti/v1' );
    $api_token   = get_option( 'sp_smti_sales_api_token',   'smti_live_9a7f3d21e6b84c54b9c2f18d6a73e4ab' );
    $hs_pat      = get_option( 'sp_smti_sales_hs_pat',      '' );
    $products_id = get_option( 'sp_smti_sales_products_id', '213697055' );
    $distrib_id  = get_option( 'sp_smti_sales_distrib_id',  '224700762' );
    $logo_url    = get_option( 'sp_smti_sales_logo_url',    '' );
    $company     = get_option( 'sp_smti_sales_company',     'Sport Medical Technology Inc' );
    $address     = get_option( 'sp_smti_sales_address',     "49 Natcon Dr\nShirley, NY 11967\nUnited States of America" );
    $terms       = get_option( 'sp_smti_sales_terms',       'This Quotation is valid for 30 days. All prices and costs indicated herein are paid by the customer to Sport Medical Technology Inc. with no allowable deductions for banking or other charges.' );
    ?>
    <div class="sp-card sp-form-card" style="margin-top:16px">
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="smti_sales_settings">
            <input type="hidden" name="sp_id" value="0">
            <h2 class="sp-section-heading">SMTI Sales Settings</h2>

            <div class="sp-field">
                <label>Sales API Base URL</label>
                <input type="text" name="sp_smti_sales_api_base" value="<?php echo esc_attr( $api_base ); ?>">
                <span class="sp-hint">URL of the SMTI WordPress API (old install)</span>
            </div>
            <div class="sp-field">
                <label>Sales API Token</label>
                <input type="text" name="sp_smti_sales_api_token" value="<?php echo esc_attr( $api_token ); ?>" autocomplete="new-password">
            </div>
            <div class="sp-field">
                <label>HubSpot Private App Token (for product sync)</label>
                <input type="password" name="sp_smti_sales_hs_pat" value="<?php echo esc_attr( $hs_pat ); ?>" autocomplete="new-password">
                <span class="sp-hint">Required to sync products from HubDB. Found in HubSpot → Settings → Integrations → Private Apps.</span>
            </div>
            <div class="sp-field">
                <label>Products HubDB Table ID</label>
                <input type="text" name="sp_smti_sales_products_id" value="<?php echo esc_attr( $products_id ); ?>">
            </div>
            <div class="sp-field">
                <label>Distributors HubDB Table ID</label>
                <input type="text" name="sp_smti_sales_distrib_id" value="<?php echo esc_attr( $distrib_id ); ?>">
            </div>
            <div class="sp-field">
                <label>Company Name (on quotes)</label>
                <input type="text" name="sp_smti_sales_company" value="<?php echo esc_attr( $company ); ?>">
            </div>
            <div class="sp-field">
                <label>Company Address (on quotes)</label>
                <textarea name="sp_smti_sales_address" rows="3"><?php echo esc_textarea( $address ); ?></textarea>
            </div>
            <div class="sp-field">
                <label>Logo URL</label>
                <input type="text" name="sp_smti_sales_logo_url" value="<?php echo esc_attr( $logo_url ); ?>">
            </div>
            <div class="sp-field">
                <label>Quote Terms</label>
                <textarea name="sp_smti_sales_terms" rows="4"><?php echo esc_textarea( $terms ); ?></textarea>
            </div>

            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save Sales Settings</button>
            </div>
        </form>
    </div>
    <?php
}

function sp_smti_sales_save_settings( $id ) {
    if ( ! sp_is_admin_member() ) {
        wp_redirect( home_url( '/sp-app/?view=settings' ) ); exit;
    }
    $fields = array(
        'sp_smti_sales_api_base'    => 'esc_url_raw',
        'sp_smti_sales_api_token'   => 'sanitize_text_field',
        'sp_smti_sales_hs_pat'      => 'sanitize_text_field',
        'sp_smti_sales_products_id' => 'sanitize_text_field',
        'sp_smti_sales_distrib_id'  => 'sanitize_text_field',
        'sp_smti_sales_company'     => 'sanitize_text_field',
        'sp_smti_sales_address'     => 'sanitize_textarea_field',
        'sp_smti_sales_logo_url'    => 'esc_url_raw',
        'sp_smti_sales_terms'       => 'sanitize_textarea_field',
    );
    foreach ( $fields as $key => $sanitizer ) {
        if ( isset( $_POST[ $key ] ) ) {
            update_option( $key, call_user_func( $sanitizer, wp_unslash( $_POST[ $key ] ) ) );
        }
    }
    wp_redirect( home_url( '/sp-app/?view=settings&saved=1' ) ); exit;
}

// ── AJAX: Auth check ──────────────────────────────────────────────────────────

function sp_smti_sales_auth_check() {
    if ( ! function_exists( 'sp_get_current_team_member' ) || ! sp_get_current_team_member() ) {
        wp_send_json_error( array( 'message' => 'Not authenticated' ) );
        exit;
    }
}

// ── AJAX: Customer search ─────────────────────────────────────────────────────

function sp_smti_sales_ajax_search() {
    sp_smti_sales_auth_check();
    $q = sanitize_text_field( isset( $_POST['q'] ) ? wp_unslash( $_POST['q'] ) : '' );
    if ( strlen( $q ) < 2 ) {
        wp_send_json_success( array( 'results' => array() ) );
    }
    $response = sp_smti_sales_api_request( 'GET', '/search-contacts?q=' . urlencode( $q ) );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    wp_send_json_success( $response );
}

// ── AJAX: Contact details ─────────────────────────────────────────────────────

function sp_smti_sales_ajax_contact() {
    sp_smti_sales_auth_check();
    $contact_id = sanitize_text_field( isset( $_POST['contact_id'] ) ? wp_unslash( $_POST['contact_id'] ) : '' );
    if ( ! $contact_id ) {
        wp_send_json_error( array( 'message' => 'No contact ID' ) );
    }
    $response = sp_smti_sales_api_request( 'GET', '/get-contact-details?contact_id=' . urlencode( $contact_id ) );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    wp_send_json_success( $response );
}

// ── AJAX: Save quote ──────────────────────────────────────────────────────────

function sp_smti_sales_ajax_save_quote() {
    global $wpdb;
    sp_smti_sales_auth_check();

    $raw = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '';
    $payload = json_decode( $raw, true );
    if ( ! is_array( $payload ) ) {
        wp_send_json_error( array( 'message' => 'Invalid payload' ) );
    }

    $response = sp_smti_sales_api_request( 'POST', '/create-deal', $payload );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    if ( empty( $response['success'] ) ) {
        wp_send_json_error( $response );
    }

    // Save locally
    $member    = sp_get_current_team_member();
    $deal_id   = isset( $response['deal_id'] )     ? sanitize_text_field( $response['deal_id'] )     : '';
    $qnum      = isset( $response['quote_number'] ) ? sanitize_text_field( $response['quote_number'] ) : '';
    $contact   = isset( $payload['contact_id'] )    ? sanitize_text_field( $payload['contact_id'] )    : '';
    $cname     = isset( $payload['customer_name'] )  ? sanitize_text_field( $payload['customer_name'] ) : '';
    $company   = isset( $payload['account_name'] )   ? sanitize_text_field( $payload['account_name'] )  : '';
    $region    = isset( $payload['pricing_region'] )  ? sanitize_key( $payload['pricing_region'] )       : 'us';
    $sub       = isset( $payload['subtotal'] )        ? floatval( $payload['subtotal'] )                : 0;
    $disc      = isset( $payload['discount_amount'] ) ? floatval( $payload['discount_amount'] )         : 0;
    $freight   = isset( $payload['freight_amount'] )  ? floatval( $payload['freight_amount'] )          : 0;
    $total     = isset( $payload['total'] )           ? floatval( $payload['total'] )                   : 0;
    $json_col  = wp_json_encode( $payload );

    $existing = $deal_id ? $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}sp_smti_quotes WHERE deal_id = %s LIMIT 1", $deal_id
    ) ) : null;

    if ( $existing ) {
        $wpdb->update( $wpdb->prefix . 'sp_smti_quotes', array(
            'quote_number'    => $qnum,
            'customer_name'   => $cname,
            'company_name'    => $company,
            'pricing_region'  => $region,
            'subtotal'        => $sub,
            'discount_amount' => $disc,
            'freight_amount'  => $freight,
            'total'           => $total,
            'status'          => 'Draft',
            'quote_json'      => $json_col,
            'updated_at'      => current_time( 'mysql' ),
        ), array( 'id' => $existing ) );
    } else {
        $wpdb->insert( $wpdb->prefix . 'sp_smti_quotes', array(
            'quote_number'    => $qnum,
            'deal_id'         => $deal_id,
            'contact_id'      => $contact,
            'customer_name'   => $cname,
            'company_name'    => $company,
            'pricing_region'  => $region,
            'subtotal'        => $sub,
            'discount_amount' => $disc,
            'freight_amount'  => $freight,
            'total'           => $total,
            'status'          => 'Draft',
            'created_by'      => $member ? $member->name : '',
            'quote_json'      => $json_col,
            'created_at'      => current_time( 'mysql' ),
            'updated_at'      => current_time( 'mysql' ),
        ) );
    }

    wp_send_json_success( $response );
}

// ── AJAX: Load quote ──────────────────────────────────────────────────────────

function sp_smti_sales_ajax_load_quote() {
    sp_smti_sales_auth_check();
    $deal_id = sanitize_text_field( isset( $_POST['deal_id'] ) ? wp_unslash( $_POST['deal_id'] ) : '' );
    if ( ! $deal_id ) {
        wp_send_json_error( array( 'message' => 'No deal ID' ) );
    }
    $response = sp_smti_sales_api_request( 'GET', '/get-deal-quote?deal_id=' . urlencode( $deal_id ) );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    wp_send_json_success( $response );
}

// ── AJAX: Revisions ───────────────────────────────────────────────────────────

function sp_smti_sales_ajax_revisions() {
    sp_smti_sales_auth_check();
    $deal_id = sanitize_text_field( isset( $_POST['deal_id'] ) ? wp_unslash( $_POST['deal_id'] ) : '' );
    if ( ! $deal_id ) { wp_send_json_error( array( 'message' => 'No deal ID' ) ); }
    $response = sp_smti_sales_api_request( 'GET', '/get-quote-revisions?deal_id=' . urlencode( $deal_id ) );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    wp_send_json_success( $response );
}

// ── AJAX: Compare revisions ───────────────────────────────────────────────────

function sp_smti_sales_ajax_compare() {
    sp_smti_sales_auth_check();
    $deal_id = sanitize_text_field( isset( $_POST['deal_id'] ) ? wp_unslash( $_POST['deal_id'] ) : '' );
    $from    = sanitize_text_field( isset( $_POST['from'] )    ? wp_unslash( $_POST['from'] )    : '' );
    $to      = sanitize_text_field( isset( $_POST['to'] )      ? wp_unslash( $_POST['to'] )      : '' );
    if ( ! $deal_id || ! $from || ! $to ) { wp_send_json_error( array( 'message' => 'Missing params' ) ); }
    $response = sp_smti_sales_api_request( 'GET',
        '/get-quote-revision-compare?deal_id=' . urlencode( $deal_id ) .
        '&from_quote_number=' . urlencode( $from ) .
        '&to_quote_number=' . urlencode( $to )
    );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    wp_send_json_success( $response );
}

// ── AJAX: Sync products & distributors from HubDB ────────────────────────────

function sp_smti_sales_ajax_sync() {
    global $wpdb;
    sp_smti_sales_auth_check();
    if ( ! sp_is_admin_member() ) {
        wp_send_json_error( array( 'message' => 'Admin only' ) );
    }

    $products_id = get_option( 'sp_smti_sales_products_id', '213697055' );
    $distrib_id  = get_option( 'sp_smti_sales_distrib_id',  '224700762' );

    $products = sp_smti_sales_fetch_hubdb( $products_id );
    $distribs  = sp_smti_sales_fetch_hubdb( $distrib_id );

    if ( is_wp_error( $products ) ) {
        wp_send_json_error( array( 'message' => 'Products fetch failed: ' . $products->get_error_message() ) );
    }
    if ( is_wp_error( $distribs ) ) {
        wp_send_json_error( array( 'message' => 'Distributors fetch failed: ' . $distribs->get_error_message() ) );
    }

    // Clear and re-insert products
    $wpdb->query( "DELETE FROM {$wpdb->prefix}sp_smti_products" );
    $now = current_time( 'mysql' );
    $p_count = 0;
    foreach ( $products as $row ) {
        $v = isset( $row['values'] ) ? $row['values'] : $row;
        $active_raw = isset( $v['active'] ) ? $v['active'] : true;
        $active = sp_smti_sales_parse_active( $active_raw );
        $wpdb->insert( $wpdb->prefix . 'sp_smti_products', array(
            'product_code'       => sanitize_text_field( isset( $v['product_code'] ) ? $v['product_code'] : '' ),
            'product_title'      => sanitize_text_field( isset( $v['product_title'] ) ? $v['product_title'] : '' ),
            'category'           => sanitize_text_field( isset( $v['category'] ) ? $v['category'] : '' ),
            'product_description'=> wp_kses_post( isset( $v['product_description'] ) ? $v['product_description'] : '' ),
            'unit_price'         => floatval( isset( $v['unit_price'] ) ? $v['unit_price'] : 0 ),
            'dealer_price'       => floatval( isset( $v['dealer_price'] ) ? $v['dealer_price'] : 0 ),
            'location'           => sanitize_key( isset( $v['location'] ) ? $v['location'] : 'us' ),
            'active'             => $active ? 1 : 0,
            'allow_discount'     => sp_smti_sales_parse_active( isset( $v['allow_discount'] ) ? $v['allow_discount'] : true ) ? 1 : 0,
            'max_discount_percent'=> intval( isset( $v['max_discount_percent'] ) ? $v['max_discount_percent'] : 10 ),
            'collateral_file'    => esc_url_raw( isset( $v['collateral_file']['url'] ) ? $v['collateral_file']['url'] : ( isset( $v['collateral_file'] ) && is_string( $v['collateral_file'] ) ? $v['collateral_file'] : '' ) ),
            'sort_order'         => intval( isset( $v['sort_order'] ) ? $v['sort_order'] : 0 ),
            'updated_at'         => $now,
        ) );
        $p_count++;
    }

    // Clear and re-insert distributors
    $wpdb->query( "DELETE FROM {$wpdb->prefix}sp_smti_distributors" );
    $d_count = 0;
    foreach ( $distribs as $row ) {
        $v = isset( $row['values'] ) ? $row['values'] : $row;
        $wpdb->insert( $wpdb->prefix . 'sp_smti_distributors', array(
            'slug'       => sanitize_key( isset( $v['slug'] ) ? $v['slug'] : '' ),
            'name'       => sanitize_text_field( isset( $v['name'] ) ? $v['name'] : '' ),
            'company'    => sanitize_text_field( isset( $v['company'] ) ? $v['company'] : '' ),
            'title'      => sanitize_text_field( isset( $v['title'] ) ? $v['title'] : '' ),
            'phone'      => sanitize_text_field( isset( $v['phone'] ) ? $v['phone'] : '' ),
            'email'      => sanitize_email( isset( $v['email'] ) ? $v['email'] : '' ),
            'updated_at' => $now,
        ) );
        $d_count++;
    }

    update_option( 'sp_smti_sales_last_sync', $now );
    wp_send_json_success( array(
        'products'     => $p_count,
        'distributors' => $d_count,
        'synced_at'    => $now,
    ) );
}

// ── AJAX: Saved quotes list ───────────────────────────────────────────────────

function sp_smti_sales_ajax_quotes_list() {
    global $wpdb;
    sp_smti_sales_auth_check();
    $rows = $wpdb->get_results(
        "SELECT id, quote_number, deal_id, customer_name, company_name, pricing_region, total, status, created_by, created_at
         FROM {$wpdb->prefix}sp_smti_quotes
         ORDER BY updated_at DESC LIMIT 100",
        ARRAY_A
    );
    wp_send_json_success( array( 'quotes' => $rows ? $rows : array() ) );
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function sp_smti_sales_api_request( $method, $path, $body = null ) {
    $base  = rtrim( get_option( 'sp_smti_sales_api_base', 'https://startwebservicesbackup.com/smti/wp-json/smti/v1' ), '/' );
    $token = get_option( 'sp_smti_sales_api_token', 'smti_live_9a7f3d21e6b84c54b9c2f18d6a73e4ab' );

    $args = array(
        'method'  => strtoupper( $method ),
        'headers' => array(
            'X-SMTI-Token' => $token,
            'Content-Type' => 'application/json',
        ),
        'timeout' => 20,
    );
    if ( $body !== null ) {
        $args['body'] = wp_json_encode( $body );
    }

    $response = wp_remote_request( $base . $path, $args );
    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $decoded = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( $decoded === null ) {
        return new WP_Error( 'json_error', 'Invalid JSON from SMTI API' );
    }
    return $decoded;
}

function sp_smti_sales_fetch_hubdb( $table_id ) {
    $token = get_option( 'sp_smti_sales_hs_pat', '' );
    if ( ! $token ) {
        return new WP_Error( 'hubdb_no_token', 'HubSpot Private App Token not set. Add it in Settings → SMTI Sales Settings.' );
    }
    $url = 'https://api.hubapi.com/cms/v3/hubdb/tables/' . rawurlencode( $table_id ) . '/rows?limit=1000';

    $args = array(
        'timeout' => 20,
        'headers' => array(
            'Authorization' => 'Bearer ' . $token,
        ),
    );

    $response = wp_remote_get( $url, $args );
    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
        return new WP_Error( 'hubdb_error', 'HubDB returned HTTP ' . $code );
    }

    $body    = json_decode( wp_remote_retrieve_body( $response ), true );
    $results = isset( $body['results'] ) ? $body['results'] : array();
    return $results;
}

function sp_smti_sales_parse_active( $value ) {
    if ( $value === true || $value === 1 || $value === '1' ) return true;
    if ( $value === false || $value === 0 || $value === '0' ) return false;
    if ( is_array( $value ) ) {
        foreach ( $value as $item ) {
            if ( sp_smti_sales_parse_active( $item ) ) return true;
        }
        return false;
    }
    if ( is_object( $value ) ) {
        $check = isset( $value->name ) ? $value->name : ( isset( $value->value ) ? $value->value : '' );
        return sp_smti_sales_parse_active( $check );
    }
    $raw = strtolower( trim( (string) $value ) );
    return in_array( $raw, array( 'yes', 'true', '1' ), true );
}

function sp_smti_sales_get_products() {
    global $wpdb;
    return $wpdb->get_results(
        "SELECT product_code, product_title, category, product_description,
                unit_price, dealer_price, location, active, allow_discount,
                max_discount_percent, collateral_file
         FROM {$wpdb->prefix}sp_smti_products
         WHERE active = 1
         ORDER BY sort_order ASC, product_code ASC",
        ARRAY_A
    );
}

function sp_smti_sales_get_distributors() {
    global $wpdb;
    return $wpdb->get_results(
        "SELECT slug, name, company, title, phone, email
         FROM {$wpdb->prefix}sp_smti_distributors
         ORDER BY name ASC",
        ARRAY_A
    );
}

function sp_smti_sales_get_recent_quotes( $limit = 10 ) {
    global $wpdb;
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT id, quote_number, deal_id, customer_name, company_name, total, status, created_at
         FROM {$wpdb->prefix}sp_smti_quotes
         ORDER BY updated_at DESC LIMIT %d",
        $limit
    ), ARRAY_A );
}
