<?php
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! sp_is_admin_member() ) { echo '<p class="sp-empty">Access denied.</p>'; return; }

$platform_name = get_option( 'sp_platform_name', 'Start Performance' );
$hidden_nav    = get_option( 'sp_hidden_nav_items', array() );
if ( ! is_array( $hidden_nav ) ) $hidden_nav = array();

// Collect all nav items so we can build the visibility toggles
$all_nav = apply_filters( 'sp_nav_items', array(
    array( 'view' => 'dashboard', 'label' => 'Dashboard' ),
    array( 'section' => true, 'label' => 'Core' ),
    array( 'view' => 'contacts',  'label' => 'Contacts'  ),
    array( 'view' => 'companies', 'label' => 'Companies' ),
    array( 'view' => 'leads',     'label' => 'Leads'     ),
) );

// Collect sections defined by sp_settings_sections
ob_start();
do_action( 'sp_settings_sections' );
$addon_sections_html = ob_get_clean();

// Build anchor list for the tab nav
// We always have: platform, navigation, team. Plus any from do_action that add IDs.
$anchor_tabs = array(
    array( 'id' => 'section-platform',   'label' => 'Platform'   ),
    array( 'id' => 'section-navigation', 'label' => 'Navigation' ),
    array( 'id' => 'section-team',       'label' => 'Team'       ),
);
// Let addons append anchor tabs via filter
$anchor_tabs = apply_filters( 'sp_settings_anchor_tabs', $anchor_tabs );
?>

<div class="sp-page-header">
    <h1>Settings</h1>
</div>

<!-- Anchor tab nav -->
<div class="sp-settings-tabs">
    <?php foreach ( $anchor_tabs as $tab ) : ?>
        <a href="#<?php echo esc_attr( $tab['id'] ); ?>" class="sp-settings-tab"><?php echo esc_html( $tab['label'] ); ?></a>
    <?php endforeach; ?>
</div>

<form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
    <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
    <input type="hidden" name="sp_type" value="settings">
    <input type="hidden" name="sp_id" value="0">

    <!-- Platform -->
    <div id="section-platform" class="sp-card sp-form-card sp-settings-section">
        <h2 class="sp-section-heading">Platform</h2>
        <div class="sp-field" style="max-width:320px">
            <label>Platform Name</label>
            <input type="text" name="sp_platform_name" value="<?php echo esc_attr( $platform_name ); ?>">
            <span class="sp-hint">Displayed in the browser title and login page.</span>
        </div>
        <div class="sp-form-actions">
            <button type="submit" class="sp-btn sp-btn-primary">Save All Settings</button>
        </div>
    </div>

    <!-- Navigation Visibility -->
    <div id="section-navigation" class="sp-card sp-form-card sp-settings-section" style="margin-top:16px">
        <h2 class="sp-section-heading">Navigation Visibility</h2>
        <p style="font-size:13px;color:#64748b;margin-bottom:20px">Choose which items appear in the sidebar navigation. Hidden items are removed for all users. Sections are hidden automatically when all their items are hidden.</p>
        <div class="sp-nav-visibility-grid">
            <?php
            $current_section = '';
            foreach ( $all_nav as $item ) :
                if ( ! empty( $item['section'] ) ) :
                    $current_section = $item['label'];
                    continue;
                endif;
                if ( empty( $item['view'] ) ) continue;
                $view    = $item['view'];
                $label   = $item['label'];
                $checked = ! in_array( $view, $hidden_nav );
            ?>
            <label class="sp-nav-toggle<?php echo $checked ? '' : ' sp-nav-toggle--off'; ?>">
                <input type="checkbox" name="sp_nav_visible[]" value="<?php echo esc_attr( $view ); ?>"<?php checked( $checked ); ?> onchange="var t=this.closest('.sp-nav-toggle');t.classList.toggle('sp-nav-toggle--off',!this.checked);t.querySelector('.sp-nav-toggle-pill').textContent=this.checked?'Visible':'Hidden';">
                <span class="sp-nav-toggle-label">
                    <span class="sp-nav-toggle-name"><?php echo esc_html( $label ); ?></span>
                    <?php if ( $current_section ) : ?>
                        <span class="sp-nav-toggle-section"><?php echo esc_html( $current_section ); ?></span>
                    <?php endif; ?>
                </span>
                <span class="sp-nav-toggle-pill"><?php echo $checked ? 'Visible' : 'Hidden'; ?></span>
            </label>
            <?php endforeach; ?>
        </div>
        <div class="sp-form-actions">
            <button type="submit" class="sp-btn sp-btn-primary">Save All Settings</button>
        </div>
    </div>

</form>

<?php echo $addon_sections_html; ?>

<!-- Team -->
<div id="section-team" class="sp-card sp-form-card sp-settings-section" style="margin-top:16px">
    <h2 class="sp-section-heading">Team &amp; Security</h2>
    <p style="font-size:13px;color:#64748b;margin-bottom:16px">Manage team members, roles, and PINs from the Team section.</p>
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=team' ) ); ?>" class="sp-btn sp-btn-ghost">Go to Team &rarr;</a>
</div>
