<?php
/*
 * Plugin Name: Start Performance — Operations Core
 * Description: Workflow templates and onboarding checklists for the Start Performance Platform
 * Version:     1.0.0
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_OPS_VERSION',    '1.0.0' );
define( 'SP_OPS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// ── Boot ──────────────────────────────────────────────────────────────────────

add_action( 'plugins_loaded', 'sp_ops_boot', 20 );

function sp_ops_boot() {
    if ( ! function_exists( 'sp_register_view' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Start Performance — Operations Core</strong> requires the Start Performance core plugin.</p></div>';
        } );
        return;
    }
    sp_ops_register();
}

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_ops_activate' );
add_action( 'sp_activate', 'sp_ops_create_tables' );

function sp_ops_activate() {
    sp_ops_create_tables();
}

function sp_ops_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_op_workflows (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL DEFAULT '',
  description text,
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_op_workflow_steps (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  workflow_id bigint(20) unsigned NOT NULL DEFAULT 0,
  sort_order int(11) NOT NULL DEFAULT 0,
  title varchar(255) NOT NULL DEFAULT '',
  due_offset_days int(11) NOT NULL DEFAULT 0,
  assigned_role varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  KEY workflow_id (workflow_id)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_op_instances (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  workflow_id bigint(20) unsigned NOT NULL DEFAULT 0,
  record_type varchar(20) NOT NULL DEFAULT '',
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  started_by bigint(20) unsigned NOT NULL DEFAULT 0,
  started_at datetime NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY  (id),
  KEY workflow_id (workflow_id),
  KEY record_type (record_type),
  KEY record_id (record_id),
  KEY status (status)
) $charset;" );

    // Add instance_id column to sp_tasks if not present (tracks which workflow created a task)
    $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}sp_tasks" );
    if ( ! in_array( 'op_instance_id', $cols ) ) {
        $wpdb->query( "ALTER TABLE {$wpdb->prefix}sp_tasks ADD COLUMN op_instance_id bigint(20) unsigned NOT NULL DEFAULT 0" );
        $wpdb->query( "ALTER TABLE {$wpdb->prefix}sp_tasks ADD KEY op_instance_id (op_instance_id)" );
    }
}

// ── Registration ──────────────────────────────────────────────────────────────

function sp_ops_register() {
    sp_ops_create_tables(); // ensure tables exist on first load

    sp_register_addon( 'sp-operations', array(
        'name'        => 'Operations Core',
        'version'     => SP_OPS_VERSION,
        'description' => 'Workflow templates and onboarding checklists — assign a workflow to any contact or company and watch tasks auto-create.',
        'icon'        => '<path fill="currentColor" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>',
        'plugin_file' => plugin_basename( __FILE__ ),
        'core_slot'   => 'operations-core',
    ) );

    sp_register_view( 'operations',          SP_OPS_PLUGIN_DIR . 'templates/views/operations.php' );
    sp_register_view( 'operations-workflow', SP_OPS_PLUGIN_DIR . 'templates/views/operations-workflow.php' );

    add_filter( 'sp_nav_items',     'sp_ops_nav_items' );
    add_filter( 'sp_allowed_views', 'sp_ops_allowed_views' );

    add_action( 'sp_post_handler_op_workflow',       'sp_ops_save_workflow' );
    add_action( 'sp_delete_handler_op_workflow',     'sp_ops_delete_workflow' );
    add_action( 'sp_post_handler_op_start_workflow', 'sp_ops_start_workflow' );
    add_action( 'sp_post_handler_op_cancel_instance','sp_ops_cancel_instance' );
}

// ── Nav ───────────────────────────────────────────────────────────────────────

function sp_ops_nav_items( $items ) {
    $result = array();
    foreach ( $items as $item ) {
        $result[] = $item;
        if ( ! empty( $item['section'] ) && ! empty( $item['section_id'] ) && $item['section_id'] === 'operations-core' ) {
            $result[] = array(
                'view'  => 'operations',
                'label' => 'Workflows',
                'icon'  => '<path fill="currentColor" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>',
            );
        }
    }
    return $result;
}

function sp_ops_allowed_views( $views ) {
    $views[] = 'operations';
    $views[] = 'operations-workflow';
    return $views;
}

// ── Save workflow template ────────────────────────────────────────────────────

function sp_ops_save_workflow( $id ) {
    global $wpdb;
    if ( ! sp_is_admin_member() ) {
        wp_redirect( home_url( '/sp-app/?view=operations' ) ); exit;
    }

    $name        = sanitize_text_field( $_POST['name'] ?? '' );
    $description = sanitize_textarea_field( $_POST['description'] ?? '' );
    $member      = sp_get_current_team_member();
    $by          = $member ? (int) $member->id : 0;

    if ( $id ) {
        $wpdb->update( $wpdb->prefix . 'sp_op_workflows',
            array( 'name' => $name, 'description' => $description ),
            array( 'id' => $id )
        );
    } else {
        $wpdb->insert( $wpdb->prefix . 'sp_op_workflows', array(
            'name'        => $name,
            'description' => $description,
            'created_by'  => $by,
            'created_at'  => current_time( 'mysql' ),
        ) );
        $id = $wpdb->insert_id;
    }

    // Replace steps
    $wpdb->delete( $wpdb->prefix . 'sp_op_workflow_steps', array( 'workflow_id' => $id ) );

    $titles  = isset( $_POST['step_title'] )      ? (array) $_POST['step_title']      : array();
    $offsets = isset( $_POST['step_offset'] )     ? (array) $_POST['step_offset']     : array();
    $roles   = isset( $_POST['step_role'] )       ? (array) $_POST['step_role']       : array();

    foreach ( $titles as $i => $title ) {
        $title = sanitize_text_field( $title );
        if ( $title === '' ) continue;
        $wpdb->insert( $wpdb->prefix . 'sp_op_workflow_steps', array(
            'workflow_id'     => $id,
            'sort_order'      => $i + 1,
            'title'           => $title,
            'due_offset_days' => (int) ( $offsets[ $i ] ?? 0 ),
            'assigned_role'   => sanitize_key( $roles[ $i ] ?? '' ),
        ) );
    }

    wp_redirect( home_url( '/sp-app/?view=operations-workflow&id=' . $id . '&saved=1' ) ); exit;
}

// ── Delete workflow template ──────────────────────────────────────────────────

function sp_ops_delete_workflow( $id ) {
    global $wpdb;
    if ( ! sp_is_admin_member() ) {
        wp_redirect( home_url( '/sp-app/?view=operations' ) ); exit;
    }
    $wpdb->delete( $wpdb->prefix . 'sp_op_workflow_steps', array( 'workflow_id' => $id ) );
    $wpdb->delete( $wpdb->prefix . 'sp_op_workflows',      array( 'id' => $id ) );
    wp_redirect( home_url( '/sp-app/?view=operations&deleted=1' ) ); exit;
}

// ── Start a workflow instance ─────────────────────────────────────────────────

function sp_ops_start_workflow( $id ) {
    global $wpdb;

    $workflow_id  = (int) ( $_POST['workflow_id']  ?? 0 );
    $record_type  = sanitize_key( $_POST['record_type']  ?? '' );
    $record_id    = (int) ( $_POST['record_id']    ?? 0 );
    $start_date   = sanitize_text_field( $_POST['start_date'] ?? current_time( 'Y-m-d' ) );

    if ( ! $workflow_id || ! $record_type || ! $record_id ) {
        wp_redirect( home_url( '/sp-app/?view=operations&error=missing' ) ); exit;
    }

    $member = sp_get_current_team_member();
    $by     = $member ? (int) $member->id : 0;

    // Create instance
    $wpdb->insert( $wpdb->prefix . 'sp_op_instances', array(
        'workflow_id' => $workflow_id,
        'record_type' => $record_type,
        'record_id'   => $record_id,
        'started_by'  => $by,
        'started_at'  => current_time( 'mysql' ),
        'status'      => 'active',
    ) );
    $instance_id = $wpdb->insert_id;

    // Load team to assign by role
    $team_by_role = array();
    $team = $wpdb->get_results( "SELECT id, role FROM {$wpdb->prefix}sp_team WHERE status='active'" );
    foreach ( $team as $m ) {
        if ( ! isset( $team_by_role[ $m->role ] ) ) $team_by_role[ $m->role ] = (int) $m->id;
    }

    // Create tasks for each step
    $steps = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}sp_op_workflow_steps WHERE workflow_id=%d ORDER BY sort_order ASC",
        $workflow_id
    ) );

    $base = strtotime( $start_date );
    foreach ( $steps as $step ) {
        $due = $step->due_offset_days > 0
            ? date( 'Y-m-d', strtotime( "+{$step->due_offset_days} days", $base ) )
            : null;
        $assigned = $step->assigned_role && isset( $team_by_role[ $step->assigned_role ] )
            ? $team_by_role[ $step->assigned_role ]
            : $by;

        $wpdb->insert( $wpdb->prefix . 'sp_tasks', array(
            'record_type'    => $record_type,
            'record_id'      => $record_id,
            'title'          => sanitize_text_field( $step->title ),
            'assigned_to'    => $assigned,
            'due_date'       => $due,
            'status'         => 'open',
            'created_by'     => $by,
            'created_at'     => current_time( 'mysql' ),
            'op_instance_id' => $instance_id,
        ) );
    }

    // Log activity
    if ( function_exists( 'sp_log_activity' ) ) {
        $wf = $wpdb->get_var( $wpdb->prepare(
            "SELECT name FROM {$wpdb->prefix}sp_op_workflows WHERE id=%d", $workflow_id
        ) );
        sp_log_activity( $record_type, $record_id, 'workflow_started', $wf, $by );
    }

    wp_redirect( home_url( "/sp-app/?view=operations&started={$instance_id}" ) ); exit;
}

// ── Cancel a workflow instance ────────────────────────────────────────────────

function sp_ops_cancel_instance( $id ) {
    global $wpdb;
    if ( ! sp_is_admin_member() ) {
        wp_redirect( home_url( '/sp-app/?view=operations' ) ); exit;
    }
    $wpdb->update( $wpdb->prefix . 'sp_op_instances',
        array( 'status' => 'cancelled' ),
        array( 'id' => $id )
    );
    // Mark remaining open tasks from this instance as cancelled
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->prefix}sp_tasks SET status='cancelled' WHERE op_instance_id=%d AND status='open'",
        $id
    ) );
    wp_redirect( home_url( '/sp-app/?view=operations&cancelled=1' ) ); exit;
}
