<?php
/*
 * Plugin Name: Start Performance
 * Description: Start Performance Platform — core
 * Version:     2.1.1
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_VERSION',    '2.1.1' );
define( 'SP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ── Upgrade / migration ────────────────────────────────────────────────────────

add_action( 'plugins_loaded', 'sp_maybe_migrate' );

// ── From name for all wp_mail() calls ────────────────────────────────────────
add_filter( 'wp_mail_from_name', function( $name ) {
    return get_option( 'sp_platform_name', 'Start Performance' );
} );

function sp_maybe_migrate() {
    global $wpdb;
    // Mark existing installs as setup-complete so the wizard never triggers
    if ( ! get_option( 'sp_setup_complete' ) ) {
        $has_team = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_team" );
        if ( $has_team ) update_option( 'sp_setup_complete', 1 );
    }
    // Add core_access column to sp_team if missing
    $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}sp_team" );
    if ( ! in_array( 'core_access', $cols ) ) {
        $wpdb->query( "ALTER TABLE {$wpdb->prefix}sp_team ADD COLUMN core_access text NOT NULL DEFAULT '' AFTER status" );
    }
}

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_activate' );
register_deactivation_hook( __FILE__, 'sp_deactivate' );

function sp_activate() {
    sp_create_tables();
    do_action( 'sp_activate' );
    flush_rewrite_rules();
    if ( ! wp_next_scheduled( 'sp_daily_digest' ) ) {
        $site_tz = get_option( 'timezone_string' ) ? get_option( 'timezone_string' ) : 'UTC';
        try {
            $tz   = new DateTimeZone( $site_tz );
            $next = new DateTime( 'tomorrow 08:00:00', $tz );
            wp_schedule_event( $next->getTimestamp(), 'daily', 'sp_daily_digest' );
        } catch ( Exception $e ) {
            wp_schedule_event( time() + 3600, 'daily', 'sp_daily_digest' );
        }
    }
}

function sp_deactivate() {
    wp_clear_scheduled_hook( 'sp_daily_digest' );
    flush_rewrite_rules();
}

add_action( 'sp_daily_digest', 'sp_send_daily_digest' );

function sp_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_contacts (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL DEFAULT '',
  last_name varchar(100) NOT NULL DEFAULT '',
  email varchar(200) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  company_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(100) NOT NULL DEFAULT '',
  status varchar(50) NOT NULL DEFAULT 'active',
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY email (email(100)),
  KEY status (status)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_companies (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL DEFAULT '',
  industry varchar(100) NOT NULL DEFAULT '',
  website varchar(255) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  address text,
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY name (name(100))
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_leads (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
  company_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(100) NOT NULL DEFAULT '',
  status varchar(50) NOT NULL DEFAULT 'new',
  score tinyint(3) unsigned NOT NULL DEFAULT 0,
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY status (status),
  KEY contact_id (contact_id)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_team (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL DEFAULT '',
  email varchar(200) NOT NULL DEFAULT '',
  role varchar(20) NOT NULL DEFAULT 'agent',
  pin varchar(255) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'active',
  core_access text NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY role (role),
  KEY status (status)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_notes (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  record_type varchar(20) NOT NULL DEFAULT '',
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  content text NOT NULL,
  reminder_at datetime DEFAULT NULL,
  reminder_sent tinyint(1) NOT NULL DEFAULT 0,
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY record_type (record_type),
  KEY record_id (record_id),
  KEY reminder_at (reminder_at)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_tasks (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  record_type varchar(20) NOT NULL DEFAULT '',
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  title varchar(255) NOT NULL DEFAULT '',
  assigned_to bigint(20) unsigned NOT NULL DEFAULT 0,
  due_date date DEFAULT NULL,
  status varchar(20) NOT NULL DEFAULT 'open',
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY record_type (record_type),
  KEY record_id (record_id),
  KEY status (status),
  KEY assigned_to (assigned_to)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_attachments (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  record_type varchar(20) NOT NULL DEFAULT '',
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  filename varchar(255) NOT NULL DEFAULT '',
  filepath varchar(500) NOT NULL DEFAULT '',
  fileurl varchar(500) NOT NULL DEFAULT '',
  filesize bigint(20) unsigned NOT NULL DEFAULT 0,
  filetype varchar(100) NOT NULL DEFAULT '',
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY record_type (record_type),
  KEY record_id (record_id)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_activity (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  record_type varchar(20) NOT NULL DEFAULT '',
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  action varchar(50) NOT NULL DEFAULT '',
  detail text,
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY record_type (record_type),
  KEY record_id (record_id),
  KEY created_at (created_at)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_email_log (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  record_type varchar(20) NOT NULL DEFAULT '',
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  direction varchar(10) NOT NULL DEFAULT 'sent',
  subject varchar(255) NOT NULL DEFAULT '',
  body text,
  logged_by bigint(20) unsigned NOT NULL DEFAULT 0,
  logged_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY record (record_type, record_id),
  KEY logged_at (logged_at)
) $charset;" );
}

// ── Team migration ─────────────────────────────────────────────────────────────
// On first load after upgrade, seed sp_team with an Admin using the legacy PIN.

add_action( 'init', 'sp_maybe_migrate_team', 5 );

function sp_maybe_migrate_team() {
    global $wpdb;
    $table = $wpdb->prefix . 'sp_team';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) ) return;
    $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
    if ( $count > 0 ) return;
    $existing_pin = get_option( 'sp_pin', '1234' );
    $wpdb->insert( $table, array(
        'name'       => 'Admin',
        'email'      => '',
        'role'       => 'admin',
        'pin'        => wp_hash_password( $existing_pin ),
        'status'     => 'active',
        'created_at' => current_time( 'mysql' ),
    ) );
}

// ── View registry ──────────────────────────────────────────────────────────────

$sp_view_registry = array();

function sp_register_view( $slug, $file_path ) {
    global $sp_view_registry;
    $sp_view_registry[ $slug ] = $file_path;
}

function sp_get_view_file( $slug ) {
    global $sp_view_registry;
    if ( isset( $sp_view_registry[ $slug ] ) && file_exists( $sp_view_registry[ $slug ] ) ) {
        return $sp_view_registry[ $slug ];
    }
    $core = SP_PLUGIN_DIR . 'templates/views/' . $slug . '.php';
    return file_exists( $core ) ? $core : '';
}

// ── Addon registry ─────────────────────────────────────────────────────────────

$sp_addon_registry = array();

function sp_register_addon( $id, $data ) {
    global $sp_addon_registry;
    $sp_addon_registry[ $id ] = array_merge( array(
        'name'         => '',
        'version'      => '',
        'description'  => '',
        'settings_url' => '',
        'icon'         => '',
        'plugin_file'  => '',
        'core_slot'    => '',
    ), $data );
}

function sp_get_addons() {
    global $sp_addon_registry;
    return $sp_addon_registry;
}

// ── Core slot registry ─────────────────────────────────────────────────────────

$sp_core_slot_registry = array();

function sp_register_core_slot( $id, $data ) {
    global $sp_core_slot_registry;
    $sp_core_slot_registry[ $id ] = array_merge( array(
        'label'       => '',
        'description' => '',
        'icon'        => '',
        'features'    => array(),
        'learn_more'  => '',
    ), $data );
}

function sp_get_core_slots() {
    global $sp_core_slot_registry;
    return $sp_core_slot_registry;
}

add_action( 'plugins_loaded', 'sp_register_default_core_slots', 1 );

function sp_register_default_core_slots() {
    sp_register_core_slot( 'intelligence-core', array(
        'label'       => 'Intelligence Core',
        'tagline'     => 'Unlock smarter decisions with powerful insights',
        'description' => 'KPI dashboards, form analytics, and business intelligence that turn your data into real performance gains.',
        'icon'        => '<path fill="currentColor" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>',
        'features'    => array(
            'KPI Dashboard|Real-time visibility into what\'s working',
            'Form Builder & Analytics|Build smarter forms and instantly understand the results',
            'Business Intelligence Reports|Beautiful, actionable reports at your fingertips',
            'Goal Tracking|Set, monitor, and crush your most important targets',
        ),
    ) );
    sp_register_core_slot( 'sales-core', array(
        'label'       => 'Sales Core',
        'tagline'     => 'Close more deals with less effort',
        'description' => 'Professional proposals, estimates, and contracts — built for speed and linked to your contacts.',
        'icon'        => '<path fill="currentColor" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>',
        'features'    => array(
            'Estimates|Create professional quotes in minutes and track acceptance',
            'Proposals|Multi-section proposals with scope, timeline, and pricing',
            'Contracts|Send, track, and record signed contracts in one place',
        ),
    ) );
    sp_register_core_slot( 'service-core', array(
        'label'       => 'Service Core',
        'tagline'     => 'Deliver outstanding service every single time',
        'description' => 'Ticket management, service scheduling, and a customer portal that keeps your clients in the loop.',
        'icon'        => '<path fill="currentColor" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z"/>',
        'features'    => array(
            'Ticket Management|Track every service request from open to resolved',
            'Service Scheduling|Keep your team on time and clients informed',
            'Customer Portal|Give clients real-time visibility into their service status',
            'Customer Calculator|Help clients scope and price their own service needs',
        ),
    ) );
    sp_register_core_slot( 'operations-core', array(
        'label'       => 'Operations Core',
        'tagline'     => 'Run a tighter, smarter operation every day',
        'description' => 'Onboarding checklists, workflow automation, and task management that keep your team moving.',
        'icon'        => '<path fill="currentColor" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065zM15 12a3 3 0 11-6 0 3 3 0 016 0z"/>',
        'features'    => array(
            'Onboarding Checklists|Visual progress tracker tied to every contact and company',
            'Workflow Automation|Build repeatable workflows that create tasks automatically',
            'Workflow Management|See every active workflow and where each one stands',
            'Task Tracking|Keep your whole team on track with linked, due-dated tasks',
        ),
    ) );
    sp_register_core_slot( 'knowledge-core', array(
        'label'       => 'Knowledge Core',
        'tagline'     => 'Build a team that never has to guess',
        'description' => 'Your team\'s single source of truth — SOPs, training, FAQs, and resources all in one place.',
        'icon'        => '<path fill="currentColor" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>',
        'features'    => array(
            'Knowledge Base|Searchable articles and SOPs your team can actually find',
            'Resource Library|Organize links, files, and docs by category',
            'Training & Testing|Build courses with quizzes and track who\'s completed what',
        ),
    ) );
    sp_register_core_slot( 'chat-core', array(
        'label'       => 'Chat Core',
        'tagline'     => 'Capture leads and support customers in real time',
        'description' => 'Website chat, support intake, and internal team messaging — all inside the platform.',
        'icon'        => '<path fill="currentColor" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>',
        'features'    => array(
            'Website Chat|Capture leads and answer questions before they leave',
            'Support Intake|Turn chat conversations into trackable service tickets',
            'Chat Analytics|See response times, volume, and team performance',
            'Internal Staff Chat|Keep your team connected without leaving the platform',
        ),
    ) );
}

// ── Vendor (Super Admin) auth helpers ──────────────────────────────────────────

function sp_set_vendor_cookie() {
    $token = hash_hmac( 'sha256', 'sp_vendor', wp_salt( 'auth' ) );
    setcookie( 'sp_vendor_auth', $token, 0, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
}

function sp_clear_vendor_cookie() {
    setcookie( 'sp_vendor_auth', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
}

function sp_is_super_admin() {
    if ( empty( $_COOKIE['sp_vendor_auth'] ) ) return false;
    $expected = hash_hmac( 'sha256', 'sp_vendor', wp_salt( 'auth' ) );
    return hash_equals( $expected, $_COOKIE['sp_vendor_auth'] );
}

// ── Team auth helpers ──────────────────────────────────────────────────────────

function sp_set_team_cookie( $member_id ) {
    $token = $member_id . '|' . hash_hmac( 'sha256', (string) $member_id, wp_salt( 'auth' ) );
    setcookie( 'sp_team_auth', $token, 0, '/', COOKIE_DOMAIN, is_ssl(), true );
}

function sp_clear_team_cookie() {
    setcookie( 'sp_team_auth', '', time() - 3600, '/', COOKIE_DOMAIN, is_ssl(), true );
}

function sp_section_label( $section_id, $default ) {
    $custom = get_option( 'sp_section_label_' . $section_id, '' );
    return $custom !== '' ? $custom : $default;
}

function sp_hex_to_rgb( $hex ) {
    $hex = ltrim( $hex, '#' );
    if ( strlen( $hex ) === 3 ) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec( substr( $hex, 0, 2 ) );
    $g = hexdec( substr( $hex, 2, 2 ) );
    $b = hexdec( substr( $hex, 4, 2 ) );
    return "$r,$g,$b";
}

function sp_darken_hex( $hex, $amount ) {
    $hex = ltrim( $hex, '#' );
    if ( strlen( $hex ) === 3 ) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = max( 0, hexdec( substr( $hex, 0, 2 ) ) - (int) round( hexdec( substr( $hex, 0, 2 ) ) * $amount ) );
    $g = max( 0, hexdec( substr( $hex, 2, 2 ) ) - (int) round( hexdec( substr( $hex, 2, 2 ) ) * $amount ) );
    $b = max( 0, hexdec( substr( $hex, 4, 2 ) ) - (int) round( hexdec( substr( $hex, 4, 2 ) ) * $amount ) );
    return sprintf( '#%02x%02x%02x', $r, $g, $b );
}

function sp_get_current_team_member() {
    static $cache = false;
    if ( $cache !== false ) return $cache;
    if ( empty( $_COOKIE['sp_team_auth'] ) ) { $cache = null; return null; }
    $parts = explode( '|', $_COOKIE['sp_team_auth'], 2 );
    if ( count( $parts ) !== 2 ) { $cache = null; return null; }
    list( $id, $hash ) = $parts;
    $id = (int) $id;
    if ( ! hash_equals( hash_hmac( 'sha256', (string) $id, wp_salt( 'auth' ) ), $hash ) ) {
        $cache = null; return null;
    }
    global $wpdb;
    $cache = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}sp_team WHERE id = %d AND status = 'active'", $id
    ) );
    return $cache;
}

function sp_is_admin_member() {
    if ( sp_is_super_admin() ) return true;
    $m = sp_get_current_team_member();
    return $m && $m->role === 'admin';
}

// Returns true if the current member can access a given core section.
// Empty core_access = unrestricted (all cores). Super admin always passes.
// 'core-system' and 'dashboard' are always accessible.
function sp_member_has_core_access( $core_id ) {
    if ( sp_is_super_admin() ) return true;
    if ( in_array( $core_id, array( 'core-system', 'dashboard' ), true ) ) return true;
    $m = sp_get_current_team_member();
    if ( ! $m ) return false;
    $access = json_decode( isset( $m->core_access ) ? $m->core_access : '', true );
    if ( empty( $access ) || ! is_array( $access ) ) return true; // no restriction
    return in_array( $core_id, $access, true );
}

// Build a view→core_id map from the current nav so view gating doesn't need a hardcoded list.
function sp_get_view_core_map() {
    $nav = apply_filters( 'sp_nav_items', array(
        array( 'view' => 'dashboard' ),
        array( 'section' => true, 'section_id' => 'core-system',       'label' => '' ),
        array( 'view' => 'contacts'  ), array( 'view' => 'companies' ),
        array( 'view' => 'leads'     ), array( 'view' => 'tasks'      ),
        array( 'section' => true, 'section_id' => 'intelligence-core', 'label' => '' ),
        array( 'section' => true, 'section_id' => 'sales-core',        'label' => '' ),
        array( 'section' => true, 'section_id' => 'service-core',      'label' => '' ),
        array( 'section' => true, 'section_id' => 'operations-core',   'label' => '' ),
        array( 'section' => true, 'section_id' => 'knowledge-core',    'label' => '' ),
        array( 'section' => true, 'section_id' => 'chat-core',         'label' => '' ),
    ) );
    $map = array();
    $cur = null;
    foreach ( $nav as $item ) {
        if ( ! empty( $item['section'] ) ) {
            $cur = $item['section_id'] ?? null;
        } elseif ( ! empty( $item['view'] ) && $cur ) {
            $map[ $item['view'] ] = $cur;
        }
    }
    return $map;
}

function sp_log_activity( $record_type, $record_id, $action, $detail = '' ) {
    global $wpdb;
    $member = sp_get_current_team_member();
    $wpdb->insert( $wpdb->prefix . 'sp_activity', array(
        'record_type' => $record_type,
        'record_id'   => (int) $record_id,
        'action'      => sanitize_key( $action ),
        'detail'      => $detail,
        'created_by'  => $member ? (int) $member->id : 0,
        'created_at'  => current_time( 'mysql' ),
    ) );
}

function sp_format_filesize( $bytes ) {
    if ( $bytes < 1024 ) return $bytes . ' B';
    if ( $bytes < 1048576 ) return round( $bytes / 1024, 1 ) . ' KB';
    return round( $bytes / 1048576, 1 ) . ' MB';
}

function sp_get_reminder_count( $member_id ) {
    global $wpdb;
    $today = date( 'Y-m-d' );
    $now   = current_time( 'mysql' );
    $tasks = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tasks WHERE assigned_to=%d AND status='open' AND due_date IS NOT NULL AND due_date<=%s",
        $member_id, $today
    ) );
    $notes = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}sp_notes WHERE created_by=%d AND reminder_at IS NOT NULL AND reminder_at<=%s AND reminder_sent=0",
        $member_id, $now
    ) );
    return $tasks + $notes;
}

function sp_my_open_task_count( $member_id ) {
    global $wpdb;
    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tasks WHERE assigned_to=%d AND status='open'",
        $member_id
    ) );
}

function sp_send_daily_digest() {
    global $wpdb;
    $today = date( 'Y-m-d' );
    $now   = current_time( 'mysql' );
    $members = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}sp_team WHERE status='active' AND email != ''" );
    if ( ! $members ) return;

    foreach ( $members as $member ) {
        $overdue = $wpdb->get_results( $wpdb->prepare(
            "SELECT tk.title, tk.due_date, tk.record_type, tk.record_id,
                COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name
             FROM {$wpdb->prefix}sp_tasks tk
             LEFT JOIN {$wpdb->prefix}sp_contacts c ON tk.record_type='contact' AND tk.record_id=c.id
             LEFT JOIN {$wpdb->prefix}sp_companies co ON tk.record_type='company' AND tk.record_id=co.id
             WHERE tk.assigned_to=%d AND tk.status='open' AND tk.due_date IS NOT NULL AND tk.due_date < %s
             ORDER BY tk.due_date ASC",
            $member->id, $today
        ) );

        $due_today = $wpdb->get_results( $wpdb->prepare(
            "SELECT tk.title, tk.record_type, tk.record_id,
                COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name
             FROM {$wpdb->prefix}sp_tasks tk
             LEFT JOIN {$wpdb->prefix}sp_contacts c ON tk.record_type='contact' AND tk.record_id=c.id
             LEFT JOIN {$wpdb->prefix}sp_companies co ON tk.record_type='company' AND tk.record_id=co.id
             WHERE tk.assigned_to=%d AND tk.status='open' AND tk.due_date=%s
             ORDER BY tk.created_at ASC",
            $member->id, $today
        ) );

        $note_reminders = $wpdb->get_results( $wpdb->prepare(
            "SELECT n.id, n.content, n.record_type, n.record_id,
                COALESCE( CONCAT(c.first_name,' ',c.last_name), co.name, '' ) AS record_name
             FROM {$wpdb->prefix}sp_notes n
             LEFT JOIN {$wpdb->prefix}sp_contacts c ON n.record_type='contact' AND n.record_id=c.id
             LEFT JOIN {$wpdb->prefix}sp_companies co ON n.record_type='company' AND n.record_id=co.id
             WHERE n.created_by=%d AND n.reminder_at IS NOT NULL AND n.reminder_at<=%s AND n.reminder_sent=0",
            $member->id, $now
        ) );

        if ( empty( $overdue ) && empty( $due_today ) && empty( $note_reminders ) ) continue;

        $subject = 'Your reminders — ' . date( 'M j, Y' );
        $body    = "Hi {$member->name},\n\nHere's what needs your attention today:\n\n";

        if ( ! empty( $overdue ) ) {
            $body .= "OVERDUE (" . count( $overdue ) . ")\n";
            foreach ( $overdue as $t ) {
                $body .= '• ' . $t->title;
                if ( $t->record_name ) $body .= ' — ' . trim( $t->record_name );
                if ( $t->due_date ) $body .= ' (was due ' . date( 'M j', strtotime( $t->due_date ) ) . ')';
                $body .= "\n";
            }
            $body .= "\n";
        }

        if ( ! empty( $due_today ) ) {
            $body .= "DUE TODAY (" . count( $due_today ) . ")\n";
            foreach ( $due_today as $t ) {
                $body .= '• ' . $t->title;
                if ( $t->record_name ) $body .= ' — ' . trim( $t->record_name );
                $body .= "\n";
            }
            $body .= "\n";
        }

        if ( ! empty( $note_reminders ) ) {
            $body .= "NOTE REMINDERS (" . count( $note_reminders ) . ")\n";
            foreach ( $note_reminders as $n ) {
                $snippet = substr( $n->content, 0, 100 ) . ( strlen( $n->content ) > 100 ? '…' : '' );
                $body .= '• ' . $snippet;
                if ( $n->record_name ) $body .= ' — ' . trim( $n->record_name );
                $body .= "\n";
            }
            $body .= "\n";
            foreach ( $note_reminders as $n ) {
                $wpdb->update( $wpdb->prefix . 'sp_notes', array( 'reminder_sent' => 1 ), array( 'id' => $n->id ) );
            }
        }

        $body .= "—\nStart Performance\n" . home_url( '/sp-app/' );
        wp_mail( $member->email, $subject, $body );
    }
}

function sp_current_member_can( $cap ) {
    $m = sp_get_current_team_member();
    if ( ! $m ) return false;
    if ( $m->role === 'admin' ) return true;
    $agent_caps = array( 'edit_records' );
    return in_array( $cap, $agent_caps );
}

// ── URL Routing ────────────────────────────────────────────────────────────────

add_action( 'init', 'sp_route', 1 );

function sp_route() {
    $uri     = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
    $wp_path = trim( parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
    if ( $wp_path ) {
        $uri = trim( substr( $uri, strlen( $wp_path ) ), '/' );
    }

    // ── /sp-setup/ ─────────────────────────────────────────────────────────────
    if ( $uri === 'sp-setup' ) {
        // If setup is already done, redirect to login
        if ( get_option( 'sp_setup_complete' ) && ! sp_is_super_admin() ) {
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && ! empty( $_POST['sp_setup_step'] ) ) {
            sp_handle_setup_post(); exit;
        }
        require SP_PLUGIN_DIR . 'templates/setup.php'; exit;
    }

    // ── /sp-login/ ─────────────────────────────────────────────────────────────
    if ( $uri === 'sp-login' ) {

        // Vendor (super admin) login
        if ( ! empty( $_POST['sp_vendor_login'] ) ) {
            $pin    = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';
            if ( ! defined( 'SP_SUPER_ADMIN_PIN' ) ) {
                wp_redirect( home_url( '/sp-login/?vendor=1&error=nopin' ) ); exit;
            }
            $stored = (string) SP_SUPER_ADMIN_PIN;
            if ( ! $pin || $pin !== $stored ) {
                wp_redirect( home_url( '/sp-login/?vendor=1&error=pin' ) ); exit;
            }
            $admins = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
            if ( empty( $admins ) ) { wp_redirect( home_url( '/sp-login/?vendor=1&error=nouser' ) ); exit; }
            wp_set_current_user( $admins[0]->ID );
            wp_set_auth_cookie( $admins[0]->ID, true );
            sp_set_vendor_cookie();
            wp_redirect( home_url( '/sp-app/' ) ); exit;
        }

        // Regular team login
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && ! empty( $_POST['sp_login_nonce'] ) ) {
            if ( ! wp_verify_nonce( $_POST['sp_login_nonce'], 'sp_login' ) ) {
                wp_redirect( home_url( '/sp-login/?error=invalid' ) ); exit;
            }
            global $wpdb;
            $team_id = (int) ( isset( $_POST['sp_team_id'] ) ? $_POST['sp_team_id'] : 0 );
            $pin     = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';
            $member  = $team_id ? $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_team WHERE id = %d AND status = 'active'", $team_id
            ) ) : null;
            if ( ! $member || ! wp_check_password( $pin, $member->pin ) ) {
                wp_redirect( home_url( '/sp-login/?error=pin' ) ); exit;
            }
            $admins = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
            if ( empty( $admins ) ) {
                wp_redirect( home_url( '/sp-login/?error=nouser' ) ); exit;
            }
            wp_set_current_user( $admins[0]->ID );
            wp_set_auth_cookie( $admins[0]->ID, true );
            sp_clear_vendor_cookie();
            sp_set_team_cookie( $member->id );
            wp_redirect( home_url( '/sp-app/' ) ); exit;
        }
        require SP_PLUGIN_DIR . 'templates/login.php'; exit;
    }

    // ── /sp-app/ ───────────────────────────────────────────────────────────────
    if ( $uri === 'sp-app' ) {
        // Redirect to setup wizard on fresh installs
        if ( ! get_option( 'sp_setup_complete' ) && ! sp_is_super_admin() ) {
            wp_redirect( home_url( '/sp-setup/' ) ); exit;
        }
        if ( ! is_user_logged_in() ) {
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( isset( $_GET['sp_logout'] ) ) {
            wp_logout();
            sp_clear_team_cookie();
            sp_clear_vendor_cookie();
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( ! empty( $_GET['sp_ajax'] ) ) {
            sp_handle_platform_ajax( sanitize_key( $_GET['sp_ajax'] ) ); exit;
        }
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
            sp_handle_post(); exit;
        }
        if ( isset( $_GET['sp_delete'] ) ) {
            sp_handle_delete(); exit;
        }
        if ( isset( $_GET['sp_export'] ) ) {
            sp_handle_export(); exit;
        }
        if ( ! empty( $_POST['sp_type'] ) && $_POST['sp_type'] === 'import' ) {
            sp_handle_import(); exit;
        }
        require SP_PLUGIN_DIR . 'templates/app.php'; exit;
    }
}

// ── Block wp-admin ─────────────────────────────────────────────────────────────

add_action( 'admin_init', function() {
    if ( wp_doing_ajax() ) return;
    if ( ! is_user_logged_in() ) {
        wp_redirect( home_url( '/sp-login/' ) ); exit;
    }
} );

// ── POST handler ───────────────────────────────────────────────────────────────

function sp_handle_post() {
    if ( empty( $_POST['sp_nonce'] ) || ! wp_verify_nonce( $_POST['sp_nonce'], 'sp_form' ) ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }
    global $wpdb;
    $type = isset( $_POST['sp_type'] ) ? sanitize_key( $_POST['sp_type'] ) : '';
    $id   = (int) ( isset( $_POST['sp_id'] ) ? $_POST['sp_id'] : 0 );

    if ( $type === 'contact' ) {
        $data = array(
            'first_name' => sanitize_text_field( isset( $_POST['first_name'] ) ? $_POST['first_name'] : '' ),
            'last_name'  => sanitize_text_field( isset( $_POST['last_name'] )  ? $_POST['last_name']  : '' ),
            'email'      => sanitize_email(      isset( $_POST['email'] )      ? $_POST['email']      : '' ),
            'phone'      => sanitize_text_field( isset( $_POST['phone'] )      ? $_POST['phone']      : '' ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field( isset( $_POST['source'] )     ? $_POST['source']     : '' ),
            'status'     => sanitize_key(        isset( $_POST['status'] )     ? $_POST['status']     : 'active' ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']      : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_contacts', $data, array( 'id' => $id ) );
            sp_log_activity( 'contact', $id, 'updated', 'Contact updated' );
            wp_redirect( home_url( '/sp-app/?view=contacts&action=view&id=' . $id . '&saved=1' ) ); exit;
        } else {
            if ( $data['email'] ) {
                $dupe = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sp_contacts WHERE email = %s", $data['email'] ) );
                if ( $dupe ) {
                    wp_redirect( home_url( '/sp-app/?view=contacts&action=new&duplicate=' . $dupe ) ); exit;
                }
            }
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_contacts', $data );
            $new_id = (int) $wpdb->insert_id;
            sp_log_activity( 'contact', $new_id, 'created', 'Contact created' );
            wp_redirect( home_url( '/sp-app/?view=contacts&action=view&id=' . $new_id . '&saved=1' ) ); exit;
        }
    }

    if ( $type === 'company' ) {
        $data = array(
            'name'     => sanitize_text_field(     isset( $_POST['name'] )     ? $_POST['name']     : '' ),
            'industry' => sanitize_text_field(     isset( $_POST['industry'] ) ? $_POST['industry'] : '' ),
            'website'  => esc_url_raw(             isset( $_POST['website'] )  ? $_POST['website']  : '' ),
            'phone'    => sanitize_text_field(     isset( $_POST['phone'] )    ? $_POST['phone']    : '' ),
            'address'  => sanitize_textarea_field( isset( $_POST['address'] )  ? $_POST['address']  : '' ),
            'notes'    => sanitize_textarea_field( isset( $_POST['notes'] )    ? $_POST['notes']    : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_companies', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_companies', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=companies&saved=1' ) ); exit;
    }

    if ( $type === 'lead' ) {
        $data = array(
            'contact_id' => (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field(     isset( $_POST['source'] ) ? $_POST['source'] : '' ),
            'status'     => sanitize_key(            isset( $_POST['status'] ) ? $_POST['status'] : 'new' ),
            'score'      => min( 100, max( 0, (int) ( isset( $_POST['score'] ) ? $_POST['score'] : 0 ) ) ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']  : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_leads', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_leads', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=leads&saved=1' ) ); exit;
    }

    if ( $type === 'settings' ) {
        if ( sp_is_admin_member() || sp_is_super_admin() ) {

            // Any admin: Welcome note
            if ( isset( $_POST['sp_welcome_note'] ) ) {
                update_option( 'sp_welcome_note', sanitize_textarea_field( $_POST['sp_welcome_note'] ) );
            }

            // Super admin only: Platform branding + section labels
            if ( sp_is_super_admin() ) {
                update_option( 'sp_platform_name',  sanitize_text_field( isset( $_POST['sp_platform_name'] )  ? $_POST['sp_platform_name']  : 'Start Performance' ) );
                update_option( 'sp_logo_url',        esc_url_raw( isset( $_POST['sp_logo_url'] )        ? $_POST['sp_logo_url']        : '' ) );
                update_option( 'sp_brand_icon_url',  esc_url_raw( isset( $_POST['sp_brand_icon_url'] )  ? $_POST['sp_brand_icon_url']  : '' ) );
                $accent = isset( $_POST['sp_accent_color'] ) ? $_POST['sp_accent_color'] : '#CC1F1F';
                update_option( 'sp_accent_color',   preg_match( '/^#[0-9a-fA-F]{3,6}$/', $accent ) ? $accent : '#CC1F1F' );
                update_option( 'sp_brand_initials', sanitize_text_field( isset( $_POST['sp_brand_initials'] ) ? substr( $_POST['sp_brand_initials'], 0, 3 ) : '' ) );

                $hex_color = function( $key, $default ) {
                    $v = isset( $_POST[ $key ] ) ? trim( $_POST[ $key ] ) : $default;
                    return preg_match( '/^#[0-9a-fA-F]{3,6}$/', $v ) ? $v : $default;
                };
                update_option( 'sp_sidebar_bg',      $hex_color( 'sp_sidebar_bg',      '#0f1729' ) );
                update_option( 'sp_nav_color',       $hex_color( 'sp_nav_color',       '#8b9ab4' ) );
                update_option( 'sp_nav_hover_color', $hex_color( 'sp_nav_hover_color', '#ffffff'  ) );
                // hover bg accepts rgba — sanitize carefully
                $hbg = isset( $_POST['sp_nav_hover_bg_text'] ) ? trim( $_POST['sp_nav_hover_bg_text'] ) : '';
                if ( preg_match( '/^(#[0-9a-fA-F]{3,6}|rgba?\([0-9\s,\.]+\))$/', $hbg ) ) {
                    update_option( 'sp_nav_hover_bg', $hbg );
                }

                $allowed_sections = array( 'core-system', 'chat-core', 'knowledge-core', 'sales-core', 'service-core', 'operations-core', 'intelligence-core' );
                $posted_labels    = isset( $_POST['sp_section_label'] ) && is_array( $_POST['sp_section_label'] ) ? $_POST['sp_section_label'] : array();
                foreach ( $allowed_sections as $sid ) {
                    update_option( 'sp_section_label_' . $sid, sanitize_text_field( isset( $posted_labels[ $sid ] ) ? $posted_labels[ $sid ] : '' ) );
                }
            }

            // Admin + super admin: Nav visibility
            // Base must include all section headers so plugin filters can inject items after them
            $all_nav   = apply_filters( 'sp_nav_items', array(
                array( 'view' => 'dashboard'  ),
                array( 'section' => true, 'section_id' => 'core-system',        'label' => 'Core System'        ),
                array( 'view' => 'contacts'   ),
                array( 'view' => 'companies'  ),
                array( 'view' => 'leads'      ),
                array( 'view' => 'tasks'      ),
                array( 'section' => true, 'section_id' => 'intelligence-core',  'label' => 'Intelligence Core'  ),
                array( 'section' => true, 'section_id' => 'sales-core',         'label' => 'Sales Core'         ),
                array( 'section' => true, 'section_id' => 'service-core',       'label' => 'Service Core'       ),
                array( 'section' => true, 'section_id' => 'operations-core',    'label' => 'Operations Core'    ),
                array( 'section' => true, 'section_id' => 'knowledge-core',     'label' => 'Knowledge Core'     ),
                array( 'section' => true, 'section_id' => 'chat-core',          'label' => 'Chat Core'          ),
            ) );
            $all_views = array();
            foreach ( $all_nav as $item ) {
                if ( ! empty( $item['view'] ) ) $all_views[] = $item['view'];
            }
            $checked = isset( $_POST['sp_nav_visible'] ) && is_array( $_POST['sp_nav_visible'] )
                ? array_map( 'sanitize_key', $_POST['sp_nav_visible'] )
                : array();
            $hidden = array_values( array_diff( $all_views, $checked ) );
            update_option( 'sp_hidden_nav_items', $hidden );
        }
        wp_redirect( home_url( '/sp-app/?view=settings&saved=1' ) ); exit;
    }

    if ( $type === 'team_member' ) {
        if ( ! sp_is_admin_member() ) {
            wp_redirect( home_url( '/sp-app/' ) ); exit;
        }
        $name   = sanitize_text_field( isset( $_POST['name'] )  ? $_POST['name']  : '' );
        $email  = sanitize_email(      isset( $_POST['email'] ) ? $_POST['email'] : '' );
        $role   = sanitize_key(        isset( $_POST['role'] )  ? $_POST['role']  : 'agent' );
        $role   = in_array( $role, array( 'admin', 'agent' ) ) ? $role : 'agent';
        $status = sanitize_key(        isset( $_POST['status'] ) ? $_POST['status'] : 'active' );
        $status = in_array( $status, array( 'active', 'inactive' ) ) ? $status : 'active';
        $new_pin = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';
        // Core access — empty array saved as '' means unrestricted
        $valid_cores  = array( 'intelligence-core', 'sales-core', 'service-core', 'operations-core', 'knowledge-core', 'chat-core' );
        $posted_cores = isset( $_POST['core_access'] ) && is_array( $_POST['core_access'] )
            ? array_values( array_intersect( array_map( 'sanitize_key', $_POST['core_access'] ), $valid_cores ) )
            : array();
        $core_access_val = empty( $posted_cores ) ? '' : wp_json_encode( $posted_cores );
        $data = array( 'name' => $name, 'email' => $email, 'role' => $role, 'status' => $status, 'core_access' => $core_access_val );
        if ( $id ) {
            if ( $new_pin !== '' ) {
                $data['pin'] = wp_hash_password( $new_pin );
            }
            $wpdb->update( $wpdb->prefix . 'sp_team', $data, array( 'id' => $id ) );
        } else {
            if ( $new_pin === '' ) {
                wp_redirect( home_url( '/sp-app/?view=team&error=nopin' ) ); exit;
            }
            $data['pin']        = wp_hash_password( $new_pin );
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_team', $data );
        }
        // Welcome email for new members
        if ( ! $id && $email ) {
            $sp_name      = get_option( 'sp_platform_name', 'Start Performance' );
            $login_url    = home_url( '/sp-login/' );
            $welcome_note = trim( get_option( 'sp_welcome_note', '' ) );
            $subject      = 'You\'re in — here\'s how to access ' . $sp_name;
            $body         = "Hi {$name},\n\n";
            if ( $welcome_note ) {
                $body .= $welcome_note . "\n\n";
            }
            $body .= "You've been added to {$sp_name}, your team's business operating platform.\n\n"
                   . "Here's how to sign in:\n\n"
                   . "Login URL: {$login_url}\n"
                   . "Your PIN: {$new_pin}\n\n"
                   . "At login, select your name from the dropdown and enter your PIN above.\n\n"
                   . "If you have any questions, reach out to your administrator.\n\n"
                   . "— The {$sp_name} Team";
            wp_mail( $email, $subject, $body );
        }
        wp_redirect( home_url( '/sp-app/?view=team&saved=1' ) ); exit;
    }

    if ( $type === 'change_pin' ) {
        $member = sp_get_current_team_member();
        if ( ! $member ) { wp_redirect( home_url( '/sp-app/' ) ); exit; }
        $current_pin = isset( $_POST['current_pin'] ) ? trim( $_POST['current_pin'] ) : '';
        $new_pin     = isset( $_POST['new_pin'] )     ? trim( $_POST['new_pin'] )     : '';
        $confirm_pin = isset( $_POST['confirm_pin'] ) ? trim( $_POST['confirm_pin'] ) : '';
        if ( ! wp_check_password( $current_pin, $member->pin ) ) {
            wp_redirect( home_url( '/sp-app/?view=profile&error=wrong_pin' ) ); exit;
        }
        if ( $new_pin === '' ) {
            wp_redirect( home_url( '/sp-app/?view=profile&error=pin_empty' ) ); exit;
        }
        if ( $new_pin !== $confirm_pin ) {
            wp_redirect( home_url( '/sp-app/?view=profile&error=pin_mismatch' ) ); exit;
        }
        $wpdb->update( $wpdb->prefix . 'sp_team', array( 'pin' => wp_hash_password( $new_pin ) ), array( 'id' => $member->id ) );
        wp_redirect( home_url( '/sp-app/?view=profile&saved=1' ) ); exit;
    }

    if ( $type === 'note' ) {
        $record_type = sanitize_key( isset( $_POST['record_type'] ) ? $_POST['record_type'] : '' );
        $record_id   = (int) ( isset( $_POST['record_id'] ) ? $_POST['record_id'] : 0 );
        $content     = sanitize_textarea_field( isset( $_POST['content'] ) ? $_POST['content'] : '' );
        $reminder    = ( isset( $_POST['reminder_at'] ) && $_POST['reminder_at'] ) ? sanitize_text_field( $_POST['reminder_at'] ) : null;
        $member      = sp_get_current_team_member();
        if ( $content && $record_type && $record_id ) {
            $wpdb->insert( $wpdb->prefix . 'sp_notes', array(
                'record_type' => $record_type,
                'record_id'   => $record_id,
                'content'     => $content,
                'reminder_at' => $reminder,
                'created_by'  => $member ? (int) $member->id : 0,
                'created_at'  => current_time( 'mysql' ),
            ) );
            sp_log_activity( $record_type, $record_id, 'note_added', substr( $content, 0, 120 ) );
        }
        wp_redirect( home_url( '/sp-app/?view=' . $record_type . 's&action=view&id=' . $record_id . '&tab=notes' ) ); exit;
    }

    if ( $type === 'task' ) {
        $record_type = sanitize_key( isset( $_POST['record_type'] ) ? $_POST['record_type'] : '' );
        $record_id   = (int) ( isset( $_POST['record_id'] ) ? $_POST['record_id'] : 0 );
        $task_id     = (int) ( isset( $_POST['task_id'] ) ? $_POST['task_id'] : 0 );
        $member      = sp_get_current_team_member();
        if ( $task_id ) {
            $task = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_tasks WHERE id = %d", $task_id ) );
            if ( $task ) {
                $new_status = $task->status === 'done' ? 'open' : 'done';
                $wpdb->update( $wpdb->prefix . 'sp_tasks', array( 'status' => $new_status ), array( 'id' => $task_id ) );
                sp_log_activity( $task->record_type, $task->record_id, 'task_' . $new_status, $task->title );
                wp_redirect( home_url( '/sp-app/?view=' . $task->record_type . 's&action=view&id=' . $task->record_id . '&tab=tasks' ) ); exit;
            }
        } else {
            $title       = sanitize_text_field( isset( $_POST['title'] ) ? $_POST['title'] : '' );
            $assigned_to = (int) ( isset( $_POST['assigned_to'] ) ? $_POST['assigned_to'] : 0 );
            $due_date    = ( isset( $_POST['due_date'] ) && $_POST['due_date'] ) ? sanitize_text_field( $_POST['due_date'] ) : null;
            if ( $title && $record_type && $record_id ) {
                $wpdb->insert( $wpdb->prefix . 'sp_tasks', array(
                    'record_type' => $record_type,
                    'record_id'   => $record_id,
                    'title'       => $title,
                    'assigned_to' => $assigned_to,
                    'due_date'    => $due_date,
                    'status'      => 'open',
                    'created_by'  => $member ? (int) $member->id : 0,
                    'created_at'  => current_time( 'mysql' ),
                ) );
                sp_log_activity( $record_type, $record_id, 'task_created', $title );
            }
        }
        if ( $record_type === 'general' || ! $record_id ) {
            wp_redirect( home_url( '/sp-app/?view=dashboard&saved=1' ) ); exit;
        }
        wp_redirect( home_url( '/sp-app/?view=' . $record_type . 's&action=view&id=' . $record_id . '&tab=tasks' ) ); exit;
    }

    if ( $type === 'task_manage' ) {
        $task_id = (int) ( isset( $_POST['task_id'] ) ? $_POST['task_id'] : 0 );
        $op      = sanitize_key( isset( $_POST['op'] ) ? $_POST['op'] : '' );
        $member  = sp_get_current_team_member();
        // Preserve worklist filters on redirect
        $rq = array( 'view' => 'tasks' );
        if ( ! empty( $_POST['tm_scope'] ) )    $rq['tm_scope']    = sanitize_key( $_POST['tm_scope'] );
        if ( ! empty( $_POST['tm_assignee'] ) ) $rq['tm_assignee'] = (int) $_POST['tm_assignee'];
        $redirect = home_url( '/sp-app/?' . http_build_query( $rq ) );

        if ( $op === 'create' ) {
            $title       = sanitize_text_field( isset( $_POST['title'] ) ? $_POST['title'] : '' );
            $assigned_to = (int) ( isset( $_POST['assigned_to'] ) ? $_POST['assigned_to'] : 0 );
            $due_date    = ( isset( $_POST['due_date'] ) && $_POST['due_date'] ) ? sanitize_text_field( $_POST['due_date'] ) : null;
            if ( $title ) {
                $wpdb->insert( $wpdb->prefix . 'sp_tasks', array(
                    'record_type' => 'general',
                    'record_id'   => 0,
                    'title'       => $title,
                    'assigned_to' => $assigned_to,
                    'due_date'    => $due_date,
                    'status'      => 'open',
                    'created_by'  => $member ? (int) $member->id : 0,
                    'created_at'  => current_time( 'mysql' ),
                ) );
                sp_log_activity( 'general', 0, 'task_created', $title );
            }
            wp_redirect( $redirect ); exit;
        }

        if ( $task_id ) {
            $task = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_tasks WHERE id = %d", $task_id ) );
            if ( $task ) {
                if ( $op === 'complete' ) {
                    $wpdb->update( $wpdb->prefix . 'sp_tasks', array( 'status' => 'done' ), array( 'id' => $task_id ) );
                    sp_log_activity( $task->record_type, $task->record_id, 'task_done', $task->title );
                } elseif ( $op === 'reopen' ) {
                    $wpdb->update( $wpdb->prefix . 'sp_tasks', array( 'status' => 'open' ), array( 'id' => $task_id ) );
                    sp_log_activity( $task->record_type, $task->record_id, 'task_open', $task->title );
                } elseif ( $op === 'reschedule' ) {
                    $due = ( isset( $_POST['due_date'] ) && $_POST['due_date'] ) ? sanitize_text_field( $_POST['due_date'] ) : null;
                    $wpdb->update( $wpdb->prefix . 'sp_tasks', array( 'due_date' => $due ), array( 'id' => $task_id ) );
                } elseif ( $op === 'reassign' ) {
                    $assignee = (int) ( isset( $_POST['assigned_to'] ) ? $_POST['assigned_to'] : 0 );
                    $wpdb->update( $wpdb->prefix . 'sp_tasks', array( 'assigned_to' => $assignee ), array( 'id' => $task_id ) );
                } elseif ( $op === 'delete' ) {
                    if ( sp_is_admin_member() || ( $member && (int) $task->created_by === (int) $member->id ) ) {
                        $wpdb->delete( $wpdb->prefix . 'sp_tasks', array( 'id' => $task_id ) );
                    }
                }
            }
        }
        wp_redirect( $redirect ); exit;
    }

    if ( $type === 'attachment' ) {
        $record_type = sanitize_key( isset( $_POST['record_type'] ) ? $_POST['record_type'] : '' );
        $record_id   = (int) ( isset( $_POST['record_id'] ) ? $_POST['record_id'] : 0 );
        $member      = sp_get_current_team_member();
        if ( ! empty( $_FILES['sp_file'] ) && $_FILES['sp_file']['error'] === UPLOAD_ERR_OK ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            $upload = wp_handle_upload( $_FILES['sp_file'], array( 'test_form' => false ) );
            if ( $upload && ! isset( $upload['error'] ) ) {
                $wpdb->insert( $wpdb->prefix . 'sp_attachments', array(
                    'record_type' => $record_type,
                    'record_id'   => $record_id,
                    'filename'    => sanitize_file_name( $_FILES['sp_file']['name'] ),
                    'filepath'    => $upload['file'],
                    'fileurl'     => $upload['url'],
                    'filesize'    => (int) $_FILES['sp_file']['size'],
                    'filetype'    => $upload['type'],
                    'created_by'  => $member ? (int) $member->id : 0,
                    'created_at'  => current_time( 'mysql' ),
                ) );
                sp_log_activity( $record_type, $record_id, 'file_attached', sanitize_file_name( $_FILES['sp_file']['name'] ) );
            }
        }
        wp_redirect( home_url( '/sp-app/?view=' . $record_type . 's&action=view&id=' . $record_id . '&tab=files' ) ); exit;
    }

    if ( $type === 'bulk' ) {
        $entity = sanitize_key( isset( $_POST['sp_entity'] ) ? $_POST['sp_entity'] : '' );
        $ba     = sanitize_text_field( isset( $_POST['bulk_action'] ) ? $_POST['bulk_action'] : '' );
        $ids    = array_filter( array_map( 'intval', (array) ( isset( $_POST['ids'] ) ? $_POST['ids'] : array() ) ) );

        $tables   = array( 'contacts' => 'sp_contacts', 'companies' => 'sp_companies', 'leads' => 'sp_leads' );
        $singular = array( 'contacts' => 'contact', 'companies' => 'company', 'leads' => 'lead' );
        $statuses = array(
            'contacts'  => array( 'active', 'inactive' ),
            'leads'     => array( 'new', 'contacted', 'qualified', 'unqualified', 'closed' ),
            'companies' => array(),
        );

        if ( ! isset( $tables[ $entity ] ) || empty( $ids ) || ! $ba ) {
            wp_redirect( home_url( '/sp-app/?view=' . ( isset( $tables[ $entity ] ) ? $entity : 'dashboard' ) ) ); exit;
        }
        $table        = $wpdb->prefix . $tables[ $entity ];
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

        if ( $ba === 'delete' ) {
            if ( ! sp_is_admin_member() ) { wp_redirect( home_url( '/sp-app/?view=' . $entity ) ); exit; }
            $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE id IN ($placeholders)", $ids ) );
            foreach ( $ids as $bid ) sp_log_activity( $singular[ $entity ], $bid, 'deleted', 'Bulk deleted' );
            wp_redirect( home_url( '/sp-app/?view=' . $entity . '&saved=1' ) ); exit;
        }

        if ( strpos( $ba, 'status:' ) === 0 ) {
            $new = sanitize_key( substr( $ba, 7 ) );
            if ( ! in_array( $new, $statuses[ $entity ], true ) ) {
                wp_redirect( home_url( '/sp-app/?view=' . $entity ) ); exit;
            }
            $args = array_merge( array( $new ), $ids );
            $wpdb->query( $wpdb->prepare( "UPDATE $table SET status=%s WHERE id IN ($placeholders)", $args ) );
            foreach ( $ids as $bid ) sp_log_activity( $singular[ $entity ], $bid, 'status_change', 'Bulk set to ' . $new );
            wp_redirect( home_url( '/sp-app/?view=' . $entity . '&saved=1' ) ); exit;
        }

        wp_redirect( home_url( '/sp-app/?view=' . $entity ) ); exit;
    }

    if ( $type === 'email_log' ) {
        $record_type = sanitize_key( isset( $_POST['record_type'] ) ? $_POST['record_type'] : '' );
        $record_id   = (int) ( isset( $_POST['record_id'] ) ? $_POST['record_id'] : 0 );
        $member      = sp_get_current_team_member();
        if ( $record_type && $record_id ) {
            $wpdb->insert( $wpdb->prefix . 'sp_email_log', array(
                'record_type' => $record_type,
                'record_id'   => $record_id,
                'direction'   => in_array( isset( $_POST['direction'] ) ? $_POST['direction'] : '', array( 'sent', 'received' ) ) ? $_POST['direction'] : 'sent',
                'subject'     => sanitize_text_field( isset( $_POST['subject'] ) ? $_POST['subject'] : '' ),
                'body'        => sanitize_textarea_field( isset( $_POST['body'] ) ? $_POST['body'] : '' ),
                'logged_by'   => $member ? (int) $member->id : 0,
                'logged_at'   => current_time( 'mysql' ),
            ) );
            sp_log_activity( $record_type, $record_id, 'email_logged', ( $_POST['direction'] === 'received' ? 'Received: ' : 'Sent: ' ) . sanitize_text_field( isset( $_POST['subject'] ) ? $_POST['subject'] : '' ) );
        }
        wp_redirect( home_url( '/sp-app/?view=' . $record_type . 's&action=view&id=' . $record_id . '&tab=emails' ) ); exit;
    }

    do_action( 'sp_post_handler_' . $type, $id );
    wp_redirect( home_url( '/sp-app/' ) ); exit;
}

// ── DELETE handler ─────────────────────────────────────────────────────────────

function sp_handle_delete() {
    $type  = sanitize_key( isset( $_GET['sp_delete'] ) ? $_GET['sp_delete'] : '' );
    $id    = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
    $nonce = isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '';

    if ( ! wp_verify_nonce( $nonce, 'sp_delete_' . $type . '_' . $id ) ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }

    // Only admins can delete records
    if ( ! sp_is_admin_member() ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }

    global $wpdb;
    if ( $type === 'contact' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_contacts', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=contacts' ) ); exit;
    }
    if ( $type === 'company' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_companies', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=companies' ) ); exit;
    }
    if ( $type === 'lead' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_leads', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=leads' ) ); exit;
    }
    if ( $type === 'team_member' ) {
        $current = sp_get_current_team_member();
        if ( $current && $current->id !== $id ) {
            $wpdb->delete( $wpdb->prefix . 'sp_team', array( 'id' => $id ) );
        }
        wp_redirect( home_url( '/sp-app/?view=team' ) ); exit;
    }

    if ( $type === 'note' ) {
        $note = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_notes WHERE id = %d", $id ) );
        if ( $note ) {
            $wpdb->delete( $wpdb->prefix . 'sp_notes', array( 'id' => $id ) );
            wp_redirect( home_url( '/sp-app/?view=' . $note->record_type . 's&action=view&id=' . $note->record_id . '&tab=notes' ) ); exit;
        }
    }
    if ( $type === 'task' ) {
        $task = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_tasks WHERE id = %d", $id ) );
        if ( $task ) {
            $wpdb->delete( $wpdb->prefix . 'sp_tasks', array( 'id' => $id ) );
            wp_redirect( home_url( '/sp-app/?view=' . $task->record_type . 's&action=view&id=' . $task->record_id . '&tab=tasks' ) ); exit;
        }
    }
    if ( $type === 'attachment' ) {
        $att = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_attachments WHERE id = %d", $id ) );
        if ( $att ) {
            if ( $att->filepath && file_exists( $att->filepath ) ) {
                @unlink( $att->filepath );
            }
            $wpdb->delete( $wpdb->prefix . 'sp_attachments', array( 'id' => $id ) );
            wp_redirect( home_url( '/sp-app/?view=' . $att->record_type . 's&action=view&id=' . $att->record_id . '&tab=files' ) ); exit;
        }
    }

    if ( $type === 'email_log' ) {
        $em = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_email_log WHERE id = %d", $id ) );
        if ( $em ) {
            $wpdb->delete( $wpdb->prefix . 'sp_email_log', array( 'id' => $id ) );
            wp_redirect( home_url( '/sp-app/?view=' . $em->record_type . 's&action=view&id=' . $em->record_id . '&tab=emails' ) ); exit;
        }
    }

    do_action( 'sp_delete_handler_' . $type, $id );
    wp_redirect( home_url( '/sp-app/' ) ); exit;
}

// ── Export handler ─────────────────────────────────────────────────────────────

function sp_handle_export() {
    if ( ! sp_get_current_team_member() ) {
        wp_redirect( home_url( '/sp-login/' ) ); exit;
    }
    global $wpdb;
    $type = sanitize_key( isset( $_GET['sp_export'] ) ? $_GET['sp_export'] : '' );

    if ( $type === 'contacts' ) {
        $rows    = $wpdb->get_results( "SELECT first_name, last_name, email, phone, source, status, notes, created_at FROM {$wpdb->prefix}sp_contacts ORDER BY created_at DESC", ARRAY_A );
        $headers = array( 'First Name', 'Last Name', 'Email', 'Phone', 'Source', 'Status', 'Notes', 'Created' );
        $file    = 'contacts-' . date( 'Y-m-d' ) . '.csv';
    } elseif ( $type === 'companies' ) {
        $rows    = $wpdb->get_results( "SELECT name, industry, website, phone, address, notes, created_at FROM {$wpdb->prefix}sp_companies ORDER BY created_at DESC", ARRAY_A );
        $headers = array( 'Name', 'Industry', 'Website', 'Phone', 'Address', 'Notes', 'Created' );
        $file    = 'companies-' . date( 'Y-m-d' ) . '.csv';
    } elseif ( $type === 'leads' ) {
        $rows    = $wpdb->get_results( "SELECT COALESCE(CONCAT(c.first_name,' ',c.last_name),'') AS contact_name, c.email AS contact_email, co.name AS company_name, l.source, l.status, l.score, l.notes, l.created_at FROM {$wpdb->prefix}sp_leads l LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id=l.contact_id LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id=l.company_id ORDER BY l.created_at DESC", ARRAY_A );
        $headers = array( 'Contact Name', 'Contact Email', 'Company', 'Source', 'Status', 'Score', 'Notes', 'Created' );
        $file    = 'leads-' . date( 'Y-m-d' ) . '.csv';
    } elseif ( $type === 'activity' ) {
        $from   = isset( $_GET['from'] )   ? sanitize_text_field( $_GET['from'] )   : date( 'Y-m-d', strtotime( '-30 days' ) );
        $to     = isset( $_GET['to'] )     ? sanitize_text_field( $_GET['to'] )     : date( 'Y-m-d' );
        $member = isset( $_GET['member'] ) ? (int) $_GET['member']                  : 0;
        $where  = "WHERE a.created_at >= '{$from} 00:00:00' AND a.created_at <= '{$to} 23:59:59'";
        if ( $member ) $where .= " AND a.created_by = $member";
        $rows    = $wpdb->get_results( "SELECT a.created_at, t.name AS member_name, a.action, a.record_type, a.record_id, a.detail FROM {$wpdb->prefix}sp_activity a LEFT JOIN {$wpdb->prefix}sp_team t ON t.id=a.created_by $where ORDER BY a.created_at DESC", ARRAY_A );
        $headers = array( 'Date', 'Team Member', 'Action', 'Record Type', 'Record ID', 'Detail' );
        $file    = 'activity-' . $from . '-' . $to . '.csv';
    } else {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }

    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename="' . $file . '"' );
    $out = fopen( 'php://output', 'w' );
    fputcsv( $out, $headers );
    foreach ( $rows as $row ) {
        fputcsv( $out, array_values( $row ) );
    }
    fclose( $out );
}

// ── Platform AJAX ──────────────────────────────────────────────────────────────

function sp_handle_platform_ajax( $action ) {
    header( 'Content-Type: application/json; charset=utf-8' );
    if ( ! sp_get_current_team_member() && ! sp_is_super_admin() ) {
        echo json_encode( array( 'success' => false, 'data' => 'Not authorized' ) ); exit;
    }

    if ( $action === 'pipeline_move' ) {
        global $wpdb;
        $id     = (int) ( isset( $_POST['lead_id'] ) ? $_POST['lead_id'] : 0 );
        $status = sanitize_key( isset( $_POST['status'] ) ? $_POST['status'] : '' );
        $valid  = array( 'new', 'contacted', 'qualified', 'unqualified', 'closed' );
        if ( ! $id || ! in_array( $status, $valid ) ) {
            echo json_encode( array( 'success' => false, 'data' => 'Invalid data' ) ); exit;
        }
        $old = $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$wpdb->prefix}sp_leads WHERE id=%d", $id ) );
        $wpdb->update( $wpdb->prefix . 'sp_leads', array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
        sp_log_activity( 'lead', $id, 'status_change', 'Status changed from ' . $old . ' to ' . $status );
        echo json_encode( array( 'success' => true ) ); exit;
    }

    if ( $action === 'search' ) {
        global $wpdb;
        $q = isset( $_GET['q'] ) ? sanitize_text_field( trim( $_GET['q'] ) ) : '';
        if ( strlen( $q ) < 2 ) { echo json_encode( array( 'success' => true, 'data' => array() ) ); exit; }
        $like = '%' . $wpdb->esc_like( $q ) . '%';

        $contacts = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, CONCAT(first_name,' ',last_name) AS label, email AS sub FROM {$wpdb->prefix}sp_contacts
             WHERE first_name LIKE %s OR last_name LIKE %s OR email LIKE %s LIMIT 5",
            $like, $like, $like
        ) );

        $companies = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, name AS label, industry AS sub FROM {$wpdb->prefix}sp_companies WHERE name LIKE %s LIMIT 5",
            $like
        ) );

        $leads = $wpdb->get_results( $wpdb->prepare(
            "SELECT l.id, CONCAT(c.first_name,' ',c.last_name) AS label, l.status AS sub
             FROM {$wpdb->prefix}sp_leads l
             LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id
             WHERE c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s LIMIT 5",
            $like, $like, $like
        ) );

        $results = array();
        foreach ( $contacts  as $r ) $results[] = array( 'type' => 'contact',  'id' => $r->id, 'label' => trim($r->label), 'sub' => $r->sub );
        foreach ( $companies as $r ) $results[] = array( 'type' => 'company',  'id' => $r->id, 'label' => $r->label,        'sub' => $r->sub );
        foreach ( $leads     as $r ) $results[] = array( 'type' => 'lead',     'id' => $r->id, 'label' => trim($r->label), 'sub' => $r->sub );

        echo json_encode( array( 'success' => true, 'data' => $results ) ); exit;
    }

    echo json_encode( array( 'success' => false, 'data' => 'Unknown action' ) ); exit;
}

// ── Onboarding Setup ───────────────────────────────────────────────────────────

function sp_handle_setup_post() {
    $step = (int) $_POST['sp_setup_step'];

    if ( $step === 1 ) {
        if ( ! wp_verify_nonce( isset( $_POST['sp_setup_nonce'] ) ? $_POST['sp_setup_nonce'] : '', 'sp_setup_1' ) ) {
            wp_redirect( home_url( '/sp-setup/?step=1&error=nonce' ) ); exit;
        }
        $name   = sanitize_text_field( isset( $_POST['sp_platform_name'] ) ? $_POST['sp_platform_name'] : '' );
        $accent = sanitize_hex_color( isset( $_POST['sp_accent_color'] ) ? $_POST['sp_accent_color'] : '' );
        if ( $name ) update_option( 'sp_platform_name', $name );
        if ( $accent ) update_option( 'sp_accent_color', $accent );
        wp_redirect( home_url( '/sp-setup/?step=2' ) ); exit;
    }

    if ( $step === 2 ) {
        if ( ! wp_verify_nonce( isset( $_POST['sp_setup_nonce'] ) ? $_POST['sp_setup_nonce'] : '', 'sp_setup_2' ) ) {
            wp_redirect( home_url( '/sp-setup/?step=2&error=nonce' ) ); exit;
        }
        $logo     = esc_url_raw( isset( $_POST['sp_brand_icon_url'] ) ? $_POST['sp_brand_icon_url'] : '' );
        $initials = sanitize_text_field( isset( $_POST['sp_brand_initials'] ) ? strtoupper( $_POST['sp_brand_initials'] ) : '' );
        update_option( 'sp_brand_icon_url', $logo );
        update_option( 'sp_brand_initials', $initials );
        wp_redirect( home_url( '/sp-setup/?step=3' ) ); exit;
    }

    if ( $step === 3 ) {
        if ( ! wp_verify_nonce( isset( $_POST['sp_setup_nonce'] ) ? $_POST['sp_setup_nonce'] : '', 'sp_setup_3' ) ) {
            wp_redirect( home_url( '/sp-setup/?step=3&error=nonce' ) ); exit;
        }
        $name    = sanitize_text_field( isset( $_POST['admin_name'] ) ? $_POST['admin_name'] : '' );
        $email   = sanitize_email( isset( $_POST['admin_email'] ) ? $_POST['admin_email'] : '' );
        $pin     = isset( $_POST['admin_pin'] ) ? trim( $_POST['admin_pin'] ) : '';
        $confirm = isset( $_POST['admin_pin_confirm'] ) ? trim( $_POST['admin_pin_confirm'] ) : '';

        if ( ! $name ) { wp_redirect( home_url( '/sp-setup/?step=3&error=name_required' ) ); exit; }
        if ( strlen( $pin ) < 4 ) { wp_redirect( home_url( '/sp-setup/?step=3&error=pin_short' ) ); exit; }
        if ( $pin !== $confirm ) { wp_redirect( home_url( '/sp-setup/?step=3&error=pin_mismatch' ) ); exit; }

        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sp_team', array(
            'name'       => $name,
            'email'      => $email,
            'role'       => 'admin',
            'pin'        => wp_hash_password( $pin ),
            'status'     => 'active',
            'created_at' => current_time( 'mysql' ),
            'updated_at' => current_time( 'mysql' ),
        ) );

        update_option( 'sp_setup_complete', 1 );
        wp_redirect( home_url( '/sp-login/?setup=done' ) ); exit;
    }

    wp_redirect( home_url( '/sp-setup/' ) ); exit;
}

// ── CSV Import ─────────────────────────────────────────────────────────────────

function sp_handle_import() {
    global $wpdb;
    $member = sp_get_current_team_member();
    if ( ! $member ) { wp_redirect( home_url( '/sp-login/' ) ); exit; }
    if ( ! wp_verify_nonce( isset( $_POST['sp_nonce'] ) ? $_POST['sp_nonce'] : '', 'sp_form' ) ) { wp_redirect( home_url( '/sp-app/?view=import&error=nonce' ) ); exit; }

    $type = sanitize_key( isset( $_POST['import_type'] ) ? $_POST['import_type'] : '' );
    if ( ! in_array( $type, array( 'contacts', 'companies', 'leads' ) ) ) { wp_redirect( home_url( '/sp-app/?view=import' ) ); exit; }
    if ( empty( $_FILES['sp_csv']['tmp_name'] ) ) { wp_redirect( home_url( '/sp-app/?view=import&type=' . $type ) ); exit; }

    $handle = fopen( $_FILES['sp_csv']['tmp_name'], 'r' );
    if ( ! $handle ) { wp_redirect( home_url( '/sp-app/?view=import&type=' . $type ) ); exit; }

    $headers = fgetcsv( $handle );
    if ( ! $headers ) { fclose( $handle ); wp_redirect( home_url( '/sp-app/?view=import&type=' . $type ) ); exit; }
    $headers = array_map( 'trim', $headers );
    $col     = array_flip( $headers );

    $imported = 0;
    $skipped  = 0;
    $now      = current_time( 'mysql' );

    while ( ( $row = fgetcsv( $handle ) ) !== false ) {
        $v = function( $key ) use ( $row, $col ) {
            return isset( $col[ $key ], $row[ $col[ $key ] ] ) ? trim( $row[ $col[ $key ] ] ) : '';
        };

        if ( $type === 'contacts' ) {
            $first = $v('first_name'); $last = $v('last_name'); $email = $v('email');
            if ( ! $first && ! $email ) { $skipped++; continue; }
            if ( $email ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sp_contacts WHERE email=%s", $email ) );
                if ( $exists ) { $skipped++; continue; }
            }
            $status = $v('status'); if ( ! in_array( $status, array( 'active','inactive','archived' ) ) ) $status = 'active';
            $wpdb->insert( $wpdb->prefix . 'sp_contacts', array(
                'first_name' => $first, 'last_name' => $last, 'email' => $email,
                'phone' => $v('phone'), 'source' => $v('source'), 'status' => $status,
                'notes' => $v('notes'), 'created_at' => $now, 'updated_at' => $now,
            ) );
            sp_log_activity( 'contact', $wpdb->insert_id, 'created', 'Imported via CSV' );
            $imported++;

        } elseif ( $type === 'companies' ) {
            $name = $v('name'); if ( ! $name ) { $skipped++; continue; }
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sp_companies WHERE name=%s", $name ) );
            if ( $exists ) { $skipped++; continue; }
            $wpdb->insert( $wpdb->prefix . 'sp_companies', array(
                'name' => $name, 'industry' => $v('industry'), 'website' => $v('website'),
                'phone' => $v('phone'), 'address' => $v('address'), 'notes' => $v('notes'),
                'created_at' => $now, 'updated_at' => $now,
            ) );
            sp_log_activity( 'company', $wpdb->insert_id, 'created', 'Imported via CSV' );
            $imported++;

        } elseif ( $type === 'leads' ) {
            $contact_id = 0; $company_id = 0;
            $contact_email = $v('contact_email');
            if ( $contact_email ) {
                $contact_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sp_contacts WHERE email=%s", $contact_email ) );
            }
            $company_name = $v('company_name');
            if ( $company_name ) {
                $company_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sp_companies WHERE name=%s", $company_name ) );
            }
            if ( ! $contact_id && ! $company_name ) { $skipped++; continue; }
            $status = $v('status'); if ( ! in_array( $status, array( 'new','contacted','qualified','unqualified','closed' ) ) ) $status = 'new';
            $score  = (int) $v('score'); if ( $score < 0 || $score > 100 ) $score = 0;
            $wpdb->insert( $wpdb->prefix . 'sp_leads', array(
                'contact_id' => $contact_id, 'company_id' => $company_id,
                'source' => $v('source'), 'status' => $status, 'score' => $score,
                'notes' => $v('notes'), 'created_at' => $now, 'updated_at' => $now,
            ) );
            sp_log_activity( 'lead', $wpdb->insert_id, 'created', 'Imported via CSV' );
            $imported++;
        }
    }
    fclose( $handle );
    wp_redirect( home_url( '/sp-app/?view=import&type=' . $type . '&imported=' . $imported . '&skipped=' . $skipped ) ); exit;
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function sp_delete_url( $type, $id ) {
    return wp_nonce_url(
        home_url( '/sp-app/?sp_delete=' . $type . '&id=' . $id ),
        'sp_delete_' . $type . '_' . $id
    );
}

// ── Addon activate / deactivate ────────────────────────────────────────────────

add_action( 'wp_ajax_sp_addon_toggle', 'sp_ajax_addon_toggle' );

function sp_ajax_addon_toggle() {
    if ( ! check_ajax_referer( 'sp_addon_toggle', 'nonce', false ) ) {
        wp_send_json_error( 'Invalid nonce' );
    }
    if ( ! sp_is_admin_member() ) {
        wp_send_json_error( 'Not authorized' );
    }
    if ( ! current_user_can( 'activate_plugins' ) ) {
        wp_send_json_error( 'WordPress permissions required' );
    }

    $plugin_file = isset( $_POST['plugin_file'] ) ? sanitize_text_field( $_POST['plugin_file'] ) : '';
    $action      = isset( $_POST['toggle'] )      ? sanitize_key( $_POST['toggle'] )             : '';

    if ( ! $plugin_file || ! in_array( $action, array( 'activate', 'deactivate' ) ) ) {
        wp_send_json_error( 'Invalid request' );
    }

    require_once ABSPATH . 'wp-admin/includes/plugin.php';

    if ( $action === 'activate' ) {
        $result = activate_plugin( $plugin_file );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }
    } else {
        deactivate_plugins( $plugin_file );
    }

    wp_send_json_success( array( 'action' => $action ) );
}

function sp_pagination( $total, $limit, $paged, $view ) {
    $pages = (int) ceil( $total / $limit );
    if ( $pages <= 1 ) return;
    echo '<div class="sp-pagination">';
    if ( $paged > 1 ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged - 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">&larr; Prev</a>';
    echo '<span>Page ' . $paged . ' of ' . $pages . '</span>';
    if ( $paged < $pages ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged + 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">Next &rarr;</a>';
    echo '</div>';
}
