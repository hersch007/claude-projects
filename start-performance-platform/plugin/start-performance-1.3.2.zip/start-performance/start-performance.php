<?php
/*
 * Plugin Name: Start Performance
 * Description: Start Performance Platform — core
 * Version:     1.3.2
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_VERSION',    '1.3.2' );
define( 'SP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_activate' );
register_deactivation_hook( __FILE__, 'sp_deactivate' );

function sp_activate() {
    sp_create_tables();
    do_action( 'sp_activate' );
    flush_rewrite_rules();
}

function sp_deactivate() {
    flush_rewrite_rules();
}

function sp_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_contacts (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL DEFAULT '',
  last_name varchar(100) NOT NULL DEFAULT '',
  email varchar(200) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  company_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(100) NOT NULL DEFAULT '',
  status varchar(50) NOT NULL DEFAULT 'active',
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY email (email(100)),
  KEY status (status)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_companies (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL DEFAULT '',
  industry varchar(100) NOT NULL DEFAULT '',
  website varchar(255) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  address text,
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY name (name(100))
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_leads (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
  company_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(100) NOT NULL DEFAULT '',
  status varchar(50) NOT NULL DEFAULT 'new',
  score tinyint(3) unsigned NOT NULL DEFAULT 0,
  notes text,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY status (status),
  KEY contact_id (contact_id)
) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}sp_team (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL DEFAULT '',
  email varchar(200) NOT NULL DEFAULT '',
  role varchar(20) NOT NULL DEFAULT 'agent',
  pin varchar(255) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'active',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY role (role),
  KEY status (status)
) $charset;" );
}

// ── Team migration ─────────────────────────────────────────────────────────────
// On first load after upgrade, seed sp_team with an Admin using the legacy PIN.

add_action( 'init', 'sp_maybe_migrate_team', 5 );

function sp_maybe_migrate_team() {
    global $wpdb;
    $table = $wpdb->prefix . 'sp_team';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) ) return;
    $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
    if ( $count > 0 ) return;
    $existing_pin = get_option( 'sp_pin', '1234' );
    $wpdb->insert( $table, array(
        'name'       => 'Admin',
        'email'      => '',
        'role'       => 'admin',
        'pin'        => wp_hash_password( $existing_pin ),
        'status'     => 'active',
        'created_at' => current_time( 'mysql' ),
    ) );
}

// ── View registry ──────────────────────────────────────────────────────────────

$sp_view_registry = array();

function sp_register_view( $slug, $file_path ) {
    global $sp_view_registry;
    $sp_view_registry[ $slug ] = $file_path;
}

function sp_get_view_file( $slug ) {
    global $sp_view_registry;
    if ( isset( $sp_view_registry[ $slug ] ) && file_exists( $sp_view_registry[ $slug ] ) ) {
        return $sp_view_registry[ $slug ];
    }
    $core = SP_PLUGIN_DIR . 'templates/views/' . $slug . '.php';
    return file_exists( $core ) ? $core : '';
}

// ── Addon registry ─────────────────────────────────────────────────────────────

$sp_addon_registry = array();

function sp_register_addon( $id, $data ) {
    global $sp_addon_registry;
    $sp_addon_registry[ $id ] = array_merge( array(
        'name'         => '',
        'version'      => '',
        'description'  => '',
        'settings_url' => '',
        'icon'         => '',
    ), $data );
}

function sp_get_addons() {
    global $sp_addon_registry;
    return $sp_addon_registry;
}

// ── Team auth helpers ──────────────────────────────────────────────────────────

function sp_set_team_cookie( $member_id ) {
    $token = $member_id . '|' . hash_hmac( 'sha256', (string) $member_id, wp_salt( 'auth' ) );
    setcookie( 'sp_team_auth', $token, 0, '/', COOKIE_DOMAIN, is_ssl(), true );
}

function sp_clear_team_cookie() {
    setcookie( 'sp_team_auth', '', time() - 3600, '/', COOKIE_DOMAIN, is_ssl(), true );
}

function sp_get_current_team_member() {
    static $cache = false;
    if ( $cache !== false ) return $cache;
    if ( empty( $_COOKIE['sp_team_auth'] ) ) { $cache = null; return null; }
    $parts = explode( '|', $_COOKIE['sp_team_auth'], 2 );
    if ( count( $parts ) !== 2 ) { $cache = null; return null; }
    list( $id, $hash ) = $parts;
    $id = (int) $id;
    if ( ! hash_equals( hash_hmac( 'sha256', (string) $id, wp_salt( 'auth' ) ), $hash ) ) {
        $cache = null; return null;
    }
    global $wpdb;
    $cache = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}sp_team WHERE id = %d AND status = 'active'", $id
    ) );
    return $cache;
}

function sp_is_admin_member() {
    $m = sp_get_current_team_member();
    return $m && $m->role === 'admin';
}

function sp_current_member_can( $cap ) {
    $m = sp_get_current_team_member();
    if ( ! $m ) return false;
    if ( $m->role === 'admin' ) return true;
    $agent_caps = array( 'edit_records' );
    return in_array( $cap, $agent_caps );
}

// ── URL Routing ────────────────────────────────────────────────────────────────

add_action( 'init', 'sp_route', 1 );

function sp_route() {
    $uri     = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
    $wp_path = trim( parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
    if ( $wp_path ) {
        $uri = trim( substr( $uri, strlen( $wp_path ) ), '/' );
    }

    // ── /sp-login/ ─────────────────────────────────────────────────────────────
    if ( $uri === 'sp-login' ) {
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && ! empty( $_POST['sp_login_nonce'] ) ) {
            if ( ! wp_verify_nonce( $_POST['sp_login_nonce'], 'sp_login' ) ) {
                wp_redirect( home_url( '/sp-login/?error=invalid' ) ); exit;
            }
            global $wpdb;
            $team_id = (int) ( isset( $_POST['sp_team_id'] ) ? $_POST['sp_team_id'] : 0 );
            $pin     = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';
            $member  = $team_id ? $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_team WHERE id = %d AND status = 'active'", $team_id
            ) ) : null;
            if ( ! $member || ! wp_check_password( $pin, $member->pin ) ) {
                wp_redirect( home_url( '/sp-login/?error=pin' ) ); exit;
            }
            $admins = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
            if ( empty( $admins ) ) {
                wp_redirect( home_url( '/sp-login/?error=nouser' ) ); exit;
            }
            wp_set_current_user( $admins[0]->ID );
            wp_set_auth_cookie( $admins[0]->ID, true );
            sp_set_team_cookie( $member->id );
            wp_redirect( home_url( '/sp-app/' ) ); exit;
        }
        require SP_PLUGIN_DIR . 'templates/login.php'; exit;
    }

    // ── /sp-app/ ───────────────────────────────────────────────────────────────
    if ( $uri === 'sp-app' ) {
        if ( ! is_user_logged_in() ) {
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( isset( $_GET['sp_logout'] ) ) {
            wp_logout();
            sp_clear_team_cookie();
            wp_redirect( home_url( '/sp-login/' ) ); exit;
        }
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
            sp_handle_post(); exit;
        }
        if ( isset( $_GET['sp_delete'] ) ) {
            sp_handle_delete(); exit;
        }
        require SP_PLUGIN_DIR . 'templates/app.php'; exit;
    }
}

// ── Block wp-admin ─────────────────────────────────────────────────────────────

add_action( 'admin_init', function() {
    if ( wp_doing_ajax() ) return;
    if ( ! is_user_logged_in() ) {
        wp_redirect( home_url( '/sp-login/' ) ); exit;
    }
} );

// ── POST handler ───────────────────────────────────────────────────────────────

function sp_handle_post() {
    if ( empty( $_POST['sp_nonce'] ) || ! wp_verify_nonce( $_POST['sp_nonce'], 'sp_form' ) ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }
    global $wpdb;
    $type = isset( $_POST['sp_type'] ) ? sanitize_key( $_POST['sp_type'] ) : '';
    $id   = (int) ( isset( $_POST['sp_id'] ) ? $_POST['sp_id'] : 0 );

    if ( $type === 'contact' ) {
        $data = array(
            'first_name' => sanitize_text_field( isset( $_POST['first_name'] ) ? $_POST['first_name'] : '' ),
            'last_name'  => sanitize_text_field( isset( $_POST['last_name'] )  ? $_POST['last_name']  : '' ),
            'email'      => sanitize_email(      isset( $_POST['email'] )      ? $_POST['email']      : '' ),
            'phone'      => sanitize_text_field( isset( $_POST['phone'] )      ? $_POST['phone']      : '' ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field( isset( $_POST['source'] )     ? $_POST['source']     : '' ),
            'status'     => sanitize_key(        isset( $_POST['status'] )     ? $_POST['status']     : 'active' ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']      : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_contacts', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_contacts', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=contacts&saved=1' ) ); exit;
    }

    if ( $type === 'company' ) {
        $data = array(
            'name'     => sanitize_text_field(     isset( $_POST['name'] )     ? $_POST['name']     : '' ),
            'industry' => sanitize_text_field(     isset( $_POST['industry'] ) ? $_POST['industry'] : '' ),
            'website'  => esc_url_raw(             isset( $_POST['website'] )  ? $_POST['website']  : '' ),
            'phone'    => sanitize_text_field(     isset( $_POST['phone'] )    ? $_POST['phone']    : '' ),
            'address'  => sanitize_textarea_field( isset( $_POST['address'] )  ? $_POST['address']  : '' ),
            'notes'    => sanitize_textarea_field( isset( $_POST['notes'] )    ? $_POST['notes']    : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_companies', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_companies', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=companies&saved=1' ) ); exit;
    }

    if ( $type === 'lead' ) {
        $data = array(
            'contact_id' => (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 ),
            'company_id' => (int) ( isset( $_POST['company_id'] ) ? $_POST['company_id'] : 0 ),
            'source'     => sanitize_text_field(     isset( $_POST['source'] ) ? $_POST['source'] : '' ),
            'status'     => sanitize_key(            isset( $_POST['status'] ) ? $_POST['status'] : 'new' ),
            'score'      => min( 100, max( 0, (int) ( isset( $_POST['score'] ) ? $_POST['score'] : 0 ) ) ),
            'notes'      => sanitize_textarea_field( isset( $_POST['notes'] )  ? $_POST['notes']  : '' ),
        );
        if ( $id ) {
            $wpdb->update( $wpdb->prefix . 'sp_leads', $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_leads', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=leads&saved=1' ) ); exit;
    }

    if ( $type === 'settings' ) {
        if ( sp_is_admin_member() ) {
            update_option( 'sp_platform_name', sanitize_text_field( isset( $_POST['sp_platform_name'] ) ? $_POST['sp_platform_name'] : 'Start Performance' ) );
        }
        wp_redirect( home_url( '/sp-app/?view=settings&saved=1' ) ); exit;
    }

    if ( $type === 'team_member' ) {
        if ( ! sp_is_admin_member() ) {
            wp_redirect( home_url( '/sp-app/' ) ); exit;
        }
        $name   = sanitize_text_field( isset( $_POST['name'] )  ? $_POST['name']  : '' );
        $email  = sanitize_email(      isset( $_POST['email'] ) ? $_POST['email'] : '' );
        $role   = sanitize_key(        isset( $_POST['role'] )  ? $_POST['role']  : 'agent' );
        $role   = in_array( $role, array( 'admin', 'agent' ) ) ? $role : 'agent';
        $status = sanitize_key(        isset( $_POST['status'] ) ? $_POST['status'] : 'active' );
        $status = in_array( $status, array( 'active', 'inactive' ) ) ? $status : 'active';
        $new_pin = isset( $_POST['pin'] ) ? trim( $_POST['pin'] ) : '';
        $data = array( 'name' => $name, 'email' => $email, 'role' => $role, 'status' => $status );
        if ( $id ) {
            if ( $new_pin !== '' ) {
                $data['pin'] = wp_hash_password( $new_pin );
            }
            $wpdb->update( $wpdb->prefix . 'sp_team', $data, array( 'id' => $id ) );
        } else {
            if ( $new_pin === '' ) {
                wp_redirect( home_url( '/sp-app/?view=team&error=nopin' ) ); exit;
            }
            $data['pin']        = wp_hash_password( $new_pin );
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'sp_team', $data );
        }
        wp_redirect( home_url( '/sp-app/?view=team&saved=1' ) ); exit;
    }

    do_action( 'sp_post_handler_' . $type, $id );
    wp_redirect( home_url( '/sp-app/' ) ); exit;
}

// ── DELETE handler ─────────────────────────────────────────────────────────────

function sp_handle_delete() {
    $type  = sanitize_key( isset( $_GET['sp_delete'] ) ? $_GET['sp_delete'] : '' );
    $id    = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );
    $nonce = isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '';

    if ( ! wp_verify_nonce( $nonce, 'sp_delete_' . $type . '_' . $id ) ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }

    // Only admins can delete records
    if ( ! sp_is_admin_member() ) {
        wp_redirect( home_url( '/sp-app/' ) ); exit;
    }

    global $wpdb;
    if ( $type === 'contact' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_contacts', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=contacts' ) ); exit;
    }
    if ( $type === 'company' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_companies', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=companies' ) ); exit;
    }
    if ( $type === 'lead' ) {
        $wpdb->delete( $wpdb->prefix . 'sp_leads', array( 'id' => $id ) );
        wp_redirect( home_url( '/sp-app/?view=leads' ) ); exit;
    }
    if ( $type === 'team_member' ) {
        $current = sp_get_current_team_member();
        if ( $current && $current->id !== $id ) {
            $wpdb->delete( $wpdb->prefix . 'sp_team', array( 'id' => $id ) );
        }
        wp_redirect( home_url( '/sp-app/?view=team' ) ); exit;
    }

    do_action( 'sp_delete_handler_' . $type, $id );
    wp_redirect( home_url( '/sp-app/' ) ); exit;
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function sp_delete_url( $type, $id ) {
    return wp_nonce_url(
        home_url( '/sp-app/?sp_delete=' . $type . '&id=' . $id ),
        'sp_delete_' . $type . '_' . $id
    );
}

function sp_pagination( $total, $limit, $paged, $view ) {
    $pages = (int) ceil( $total / $limit );
    if ( $pages <= 1 ) return;
    echo '<div class="sp-pagination">';
    if ( $paged > 1 ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged - 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">&larr; Prev</a>';
    echo '<span>Page ' . $paged . ' of ' . $pages . '</span>';
    if ( $paged < $pages ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged + 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">Next &rarr;</a>';
    echo '</div>';
}
