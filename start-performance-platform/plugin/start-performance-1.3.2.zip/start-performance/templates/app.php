<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$view    = sanitize_key( isset( $_GET['view'] ) ? $_GET['view'] : 'dashboard' );
$saved   = isset( $_GET['saved'] );
$allowed = apply_filters( 'sp_allowed_views', array( 'dashboard', 'contacts', 'companies', 'leads', 'settings', 'addons', 'team' ) );
if ( ! in_array( $view, $allowed ) ) $view = 'dashboard';

$view_file  = sp_get_view_file( $view );
$team_member = sp_get_current_team_member();
$is_admin   = sp_is_admin_member();
$logout     = esc_url( home_url( '/sp-app/?sp_logout=1' ) );
$member_name = $team_member ? $team_member->name : 'User';
$member_role = $team_member ? ucfirst( $team_member->role ) : '';
$member_init = strtoupper( substr( $member_name, 0, 1 ) );

// Core middle items — addons inject here via sp_nav_items filter
$nav_middle = apply_filters( 'sp_nav_items', array(
    array( 'view' => 'dashboard', 'label' => 'Dashboard',  'icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' ),
    array( 'view' => 'contacts',  'label' => 'Contacts',   'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z' ),
    array( 'view' => 'companies', 'label' => 'Companies',  'icon' => 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4' ),
    array( 'view' => 'leads',     'label' => 'Leads',      'icon' => 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6' ),
) );

// Bottom items — always pinned last, admin-only
$nav_bottom = array(
    array( 'view' => 'team',     'label' => 'Team',     'icon' => 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z', 'admin_only' => true ),
    array( 'view' => 'addons',   'label' => 'Add-ons',  'icon' => '<path d="M12 2l8.66 5v10L12 22l-8.66-5V7z"/><path d="M12 8v8M8 12h8"/>', 'admin_only' => true ),
    array( 'view' => 'settings', 'label' => 'Settings', 'icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z', 'admin_only' => true ),
);

$nav = array_merge( $nav_middle, $nav_bottom );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Start Performance</title>
<link rel="stylesheet" href="<?php echo esc_url( SP_PLUGIN_URL . 'assets/css/app.css?v=' . SP_VERSION ); ?>">
</head>
<body>
<div class="sp-layout">

    <aside class="sp-sidebar">
        <div class="sp-brand">
            <div class="sp-brand-icon">
                <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="18" cy="18" r="3.5" fill="white"/>
                    <circle cx="18" cy="5"  r="2.5" fill="white"/>
                    <circle cx="18" cy="31" r="2.5" fill="white"/>
                    <circle cx="5"  cy="18" r="2.5" fill="white"/>
                    <circle cx="31" cy="18" r="2.5" fill="white"/>
                    <circle cx="8"  cy="8"  r="2.5" fill="white"/>
                    <circle cx="28" cy="8"  r="2.5" fill="white"/>
                    <circle cx="8"  cy="28" r="2.5" fill="white"/>
                    <circle cx="28" cy="28" r="2.5" fill="white"/>
                    <line x1="18" y1="14.5" x2="18" y2="7.5"   stroke="white" stroke-width="1.8"/>
                    <line x1="18" y1="21.5" x2="18" y2="28.5"  stroke="white" stroke-width="1.8"/>
                    <line x1="14.5" y1="18" x2="7.5"  y2="18"  stroke="white" stroke-width="1.8"/>
                    <line x1="21.5" y1="18" x2="28.5" y2="18"  stroke="white" stroke-width="1.8"/>
                    <line x1="15.5" y1="15.5" x2="10" y2="10"  stroke="white" stroke-width="1.8"/>
                    <line x1="20.5" y1="15.5" x2="26" y2="10"  stroke="white" stroke-width="1.8"/>
                    <line x1="15.5" y1="20.5" x2="10" y2="26"  stroke="white" stroke-width="1.8"/>
                    <line x1="20.5" y1="20.5" x2="26" y2="26"  stroke="white" stroke-width="1.8"/>
                </svg>
            </div>
            <span class="sp-brand-name">Start Performance</span>
        </div>

        <nav class="sp-nav">
            <?php foreach ( $nav as $item ) : ?>
                <?php if ( ! empty( $item['admin_only'] ) && ! $is_admin ) continue; ?>
                <a href="<?php echo esc_url( home_url( '/sp-app/?view=' . $item['view'] ) ); ?>"
                   class="sp-nav-item<?php echo $view === $item['view'] ? ' active' : ''; ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <?php if ( strpos( $item['icon'], '<path' ) !== false ) : ?>
                            <?php echo $item['icon']; ?>
                        <?php else : ?>
                            <path d="<?php echo esc_attr( $item['icon'] ); ?>"/>
                        <?php endif; ?>
                    </svg>
                    <?php echo esc_html( $item['label'] ); ?>
                    <?php if ( ! empty( $item['addon'] ) ) : ?><span class="sp-nav-addon">+</span><?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="sp-sidebar-footer">
            <div class="sp-user">
                <div class="sp-avatar"><?php echo esc_html( $member_init ); ?></div>
                <div class="sp-user-info">
                    <div class="sp-user-name"><?php echo esc_html( $member_name ); ?></div>
                    <div class="sp-user-role"><?php echo esc_html( $member_role ); ?></div>
                </div>
                <a href="<?php echo $logout; ?>" class="sp-logout" title="Sign out">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                        <path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                </a>
            </div>
        </div>
    </aside>

    <main class="sp-main">
        <?php if ( $saved ) : ?>
            <div class="sp-toast">Saved successfully.</div>
        <?php endif; ?>
        <?php if ( $view_file ) require $view_file; ?>
    </main>

</div>
<script src="<?php echo esc_url( SP_PLUGIN_URL . 'assets/js/app.js?v=' . SP_VERSION ); ?>"></script>
</body>
</html>
