<?php
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! sp_is_admin_member() ) { echo '<p class="sp-empty">Access denied.</p>'; return; }

$platform_name = get_option( 'sp_platform_name', 'Start Performance' );
?>
<div class="sp-page-header">
    <h1>Settings</h1>
</div>
<div class="sp-card sp-form-card">
    <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
        <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
        <input type="hidden" name="sp_type" value="settings">
        <input type="hidden" name="sp_id" value="0">

        <h2 class="sp-section-heading">Platform</h2>
        <div class="sp-field" style="max-width:320px">
            <label>Platform Name</label>
            <input type="text" name="sp_platform_name" value="<?php echo esc_attr( $platform_name ); ?>">
            <span class="sp-hint">Displayed in the browser title and login page.</span>
        </div>

        <div class="sp-form-actions">
            <button type="submit" class="sp-btn sp-btn-primary">Save Settings</button>
        </div>
    </form>
</div>

<?php do_action( 'sp_settings_sections' ); ?>

<div class="sp-card sp-form-card" style="margin-top:16px">
    <h2 class="sp-section-heading">Team &amp; Security</h2>
    <p style="font-size:13px;color:#64748b;margin-bottom:16px">Manage team members, roles, and PINs from the Team section.</p>
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=team' ) ); ?>" class="sp-btn sp-btn-ghost">Go to Team &rarr;</a>
</div>
