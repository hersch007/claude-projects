<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$addons = function_exists( 'sp_get_addons' ) ? sp_get_addons() : array();
?>
<div class="sp-page-header">
    <h1>Add-ons</h1>
</div>

<div class="sp-addon-grid">

<?php if ( empty( $addons ) ) : ?>
    <div class="sp-card sp-form-card">
        <p class="sp-empty">No add-ons installed yet.</p>
    </div>
<?php else : ?>
    <?php foreach ( $addons as $id => $addon ) : ?>
    <div class="sp-addon-card">
        <div class="sp-addon-card-header">
            <div class="sp-addon-icon">
                <?php
                $icon = isset( $addon['icon'] ) ? $addon['icon'] : '';
                $fallback = '<path d="M12 2l8.66 5v10L12 22l-8.66-5V7z"/><path d="M12 8v8M8 12h8"/>';
                $paths = $icon ? $icon : $fallback;
                ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                    <?php echo $paths; ?>
                </svg>
            </div>
            <div>
                <div class="sp-addon-name"><?php echo esc_html( $addon['name'] ); ?></div>
                <div class="sp-addon-version">v<?php echo esc_html( $addon['version'] ); ?></div>
            </div>
            <span class="sp-badge sp-badge-active" style="margin-left:auto">Active</span>
        </div>
        <p class="sp-addon-desc"><?php echo esc_html( $addon['description'] ); ?></p>
        <?php if ( $addon['settings_url'] ) : ?>
            <a href="<?php echo esc_url( $addon['settings_url'] ); ?>" class="sp-btn sp-btn-ghost sp-btn-sm">Settings</a>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

</div>

<?php if ( ! isset( $addons['sp-ai'] ) ) : ?>
<div class="sp-addon-promo" style="margin-top:16px;border:2px dashed #c7d2fe;border-radius:12px;padding:20px 24px;display:flex;align-items:center;gap:16px;background:#fafafe">
    <div style="background:#6366f1;border-radius:10px;width:44px;height:44px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
    </div>
    <div style="flex:1">
        <div style="font-weight:700;font-size:14px;color:#1e293b">AI Assistant <span style="font-size:11px;font-weight:600;background:#6366f1;color:#fff;border-radius:4px;padding:2px 7px;margin-left:6px;vertical-align:middle">PREMIUM</span></div>
        <div style="font-size:13px;color:#64748b;margin-top:3px">Contact summaries, pipeline insights, and ticket triage — powered by your AI provider.</div>
    </div>
    <a href="https://startperformance.com/addons/ai" class="sp-btn sp-btn-primary sp-btn-sm" target="_blank">Learn More &rarr;</a>
</div>
<?php endif; ?>

<div class="sp-addon-discover">
    <div class="sp-addon-discover-inner">
        <div class="sp-addon-discover-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">
                <path d="M12 2l8.66 5v10L12 22l-8.66-5V7z"/>
                <path d="M12 8v8M8 12h8"/>
            </svg>
        </div>
        <div>
            <div class="sp-addon-discover-title">More Add-ons</div>
            <div class="sp-addon-discover-sub">Extend your platform with additional modules from Start Performance.</div>
        </div>
        <a href="https://startperformance.com/addons" class="sp-btn sp-btn-ghost sp-btn-sm" target="_blank">Browse &rarr;</a>
    </div>
</div>
