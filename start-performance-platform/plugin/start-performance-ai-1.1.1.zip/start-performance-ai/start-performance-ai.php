<?php
/*
 * Plugin Name: Start Performance — AI
 * Description: AI assistant addon for the Start Performance Platform
 * Version:     1.1.1
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_AI_VERSION',    '1.1.1' );
define( 'SP_AI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// ── Dependency check ──────────────────────────────────────────────────────────

add_action( 'plugins_loaded', 'sp_ai_boot', 20 );

function sp_ai_boot() {
    if ( ! function_exists( 'sp_register_view' ) ) {
        add_action( 'admin_notices', 'sp_ai_dependency_notice' );
        return;
    }
    sp_ai_register();
}

function sp_ai_dependency_notice() {
    echo '<div class="notice notice-error"><p><strong>Start Performance — AI</strong> requires the Start Performance core plugin to be installed and active.</p></div>';
}

// ── Registration ──────────────────────────────────────────────────────────────

function sp_ai_register() {
    sp_register_addon( 'sp-ai', array(
        'name'         => 'AI Assistant',
        'version'      => SP_AI_VERSION,
        'description'  => 'AI-powered insights, summaries, and automation for your contacts, leads, and tickets.',
        'settings_url' => home_url( '/sp-app/?view=ai' ),
        'icon'         => '<path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>',
    ) );

    sp_register_view( 'ai', SP_AI_PLUGIN_DIR . 'templates/views/ai.php' );

    add_filter( 'sp_nav_items',          'sp_ai_nav_items', 50 );
    add_filter( 'sp_allowed_views',      'sp_ai_allowed_views' );
    add_action( 'sp_post_handler_ai_settings', 'sp_ai_save_settings' );
    add_filter( 'sp_settings_anchor_tabs', 'sp_ai_settings_tab' );
    add_action( 'sp_settings_sections',    'sp_ai_settings_section' );
    add_action( 'sp_contact_edit_after',         'sp_ai_contact_summary_ui' );
    add_action( 'wp_ajax_sp_ai_contact_summary', 'sp_ai_ajax_contact_summary' );
    add_action( 'sp_dashboard_after_grid',       'sp_ai_pipeline_insights_ui' );
    add_action( 'wp_ajax_sp_ai_pipeline_insights', 'sp_ai_ajax_pipeline_insights' );
}

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_ai_activate' );

function sp_ai_activate() {
    // No custom tables needed yet — settings stored in wp_options
}

// ── Nav filter ────────────────────────────────────────────────────────────────

function sp_ai_nav_items( $items ) {
    $items[] = array( 'section' => true, 'label' => 'AI', 'view' => '', 'icon' => '' );
    $items[] = array(
        'view'  => 'ai',
        'label' => 'AI Assistant',
        'icon'  => '<path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>',
        'addon' => true,
    );
    return $items;
}

// ── Allowed views filter ──────────────────────────────────────────────────────

function sp_ai_allowed_views( $views ) {
    $views[] = 'ai';
    return $views;
}

// ── Settings handler ──────────────────────────────────────────────────────────

function sp_ai_save_settings( $id ) {
    $api_key = sanitize_text_field( isset( $_POST['sp_ai_api_key'] ) ? $_POST['sp_ai_api_key'] : '' );
    $model   = sanitize_key(        isset( $_POST['sp_ai_model'] )   ? $_POST['sp_ai_model']   : 'gpt-4o-mini' );
    update_option( 'sp_ai_api_key', $api_key );
    update_option( 'sp_ai_model',   $model );
    wp_redirect( home_url( '/sp-app/?view=settings&saved=1#section-ai' ) ); exit;
}

// ── Settings integration ──────────────────────────────────────────────────────

function sp_ai_settings_tab( $tabs ) {
    $tabs[] = array( 'id' => 'section-ai', 'label' => 'AI' );
    return $tabs;
}

function sp_ai_settings_section() {
    $api_key    = sp_ai_get_api_key();
    $model      = sp_ai_get_model();
    $masked_key = $api_key ? substr( $api_key, 0, 8 ) . str_repeat( '•', 24 ) : '';

    $models = array(
        'gpt-4o-mini'               => 'GPT-4o Mini (fast, economical)',
        'gpt-4o'                    => 'GPT-4o (powerful, higher cost)',
        'claude-sonnet-4-6'         => 'Claude Sonnet 4.6 (Anthropic)',
        'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5 (Anthropic, fast)',
    );
    ?>
    <div id="section-ai" class="sp-card sp-form-card sp-settings-section" style="margin-top:16px">
        <h2 class="sp-section-heading">AI Integration</h2>
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="ai_settings">
            <input type="hidden" name="sp_id" value="0">

            <div class="sp-field" style="max-width:400px">
                <label>API Key</label>
                <input type="text" name="sp_ai_api_key" value="<?php echo esc_attr( $api_key ); ?>" placeholder="sk-... or sk-ant-..." autocomplete="off" style="font-family:monospace;font-size:13px">
                <?php if ( $masked_key ) : ?>
                    <span class="sp-hint">Currently set: <?php echo esc_html( $masked_key ); ?></span>
                <?php endif; ?>
            </div>

            <div class="sp-field" style="max-width:320px;margin-top:16px">
                <label>Model</label>
                <select name="sp_ai_model">
                    <?php foreach ( $models as $val => $label ) : ?>
                        <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $model, $val ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save AI Settings</button>
            </div>
        </form>
    </div>
    <?php
}

// ── Helper: get config ────────────────────────────────────────────────────────

function sp_ai_get_api_key() {
    return get_option( 'sp_ai_api_key', '' );
}

function sp_ai_get_model() {
    return get_option( 'sp_ai_model', 'gpt-4o-mini' );
}

function sp_ai_is_configured() {
    return sp_ai_get_api_key() !== '';
}

// ── Contact Summary UI ────────────────────────────────────────────────────────

function sp_ai_contact_summary_ui( $contact_id ) {
    if ( ! sp_ai_is_configured() ) return;
    $nonce = wp_create_nonce( 'sp_ai_contact_summary' );
    ?>
    <div class="sp-card sp-form-card" style="margin-top:16px" id="sp-ai-summary-card">
        <div class="sp-section-heading" style="display:flex;align-items:center;gap:8px">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
            AI Contact Summary
        </div>
        <div id="sp-ai-summary-output" style="display:none;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 16px;font-size:14px;line-height:1.7;color:#1e293b;margin-bottom:16px;white-space:pre-wrap"></div>
        <button type="button" class="sp-btn sp-btn-ghost" id="sp-ai-summary-btn"
            data-contact="<?php echo esc_attr( $contact_id ); ?>"
            data-nonce="<?php echo esc_attr( $nonce ); ?>"
            data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
            Generate Summary
        </button>
        <span id="sp-ai-summary-status" style="font-size:12px;color:#64748b;margin-left:10px;display:none">Generating…</span>
    </div>
    <script>
    (function(){
        var btn    = document.getElementById('sp-ai-summary-btn');
        var output = document.getElementById('sp-ai-summary-output');
        var status = document.getElementById('sp-ai-summary-status');
        if ( ! btn ) return;
        btn.addEventListener('click', function(){
            btn.disabled = true;
            status.style.display = 'inline';
            output.style.display = 'none';
            output.textContent   = '';
            var fd = new FormData();
            fd.append('action',     'sp_ai_contact_summary');
            fd.append('contact_id', btn.dataset.contact);
            fd.append('nonce',      btn.dataset.nonce);
            fetch(btn.dataset.ajax, { method:'POST', body:fd })
                .then(function(r){ return r.json(); })
                .then(function(data){
                    status.style.display = 'none';
                    btn.disabled = false;
                    if ( data.success ) {
                        output.textContent   = data.data;
                        output.style.display = 'block';
                    } else {
                        output.textContent   = 'Error: ' + (data.data || 'Unknown error');
                        output.style.display = 'block';
                    }
                })
                .catch(function(e){
                    status.style.display = 'none';
                    btn.disabled = false;
                    output.textContent   = 'Request failed. Check your connection.';
                    output.style.display = 'block';
                });
        });
    })();
    </script>
    <?php
}

// ── Contact Summary AJAX handler ──────────────────────────────────────────────

function sp_ai_ajax_contact_summary() {
    if ( ! check_ajax_referer( 'sp_ai_contact_summary', 'nonce', false ) ) {
        wp_send_json_error( 'Invalid nonce' );
    }
    if ( ! function_exists( 'sp_get_current_team_member' ) || ! sp_get_current_team_member() ) {
        wp_send_json_error( 'Not authorized' );
    }

    $contact_id = (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 );
    if ( ! $contact_id ) wp_send_json_error( 'No contact ID' );

    global $wpdb;

    $contact = $wpdb->get_row( $wpdb->prepare(
        "SELECT c.*, co.name AS company_name, co.industry
         FROM {$wpdb->prefix}sp_contacts c
         LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id
         WHERE c.id = %d", $contact_id
    ) );
    if ( ! $contact ) wp_send_json_error( 'Contact not found' );

    $leads = $wpdb->get_results( $wpdb->prepare(
        "SELECT status, source, score, notes, created_at
         FROM {$wpdb->prefix}sp_leads WHERE contact_id = %d ORDER BY created_at DESC", $contact_id
    ) );

    $tickets = array();
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}sp_tickets'" ) ) {
        $tickets = $wpdb->get_results( $wpdb->prepare(
            "SELECT title, status, priority, created_at
             FROM {$wpdb->prefix}sp_tickets WHERE contact_id = %d ORDER BY created_at DESC LIMIT 10", $contact_id
        ) );
    }

    // Build prompt context
    $name = trim( $contact->first_name . ' ' . $contact->last_name );
    $lines = array();
    $lines[] = "Contact: $name";
    if ( $contact->email )        $lines[] = "Email: {$contact->email}";
    if ( $contact->phone )        $lines[] = "Phone: {$contact->phone}";
    if ( $contact->company_name ) $lines[] = "Company: {$contact->company_name}" . ( $contact->industry ? " ({$contact->industry})" : '' );
    if ( $contact->source )       $lines[] = "Source: {$contact->source}";
    $lines[] = "Status: {$contact->status}";
    $lines[] = "Added: " . date( 'M j, Y', strtotime( $contact->created_at ) );
    if ( $contact->notes )        $lines[] = "Notes: {$contact->notes}";

    if ( $leads ) {
        $lines[] = '';
        $lines[] = 'Leads (' . count( $leads ) . '):';
        foreach ( $leads as $l ) {
            $line = '- ' . ucfirst( $l->status );
            if ( $l->source ) $line .= ", source: {$l->source}";
            if ( $l->score )  $line .= ", score: {$l->score}";
            if ( $l->notes )  $line .= ". Notes: {$l->notes}";
            $lines[] = $line;
        }
    }

    if ( $tickets ) {
        $lines[] = '';
        $lines[] = 'Support Tickets (' . count( $tickets ) . '):';
        foreach ( $tickets as $t ) {
            $lines[] = "- [{$t->priority}] {$t->title} ({$t->status})";
        }
    }

    $context = implode( "\n", $lines );

    $prompt = "You are a CRM assistant. Write a concise 2-3 paragraph summary of this contact for a sales or service rep about to reach out. Cover who they are, their history with the business, any open issues or opportunities, and a suggested next action. Be direct and practical — no fluff.\n\n$context";

    $summary = sp_ai_call_api( $prompt );

    if ( is_wp_error( $summary ) ) {
        wp_send_json_error( $summary->get_error_message() );
    }

    wp_send_json_success( $summary );
}

// ── Pipeline Insights UI ──────────────────────────────────────────────────────

function sp_ai_pipeline_insights_ui() {
    if ( ! sp_ai_is_configured() ) return;
    $nonce = wp_create_nonce( 'sp_ai_pipeline_insights' );
    ?>
    <div class="sp-card" style="margin-top:16px" id="sp-ai-pipeline-card">
        <div class="sp-card-header">
            <h2 style="display:flex;align-items:center;gap:8px">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
                Pipeline Insights
            </h2>
            <div style="display:flex;align-items:center;gap:10px">
                <span id="sp-ai-pi-status" style="font-size:12px;color:#64748b;display:none">Analyzing…</span>
                <button type="button" class="sp-btn sp-btn-ghost sp-btn-sm" id="sp-ai-pi-btn"
                    data-nonce="<?php echo esc_attr( $nonce ); ?>"
                    data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
                    Generate Insights
                </button>
            </div>
        </div>
        <div id="sp-ai-pi-output" style="display:none;font-size:14px;line-height:1.75;color:#1e293b;padding:4px 0"></div>
    </div>
    <style>
    #sp-ai-pi-output h2{font-size:16px;font-weight:700;color:#0f172a;margin:20px 0 4px;display:flex;align-items:center;gap:7px}
    #sp-ai-pi-output h2:first-child{margin-top:0}
    #sp-ai-pi-output h3{font-size:14px;font-weight:700;color:#1e293b;margin:14px 0 3px;display:flex;align-items:center;gap:6px}
    #sp-ai-pi-output p{margin:0 0 10px;color:#374151}
    #sp-ai-pi-output strong{font-weight:600;color:#0f172a}
    #sp-ai-pi-output ul{margin:4px 0 10px 18px;padding:0}
    #sp-ai-pi-output li{margin-bottom:3px}
    </style>
    <script>
    (function(){
        var btn    = document.getElementById('sp-ai-pi-btn');
        var output = document.getElementById('sp-ai-pi-output');
        var status = document.getElementById('sp-ai-pi-status');
        if ( ! btn ) return;

        var iconH2 = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15" style="flex-shrink:0;color:#6366f1"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>';
        var iconH3 = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="13" height="13" style="flex-shrink:0;color:#94a3b8"><path d="M9 5l7 7-7 7"/></svg>';

        function renderMarkdown(md) {
            var lines = md.split('\n');
            var html  = '';
            var inUl  = false;

            lines.forEach(function(line) {
                // h1 → h2
                if (/^# /.test(line)) {
                    if (inUl) { html += '</ul>'; inUl = false; }
                    html += '<h2>' + iconH2 + esc(line.replace(/^# /, '')) + '</h2>';
                // h2 → h3
                } else if (/^## /.test(line)) {
                    if (inUl) { html += '</ul>'; inUl = false; }
                    html += '<h3>' + iconH3 + esc(line.replace(/^## /, '')) + '</h3>';
                // bullet
                } else if (/^[-*] /.test(line)) {
                    if (!inUl) { html += '<ul>'; inUl = true; }
                    html += '<li>' + inline(line.replace(/^[-*] /, '')) + '</li>';
                // blank
                } else if (line.trim() === '') {
                    if (inUl) { html += '</ul>'; inUl = false; }
                // paragraph
                } else {
                    if (inUl) { html += '</ul>'; inUl = false; }
                    html += '<p>' + inline(line) + '</p>';
                }
            });

            if (inUl) html += '</ul>';
            return html;
        }

        function inline(text) {
            return esc(text)
                .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.+?)\*/g,     '<em>$1</em>');
        }

        function esc(s) {
            return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        }

        btn.addEventListener('click', function(){
            btn.disabled = true;
            status.style.display = 'inline';
            output.style.display = 'none';
            output.innerHTML     = '';
            var fd = new FormData();
            fd.append('action', 'sp_ai_pipeline_insights');
            fd.append('nonce',  btn.dataset.nonce);
            fetch(btn.dataset.ajax, { method:'POST', body:fd })
                .then(function(r){ return r.json(); })
                .then(function(data){
                    status.style.display = 'none';
                    btn.disabled         = false;
                    btn.textContent      = 'Refresh';
                    if ( data.success ) {
                        output.innerHTML     = renderMarkdown(data.data);
                        output.style.display = 'block';
                    } else {
                        output.textContent   = 'Error: ' + (data.data || 'Unknown error');
                        output.style.display = 'block';
                    }
                })
                .catch(function(){
                    status.style.display = 'none';
                    btn.disabled         = false;
                    output.textContent   = 'Request failed. Check your connection.';
                    output.style.display = 'block';
                });
        });
    })();
    </script>
    <?php
}

// ── Pipeline Insights AJAX handler ────────────────────────────────────────────

function sp_ai_ajax_pipeline_insights() {
    if ( ! check_ajax_referer( 'sp_ai_pipeline_insights', 'nonce', false ) ) {
        wp_send_json_error( 'Invalid nonce' );
    }
    if ( ! function_exists( 'sp_get_current_team_member' ) || ! sp_get_current_team_member() ) {
        wp_send_json_error( 'Not authorized' );
    }

    global $wpdb;

    // Lead counts by status
    $by_status = $wpdb->get_results(
        "SELECT status, COUNT(*) as count FROM {$wpdb->prefix}sp_leads GROUP BY status ORDER BY count DESC"
    );

    // Leads by source
    $by_source = $wpdb->get_results(
        "SELECT source, COUNT(*) as count FROM {$wpdb->prefix}sp_leads WHERE source != '' GROUP BY source ORDER BY count DESC LIMIT 8"
    );

    // Leads created in last 30 days
    $recent_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );

    // Leads with no activity (status still 'new') older than 14 days
    $stale_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE status = 'new' AND created_at < DATE_SUB(NOW(), INTERVAL 14 DAY)"
    );

    // Average score
    $avg_score = (float) $wpdb->get_var(
        "SELECT AVG(score) FROM {$wpdb->prefix}sp_leads WHERE score > 0"
    );

    // Top scored leads
    $top_leads = $wpdb->get_results(
        "SELECT l.score, l.status, l.source, c.first_name, c.last_name
         FROM {$wpdb->prefix}sp_leads l
         LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id
         WHERE l.score > 0
         ORDER BY l.score DESC LIMIT 5"
    );

    // Build context
    $lines = array();
    $lines[] = 'Pipeline snapshot as of ' . date( 'F j, Y' ) . ':';
    $lines[] = '';

    $lines[] = 'Leads by status:';
    foreach ( $by_status as $row ) {
        $lines[] = "  {$row->status}: {$row->count}";
    }

    if ( $by_source ) {
        $lines[] = '';
        $lines[] = 'Top lead sources:';
        foreach ( $by_source as $row ) {
            $lines[] = "  {$row->source}: {$row->count}";
        }
    }

    $lines[] = '';
    $lines[] = "New leads in last 30 days: $recent_count";
    $lines[] = "Stale new leads (14+ days untouched): $stale_count";

    if ( $avg_score ) {
        $lines[] = 'Average lead score: ' . round( $avg_score, 1 );
    }

    if ( $top_leads ) {
        $lines[] = '';
        $lines[] = 'Top scored leads:';
        foreach ( $top_leads as $l ) {
            $name = trim( $l->first_name . ' ' . $l->last_name ) ?: 'Unknown';
            $lines[] = "  {$name} — score {$l->score}, status: {$l->status}" . ( $l->source ? ", source: {$l->source}" : '' );
        }
    }

    $context = implode( "\n", $lines );

    $prompt = "You are a sales pipeline analyst. Based on the following pipeline data, write a concise 3-4 paragraph analysis covering: overall pipeline health, what's working (top sources, high scores), what needs attention (stale leads, bottlenecks), and 2-3 specific recommended actions for this week. Be direct and actionable — no generic advice.\n\n$context";

    $result = sp_ai_call_api( $prompt );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}

// ── API call helper ───────────────────────────────────────────────────────────

function sp_ai_call_api( $prompt ) {
    $api_key = sp_ai_get_api_key();
    $model   = sp_ai_get_model();

    $is_anthropic = strpos( $model, 'claude' ) !== false;

    if ( $is_anthropic ) {
        $url     = 'https://api.anthropic.com/v1/messages';
        $headers = array(
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'content-type'      => 'application/json',
        );
        $body = wp_json_encode( array(
            'model'      => $model,
            'max_tokens' => 1024,
            'messages'   => array(
                array( 'role' => 'user', 'content' => $prompt ),
            ),
        ) );
    } else {
        $url     = 'https://api.openai.com/v1/chat/completions';
        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        );
        $body = wp_json_encode( array(
            'model'    => $model,
            'messages' => array(
                array( 'role' => 'user', 'content' => $prompt ),
            ),
        ) );
    }

    $response = wp_remote_post( $url, array(
        'headers' => $headers,
        'body'    => $body,
        'timeout' => 30,
    ) );

    if ( is_wp_error( $response ) ) return $response;

    $code = wp_remote_retrieve_response_code( $response );
    $json = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code !== 200 ) {
        $msg = isset( $json['error']['message'] ) ? $json['error']['message'] : "API error ($code)";
        return new WP_Error( 'sp_ai_api', $msg );
    }

    if ( $is_anthropic ) {
        return isset( $json['content'][0]['text'] ) ? trim( $json['content'][0]['text'] ) : new WP_Error( 'sp_ai_api', 'Empty response' );
    } else {
        return isset( $json['choices'][0]['message']['content'] ) ? trim( $json['choices'][0]['message']['content'] ) : new WP_Error( 'sp_ai_api', 'Empty response' );
    }
}
