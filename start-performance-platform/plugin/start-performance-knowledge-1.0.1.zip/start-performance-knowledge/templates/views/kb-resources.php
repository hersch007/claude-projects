﻿<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$is_admin = sp_is_admin_member();
$action   = sanitize_key( $_GET['action'] ?? '' );
$cat_id   = (int)( $_GET['cat'] ?? 0 );

// â”€â”€ Category form â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
if ( $is_admin && $action === 'new-cat' ) { ?>
    <div class="sp-view-header">
        <h1>New Resource Category</h1>
        <a href="<?php echo esc_url(home_url('/sp-app/?view=kb-resources')); ?>" class="sp-btn sp-btn-secondary">â† Back</a>
    </div>
    <div class="sp-card sp-form-card">
        <form method="post" action="<?php echo esc_url(home_url('/sp-app/')); ?>">
            <?php wp_nonce_field('sp_form','sp_nonce'); ?>
            <input type="hidden" name="sp_type"  value="kb_category">
            <input type="hidden" name="sp_id"    value="0">
            <input type="hidden" name="cat_type" value="resource">
            <div class="sp-field"><label>Category Name <span class="sp-required">*</span></label><input type="text" name="name" required></div>
            <div class="sp-field"><label>Description</label><textarea name="description" rows="2"></textarea></div>
            <div class="sp-form-actions"><button type="submit" class="sp-btn sp-btn-primary">Save Category</button></div>
        </form>
    </div>
    <?php return;
}

// â”€â”€ Add resource form â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
if ( $is_admin && $action === 'new' ) {
    $cats = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sp_kb_categories WHERE type='resource' ORDER BY name ASC");
    ?>
    <div class="sp-view-header">
        <h1>Add Resource</h1>
        <a href="<?php echo esc_url(home_url('/sp-app/?view=kb-resources')); ?>" class="sp-btn sp-btn-secondary">â† Back</a>
    </div>
    <div class="sp-card sp-form-card">
        <form method="post" action="<?php echo esc_url(home_url('/sp-app/')); ?>" enctype="multipart/form-data">
            <?php wp_nonce_field('sp_form','sp_nonce'); ?>
            <input type="hidden" name="sp_type" value="kb_resource">
            <input type="hidden" name="sp_id"   value="0">
            <div class="sp-field"><label>Title <span class="sp-required">*</span></label><input type="text" name="title" required></div>
            <div class="sp-field"><label>Description</label><textarea name="description" rows="2"></textarea></div>
            <div class="sp-form-row">
                <div class="sp-field">
                    <label>Category</label>
                    <select name="category_id">
                        <option value="0">â€” Uncategorized â€”</option>
                        <?php foreach($cats as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->name); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-field">
                    <label>Type</label>
                    <select name="resource_type" id="sp-res-type" onchange="document.getElementById('sp-res-file').style.display=this.value==='file'?'':'none';document.getElementById('sp-res-link').style.display=this.value==='link'?'':'none';">
                        <option value="link">Link / URL</option>
                        <option value="file">Upload File</option>
                    </select>
                </div>
            </div>
            <div class="sp-field" id="sp-res-link"><label>URL <span class="sp-required">*</span></label><input type="url" name="url" placeholder="https://"></div>
            <div class="sp-field" id="sp-res-file" style="display:none;"><label>File</label><input type="file" name="resource_file"></div>
            <div class="sp-form-actions"><button type="submit" class="sp-btn sp-btn-primary">Add Resource</button></div>
        </form>
    </div>
    <?php return;
}

// â”€â”€ List â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$categories = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sp_kb_categories WHERE type='resource' ORDER BY sort_order ASC, name ASC");

$where = array('1=1'); $args = array();
if($cat_id){ $where[]='r.category_id=%d'; $args[]=$cat_id; }
$sql = "SELECT r.*, c.name AS cat_name, t.name AS author
        FROM {$wpdb->prefix}sp_kb_resources r
        LEFT JOIN {$wpdb->prefix}sp_kb_categories c ON c.id=r.category_id
        LEFT JOIN {$wpdb->prefix}sp_team t ON t.id=r.created_by
        WHERE ".implode(' AND ',$where)." ORDER BY c.sort_order ASC, c.name ASC, r.title ASC";
$resources = $args ? $wpdb->get_results($wpdb->prepare($sql,$args)) : $wpdb->get_results($sql);

// Group by category
$grouped = array('__none__' => array());
foreach($resources as $r){
    $key = $r->cat_name ?: '__none__';
    $grouped[$key][] = $r;
}
unset($grouped['__none__']); // reappend at end
?>

<div class="sp-view-header">
    <h1>Resource Library</h1>
    <div style="display:flex;gap:8px;">
        <?php if($is_admin): ?>
            <a href="<?php echo esc_url(home_url('/sp-app/?view=kb-resources&action=new')); ?>" class="sp-btn sp-btn-primary">+ Add Resource</a>
            <a href="<?php echo esc_url(home_url('/sp-app/?view=kb-resources&action=new-cat')); ?>" class="sp-btn sp-btn-secondary">+ Category</a>
        <?php endif; ?>
    </div>
</div>

<?php if(isset($_GET['saved']))  : ?><div class="sp-notice sp-notice-success">Resource saved.</div><?php endif; ?>
<?php if(isset($_GET['deleted'])): ?><div class="sp-notice sp-notice-success">Resource deleted.</div><?php endif; ?>

<?php if(empty($resources)): ?>
    <div class="sp-card" style="padding:20px;"><p class="sp-empty">No resources yet.
        <?php if($is_admin): ?><a href="<?php echo esc_url(home_url('/sp-app/?view=kb-resources&action=new')); ?>" class="sp-link">Add the first one â†’</a><?php endif; ?>
    </p></div>
<?php else: ?>
    <?php
    // Group by category name
    $by_cat = array();
    foreach($resources as $r){
        $cn = $r->cat_name ?: 'â€” Uncategorized';
        $by_cat[$cn][] = $r;
    }
    foreach($by_cat as $cat_name => $rows):
    ?>
    <div class="sp-card sp-table-card" style="margin-bottom:18px;">
        <div class="sp-card-header"><h2><?php echo esc_html($cat_name); ?></h2></div>
        <table class="sp-table">
            <thead><tr><th>Title</th><th>Type</th><th>Description</th><th>Added</th><th></th></tr></thead>
            <tbody>
            <?php foreach($rows as $r):
                $is_file = $r->resource_type === 'file';
                $icon = $is_file
                    ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path fill="currentColor" d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zm-1 1.5L18.5 9H13V3.5zM6 20V4h5v7h7v9H6z"/></svg>'
                    : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path fill="currentColor" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>';
            ?>
            <tr>
                <td>
                    <a href="<?php echo esc_url($r->url); ?>" target="_blank" class="sp-link" style="display:flex;align-items:center;gap:6px;">
                        <?php echo $icon; ?> <?php echo esc_html($r->title); ?>
                    </a>
                </td>
                <td><span class="sp-badge"><?php echo $is_file ? 'File' : 'Link'; ?><?php if($is_file && $r->filesize): ?> Â· <?php echo esc_html(sp_format_filesize($r->filesize)); ?><?php endif; ?></span></td>
                <td class="sp-muted"><?php echo esc_html($r->description ?: 'â€”'); ?></td>
                <td class="sp-muted"><?php echo esc_html(date('M j, Y',strtotime($r->created_at))); ?></td>
                <td>
                    <?php if($is_admin): ?>
                        <a href="<?php echo esc_url(home_url('/sp-app/?sp_delete=kb_resource&id='.(int)$r->id.'&_wpnonce='.wp_create_nonce('sp_delete_kb_resource_'.(int)$r->id))); ?>"
                           class="sp-btn sp-btn-ghost sp-btn-sm" data-sp-confirm="Delete this resource?" style="color:var(--sp-muted);">Delete</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endforeach; ?>
<?php endif; ?>
