// Auto-hide toast after 3 seconds
document.addEventListener('DOMContentLoaded', function() {
    var toast = document.querySelector('.sp-toast');
    if (toast) {
        setTimeout(function() {
            toast.style.transition = 'opacity .4s';
            toast.style.opacity = '0';
            setTimeout(function() { toast.remove(); }, 400);
        }, 3000);
    }

    // ── Collapsible nav groups ────────────────────────────────────────────────
    var nav = document.querySelector('.sp-nav');
    if (!nav) return;

    var activeSection = nav.getAttribute('data-active-section') || '';
    var STORAGE_KEY = 'sp_nav_open';

    function getSavedOpen() {
        try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch(e) { return {}; }
    }
    function saveOpen(state) {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch(e) {}
    }

    function setGroupOpen(group, open) {
        var items = group.querySelector('.sp-nav-group-items');
        if (open) {
            group.classList.add('open');
            items.style.maxHeight = items.scrollHeight + 'px';
        } else {
            group.classList.remove('open');
            items.style.maxHeight = '0';
        }
    }

    var savedOpen = getSavedOpen();
    // ── Mobile sidebar toggle ─────────────────────────────────────────────────
    var sidebar  = document.getElementById('sp-sidebar');
    var overlay  = document.getElementById('sp-overlay');
    var menuBtn  = document.getElementById('sp-menu-toggle');

    function openSidebar() {
        if (sidebar) sidebar.classList.add('open');
        if (overlay) overlay.classList.add('active');
    }
    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
    }
    if (menuBtn)  menuBtn.addEventListener('click', openSidebar);
    if (overlay)  overlay.addEventListener('click', closeSidebar);
    // Close sidebar when a nav link is tapped
    if (sidebar) {
        sidebar.querySelectorAll('.sp-nav-item').forEach(function(link) {
            link.addEventListener('click', closeSidebar);
        });
    }

    var groups = nav.querySelectorAll('.sp-nav-group');

    groups.forEach(function(group) {
        var key = group.getAttribute('data-section');
        var isActive = activeSection && key === activeSection;
        // Open if active section, or if user previously had it open
        var shouldOpen = isActive || (savedOpen[key] === true);
        setGroupOpen(group, shouldOpen);

        var toggle = group.querySelector('.sp-nav-section-toggle');
        if (toggle) {
            toggle.addEventListener('click', function() {
                var nowOpen = group.classList.contains('open');
                setGroupOpen(group, !nowOpen);
                var state = getSavedOpen();
                state[key] = !nowOpen;
                saveOpen(state);
            });
        }
    });
});
