// Auto-hide toast after 3 seconds
document.addEventListener('DOMContentLoaded', function() {
    var toast = document.querySelector('.sp-toast');
    if (toast) {
        setTimeout(function() {
            toast.style.transition = 'opacity .4s';
            toast.style.opacity = '0';
            setTimeout(function() { toast.remove(); }, 400);
        }, 3000);
    }
});
