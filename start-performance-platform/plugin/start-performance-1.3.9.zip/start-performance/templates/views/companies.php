<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$action = sanitize_key( isset( $_GET['action'] ) ? $_GET['action'] : 'list' );
$id     = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );

if ( $action === 'new' || $action === 'edit' ) {
    $company = null;
    if ( $action === 'edit' && $id ) {
        $company = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_companies WHERE id = %d", $id ) );
        if ( ! $company ) { echo '<p class="sp-empty">Company not found.</p>'; return; }
    }
    ?>
    <div class="sp-page-header">
        <h1><?php echo $action === 'edit' ? 'Edit Company' : 'New Company'; ?></h1>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=companies' ) ); ?>" class="sp-btn sp-btn-ghost">&larr; Back</a>
    </div>
    <div class="sp-card sp-form-card">
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="company">
            <input type="hidden" name="sp_id" value="<?php echo esc_attr( $id ); ?>">
            <div class="sp-form-row">
                <div class="sp-field"><label>Company Name</label><input type="text" name="name" value="<?php echo esc_attr( $company ? $company->name : '' ); ?>" required></div>
                <div class="sp-field"><label>Industry</label><input type="text" name="industry" value="<?php echo esc_attr( $company ? $company->industry : '' ); ?>"></div>
            </div>
            <div class="sp-form-row">
                <div class="sp-field"><label>Website</label><input type="url" name="website" value="<?php echo esc_attr( $company ? $company->website : '' ); ?>"></div>
                <div class="sp-field"><label>Phone</label><input type="text" name="phone" value="<?php echo esc_attr( $company ? $company->phone : '' ); ?>"></div>
            </div>
            <div class="sp-field"><label>Address</label><textarea name="address" rows="2"><?php echo esc_textarea( $company ? $company->address : '' ); ?></textarea></div>
            <div class="sp-field"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $company ? $company->notes : '' ); ?></textarea></div>
            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save Company</button>
                <a href="<?php echo esc_url( home_url( '/sp-app/?view=companies' ) ); ?>" class="sp-btn sp-btn-ghost">Cancel</a>
            </div>
        </form>
    </div>
    <?php return;
}

$search = sanitize_text_field( isset( $_GET['s'] ) ? $_GET['s'] : '' );
$paged  = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
$limit  = 20; $offset = ( $paged - 1 ) * $limit;

if ( $search ) {
    $like  = '%' . $wpdb->esc_like( $search ) . '%';
    $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies WHERE name LIKE %s OR industry LIKE %s", $like, $like ) );
    $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_companies WHERE name LIKE %s OR industry LIKE %s ORDER BY name LIMIT %d OFFSET %d", $like, $like, $limit, $offset ) );
} else {
    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies" );
    $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_companies ORDER BY name LIMIT %d OFFSET %d", $limit, $offset ) );
}
?>
<div class="sp-page-header">
    <h1>Companies <span class="sp-count"><?php echo number_format( $total ); ?></span></h1>
    <div class="sp-header-actions">
        <form method="get" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" class="sp-search-form">
            <input type="hidden" name="view" value="companies">
            <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search...">
        </form>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=companies&action=new' ) ); ?>" class="sp-btn sp-btn-primary">+ New Company</a>
    </div>
</div>
<div class="sp-card sp-table-card">
    <table class="sp-table">
        <thead><tr><th>Name</th><th>Industry</th><th>Phone</th><th>Website</th><th>Created</th><th></th></tr></thead>
        <tbody>
        <?php if ( empty( $rows ) ) : ?>
            <tr><td colspan="6" class="sp-empty">No companies found.</td></tr>
        <?php else : foreach ( $rows as $row ) : ?>
            <tr>
                <td><a href="<?php echo esc_url( home_url( '/sp-app/?view=companies&action=edit&id=' . $row->id ) ); ?>" class="sp-link"><?php echo esc_html( $row->name ); ?></a></td>
                <td class="sp-muted"><?php echo esc_html( $row->industry ? $row->industry : '—' ); ?></td>
                <td class="sp-muted"><?php echo esc_html( $row->phone ? $row->phone : '—' ); ?></td>
                <td><?php echo $row->website ? '<a href="' . esc_url( $row->website ) . '" target="_blank" class="sp-link">' . esc_html( $row->website ) . '</a>' : '—'; ?></td>
                <td class="sp-muted"><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                <td class="sp-actions">
                    <a href="<?php echo esc_url( home_url( '/sp-app/?view=companies&action=edit&id=' . $row->id ) ); ?>">Edit</a>
                    <a href="<?php echo esc_url( sp_delete_url( 'company', $row->id ) ); ?>" onclick="return confirm('Delete this company?')" class="sp-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php sp_pagination( $total, $limit, $paged, 'companies' ); ?>
</div>
