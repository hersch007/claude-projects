<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$action = sanitize_key( isset( $_GET['action'] ) ? $_GET['action'] : 'list' );
$id     = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );

if ( $action === 'new' || $action === 'edit' ) {
    $lead      = null;
    $contacts  = $wpdb->get_results( "SELECT id, first_name, last_name, email FROM {$wpdb->prefix}sp_contacts ORDER BY first_name, last_name" );
    $companies = $wpdb->get_results( "SELECT id, name FROM {$wpdb->prefix}sp_companies ORDER BY name" );
    if ( $action === 'edit' && $id ) {
        $lead = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_leads WHERE id = %d", $id ) );
        if ( ! $lead ) { echo '<p class="sp-empty">Lead not found.</p>'; return; }
    }
    $statuses = array( 'new', 'contacted', 'qualified', 'unqualified', 'closed' );
    ?>
    <div class="sp-page-header">
        <h1><?php echo $action === 'edit' ? 'Edit Lead' : 'New Lead'; ?></h1>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads' ) ); ?>" class="sp-btn sp-btn-ghost">&larr; Back</a>
    </div>
    <div class="sp-card sp-form-card">
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="lead">
            <input type="hidden" name="sp_id" value="<?php echo esc_attr( $id ); ?>">
            <div class="sp-form-row">
                <div class="sp-field">
                    <label>Contact</label>
                    <select name="contact_id">
                        <option value="0">— Select Contact —</option>
                        <?php foreach ( $contacts as $c ) :
                            $label = trim( $c->first_name . ' ' . $c->last_name ) ? trim( $c->first_name . ' ' . $c->last_name ) : $c->email; ?>
                            <option value="<?php echo esc_attr( $c->id ); ?>" <?php selected( $lead ? $lead->contact_id : 0, $c->id ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-field">
                    <label>Company</label>
                    <select name="company_id">
                        <option value="0">— None —</option>
                        <?php foreach ( $companies as $co ) : ?>
                            <option value="<?php echo esc_attr( $co->id ); ?>" <?php selected( $lead ? $lead->company_id : 0, $co->id ); ?>><?php echo esc_html( $co->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="sp-form-row">
                <div class="sp-field"><label>Source</label><input type="text" name="source" value="<?php echo esc_attr( $lead ? $lead->source : '' ); ?>" placeholder="website, referral..."></div>
                <div class="sp-field">
                    <label>Status</label>
                    <select name="status">
                        <?php foreach ( $statuses as $s ) : ?>
                            <option value="<?php echo $s; ?>" <?php selected( $lead ? $lead->status : 'new', $s ); ?>><?php echo ucfirst( $s ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="sp-form-row">
                <div class="sp-field"><label>Score (0–100)</label><input type="number" name="score" min="0" max="100" value="<?php echo esc_attr( $lead ? $lead->score : 0 ); ?>"></div>
            </div>
            <div class="sp-field"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $lead ? $lead->notes : '' ); ?></textarea></div>
            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save Lead</button>
                <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads' ) ); ?>" class="sp-btn sp-btn-ghost">Cancel</a>
            </div>
        </form>
    </div>
    <?php return;
}

$status_filter = sanitize_key( isset( $_GET['status'] ) ? $_GET['status'] : '' );
$paged  = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
$limit  = 20; $offset = ( $paged - 1 ) * $limit;

if ( $status_filter ) {
    $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE status = %s", $status_filter ) );
    $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, c.first_name, c.last_name, co.name AS company_name FROM {$wpdb->prefix}sp_leads l LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = l.company_id WHERE l.status = %s ORDER BY l.created_at DESC LIMIT %d OFFSET %d", $status_filter, $limit, $offset ) );
} else {
    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads" );
    $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, c.first_name, c.last_name, co.name AS company_name FROM {$wpdb->prefix}sp_leads l LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = l.company_id ORDER BY l.created_at DESC LIMIT %d OFFSET %d", $limit, $offset ) );
}
$statuses = array( '', 'new', 'contacted', 'qualified', 'unqualified', 'closed' );
?>
<div class="sp-page-header">
    <h1>Leads <span class="sp-count"><?php echo number_format( $total ); ?></span></h1>
    <div class="sp-header-actions">
        <form method="get" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" class="sp-search-form">
            <input type="hidden" name="view" value="leads">
            <select name="status" onchange="this.form.submit()">
                <?php foreach ( $statuses as $s ) : ?>
                    <option value="<?php echo $s; ?>" <?php selected( $status_filter, $s ); ?>><?php echo $s ? ucfirst( $s ) : 'All Statuses'; ?></option>
                <?php endforeach; ?>
            </select>
        </form>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&action=new' ) ); ?>" class="sp-btn sp-btn-primary">+ New Lead</a>
    </div>
</div>
<div class="sp-card sp-table-card">
    <table class="sp-table">
        <thead><tr><th>Contact</th><th>Company</th><th>Source</th><th>Status</th><th>Score</th><th>Created</th><th></th></tr></thead>
        <tbody>
        <?php if ( empty( $rows ) ) : ?>
            <tr><td colspan="7" class="sp-empty">No leads found.</td></tr>
        <?php else : foreach ( $rows as $row ) :
            $name = trim( $row->first_name . ' ' . $row->last_name );
            $name = $name ? $name : '(no contact)'; ?>
            <tr>
                <td><a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&action=edit&id=' . $row->id ) ); ?>" class="sp-link"><?php echo esc_html( $name ); ?></a></td>
                <td class="sp-muted"><?php echo esc_html( $row->company_name ? $row->company_name : '—' ); ?></td>
                <td class="sp-muted"><?php echo esc_html( $row->source ? $row->source : '—' ); ?></td>
                <td><span class="sp-badge sp-badge-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
                <td><?php echo esc_html( $row->score ); ?></td>
                <td class="sp-muted"><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                <td class="sp-actions">
                    <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&action=edit&id=' . $row->id ) ); ?>">Edit</a>
                    <a href="<?php echo esc_url( sp_delete_url( 'lead', $row->id ) ); ?>" onclick="return confirm('Delete this lead?')" class="sp-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php if ( function_exists( 'sp_pagination' ) ) sp_pagination( $total, $limit, $paged, 'leads' ); ?>
</div>
