<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$contacts  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts" );
$companies = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_companies" );
$leads     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads" );
$new_leads = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE status = 'new'" );

$recent_contacts = $wpdb->get_results(
    "SELECT * FROM {$wpdb->prefix}sp_contacts ORDER BY created_at DESC LIMIT 5"
);
$recent_leads = $wpdb->get_results(
    "SELECT l.*, c.first_name, c.last_name FROM {$wpdb->prefix}sp_leads l
     LEFT JOIN {$wpdb->prefix}sp_contacts c ON c.id = l.contact_id
     ORDER BY l.created_at DESC LIMIT 5"
);
?>
<div class="sp-page-header">
    <h1>Dashboard</h1>
    <span class="sp-date"><?php echo date( 'l, F j, Y' ); ?></span>
</div>

<div class="sp-stats">
    <div class="sp-stat-card sp-stat-contacts">
        <div class="sp-stat-value"><?php echo number_format( $contacts ); ?></div>
        <div class="sp-stat-label">Contacts</div>
    </div>
    <div class="sp-stat-card sp-stat-companies">
        <div class="sp-stat-value"><?php echo number_format( $companies ); ?></div>
        <div class="sp-stat-label">Companies</div>
    </div>
    <div class="sp-stat-card sp-stat-leads">
        <div class="sp-stat-value"><?php echo number_format( $leads ); ?></div>
        <div class="sp-stat-label">Total Leads</div>
    </div>
    <div class="sp-stat-card sp-stat-accent">
        <div class="sp-stat-value"><?php echo number_format( $new_leads ); ?></div>
        <div class="sp-stat-label">New Leads</div>
    </div>
</div>

<?php do_action( 'sp_dashboard_after_stats' ); ?>

<div class="sp-grid-2">
    <div class="sp-card">
        <div class="sp-card-header">
            <h2>Recent Contacts</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=new' ) ); ?>" class="sp-btn sp-btn-primary sp-btn-sm">+ Add</a>
        </div>
        <?php if ( empty( $recent_contacts ) ) : ?>
            <p class="sp-empty">No contacts yet.</p>
        <?php else : ?>
            <table class="sp-table">
                <tbody>
                <?php foreach ( $recent_contacts as $c ) : ?>
                    <tr>
                        <td><?php echo esc_html( trim( $c->first_name . ' ' . $c->last_name ) ); ?></td>
                        <td class="sp-muted"><?php echo esc_html( $c->email ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $c->status ); ?>"><?php echo esc_html( ucfirst( $c->status ) ); ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="sp-card">
        <div class="sp-card-header">
            <h2>Recent Leads</h2>
            <a href="<?php echo esc_url( home_url( '/sp-app/?view=leads&action=new' ) ); ?>" class="sp-btn sp-btn-primary sp-btn-sm">+ Add</a>
        </div>
        <?php if ( empty( $recent_leads ) ) : ?>
            <p class="sp-empty">No leads yet.</p>
        <?php else : ?>
            <table class="sp-table">
                <tbody>
                <?php foreach ( $recent_leads as $l ) : ?>
                    <tr>
                        <td><?php echo esc_html( trim( $l->first_name . ' ' . $l->last_name ) ); ?></td>
                        <td class="sp-muted"><?php echo esc_html( $l->source ); ?></td>
                        <td><span class="sp-badge sp-badge-<?php echo esc_attr( $l->status ); ?>"><?php echo esc_html( ucfirst( $l->status ) ); ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php do_action( 'sp_dashboard_after_grid' ); ?>
