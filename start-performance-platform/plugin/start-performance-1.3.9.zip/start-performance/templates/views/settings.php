<?php
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! sp_is_admin_member() ) { echo '<p class="sp-empty">Access denied.</p>'; return; }

$platform_name   = get_option( 'sp_platform_name',  'Start Performance' );
$sp_logo_url     = get_option( 'sp_logo_url',       '' );
$sp_accent_color = get_option( 'sp_accent_color',   '#CC1F1F' );
$sp_brand_init   = get_option( 'sp_brand_initials', '' );
$sp_icon_url     = get_option( 'sp_brand_icon_url', '' );
$hidden_nav      = get_option( 'sp_hidden_nav_items', array() );
if ( ! is_array( $hidden_nav ) ) $hidden_nav = array();

// Collect all nav items so we can build the visibility toggles
$all_nav = apply_filters( 'sp_nav_items', array(
    array( 'view' => 'dashboard', 'label' => 'Dashboard' ),
    array( 'section' => true, 'label' => 'Core' ),
    array( 'view' => 'contacts',  'label' => 'Contacts'  ),
    array( 'view' => 'companies', 'label' => 'Companies' ),
    array( 'view' => 'leads',     'label' => 'Leads'     ),
) );

// Collect sections defined by sp_settings_sections
ob_start();
do_action( 'sp_settings_sections' );
$addon_sections_html = ob_get_clean();

// Build anchor list for the tab nav
// We always have: platform, navigation, team. Plus any from do_action that add IDs.
$anchor_tabs = array(
    array( 'id' => 'section-platform',   'label' => 'Platform'   ),
    array( 'id' => 'section-navigation', 'label' => 'Navigation' ),
    array( 'id' => 'section-team',       'label' => 'Team'       ),
);
// Let addons append anchor tabs via filter
$anchor_tabs = apply_filters( 'sp_settings_anchor_tabs', $anchor_tabs );
?>

<div class="sp-page-header">
    <h1>Settings</h1>
</div>

<!-- Anchor tab nav -->
<div class="sp-settings-tabs">
    <?php foreach ( $anchor_tabs as $tab ) : ?>
        <a href="#<?php echo esc_attr( $tab['id'] ); ?>" class="sp-settings-tab"><?php echo esc_html( $tab['label'] ); ?></a>
    <?php endforeach; ?>
</div>

<form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
    <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
    <input type="hidden" name="sp_type" value="settings">
    <input type="hidden" name="sp_id" value="0">

    <!-- Platform -->
    <div id="section-platform" class="sp-card sp-form-card sp-settings-section">
        <h2 class="sp-section-heading">Platform</h2>
        <div class="sp-field" style="max-width:320px">
            <label>Platform Name</label>
            <input type="text" name="sp_platform_name" value="<?php echo esc_attr( $platform_name ); ?>">
            <span class="sp-hint">Displayed in the browser title and login page.</span>
        </div>
        <div class="sp-field" style="max-width:480px;margin-top:16px">
            <label>Brand Icon Image <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:11px;color:#94a3b8">(sidebar &amp; login)</span></label>
            <input type="url" name="sp_brand_icon_url" value="<?php echo esc_attr( $sp_icon_url ); ?>" placeholder="https://… (upload to Media Library, paste URL)">
            <span class="sp-hint">Upload your icon to the WordPress Media Library, then paste the URL here. Square image recommended. Overrides letters and the default logo mark.</span>
            <?php if ( $sp_icon_url ) : ?>
                <div style="margin-top:8px"><img src="<?php echo esc_url( $sp_icon_url ); ?>" style="width:40px;height:40px;border-radius:8px;object-fit:cover;border:1px solid #e2e8f0" alt="Icon preview"></div>
            <?php endif; ?>
        </div>
        <div class="sp-field" style="max-width:320px;margin-top:16px">
            <label>Brand Icon Letters <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:11px;color:#94a3b8">(if no image)</span></label>
            <input type="text" name="sp_brand_initials" value="<?php echo esc_attr( $sp_brand_init ); ?>" maxlength="3" placeholder="e.g. SP" style="max-width:80px">
            <span class="sp-hint">Used only when no icon image is set. Leave blank for the default logo mark.</span>
        </div>
        <div class="sp-field" style="max-width:320px;margin-top:16px">
            <label>Accent Color</label>
            <div style="display:flex;align-items:center;gap:10px">
                <input type="color" name="sp_accent_color" value="<?php echo esc_attr( $sp_accent_color ); ?>" style="width:48px;height:38px;border:1px solid #e2e8f0;border-radius:8px;cursor:pointer;padding:2px">
                <input type="text" id="sp_accent_hex" value="<?php echo esc_attr( $sp_accent_color ); ?>" maxlength="7" style="width:90px;font-family:monospace" oninput="document.querySelector('[name=sp_accent_color]').value=this.value">
            </div>
            <span class="sp-hint">Used for buttons, active nav, and the brand icon background.</span>
        </div>
        <div class="sp-field" style="max-width:480px;margin-top:16px">
            <label>Logo URL <span style="font-weight:400;text-transform:none;letter-spacing:0;font-size:11px;color:#94a3b8">(used on printed quotes)</span></label>
            <input type="url" name="sp_logo_url" value="<?php echo esc_attr( $sp_logo_url ); ?>" placeholder="https://…">
            <span class="sp-hint">Paste the full URL of your logo image. PNG or SVG recommended.</span>
            <?php if ( $sp_logo_url ) : ?>
                <div style="margin-top:8px"><img src="<?php echo esc_url( $sp_logo_url ); ?>" style="max-height:48px;max-width:200px;border:1px solid #e2e8f0;border-radius:6px;padding:4px;background:#fff" alt="Logo preview"></div>
            <?php endif; ?>
        </div>
        <div class="sp-form-actions">
            <button type="submit" class="sp-btn sp-btn-primary">Save All Settings</button>
        </div>
    </div>

    <script>
    (function(){
        var picker=document.querySelector('[name=sp_accent_color]');
        var hex=document.getElementById('sp_accent_hex');
        if(picker&&hex){
            picker.addEventListener('input',function(){hex.value=this.value;});
            hex.addEventListener('input',function(){if(/^#[0-9a-fA-F]{6}$/.test(this.value))picker.value=this.value;});
        }
    })();
    </script>

    <!-- Navigation Visibility -->
    <div id="section-navigation" class="sp-card sp-form-card sp-settings-section" style="margin-top:16px">
        <h2 class="sp-section-heading">Navigation Visibility</h2>
        <p style="font-size:13px;color:#64748b;margin-bottom:20px">Choose which items appear in the sidebar navigation. Hidden items are removed for all users. Sections are hidden automatically when all their items are hidden.</p>
        <div class="sp-nav-visibility-grid">
            <?php
            $current_section = '';
            foreach ( $all_nav as $item ) :
                if ( ! empty( $item['section'] ) ) :
                    $current_section = $item['label'];
                    continue;
                endif;
                if ( empty( $item['view'] ) ) continue;
                $view    = $item['view'];
                $label   = $item['label'];
                $checked = ! in_array( $view, $hidden_nav );
            ?>
            <label class="sp-nav-toggle<?php echo $checked ? '' : ' sp-nav-toggle--off'; ?>">
                <input type="checkbox" name="sp_nav_visible[]" value="<?php echo esc_attr( $view ); ?>"<?php checked( $checked ); ?> onchange="var t=this.closest('.sp-nav-toggle');t.classList.toggle('sp-nav-toggle--off',!this.checked);t.querySelector('.sp-nav-toggle-pill').textContent=this.checked?'Visible':'Hidden';">
                <span class="sp-nav-toggle-label">
                    <span class="sp-nav-toggle-name"><?php echo esc_html( $label ); ?></span>
                    <?php if ( $current_section ) : ?>
                        <span class="sp-nav-toggle-section"><?php echo esc_html( $current_section ); ?></span>
                    <?php endif; ?>
                </span>
                <span class="sp-nav-toggle-pill"><?php echo $checked ? 'Visible' : 'Hidden'; ?></span>
            </label>
            <?php endforeach; ?>
        </div>
        <div class="sp-form-actions">
            <button type="submit" class="sp-btn sp-btn-primary">Save All Settings</button>
        </div>
    </div>

</form>

<?php echo $addon_sections_html; ?>

<!-- Team -->
<div id="section-team" class="sp-card sp-form-card sp-settings-section" style="margin-top:16px">
    <h2 class="sp-section-heading">Team &amp; Security</h2>
    <p style="font-size:13px;color:#64748b;margin-bottom:16px">Manage team members, roles, and PINs from the Team section.</p>
    <a href="<?php echo esc_url( home_url( '/sp-app/?view=team' ) ); ?>" class="sp-btn sp-btn-ghost">Go to Team &rarr;</a>
</div>
