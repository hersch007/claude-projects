<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$is_configured = function_exists( 'sp_ai_is_configured' ) && sp_ai_is_configured();
$model         = function_exists( 'sp_ai_get_model' ) ? sp_ai_get_model() : '';

$model_labels = array(
    'gpt-4o-mini'               => 'GPT-4o Mini',
    'gpt-4o'                    => 'GPT-4o',
    'claude-sonnet-4-6'         => 'Claude Sonnet 4.6',
    'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5',
);
$model_label = isset( $model_labels[ $model ] ) ? $model_labels[ $model ] : $model;
?>

<div class="sp-page-header">
    <h1>AI Assistant <span class="sp-nav-addon" style="font-size:11px;padding:3px 8px">ADD-ON</span></h1>
</div>

<?php if ( ! $is_configured ) : ?>
<div class="sp-ai-banner">
    <div class="sp-ai-banner-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="28" height="28">
            <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
        </svg>
    </div>
    <div>
        <div class="sp-ai-banner-title">Connect your AI provider</div>
        <div class="sp-ai-banner-sub">Add an API key in <a href="<?php echo esc_url( home_url( '/sp-app/?view=settings#section-ai' ) ); ?>">Settings → AI</a> to unlock AI-powered features.</div>
    </div>
</div>
<?php else : ?>
<div class="sp-ai-banner" style="background:#f0fdf4;border-color:#86efac">
    <div class="sp-ai-banner-icon" style="color:#16a34a">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="28" height="28">
            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
    </div>
    <div>
        <div class="sp-ai-banner-title" style="color:#15803d">AI connected</div>
        <div class="sp-ai-banner-sub">Using <strong><?php echo esc_html( $model_label ); ?></strong> &mdash; <a href="<?php echo esc_url( home_url( '/sp-app/?view=settings#section-ai' ) ); ?>">change in Settings</a></div>
    </div>
</div>
<?php endif; ?>

<div class="sp-card sp-form-card" style="margin-top:16px">
    <div class="sp-section-heading">Coming Soon</div>
    <div class="sp-ai-feature-list">
        <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
            <span class="sp-ai-feature-dot"></span>
            <div>
                <div class="sp-ai-feature-name">Lead Scoring</div>
                <div class="sp-ai-feature-desc">Automatically score and prioritize leads based on engagement and profile data.</div>
            </div>
        </div>
        <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
            <span class="sp-ai-feature-dot"></span>
            <div>
                <div class="sp-ai-feature-name">Contact Summaries</div>
                <div class="sp-ai-feature-desc">Generate a one-paragraph summary of a contact's history and interactions.</div>
            </div>
        </div>
        <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
            <span class="sp-ai-feature-dot"></span>
            <div>
                <div class="sp-ai-feature-name">Ticket Triage</div>
                <div class="sp-ai-feature-desc">Suggest priority and category for incoming tickets automatically.</div>
            </div>
        </div>
        <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
            <span class="sp-ai-feature-dot"></span>
            <div>
                <div class="sp-ai-feature-name">Pipeline Insights</div>
                <div class="sp-ai-feature-desc">Weekly AI-generated analysis of your lead pipeline and conversion trends.</div>
            </div>
        </div>
    </div>
    <?php if ( ! $is_configured ) : ?>
        <p class="sp-hint" style="margin-top:16px">Configure your API key in <a href="<?php echo esc_url( home_url( '/sp-app/?view=settings#section-ai' ) ); ?>">Settings → AI</a> to enable these features.</p>
    <?php endif; ?>
</div>
