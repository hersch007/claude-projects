<?php
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;

$action = sanitize_key( isset( $_GET['action'] ) ? $_GET['action'] : 'list' );
$id     = (int) ( isset( $_GET['id'] ) ? $_GET['id'] : 0 );

// ── Edit / New form ───────────────────────────────────────────────────────────
if ( $action === 'new' || $action === 'edit' ) {
    $contact   = null;
    $companies = $wpdb->get_results( "SELECT id, name FROM {$wpdb->prefix}sp_companies ORDER BY name" );
    if ( $action === 'edit' && $id ) {
        $contact = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sp_contacts WHERE id = %d", $id ) );
        if ( ! $contact ) { echo '<p class="sp-empty">Contact not found.</p>'; return; }
    }
    ?>
    <div class="sp-page-header">
        <h1><?php echo $action === 'edit' ? 'Edit Contact' : 'New Contact'; ?></h1>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts' ) ); ?>" class="sp-btn sp-btn-ghost">&larr; Back</a>
    </div>
    <div class="sp-card sp-form-card">
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="contact">
            <input type="hidden" name="sp_id" value="<?php echo esc_attr( $id ); ?>">
            <div class="sp-form-row">
                <div class="sp-field"><label>First Name</label><input type="text" name="first_name" value="<?php echo esc_attr( $contact ? $contact->first_name : '' ); ?>" required></div>
                <div class="sp-field"><label>Last Name</label><input type="text" name="last_name" value="<?php echo esc_attr( $contact ? $contact->last_name : '' ); ?>"></div>
            </div>
            <div class="sp-form-row">
                <div class="sp-field"><label>Email</label><input type="email" name="email" value="<?php echo esc_attr( $contact ? $contact->email : '' ); ?>"></div>
                <div class="sp-field"><label>Phone</label><input type="text" name="phone" value="<?php echo esc_attr( $contact ? $contact->phone : '' ); ?>"></div>
            </div>
            <div class="sp-form-row">
                <div class="sp-field">
                    <label>Company</label>
                    <select name="company_id">
                        <option value="0">— None —</option>
                        <?php foreach ( $companies as $co ) : ?>
                            <option value="<?php echo esc_attr( $co->id ); ?>" <?php selected( $contact ? $contact->company_id : 0, $co->id ); ?>><?php echo esc_html( $co->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="sp-field">
                    <label>Source</label>
                    <input type="text" name="source" value="<?php echo esc_attr( $contact ? $contact->source : '' ); ?>" placeholder="website, referral...">
                </div>
            </div>
            <div class="sp-form-row">
                <div class="sp-field">
                    <label>Status</label>
                    <select name="status">
                        <?php foreach ( array( 'active', 'inactive', 'archived' ) as $s ) : ?>
                            <option value="<?php echo $s; ?>" <?php selected( $contact ? $contact->status : 'active', $s ); ?>><?php echo ucfirst( $s ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="sp-field"><label>Notes</label><textarea name="notes" rows="4"><?php echo esc_textarea( $contact ? $contact->notes : '' ); ?></textarea></div>
            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save Contact</button>
                <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts' ) ); ?>" class="sp-btn sp-btn-ghost">Cancel</a>
            </div>
        </form>
    </div>
    <?php
    return;
}

// ── List ──────────────────────────────────────────────────────────────────────
$search = sanitize_text_field( isset( $_GET['s'] ) ? $_GET['s'] : '' );
$paged  = max( 1, (int) ( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
$limit  = 20;
$offset = ( $paged - 1 ) * $limit;

if ( $search ) {
    $like  = '%' . $wpdb->esc_like( $search ) . '%';
    $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts WHERE first_name LIKE %s OR last_name LIKE %s OR email LIKE %s", $like, $like, $like ) );
    $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT c.*, co.name AS company_name FROM {$wpdb->prefix}sp_contacts c LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id WHERE c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s ORDER BY c.created_at DESC LIMIT %d OFFSET %d", $like, $like, $like, $limit, $offset ) );
} else {
    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts" );
    $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT c.*, co.name AS company_name FROM {$wpdb->prefix}sp_contacts c LEFT JOIN {$wpdb->prefix}sp_companies co ON co.id = c.company_id ORDER BY c.created_at DESC LIMIT %d OFFSET %d", $limit, $offset ) );
}
?>
<div class="sp-page-header">
    <h1>Contacts <span class="sp-count"><?php echo number_format( $total ); ?></span></h1>
    <div class="sp-header-actions">
        <form method="get" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>" class="sp-search-form">
            <input type="hidden" name="view" value="contacts">
            <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search...">
        </form>
        <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=new' ) ); ?>" class="sp-btn sp-btn-primary">+ New Contact</a>
    </div>
</div>

<div class="sp-card sp-table-card">
    <table class="sp-table">
        <thead>
            <tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Status</th><th>Created</th><th></th></tr>
        </thead>
        <tbody>
        <?php if ( empty( $rows ) ) : ?>
            <tr><td colspan="7" class="sp-empty">No contacts found.</td></tr>
        <?php else : foreach ( $rows as $row ) : ?>
            <tr>
                <td><a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=edit&id=' . $row->id ) ); ?>" class="sp-link"><?php echo esc_html( trim( $row->first_name . ' ' . $row->last_name ) ); ?></a></td>
                <td class="sp-muted"><?php echo esc_html( $row->email ); ?></td>
                <td class="sp-muted"><?php echo esc_html( $row->phone ); ?></td>
                <td><?php echo esc_html( $row->company_name ? $row->company_name : '—' ); ?></td>
                <td><span class="sp-badge sp-badge-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
                <td class="sp-muted"><?php echo esc_html( date( 'M j, Y', strtotime( $row->created_at ) ) ); ?></td>
                <td class="sp-actions">
                    <a href="<?php echo esc_url( home_url( '/sp-app/?view=contacts&action=edit&id=' . $row->id ) ); ?>">Edit</a>
                    <a href="<?php echo esc_url( sp_delete_url( 'contact', $row->id ) ); ?>" onclick="return confirm('Delete this contact?')" class="sp-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php sp_pagination( $total, $limit, $paged, 'contacts' ); ?>
</div>
<?php

function sp_pagination( $total, $limit, $paged, $view ) {
    $pages = (int) ceil( $total / $limit );
    if ( $pages <= 1 ) return;
    echo '<div class="sp-pagination">';
    if ( $paged > 1 ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged - 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">&larr; Prev</a>';
    echo '<span>Page ' . $paged . ' of ' . $pages . '</span>';
    if ( $paged < $pages ) echo '<a href="' . esc_url( home_url( '/sp-app/?view=' . $view . '&paged=' . ( $paged + 1 ) ) ) . '" class="sp-btn sp-btn-ghost sp-btn-sm">Next &rarr;</a>';
    echo '</div>';
}
