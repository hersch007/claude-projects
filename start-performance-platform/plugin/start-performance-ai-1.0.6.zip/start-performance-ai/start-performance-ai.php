<?php
/*
 * Plugin Name: Start Performance — AI
 * Description: AI assistant addon for the Start Performance Platform
 * Version:     1.0.6
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_AI_VERSION',    '1.0.6' );
define( 'SP_AI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// ── Dependency check ──────────────────────────────────────────────────────────

add_action( 'plugins_loaded', 'sp_ai_boot', 20 );

function sp_ai_boot() {
    if ( ! function_exists( 'sp_register_view' ) ) {
        add_action( 'admin_notices', 'sp_ai_dependency_notice' );
        return;
    }
    sp_ai_register();
}

function sp_ai_dependency_notice() {
    echo '<div class="notice notice-error"><p><strong>Start Performance — AI</strong> requires the Start Performance core plugin to be installed and active.</p></div>';
}

// ── Registration ──────────────────────────────────────────────────────────────

function sp_ai_register() {
    sp_register_addon( 'sp-ai', array(
        'name'         => 'AI Assistant',
        'version'      => SP_AI_VERSION,
        'description'  => 'AI-powered insights, summaries, and automation for your contacts, leads, and tickets.',
        'settings_url' => home_url( '/sp-app/?view=ai' ),
        'icon'         => '<path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>',
    ) );

    sp_register_view( 'ai', SP_AI_PLUGIN_DIR . 'templates/views/ai.php' );

    add_filter( 'sp_nav_items',          'sp_ai_nav_items', 50 );
    add_filter( 'sp_allowed_views',      'sp_ai_allowed_views' );
    add_action( 'sp_post_handler_ai_settings', 'sp_ai_save_settings' );
    add_filter( 'sp_settings_anchor_tabs', 'sp_ai_settings_tab' );
    add_action( 'sp_settings_sections',    'sp_ai_settings_section' );
}

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'sp_ai_activate' );

function sp_ai_activate() {
    // No custom tables needed yet — settings stored in wp_options
}

// ── Nav filter ────────────────────────────────────────────────────────────────

function sp_ai_nav_items( $items ) {
    $items[] = array( 'section' => true, 'label' => 'AI', 'view' => '', 'icon' => '' );
    $items[] = array(
        'view'  => 'ai',
        'label' => 'AI Assistant',
        'icon'  => '<path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>',
        'addon' => true,
    );
    return $items;
}

// ── Allowed views filter ──────────────────────────────────────────────────────

function sp_ai_allowed_views( $views ) {
    $views[] = 'ai';
    return $views;
}

// ── Settings handler ──────────────────────────────────────────────────────────

function sp_ai_save_settings( $id ) {
    $api_key = sanitize_text_field( isset( $_POST['sp_ai_api_key'] ) ? $_POST['sp_ai_api_key'] : '' );
    $model   = sanitize_key(        isset( $_POST['sp_ai_model'] )   ? $_POST['sp_ai_model']   : 'gpt-4o-mini' );
    update_option( 'sp_ai_api_key', $api_key );
    update_option( 'sp_ai_model',   $model );
    wp_redirect( home_url( '/sp-app/?view=ai&saved=1' ) ); exit;
}

// ── Settings integration ──────────────────────────────────────────────────────

function sp_ai_settings_tab( $tabs ) {
    $tabs[] = array( 'id' => 'section-ai', 'label' => 'AI' );
    return $tabs;
}

function sp_ai_settings_section() {
    $api_key    = sp_ai_get_api_key();
    $model      = sp_ai_get_model();
    $masked_key = $api_key ? substr( $api_key, 0, 8 ) . str_repeat( '•', 24 ) : '';

    $models = array(
        'gpt-4o-mini'               => 'GPT-4o Mini (fast, economical)',
        'gpt-4o'                    => 'GPT-4o (powerful, higher cost)',
        'claude-sonnet-4-6'         => 'Claude Sonnet 4.6 (Anthropic)',
        'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5 (Anthropic, fast)',
    );
    ?>
    <div id="section-ai" class="sp-card sp-form-card sp-settings-section" style="margin-top:16px">
        <h2 class="sp-section-heading">AI Integration</h2>
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="ai_settings">
            <input type="hidden" name="sp_id" value="0">

            <div class="sp-field" style="max-width:400px">
                <label>API Key</label>
                <input type="password" name="sp_ai_api_key" value="<?php echo esc_attr( $api_key ); ?>" placeholder="sk-... or sk-ant-...">
                <?php if ( $masked_key ) : ?>
                    <span class="sp-hint">Currently set: <?php echo esc_html( $masked_key ); ?></span>
                <?php endif; ?>
            </div>

            <div class="sp-field" style="max-width:320px;margin-top:16px">
                <label>Model</label>
                <select name="sp_ai_model">
                    <?php foreach ( $models as $val => $label ) : ?>
                        <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $model, $val ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save AI Settings</button>
            </div>
        </form>
    </div>
    <?php
}

// ── Helper: get config ────────────────────────────────────────────────────────

function sp_ai_get_api_key() {
    return get_option( 'sp_ai_api_key', '' );
}

function sp_ai_get_model() {
    return get_option( 'sp_ai_model', 'gpt-4o-mini' );
}

function sp_ai_is_configured() {
    return sp_ai_get_api_key() !== '';
}
