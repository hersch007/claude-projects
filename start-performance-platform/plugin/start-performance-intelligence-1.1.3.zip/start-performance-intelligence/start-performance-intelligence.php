<?php
/*
 * Plugin Name: Start Performance — Intelligence Core
 * Description: KPI dashboard and business intelligence for the Start Performance Platform
 * Version:     1.1.3
 * Author:      Richard Brashear / Start Performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SP_INTEL_VERSION',    '1.1.3' );
define( 'SP_INTEL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

add_action( 'plugins_loaded', 'sp_intel_boot', 20 );

function sp_intel_boot() {
    if ( ! function_exists( 'sp_register_view' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Start Performance — Intelligence Core</strong> requires the Start Performance core plugin.</p></div>';
        } );
        return;
    }
    sp_intel_register();
}

function sp_intel_register() {
    sp_register_addon( 'sp-intelligence', array(
        'name'        => 'Intelligence Core',
        'version'     => SP_INTEL_VERSION,
        'description' => 'KPI dashboard, business performance metrics, and pipeline insights across all active modules.',
        'icon'        => '<path fill="currentColor" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>',
        'plugin_file' => plugin_basename( __FILE__ ),
        'core_slot'   => 'intelligence-core',
    ) );

    sp_register_view( 'intelligence', SP_INTEL_PLUGIN_DIR . 'templates/views/intelligence.php' );

    add_filter( 'sp_nav_items',        'sp_intel_nav_items' );
    add_filter( 'sp_allowed_views',    'sp_intel_allowed_views' );
    add_action( 'sp_settings_sections','sp_intel_settings_section' );
    add_action( 'sp_post_handler_intel_settings', 'sp_intel_save_settings' );

    add_action( 'wp_ajax_sp_intel_ai_insights', 'sp_intel_ajax_ai_insights' );
    add_action( 'wp_ajax_nopriv_sp_intel_ai_insights', 'sp_intel_ajax_ai_insights' );
}

function sp_intel_nav_items( $items ) {
    $result = array();
    foreach ( $items as $item ) {
        $result[] = $item;
        if ( ! empty( $item['section'] ) && ! empty( $item['section_id'] ) && $item['section_id'] === 'intelligence-core' ) {
            $result[] = array(
                'view'  => 'intelligence',
                'label' => 'KPI Dashboard',
                'icon'  => '<path fill="currentColor" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>',
            );
        }
    }
    return $result;
}

function sp_intel_allowed_views( $views ) {
    $views[] = 'intelligence';
    return $views;
}

// ── Settings section (Super Admin only) ───────────────────────────────────────

function sp_intel_settings_section() {
    if ( ! function_exists( 'sp_is_super_admin' ) || ! sp_is_super_admin() ) return;
    $api_key = get_option( 'sp_anthropic_api_key', '' );
    ?>
    <div style="margin-top:16px;border:2px solid #f59e0b;border-radius:12px;overflow:hidden;">
        <div style="background:linear-gradient(135deg,#451a03,#78350f);padding:12px 20px;display:flex;align-items:center;gap:10px;">
            <svg viewBox="0 0 20 20" fill="#fbbf24" width="16" height="16"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>
            <span style="font-size:.8rem;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#fbbf24;">Super Admin Only — AI &amp; Intelligence Keys</span>
        </div>
        <div class="sp-form-card" style="padding:20px 24px;background:#fff;">
            <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
                <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
                <input type="hidden" name="sp_type" value="intel_settings">
                <input type="hidden" name="sp_id"   value="0">
                <h2 class="sp-section-heading" style="margin-top:0;">Intelligence Core — AI Settings</h2>
                <div class="sp-form-row">
                    <div class="sp-field">
                        <label>Anthropic API Key</label>
                        <input type="password" name="sp_anthropic_api_key" value="<?php echo esc_attr( $api_key ); ?>" autocomplete="new-password" style="font-family:monospace;font-size:12px;max-width:480px;">
                        <span class="sp-hint">Used for AI-powered insights on the KPI Dashboard. Get your key at console.anthropic.com.</span>
                    </div>
                </div>
                <div class="sp-form-actions">
                    <button type="submit" class="sp-btn sp-btn-primary">Save AI Settings</button>
                </div>
            </form>
        </div>
    </div>
    <?php
}

function sp_intel_save_settings( $id ) {
    if ( ! function_exists( 'sp_is_super_admin' ) || ! sp_is_super_admin() ) {
        wp_redirect( home_url( '/sp-app/?view=settings' ) ); exit;
    }
    $key = isset( $_POST['sp_anthropic_api_key'] ) ? sanitize_text_field( trim( $_POST['sp_anthropic_api_key'] ) ) : '';
    if ( $key ) update_option( 'sp_anthropic_api_key', $key );
    wp_redirect( home_url( '/sp-app/?view=settings&saved=1' ) ); exit;
}

// ── AI Insights AJAX handler ──────────────────────────────────────────────────

function sp_intel_ajax_ai_insights() {
    if ( ! function_exists( 'sp_get_current_team_member' ) ) wp_send_json_error( 'not_auth' );
    $member = sp_get_current_team_member();
    $is_super = function_exists( 'sp_is_super_admin' ) && sp_is_super_admin();
    if ( ! $member && ! $is_super ) wp_send_json_error( 'not_auth' );

    $api_key = get_option( 'sp_anthropic_api_key', '' );
    if ( ! $api_key ) wp_send_json_error( 'no_key' );

    $days = (int) ( isset( $_POST['days'] ) ? $_POST['days'] : 30 );
    if ( ! in_array( $days, array( 7, 30, 90 ) ) ) $days = 30;

    global $wpdb;
    $since = date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
    $today = date( 'Y-m-d' );

    // Compile data snapshot
    $data = array();
    $data['period_days']   = $days;
    $data['contacts_total']= (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts" );
    $data['contacts_new']  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contacts WHERE created_at >= %s", $since ) );
    $data['leads_active']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE status IN ('new','contacted','qualified')" );
    $data['leads_new']     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE created_at >= %s", $since ) );
    $data['leads_closed']  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_leads WHERE status='closed' AND updated_at >= %s", $since ) );
    $data['tasks_open']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tasks WHERE status='open'" );
    $data['tasks_overdue'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tasks WHERE status='open' AND due_date IS NOT NULL AND due_date < %s", $today ) );
    $data['tasks_done']    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tasks WHERE status='done' AND updated_at >= %s", $since ) );

    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}sp_smti_quotes'" ) ) {
        $data['quotes_pipeline_value'] = (float) $wpdb->get_var( "SELECT SUM(total) FROM {$wpdb->prefix}sp_smti_quotes WHERE status NOT IN ('Cancelled','Lost')" );
        $data['quotes_sent']           = (int)   $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_smti_quotes WHERE created_at >= %s", $since ) );
        $data['quotes_won']            = (int)   $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_smti_quotes WHERE status='Won' AND updated_at >= %s", $since ) );
        $data['quotes_won_value']      = (float) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(total) FROM {$wpdb->prefix}sp_smti_quotes WHERE status='Won' AND updated_at >= %s", $since ) );
    }

    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}sp_tickets'" ) ) {
        $data['service_open']     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tickets WHERE status IN ('open','in_progress')" );
        $data['service_urgent']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tickets WHERE priority='urgent' AND status IN ('open','in_progress')" );
        $data['service_resolved'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_tickets WHERE status IN ('resolved','closed') AND updated_at >= %s", $since ) );
    }

    // Operations Core data
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}sp_op_workflows'" ) ) {
        $data['workflows_total']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_op_workflows WHERE status='active'" );
        $data['workflows_running']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_op_instances WHERE status='active'" );
        $data['workflows_done']     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_op_instances WHERE status='completed' AND updated_at >= %s", $since ) );
        $data['onboarding_active']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_ob_instances WHERE status='active'" );
        $data['onboarding_done']    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_ob_instances WHERE status='completed' AND updated_at >= %s", $since ) );
    }

    // Knowledge Core data
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}sp_kb_articles'" ) ) {
        $data['kb_articles']        = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_kb_articles WHERE status='published'" );
        $data['kb_resources']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_kb_resources" );
        $data['kb_courses']         = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_kb_courses WHERE status='published'" );
        $data['kb_completions']     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_kb_completions WHERE completed_at >= %s", $since ) );
        $data['kb_members_trained'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT member_id) FROM {$wpdb->prefix}sp_kb_completions WHERE completed_at >= %s", $since ) );
    }

    // Sales Core data (estimates, proposals, contracts)
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}sp_estimates'" ) ) {
        $data['estimates_open']  = (int)   $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_estimates WHERE status IN ('draft','sent')" );
        $data['estimates_value'] = (float) $wpdb->get_var( "SELECT SUM(total) FROM {$wpdb->prefix}sp_estimates WHERE status IN ('draft','sent')" );
        $data['proposals_open']  = (int)   $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_proposals WHERE status IN ('draft','sent')" );
        $data['contracts_active']= (int)   $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}sp_contracts WHERE status='active'" );
    }

    $platform_name = get_option( 'sp_platform_name', 'the business' );

    $summary_lines = array(
        "Business performance data for {$platform_name} over the last {$days} days:",
        "- Contacts: {$data['contacts_total']} total, {$data['contacts_new']} new this period",
        "- Active leads: {$data['leads_active']}, {$data['leads_new']} new, {$data['leads_closed']} closed",
        "- Tasks: {$data['tasks_open']} open, {$data['tasks_overdue']} overdue, {$data['tasks_done']} completed",
    );
    if ( isset( $data['quotes_sent'] ) ) {
        $summary_lines[] = "- Quotes: {$data['quotes_sent']} sent, {$data['quotes_won']} won (\${$data['quotes_won_value']}), pipeline value \${$data['quotes_pipeline_value']}";
    }
    if ( isset( $data['estimates_open'] ) ) {
        $summary_lines[] = "- Sales pipeline: {$data['estimates_open']} open estimates (\${$data['estimates_value']}), {$data['proposals_open']} proposals out, {$data['contracts_active']} active contracts";
    }
    if ( isset( $data['service_open'] ) ) {
        $summary_lines[] = "- Service tickets: {$data['service_open']} open, {$data['service_urgent']} urgent, {$data['service_resolved']} resolved this period";
    }
    if ( isset( $data['workflows_total'] ) ) {
        $summary_lines[] = "- Operations: {$data['workflows_total']} active workflows, {$data['workflows_running']} running instances, {$data['workflows_done']} completed this period, {$data['onboarding_active']} onboardings in progress, {$data['onboarding_done']} completed";
    }
    if ( isset( $data['kb_articles'] ) ) {
        $summary_lines[] = "- Knowledge base: {$data['kb_articles']} published articles, {$data['kb_courses']} courses, {$data['kb_completions']} lesson completions by {$data['kb_members_trained']} team members this period";
    }

    $prompt = implode( "\n", $summary_lines );
    $prompt .= "\n\nAnalyze this business data and respond in this exact format (use plain hyphens for bullets, no special characters):\n\n**Status:** One sentence overall health assessment.\n\n**What's working:**\n- one positive signal per line. Max 2 lines.\n\n**Needs attention:**\n- one risk or gap per line, with the specific number and what it means for the business. Max 3 lines.\n\n**Next move:** One sentence — the single highest-leverage action right now.\n\nBe direct, specific, and sharp. No fluff.";

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
        'timeout' => 20,
        'headers' => array(
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'content-type'      => 'application/json',
        ),
        'body' => wp_json_encode( array(
            'model'      => 'claude-haiku-4-5-20251001',
            'max_tokens' => 200,
            'messages'   => array(
                array( 'role' => 'user', 'content' => $prompt ),
            ),
        ) ),
    ) );

    if ( is_wp_error( $response ) ) wp_send_json_error( 'api_error' );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    $text = $body['content'][0]['text'] ?? '';
    if ( ! $text ) wp_send_json_error( 'empty_response' );

    wp_send_json_success( array( 'insight' => $text ) );
}
