<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$is_configured = function_exists( 'sp_ai_is_configured' ) && sp_ai_is_configured();
$api_key       = function_exists( 'sp_ai_get_api_key' ) ? sp_ai_get_api_key() : '';
$model         = function_exists( 'sp_ai_get_model' )   ? sp_ai_get_model()   : 'gpt-4o-mini';
$masked_key    = $api_key ? substr( $api_key, 0, 8 ) . str_repeat( '•', 24 ) : '';

$models = array(
    'gpt-4o-mini'  => 'GPT-4o Mini (fast, economical)',
    'gpt-4o'       => 'GPT-4o (powerful, higher cost)',
    'claude-sonnet-4-6' => 'Claude Sonnet 4.6 (Anthropic)',
    'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5 (Anthropic, fast)',
);
?>

<div class="sp-page-header">
    <h1>AI Assistant <span class="sp-nav-addon" style="font-size:11px;padding:3px 8px">ADD-ON</span></h1>
</div>

<?php if ( ! $is_configured ) : ?>
<div class="sp-ai-banner">
    <div class="sp-ai-banner-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="28" height="28">
            <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
        </svg>
    </div>
    <div>
        <div class="sp-ai-banner-title">Connect your AI provider</div>
        <div class="sp-ai-banner-sub">Add an API key below to unlock AI-powered features across your platform.</div>
    </div>
</div>
<?php endif; ?>

<div class="sp-grid-2" style="margin-bottom:16px">

    <div class="sp-card sp-form-card">
        <div class="sp-section-heading">API Configuration</div>
        <form method="post" action="<?php echo esc_url( home_url( '/sp-app/' ) ); ?>">
            <?php wp_nonce_field( 'sp_form', 'sp_nonce' ); ?>
            <input type="hidden" name="sp_type" value="ai_settings">
            <input type="hidden" name="sp_id" value="0">

            <div class="sp-field">
                <label>API Key</label>
                <input type="password" name="sp_ai_api_key" value="<?php echo esc_attr( $api_key ); ?>" placeholder="sk-... or sk-ant-...">
                <?php if ( $masked_key ) : ?>
                    <span class="sp-hint">Currently set: <?php echo esc_html( $masked_key ); ?></span>
                <?php endif; ?>
            </div>

            <div class="sp-field">
                <label>Model</label>
                <select name="sp_ai_model">
                    <?php foreach ( $models as $val => $label ) : ?>
                        <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $model, $val ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="sp-form-actions">
                <button type="submit" class="sp-btn sp-btn-primary">Save Configuration</button>
            </div>
        </form>
    </div>

    <div class="sp-card sp-form-card">
        <div class="sp-section-heading">Coming Soon</div>
        <div class="sp-ai-feature-list">
            <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
                <span class="sp-ai-feature-dot"></span>
                <div>
                    <div class="sp-ai-feature-name">Lead Scoring</div>
                    <div class="sp-ai-feature-desc">Automatically score and prioritize leads based on engagement and profile data.</div>
                </div>
            </div>
            <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
                <span class="sp-ai-feature-dot"></span>
                <div>
                    <div class="sp-ai-feature-name">Contact Summaries</div>
                    <div class="sp-ai-feature-desc">Generate a one-paragraph summary of a contact's history and interactions.</div>
                </div>
            </div>
            <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
                <span class="sp-ai-feature-dot"></span>
                <div>
                    <div class="sp-ai-feature-name">Ticket Triage</div>
                    <div class="sp-ai-feature-desc">Suggest priority and category for incoming tickets automatically.</div>
                </div>
            </div>
            <div class="sp-ai-feature <?php echo $is_configured ? 'sp-ai-feature-ready' : ''; ?>">
                <span class="sp-ai-feature-dot"></span>
                <div>
                    <div class="sp-ai-feature-name">Pipeline Insights</div>
                    <div class="sp-ai-feature-desc">Weekly AI-generated analysis of your lead pipeline and conversion trends.</div>
                </div>
            </div>
        </div>
        <?php if ( ! $is_configured ) : ?>
            <p class="sp-hint" style="margin-top:16px">Configure your API key to enable these features.</p>
        <?php endif; ?>
    </div>

</div>
