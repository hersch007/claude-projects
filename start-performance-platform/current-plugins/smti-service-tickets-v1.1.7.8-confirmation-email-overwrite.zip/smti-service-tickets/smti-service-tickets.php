<?php
/**
 * Plugin Name:  SMTI Service Tickets
 * Description:  Serial number equipment lookup via HubDB, HubSpot owner list, and service ticket creation for the SMTI service ticket page.
 * Version:      1.1.7.8
 * Author:       Richard Brashear – Start Advertising
 * Author URI:   https://startadvertising.com
 * License:      GPL-2.0-or-later
 * Text Domain:  smti-service-tickets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SMTI_ST_VERSION', '1.1.7.8' );
define( 'SMTI_ST_OPTION',  'smti_service_settings' );

// Default HubDB table ID for SMTI Assets Registry
define( 'SMTI_ST_DEFAULT_HUBDB_TABLE', '279292269' );

add_action( 'admin_menu',    'smti_st_add_settings_page' );
add_action( 'admin_init',    'smti_st_register_settings' );
add_action( 'rest_api_init', 'smti_st_register_routes' );
add_action( 'init',          'smti_st_handle_options_requests' );

// ---------------------------------------------------------------------------
// Admin – settings page
// ---------------------------------------------------------------------------

function smti_st_add_settings_page() {
	add_options_page(
		'SMTI Service Tickets',
		'SMTI Service Tickets',
		'manage_options',
		'smti-service-tickets',
		'smti_st_render_settings_page'
	);
}

function smti_st_register_settings() {
	register_setting( 'smti_st_group', SMTI_ST_OPTION, 'smti_st_sanitize_settings' );
}

function smti_st_sanitize_settings( $input ) {
	$current = get_option( SMTI_ST_OPTION, array() );
	$dashboard_pin_hash = isset( $current['dashboard_pin_hash'] ) ? (string) $current['dashboard_pin_hash'] : '';
	if ( isset( $input['dashboard_pin'] ) && trim( (string) $input['dashboard_pin'] ) !== '' ) {
		$pin = preg_replace( '/\D/', '', (string) $input['dashboard_pin'] );
		if ( strlen( $pin ) === 6 ) {
			$dashboard_pin_hash = wp_hash_password( $pin );
		}
	}
	return array(
		'hubspot_token'        => isset( $input['hubspot_token'] )        ? sanitize_text_field( $input['hubspot_token'] )        : '',
		'allowed_origin'       => isset( $input['allowed_origin'] )       ? esc_url_raw( trim( $input['allowed_origin'] ) )       : '',
		'form_token'           => isset( $input['form_token'] )           ? sanitize_text_field( $input['form_token'] )           : '',
		'recaptcha_site_key'   => isset( $input['recaptcha_site_key'] )   ? sanitize_text_field( $input['recaptcha_site_key'] )   : '',
		'recaptcha_secret_key' => isset( $input['recaptcha_secret_key'] ) ? sanitize_text_field( $input['recaptcha_secret_key'] ) : '',
		'hubdb_table_id'       => isset( $input['hubdb_table_id'] )       ? sanitize_text_field( $input['hubdb_table_id'] )       : SMTI_ST_DEFAULT_HUBDB_TABLE,
		'ticket_pipeline_id'   => isset( $input['ticket_pipeline_id'] )   ? sanitize_text_field( $input['ticket_pipeline_id'] )   : '0',
		'ticket_stage_id'      => isset( $input['ticket_stage_id'] )      ? sanitize_text_field( $input['ticket_stage_id'] )      : '1',
		'dashboard_pin_hash'   => $dashboard_pin_hash,
	);
}

function smti_st_render_settings_page() {
	$o = smti_st_get_settings();
	?>
	<div class="wrap">
		<h1>SMTI Service Tickets <span style="font-size:13px;font-weight:400;color:#888;">v<?php echo esc_html( SMTI_ST_VERSION ); ?></span></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'smti_st_group' ); ?>
			<table class="form-table">
				<tr>
					<th><label for="smti_st_hs_token">HubSpot Private App Token</label></th>
					<td>
						<input type="password" id="smti_st_hs_token"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[hubspot_token]"
							value="<?php echo esc_attr( $o['hubspot_token'] ); ?>"
							class="regular-text" autocomplete="off">
					</td>
				</tr>
				<tr>
					<th><label for="smti_st_origin">Allowed Origin</label></th>
					<td>
						<input type="url" id="smti_st_origin"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[allowed_origin]"
							value="<?php echo esc_attr( $o['allowed_origin'] ); ?>"
							class="regular-text" placeholder="https://smti.co">
					</td>
				</tr>
				<tr>
					<th><label for="smti_st_form_token">Form Token (X-SMTI-Form-Token)</label></th>
					<td>
						<input type="text" id="smti_st_form_token"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[form_token]"
							value="<?php echo esc_attr( $o['form_token'] ); ?>"
							class="regular-text" autocomplete="off">
						<p class="description">Must match <code>FORM_TOKEN</code> in your HubSpot page JavaScript.</p>
					</td>
				</tr>
				<tr>
					<th><label for="smti_st_recaptcha_site_key">reCAPTCHA Site Key</label></th>
					<td>
						<input type="text" id="smti_st_recaptcha_site_key"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[recaptcha_site_key]"
							value="<?php echo esc_attr( $o['recaptcha_site_key'] ); ?>"
							class="regular-text" autocomplete="off">
						<p class="description">Optional. Used by the HubSpot form template. Keep blank until Google reCAPTCHA keys are ready.</p>
					</td>
				</tr>
				<tr>
					<th><label for="smti_st_recaptcha_secret_key">reCAPTCHA Secret Key</label></th>
					<td>
						<input type="password" id="smti_st_recaptcha_secret_key"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[recaptcha_secret_key]"
							value="<?php echo esc_attr( $o['recaptcha_secret_key'] ); ?>"
							class="regular-text" autocomplete="off">
						<p class="description">Optional. If set, customer service ticket submissions must include a valid reCAPTCHA token.</p>
					</td>
				</tr>

				<tr>
					<th><label for="smti_st_dashboard_pin">Dashboard PIN</label></th>
					<td>
						<input type="text" id="smti_st_dashboard_pin"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[dashboard_pin]"
							value=""
							class="regular-text" autocomplete="off" inputmode="numeric" maxlength="6" placeholder="6-digit PIN">
						<p class="description">Optional 6-digit PIN for the HubSpot service dashboard. Leave blank to keep the existing PIN.</p>
					</td>
				</tr>

				<tr>
					<th><label for="smti_st_hubdb">HubDB Table ID (Assets Registry)</label></th>
					<td>
						<input type="text" id="smti_st_hubdb"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[hubdb_table_id]"
							value="<?php echo esc_attr( $o['hubdb_table_id'] ); ?>"
							class="regular-text" placeholder="279292269">
						<p class="description">HubSpot → Content → HubDB → SMTI Assets Registry. Table ID is in the page URL.</p>
					</td>
				</tr>
				<tr>
					<th><label for="smti_st_pipeline">Ticket Pipeline ID</label></th>
					<td>
						<input type="text" id="smti_st_pipeline"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[ticket_pipeline_id]"
							value="<?php echo esc_attr( $o['ticket_pipeline_id'] ); ?>"
							class="regular-text" placeholder="0">
					</td>
				</tr>
				<tr>
					<th><label for="smti_st_stage">Ticket Stage ID</label></th>
					<td>
						<input type="text" id="smti_st_stage"
							name="<?php echo esc_attr( SMTI_ST_OPTION ); ?>[ticket_stage_id]"
							value="<?php echo esc_attr( $o['ticket_stage_id'] ); ?>"
							class="regular-text" placeholder="1">
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

// ---------------------------------------------------------------------------
// Settings helper
// ---------------------------------------------------------------------------

function smti_st_get_settings() {
	$o = get_option( SMTI_ST_OPTION, array() );
	return array(
		'hubspot_token'        => isset( $o['hubspot_token'] )        ? $o['hubspot_token']        : '',
		'allowed_origin'       => isset( $o['allowed_origin'] )       ? $o['allowed_origin']       : '',
		'form_token'           => isset( $o['form_token'] )           ? $o['form_token']           : '',
		'recaptcha_site_key'   => isset( $o['recaptcha_site_key'] )   ? $o['recaptcha_site_key']   : '',
		'recaptcha_secret_key' => isset( $o['recaptcha_secret_key'] ) ? $o['recaptcha_secret_key'] : '',
		'hubdb_table_id'       => isset( $o['hubdb_table_id'] )       ? $o['hubdb_table_id']       : SMTI_ST_DEFAULT_HUBDB_TABLE,
		'ticket_pipeline_id'   => isset( $o['ticket_pipeline_id'] )   ? $o['ticket_pipeline_id']   : '0',
		'ticket_stage_id'      => isset( $o['ticket_stage_id'] )      ? $o['ticket_stage_id']      : '1',
		'dashboard_pin_hash'   => isset( $o['dashboard_pin_hash'] )   ? $o['dashboard_pin_hash']   : '',
	);
}

// ---------------------------------------------------------------------------
// CORS
// ---------------------------------------------------------------------------

function smti_st_send_cors_headers() {
	$settings       = smti_st_get_settings();
	$allowed_origin = $settings['allowed_origin'];
	if ( empty( $allowed_origin ) ) return;

	$request_origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? trim( $_SERVER['HTTP_ORIGIN'] ) : '';
	if ( $request_origin && rtrim( $request_origin, '/' ) === rtrim( $allowed_origin, '/' ) ) {
		header( 'Access-Control-Allow-Origin: '   . $allowed_origin );
		header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
		header( 'Access-Control-Allow-Headers: Content-Type, Authorization, X-SMTI-Form-Token, X-SMTI-Dashboard-Token' );
		header( 'Vary: Origin' );
	}
}

function smti_st_handle_options_requests() {
	if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || strtoupper( $_SERVER['REQUEST_METHOD'] ) !== 'OPTIONS' ) return;
	if ( empty( $_SERVER['REQUEST_URI'] ) || strpos( $_SERVER['REQUEST_URI'], '/wp-json/smti-service/v1/' ) === false ) return;
	smti_st_send_cors_headers();
	status_header( 200 );
	exit;
}

// ---------------------------------------------------------------------------
// REST routes
// ---------------------------------------------------------------------------

function smti_st_register_routes() {
	register_rest_route( 'smti-service/v1', '/search-equipment', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_search_equipment',
		'permission_callback' => 'smti_st_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/hubspot-owners', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_get_owners',
		'permission_callback' => 'smti_st_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/create-service-ticket', array(
		'methods'             => 'POST',
		'callback'            => 'smti_st_create_ticket',
		'permission_callback' => 'smti_st_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/check-duplicate-ticket', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_check_duplicate_ticket_endpoint',
		'permission_callback' => 'smti_st_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-login', array(
		'methods'             => 'POST',
		'callback'            => 'smti_st_dashboard_login',
		'permission_callback' => '__return_true',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-tickets', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_dashboard_tickets',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-ticket/(?P<id>[0-9]+)', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_dashboard_ticket_detail',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-ticket/(?P<id>[0-9]+)/stage', array(
		'methods'             => 'POST',
		'callback'            => 'smti_st_dashboard_update_stage',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-ticket/(?P<id>[0-9]+)/note', array(
		'methods'             => 'POST',
		'callback'            => 'smti_st_dashboard_add_note',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-ticket/(?P<id>[0-9]+)/assign', array(
		'methods'             => 'POST',
		'callback'            => 'smti_st_dashboard_assign_owner',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-metrics', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_dashboard_metrics',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/dashboard-owners', array(
		'methods'             => 'GET',
		'callback'            => 'smti_st_dashboard_owners',
		'permission_callback' => 'smti_st_dashboard_permission_callback',
	) );

	register_rest_route( 'smti-service/v1', '/customer-ticket-status', array(
		'methods'             => 'POST',
		'callback'            => 'smti_st_customer_ticket_status',
		'permission_callback' => '__return_true',
	) );
}

// ---------------------------------------------------------------------------
// Auth / permission callback
// ---------------------------------------------------------------------------

function smti_st_get_header( $key ) {
	if ( function_exists( 'getallheaders' ) ) {
		$headers = getallheaders();
		if ( is_array( $headers ) ) {
			foreach ( $headers as $k => $v ) {
				if ( strtolower( $k ) === strtolower( $key ) ) return $v;
			}
		}
	}
	$server_key = 'HTTP_' . strtoupper( str_replace( '-', '_', $key ) );
	return isset( $_SERVER[ $server_key ] ) ? sanitize_text_field( wp_unslash( $_SERVER[ $server_key ] ) ) : '';
}

function smti_st_permission_callback() {
	$settings = smti_st_get_settings();
	$expected = trim( $settings['form_token'] );
	$provided = smti_st_get_header( 'X-SMTI-Form-Token' );

	if ( empty( $expected ) ) {
		return new WP_Error( 'smti_not_configured', 'Form token is not configured.', array( 'status' => 500 ) );
	}
	if ( empty( $provided ) || ! hash_equals( $expected, $provided ) ) {
		return new WP_Error( 'smti_forbidden', 'Invalid or missing form token.', array( 'status' => 403 ) );
	}

	$allowed_origin = $settings['allowed_origin'];
	if ( ! empty( $allowed_origin ) ) {
		$origin  = isset( $_SERVER['HTTP_ORIGIN'] )  ? trim( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) )  : '';
		$referer = isset( $_SERVER['HTTP_REFERER'] ) ? trim( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
		$ok = ( $origin  && stripos( $origin,  $allowed_origin ) === 0 )
		   || ( $referer && stripos( $referer, $allowed_origin ) === 0 );
		if ( ! $ok ) {
			return new WP_Error( 'smti_bad_origin', 'Origin not allowed.', array( 'status' => 403 ) );
		}
	}

	return true;
}

// ---------------------------------------------------------------------------
// HubSpot HTTP helper
// ---------------------------------------------------------------------------

function smti_st_hs_request( $method, $path, $body = null ) {
	$settings = smti_st_get_settings();
	$token    = $settings['hubspot_token'];
	if ( empty( $token ) ) return new WP_Error( 'smti_missing_token', 'HubSpot token is not configured.' );

	$args = array(
		'method'  => $method,
		'timeout' => 25,
		'headers' => array(
			'Authorization' => 'Bearer ' . $token,
			'Content-Type'  => 'application/json',
		),
	);
	if ( ! is_null( $body ) ) $args['body'] = wp_json_encode( $body );

	$response = wp_remote_request( 'https://api.hubapi.com' . $path, $args );
	if ( is_wp_error( $response ) ) return $response;

	return array(
		'status' => wp_remote_retrieve_response_code( $response ),
		'body'   => json_decode( wp_remote_retrieve_body( $response ), true ),
		'raw'    => wp_remote_retrieve_body( $response ),
	);
}

// ---------------------------------------------------------------------------
// Endpoint: GET /search-equipment
// Queries HubDB table 279292269 (SMTI Assets Registry) by serial_number.
//
// HubDB columns confirmed from CSV export:
//   serial_number, serial_number_normalized, asset_name, part_id,
//   part_description, order_number, smti_customer_id, associated_company_name,
//   smti_location_id, smti_location_key, location_name,
//   shipping_address_1, shipping_address_2, shipping_city, shipping_state,
//   shipping_zip, shipping_country, match_status, import_notes,
//   invoice_date_ship_date
// ---------------------------------------------------------------------------

function smti_st_search_equipment( WP_REST_Request $request ) {
	smti_st_send_cors_headers();

	$serial = trim( sanitize_text_field( $request->get_param( 'serial' ) ) );
	if ( empty( $serial ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Serial number is required.' ), 400 );
	}

	$settings = smti_st_get_settings();
	$table_id = trim( $settings['hubdb_table_id'] );

	if ( empty( $table_id ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'HubDB table ID is not configured in plugin settings.' ), 500 );
	}

	// Try exact match on serial_number first, then fall back to serial_number_normalized
	$result = smti_st_hubdb_search( $table_id, 'serial_number', $serial );

	if ( empty( $result ) ) {
		// Normalize: strip non-alphanumeric for a looser match
		$normalized = preg_replace( '/[^a-zA-Z0-9]/', '', strtoupper( $serial ) );
		$result = smti_st_hubdb_search( $table_id, 'serial_number_normalized', $normalized );
	}

	if ( empty( $result ) ) {
		return new WP_REST_Response( array(
			'success' => false,
			'message' => 'No equipment found for serial number: ' . $serial,
		), 200 );
	}

	$values    = isset( $result['values'] ) ? $result['values'] : array();
	$equipment = smti_st_map_hubdb_row( $values, $serial );
	$duplicate = smti_st_find_recent_duplicate_ticket( $equipment['serial_number'] ?: $serial, '' );

	$response = array(
		'success'   => true,
		'equipment' => $equipment,
	);

	if ( ! empty( $duplicate['found'] ) ) {
		$response['duplicate_detected'] = true;
		$response['existing_ticket'] = array(
			'ticket_id'         => $duplicate['ticket_id'],
			'subject'           => $duplicate['subject'],
			'createdate'        => $duplicate['createdate'],
			'pipeline_stage'    => $duplicate['pipeline_stage'] ?? '',
			'contact_name'      => $duplicate['contact_name'] ?? '',
			'contact_email'     => $duplicate['contact_email'] ?? '',
			'contact_phone'     => $duplicate['contact_phone'] ?? '',
			'company'           => $duplicate['company'] ?? '',
			'location_name'     => $duplicate['location_name'] ?? '',
			'serial_number'     => $duplicate['serial_number'] ?? '',
			'asset_name'        => $duplicate['asset_name'] ?? '',
			'part_id'           => $duplicate['part_id'] ?? '',
			'part_description'  => $duplicate['part_description'] ?? '',
			'order_number'      => $duplicate['order_number'] ?? '',
			'issue_description' => $duplicate['issue_description'] ?? '',
		);
	}

	return new WP_REST_Response( $response, 200 );
}

/**
 * Query a HubDB table for an exact match on a given column.
 * Returns the first matching row or null.
 */
function smti_st_hubdb_search( $table_id, $column, $value ) {
	$path     = '/cms/v3/hubdb/tables/' . rawurlencode( $table_id ) . '/rows?'
	          . rawurlencode( $column ) . '__eq=' . rawurlencode( $value )
	          . '&limit=1';
	$response = smti_st_hs_request( 'GET', $path );

	if ( is_wp_error( $response ) || (int) $response['status'] !== 200 ) return null;
	return ! empty( $response['body']['results'][0] ) ? $response['body']['results'][0] : null;
}

/**
 * Map a HubDB row's values to the field names expected by the front-end form.
 */
function smti_st_map_hubdb_row( $values, $serial_fallback ) {
	$g = function( $key ) use ( $values ) {
		if ( ! isset( $values[ $key ] ) ) return '';
		$v = $values[ $key ];
		// HubDB sometimes wraps values in arrays for option/multi-select columns
		if ( is_array( $v ) ) return isset( $v['name'] ) ? (string) $v['name'] : implode( ', ', array_column( $v, 'name' ) );
		return (string) $v;
	};

	return array(
		'serial_number'           => $g( 'serial_number' ) ?: $serial_fallback,
		'asset_name'              => $g( 'asset_name' ),
		'part_id'                 => $g( 'part_id' ),
		'part_description'        => $g( 'part_description' ),
		'order_number'            => $g( 'order_number' ),
		'invoice_date_ship_date'  => $g( 'invoice_date_ship_date' ),
		'associated_company_name' => $g( 'associated_company_name' ),
		'smti_customer_id'        => $g( 'smti_customer_id' ),
		'smti_location_id'        => $g( 'smti_location_id' ),
		'smti_location_key'       => $g( 'smti_location_key' ),
		'location_name'           => $g( 'location_name' ),
		'shipping_address_1'      => $g( 'shipping_address_1' ),
		'shipping_address_2'      => $g( 'shipping_address_2' ),
		'shipping_city'           => $g( 'shipping_city' ),
		'shipping_state'          => $g( 'shipping_state' ),
		'shipping_zip'            => $g( 'shipping_zip' ),
		'shipping_country'        => $g( 'shipping_country' ),
		'match_status'            => $g( 'match_status' ),
		'import_notes'            => $g( 'import_notes' ),
	);
}

// ---------------------------------------------------------------------------
// Endpoint: GET /hubspot-owners
// ---------------------------------------------------------------------------

function smti_st_get_owners( WP_REST_Request $request ) {
	smti_st_send_cors_headers();

	$response = smti_st_hs_request( 'GET', '/crm/v3/owners/?limit=100' );

	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'owners' => array(), 'message' => $response->get_error_message() ), 500 );
	}

	if ( (int) $response['status'] !== 200 || empty( $response['body']['results'] ) ) {
		return new WP_REST_Response( array( 'success' => true, 'owners' => array() ), 200 );
	}

	$owners = array();
	foreach ( $response['body']['results'] as $owner ) {
		$first = isset( $owner['firstName'] ) ? $owner['firstName'] : '';
		$last  = isset( $owner['lastName'] )  ? $owner['lastName']  : '';
		$email = isset( $owner['email'] )     ? $owner['email']     : '';
		$label = trim( $first . ' ' . $last );
		if ( empty( $label ) ) $label = $email;
		$owners[] = array(
			'id'    => isset( $owner['id'] ) ? (string) $owner['id'] : '',
			'label' => $label,
			'email' => $email,
		);
	}

	return new WP_REST_Response( array( 'success' => true, 'owners' => $owners ), 200 );
}



/**
 * Pull readable summary fields out of the ticket content body.
 */
function smti_st_extract_ticket_body_value( $content, $label ) {
	$content = (string) $content;
	$label   = preg_quote( (string) $label, '/' );
	if ( preg_match( '/^' . $label . '\s*:\s*(.*)$/mi', $content, $m ) ) {
		return trim( (string) $m[1] );
	}
	return '';
}

function smti_st_extract_issue_description_from_ticket_body( $content ) {
	$content = (string) $content;
	if ( preg_match( '/ISSUE DESCRIPTION\s*\R(.*?)(?:\R\s*IMPORT NOTES\s*\R|\R\s*DUPLICATE OVERRIDE\s*\R|$)/is', $content, $m ) ) {
		return trim( (string) $m[1] );
	}
	return '';
}

function smti_st_prop_value( $props, $keys, $fallback = '' ) {
	foreach ( (array) $keys as $key ) {
		if ( isset( $props[ $key ] ) && trim( (string) $props[ $key ] ) !== '' ) {
			return trim( (string) $props[ $key ] );
		}
	}
	return $fallback;
}

function smti_st_get_ticket_details_by_id( $ticket_id ) {
	$ticket_id = trim( (string) $ticket_id );
	if ( $ticket_id === '' ) {
		return array();
	}

	$properties = array(
		'subject',
		'content',
		'createdate',
		'hs_lastmodifieddate',
		'hs_pipeline_stage',
		'smti_service_request_number',
		'smti_contact_name',
		'smti_contact_email',
		'smti_contact_phone',
		'smti_facility_name',
		'smti_location_name',
		'smti_serial_number',
		'smti_equipment_type',
		'smti_equipment_model',
		'smti_issue_description',
		'smti_part_id',
		'smti_order_number',
		'smti_customer_id',
	);

	$endpoint = '/crm/v3/objects/tickets/' . rawurlencode( $ticket_id ) . '?properties=' . rawurlencode( implode( ',', $properties ) );
	$response = smti_st_hs_request( 'GET', $endpoint );

	if ( is_wp_error( $response ) || (int) $response['status'] !== 200 || empty( $response['body'] ) ) {
		return array();
	}

	return $response['body'];
}

function smti_st_build_existing_ticket_summary( $ticket ) {
	$ticket_id = isset( $ticket['id'] ) ? (string) $ticket['id'] : '';

	$full_ticket = smti_st_get_ticket_details_by_id( $ticket_id );
	if ( ! empty( $full_ticket ) ) {
		$ticket = array_replace_recursive( $ticket, $full_ticket );
	}

	$props   = isset( $ticket['properties'] ) && is_array( $ticket['properties'] ) ? $ticket['properties'] : array();
	$content = isset( $props['content'] ) ? (string) $props['content'] : '';

	$contact_name  = smti_st_prop_value( $props, array( 'smti_contact_name' ), smti_st_extract_ticket_body_value( $content, 'Name' ) );
	$contact_email = smti_st_prop_value( $props, array( 'smti_contact_email' ), smti_st_extract_ticket_body_value( $content, 'Email' ) );
	$contact_phone = smti_st_prop_value( $props, array( 'smti_contact_phone' ), smti_st_extract_ticket_body_value( $content, 'Phone' ) );
	$company       = smti_st_prop_value( $props, array( 'smti_facility_name' ), smti_st_extract_ticket_body_value( $content, 'Company' ) );
	$location_name = smti_st_prop_value( $props, array( 'smti_location_name' ), smti_st_extract_ticket_body_value( $content, 'Location Name' ) );
	$serial_number = smti_st_prop_value( $props, array( 'smti_serial_number' ), smti_st_extract_ticket_body_value( $content, 'Serial Number' ) );
	$part_id       = smti_st_prop_value( $props, array( 'smti_part_id', 'smti_equipment_type' ), smti_st_extract_ticket_body_value( $content, 'Part ID' ) );
	$part_desc     = smti_st_prop_value( $props, array( 'smti_equipment_model' ), smti_st_extract_ticket_body_value( $content, 'Part Description' ) );
	$issue         = smti_st_prop_value( $props, array( 'smti_issue_description' ), smti_st_extract_issue_description_from_ticket_body( $content ) );

	return array(
		'ticket_id'              => $ticket_id,
		'subject'                => smti_st_prop_value( $props, array( 'subject' ) ),
		'createdate'             => smti_st_prop_value( $props, array( 'createdate' ) ),
		'pipeline_stage'         => smti_st_prop_value( $props, array( 'hs_pipeline_stage' ) ),
		'lastmodifieddate'      => smti_st_prop_value( $props, array( 'hs_lastmodifieddate' ) ),
		'service_request_number' => smti_st_prop_value( $props, array( 'smti_service_request_number' ) ),
		'content'                => $content,
		'contact_name'           => $contact_name,
		'contact_email'          => $contact_email,
		'contact_phone'          => $contact_phone,
		'company'                => $company,
		'location_name'          => $location_name,
		'serial_number'          => $serial_number,
		'asset_name'             => smti_st_extract_ticket_body_value( $content, 'Asset Name' ),
		'part_id'                => $part_id,
		'part_description'       => $part_desc,
		'order_number'           => smti_st_prop_value( $props, array( 'smti_order_number' ), smti_st_extract_ticket_body_value( $content, 'Order Number' ) ),
		'issue_description'      => $issue,
	);
}

/**
 * Check for a recent existing service ticket for the same serial number.
 * This prevents accidental duplicate service requests from the external ticket form.
 */
function smti_st_find_recent_duplicate_ticket( $serial_number, $contact_email = '' ) {
	$serial_number = trim( (string) $serial_number );
	$contact_email = sanitize_email( (string) $contact_email );

	if ( $serial_number === '' ) {
		return array( 'found' => false );
	}

	$created_after_ms = ( time() - ( 30 * DAY_IN_SECONDS ) ) * 1000;

	$search_body = array(
		'filterGroups' => array(
			array(
				'filters' => array(
					array(
						'propertyName' => 'subject',
						'operator'     => 'CONTAINS_TOKEN',
						'value'        => $serial_number,
					),
					array(
						'propertyName' => 'createdate',
						'operator'     => 'GTE',
						'value'        => (string) $created_after_ms,
					),
				),
			),
		),
		'properties' => array( 'subject', 'content', 'createdate', 'hs_lastmodifieddate', 'hs_pipeline_stage', 'smti_service_request_number', 'smti_contact_name', 'smti_contact_email', 'smti_contact_phone', 'smti_facility_name', 'smti_location_name', 'smti_serial_number', 'smti_equipment_type', 'smti_equipment_model', 'smti_issue_description', 'smti_part_id', 'smti_order_number', 'smti_customer_id' ),
		'sorts'      => array( '-createdate' ),
		'limit'      => 5,
	);

	$response = smti_st_hs_request( 'POST', '/crm/v3/objects/tickets/search', $search_body );

	if ( is_wp_error( $response ) || (int) $response['status'] !== 200 || empty( $response['body']['results'] ) ) {
		return array( 'found' => false );
	}

	foreach ( $response['body']['results'] as $ticket ) {
		$props   = isset( $ticket['properties'] ) ? $ticket['properties'] : array();
		$subject = isset( $props['subject'] ) ? (string) $props['subject'] : '';
		$content = isset( $props['content'] ) ? (string) $props['content'] : '';

		$serial_match = stripos( $subject . "\n" . $content, $serial_number ) !== false;
		$email_match  = $contact_email === '' || stripos( $content, $contact_email ) !== false;

		if ( $serial_match && $email_match ) {
			$summary = smti_st_build_existing_ticket_summary( $ticket );
			$summary['found'] = true;
			return $summary;
		}
	}

	return array( 'found' => false );
}

function smti_st_check_duplicate_ticket_endpoint( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$serial = trim( sanitize_text_field( (string) $request->get_param( 'serial' ) ) );
	$email  = sanitize_email( (string) ( $request->get_param( 'contact_email' ) ?: $request->get_param( 'email' ) ) );
	if ( $serial === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Serial number is required.' ), 400 );
	}
	$duplicate = smti_st_find_recent_duplicate_ticket( $serial, $email );

	if ( empty( $duplicate['found'] ) ) {
		return new WP_REST_Response( array(
			'success'            => true,
			'duplicate_detected' => false,
			'existing_ticket'    => null,
		), 200 );
	}

	$existing_ticket = array(
		'ticket_id'              => $duplicate['ticket_id'] ?? '',
		'subject'                => $duplicate['subject'] ?? '',
		'createdate'             => $duplicate['createdate'] ?? '',
		'pipeline_stage'         => $duplicate['pipeline_stage'] ?? '',
		'lastmodifieddate'      => $duplicate['lastmodifieddate'] ?? '',
		'service_request_number' => $duplicate['service_request_number'] ?? '',
		'contact_name'           => $duplicate['contact_name'] ?? '',
		'contact_email'          => $duplicate['contact_email'] ?? '',
		'contact_phone'          => $duplicate['contact_phone'] ?? '',
		'company'                => $duplicate['company'] ?? '',
		'location_name'          => $duplicate['location_name'] ?? '',
		'serial_number'          => $duplicate['serial_number'] ?? '',
		'asset_name'             => $duplicate['asset_name'] ?? '',
		'part_id'                => $duplicate['part_id'] ?? '',
		'part_description'       => $duplicate['part_description'] ?? '',
		'order_number'           => $duplicate['order_number'] ?? '',
		'issue_description'      => $duplicate['issue_description'] ?? '',
	);

	return new WP_REST_Response( array_merge( array(
		'success'                 => true,
		'duplicate_detected'      => true,
		'existing_ticket'         => $existing_ticket,
		'existing_ticket_id'      => $existing_ticket['ticket_id'],
		'existing_subject'        => $existing_ticket['subject'],
		'existing_created'        => $existing_ticket['createdate'],
		'existing_request_number' => $existing_ticket['service_request_number'],
	), $existing_ticket ), 200 );
}

function smti_st_add_note_to_ticket( $ticket_id, $note_body, $contact_id = '', $company_id = '' ) {
	$ticket_id = trim( (string) $ticket_id );
	$note_body = trim( (string) $note_body );
	if ( $ticket_id === '' || $note_body === '' ) return '';
	$note_response = smti_st_hs_request( 'POST', '/crm/v3/objects/notes', array(
		'properties' => array(
			'hs_note_body' => nl2br( esc_html( $note_body ) ),
			'hs_timestamp' => gmdate( 'c' ),
		),
	) );
	if ( is_wp_error( $note_response ) || (int) $note_response['status'] !== 201 || empty( $note_response['body']['id'] ) ) return '';
	$note_id = (string) $note_response['body']['id'];
	smti_st_hs_request( 'PUT', '/crm/v3/objects/notes/' . rawurlencode( $note_id ) . '/associations/tickets/' . rawurlencode( $ticket_id ) . '/note_to_ticket' );
	if ( ! empty( $contact_id ) ) {
		smti_st_hs_request( 'PUT', '/crm/v3/objects/notes/' . rawurlencode( $note_id ) . '/associations/contacts/' . rawurlencode( $contact_id ) . '/note_to_contact' );
	}
	if ( ! empty( $company_id ) ) {
		smti_st_hs_request( 'PUT', '/crm/v3/objects/notes/' . rawurlencode( $note_id ) . '/associations/companies/' . rawurlencode( $company_id ) . '/note_to_company' );
	}
	return $note_id;
}


function smti_st_submission_hash( $serial_number, $contact_email, $issue_description, $duplicate_action = '' ) {
	$seed = strtolower( trim( (string) $serial_number ) ) . '|' . strtolower( trim( (string) $contact_email ) ) . '|' . trim( (string) $issue_description ) . '|' . trim( (string) $duplicate_action );
	return 'smti_st_submit_' . md5( $seed );
}

function smti_st_check_submission_cooldown( $serial_number, $contact_email, $issue_description, $duplicate_action = '' ) {
	$key = smti_st_submission_hash( $serial_number, $contact_email, $issue_description, $duplicate_action );
	if ( get_transient( $key ) ) {
		return true;
	}
	return false;
}

function smti_st_set_submission_cooldown( $serial_number, $contact_email, $issue_description, $duplicate_action = '' ) {
	$key = smti_st_submission_hash( $serial_number, $contact_email, $issue_description, $duplicate_action );
	set_transient( $key, 1, 5 * MINUTE_IN_SECONDS );
}

function smti_st_upload_one_file_to_hubspot( $tmp_name, $original_name, $mime_type = '' ) {
	$settings = smti_st_get_settings();
	$token = trim( (string) $settings['hubspot_token'] );

	if ( $token === '' || ! file_exists( $tmp_name ) ) {
		return array( 'success' => false, 'message' => 'Missing HubSpot token or temporary file.' );
	}

	if ( ! function_exists( 'curl_init' ) || ! class_exists( 'CURLFile' ) ) {
		return array( 'success' => false, 'message' => 'Server cURL file upload support is unavailable.' );
	}

	$original_name = sanitize_file_name( (string) $original_name );
	if ( $mime_type === '' ) {
		$mime_type = function_exists( 'mime_content_type' ) ? mime_content_type( $tmp_name ) : 'application/octet-stream';
	}
	if ( empty( $mime_type ) ) {
		$mime_type = 'application/octet-stream';
	}

	$post_fields = array(
		'file'       => new CURLFile( $tmp_name, $mime_type, $original_name ),
		'folderPath' => '/SMTI-Service-Ticket-Attachments',
		'options'    => wp_json_encode( array( 'access' => 'PRIVATE' ) ),
	);

	$ch = curl_init();
	curl_setopt_array( $ch, array(
		CURLOPT_URL            => 'https://api.hubapi.com/files/v3/files',
		CURLOPT_POST           => true,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_TIMEOUT        => 60,
		CURLOPT_HTTPHEADER     => array( 'Authorization: Bearer ' . $token ),
		CURLOPT_POSTFIELDS     => $post_fields,
	) );

	$raw       = curl_exec( $ch );
	$error     = curl_error( $ch );
	$http_code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
	curl_close( $ch );

	$decoded = json_decode( (string) $raw, true );

	if ( $http_code >= 200 && $http_code < 300 && ! empty( $decoded['id'] ) ) {
		return array(
			'success' => true,
			'id'      => (string) $decoded['id'],
			'name'    => $original_name,
			'url'     => $decoded['url'] ?? '',
		);
	}

	return array(
		'success' => false,
		'message' => $error ?: 'HubSpot file upload failed.',
		'status'  => $http_code,
		'body'    => $decoded ?: $raw,
	);
}


function smti_st_verify_recaptcha_token( $token, $secret ) {
	$token  = trim( (string) $token );
	$secret = trim( (string) $secret );

	if ( $secret === '' ) {
		return true;
	}

	if ( $token === '' ) {
		return false;
	}

	$response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
		'timeout' => 15,
		'body'    => array(
			'secret'   => $secret,
			'response' => $token,
			'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
		),
	) );

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	return ! empty( $body['success'] );
}


// ---------------------------------------------------------------------------
// Customer confirmation email
// ---------------------------------------------------------------------------

function smti_st_clean_issue_for_email( $issue_description ) {
	$issue_description = trim( (string) $issue_description );
	if ( $issue_description === '' ) return '';

	$lines = preg_split( "/\r\n|\n|\r/", $issue_description );
	$clean = array();
	foreach ( $lines as $line ) {
		$line = trim( (string) $line );
		if ( $line === '' ) continue;
		if ( stripos( $line, 'SERIAL NUMBER STATUS:' ) === 0 ) continue;
		if ( strtoupper( $line ) === 'DESCRIPTION' ) continue;
		if ( strtoupper( $line ) === 'PROBLEM DESCRIPTION' ) continue;
		$clean[] = $line;
	}

	$summary = trim( implode( "\n", $clean ) );
	return $summary !== '' ? $summary : $issue_description;
}

function smti_st_send_customer_confirmation_email( $context ) {
	$email = isset( $context['contact_email'] ) ? sanitize_email( (string) $context['contact_email'] ) : '';
	if ( $email === '' || ! is_email( $email ) ) return false;

	$name        = isset( $context['contact_name'] ) ? trim( (string) $context['contact_name'] ) : '';
	$request_no  = isset( $context['service_request_number'] ) ? trim( (string) $context['service_request_number'] ) : '';
	$status      = isset( $context['status'] ) ? trim( (string) $context['status'] ) : 'Awaiting Review';
	$facility    = isset( $context['facility_name'] ) ? trim( (string) $context['facility_name'] ) : '';
	$equipment   = isset( $context['equipment'] ) ? trim( (string) $context['equipment'] ) : '';
	$serial      = isset( $context['serial_number'] ) ? trim( (string) $context['serial_number'] ) : '';
	$issue       = isset( $context['issue_description'] ) ? smti_st_clean_issue_for_email( $context['issue_description'] ) : '';

	$subject_ticket = $request_no !== '' ? $request_no : 'Your Ticket';
	$subject = 'SMTI Service Request Received - Ticket #' . $subject_ticket;

	$greeting_name = $name !== '' ? $name : 'there';
	$body_lines = array(
		'Hello ' . $greeting_name . ',',
		'',
		'Thank you for contacting SMTI.',
		'',
		'We have received your service request and created Ticket #' . $subject_ticket . '.',
		'',
		'Current Status:',
		$status !== '' ? $status : 'Awaiting Review',
		'',
		'Facility:',
		$facility !== '' ? $facility : 'Not provided',
		'',
		'Equipment:',
		$equipment !== '' ? $equipment : 'Not provided',
		'',
		'Serial Number:',
		$serial !== '' ? $serial : 'Not provided',
		'',
		'Issue Summary:',
		$issue !== '' ? $issue : 'Not provided',
		'',
		'An SMTI service representative will review your request and contact you if additional information is needed.',
		'',
		'Please do not reply to this email.',
		'',
		'Thank you,',
		'',
		'SMTI Service Team',
		'support@smti.co',
	);

	$headers = array(
		'From: SMTI Service Team <noreply@smti.co>',
		'Content-Type: text/plain; charset=UTF-8',
	);

	return wp_mail( $email, $subject, implode( "\n", $body_lines ), $headers );
}

// ---------------------------------------------------------------------------
// Endpoint: POST /create-service-ticket
// ---------------------------------------------------------------------------

function smti_st_create_ticket( WP_REST_Request $request ) {
	smti_st_send_cors_headers();

	$settings = smti_st_get_settings();

	if ( ! empty( $settings['recaptcha_secret_key'] ) ) {
		$captcha_token = (string) ( $request->get_param( 'captcha_token' ) ?: $request->get_param( 'g-recaptcha-response' ) );
		if ( ! smti_st_verify_recaptcha_token( $captcha_token, $settings['recaptcha_secret_key'] ) ) {
			return new WP_REST_Response( array(
				'success' => false,
				'message' => 'CAPTCHA verification failed. Please try again.',
			), 400 );
		}
	}

	$g = function( $key ) use ( $request ) {
		$val = $request->get_param( $key );
		return $val !== null ? sanitize_text_field( (string) $val ) : '';
	};

	$contact_name      = $g( 'contact_name' );
	$contact_email     = sanitize_email( (string) $request->get_param( 'contact_email' ) );
	$contact_phone     = $g( 'contact_phone' );
	$contact_id        = $g( 'contact_id' );
	$facility_name     = $g( 'facility_name' );
	$location_name     = $g( 'location_name' );
	$serial_number     = $g( 'serial_number' );
	$equipment_type    = $g( 'equipment_type' );
	$equipment_model   = $g( 'equipment_model' );
	$asset_name        = $g( 'asset_name' );
	$part_id           = $g( 'part_id' );
	$part_description  = $g( 'part_description' );
	$order_number      = $g( 'order_number' );
	$invoice_date      = $g( 'invoice_date_ship_date' );
	$smti_customer_id  = $g( 'smti_customer_id' );
	$smti_location_id  = $g( 'smti_location_id' );
	$smti_location_key = $g( 'smti_location_key' );
	$address1          = $g( 'address1' );
	$address2          = $g( 'address2' );
	$city              = $g( 'city' );
	$state             = $g( 'state' );
	$postal_code       = $g( 'postal_code' );
	$country           = $g( 'country' );
	$match_status      = $g( 'match_status' );
	$import_notes      = sanitize_textarea_field( (string) $request->get_param( 'import_notes' ) );
	$error_code        = $g( 'error_code' );
	$priority          = $g( 'priority' );
	$assigned_to       = $g( 'assigned_to' );
	$assigned_external = $g( 'assigned_external' );
	$issue_description = sanitize_textarea_field( (string) $request->get_param( 'issue_description' ) );
	$duplicate_action  = $g( 'duplicate_action' );
	$override_reason   = sanitize_textarea_field( (string) $request->get_param( 'override_reason' ) );
	$existing_ticket_id = $g( 'existing_ticket_id' );

	// Validation
	if ( empty( $contact_name ) )      return new WP_REST_Response( array( 'success' => false, 'message' => 'Contact Name is required.' ), 400 );
	if ( empty( $contact_email ) )     return new WP_REST_Response( array( 'success' => false, 'message' => 'Contact Email is required.' ), 400 );
	if ( empty( $part_id ) )           return new WP_REST_Response( array( 'success' => false, 'message' => 'Part ID is required.' ), 400 );
	if ( empty( $part_description ) )  return new WP_REST_Response( array( 'success' => false, 'message' => 'Part Description is required.' ), 400 );
	if ( empty( $issue_description ) ) return new WP_REST_Response( array( 'success' => false, 'message' => 'Issue Description is required.' ), 400 );


	$attachment_context = array(
		'contact_name'      => $contact_name,
		'contact_email'     => $contact_email,
		'contact_phone'     => $contact_phone,
		'facility_name'     => $facility_name,
		'location_name'     => $location_name,
		'address1'          => $address1,
		'address2'          => $address2,
		'city'              => $city,
		'state'             => $state,
		'postal_code'       => $postal_code,
		'country'           => $country,
		'serial_number'     => $serial_number,
		'asset_name'        => $asset_name,
		'model_number'      => $equipment_model,
		'equipment_model'   => $equipment_model,
		'part_id'           => $part_id,
		'part_description'  => $part_description,
		'order_number'      => $order_number,
		'error_code'        => $error_code !== '' ? $error_code : smti_st_extract_error_code_from_issue( $issue_description ),
		'issue_description' => $issue_description,
	);

	$company_properties = array(
		'smti_customer_id'        => $smti_customer_id,
		'smti_location_id'        => $smti_location_id,
		'smti_location_key'       => $smti_location_key,
		'smti_location_name'      => $location_name,
		'smti_shipping_address_1' => $address1,
		'smti_shipping_address_2' => $address2,
		'smti_shipping_city'      => $city,
		'smti_shipping_state'     => $state,
		'smti_shipping_zip'       => $postal_code,
		'smti_shipping_country'   => $country,
	);

	if ( smti_st_check_submission_cooldown( $serial_number, $contact_email, $issue_description, $duplicate_action ) ) {
		return new WP_REST_Response( array(
			'success' => false,
			'message' => 'This same service ticket submission was already received recently. Please wait a few minutes before submitting it again.',
			'cooldown_detected' => true,
		), 429 );
	}

	// Duplicate prevention: block another recent ticket unless the user explicitly chooses an action.
	$duplicate = smti_st_find_recent_duplicate_ticket( $serial_number, $contact_email );
	if ( ! empty( $duplicate['found'] ) ) {
		$target_ticket_id = ! empty( $existing_ticket_id ) ? $existing_ticket_id : $duplicate['ticket_id'];
		if ( $duplicate_action === 'update_existing' && ! empty( $target_ticket_id ) ) {
			$resolved_contact_id = '';
			if ( ! empty( $contact_id ) ) {
				$resolved_contact_id = $contact_id;
			} elseif ( ! empty( $contact_email ) ) {
				$resolved_contact_id = smti_st_find_or_create_contact( $contact_name, $contact_email, $contact_phone, $facility_name, $address1, $city, $state, $postal_code, $country );
			}

			$resolved_company_id = smti_st_find_or_create_company( $facility_name, $smti_customer_id, $company_properties );
			if ( ! empty( $resolved_company_id ) ) {
				smti_st_associate_default( 'tickets', $target_ticket_id, 'companies', $resolved_company_id );
				if ( ! empty( $resolved_contact_id ) ) {
					smti_st_associate_default( 'contacts', $resolved_contact_id, 'companies', $resolved_company_id );
				}
			}
			$update_lines = array(
				'UPDATE TO EXISTING SERVICE TICKET',
				str_repeat( '-', 40 ),
				'Existing Ticket ID: ' . $target_ticket_id,
				'Updated From: SMTI external service ticket form',
				'',
				'Contact: ' . $contact_name,
				'Email: ' . $contact_email,
				'Phone: ' . $contact_phone,
				'',
				'Facility / Company: ' . $facility_name,
				'Facility Address: ' . trim( $address1 . ' ' . $address2 . ' ' . $city . ' ' . $state . ' ' . $postal_code ),
				'Department / Room / Location: ' . $location_name,
				'',
				'Serial Number: ' . $serial_number,
				'Part ID: ' . $part_id,
				'Part Description: ' . $part_description,
				'Error Code / LED Lights: ' . ( $error_code !== '' ? $error_code : smti_st_extract_error_code_from_issue( $issue_description ) ),
				'',
				'New Issue / Update:',
				$issue_description,
			);
			if ( $override_reason !== '' ) {
				$update_lines[] = '';
				$update_lines[] = 'Reason / Notes:';
				$update_lines[] = $override_reason;
			}
			$note_id = smti_st_add_note_to_ticket( $target_ticket_id, implode( "\n", $update_lines ), $resolved_contact_id, $resolved_company_id );
			$files = $request->get_file_params();
			$attachment_note_id = '';
			if ( ! empty( $files['smti_attachments'] ) ) {
				$attachment_note_id = smti_st_handle_attachments( $files['smti_attachments'], $target_ticket_id, $resolved_contact_id, $attachment_context, $resolved_company_id );
			}
			smti_st_set_submission_cooldown( $serial_number, $contact_email, $issue_description, $duplicate_action );

			return new WP_REST_Response( array(
				'success'            => true,
				'updated_existing'   => true,
				'message'            => 'The existing service ticket was updated successfully.',
				'existing_ticket_id' => $target_ticket_id,
				'note_id'            => $note_id,
				'attachment_note_id' => $attachment_note_id,
				'contact_id'         => $resolved_contact_id,
				'company_id'         => $resolved_company_id,
			), 200 );
		}
		if ( $duplicate_action !== 'create_new' ) {
			return new WP_REST_Response( array(
				'success'            => false,
				'duplicate_detected' => true,
				'message'            => 'A recent service ticket already exists for this serial number. You can update the existing ticket or create a new ticket anyway.',
				'existing_ticket_id' => $duplicate['ticket_id'],
				'existing_subject'   => $duplicate['subject'],
				'existing_created'   => $duplicate['createdate'],
				'existing_ticket'    => $duplicate,
				'actions'            => array( 'update_existing', 'create_new' ),
			), 200 );
		}
	}

	// Build ticket subject
	$subject_parts  = array_filter( array( $facility_name, $serial_number ? 'SN:' . $serial_number : '', $part_id ) );
	$ticket_subject = 'Service Request' . ( $subject_parts ? ' — ' . implode( ' | ', $subject_parts ) : '' );

	// Build ticket body
	$lines = array(
		'SERVICE TICKET SUBMISSION',
		str_repeat( '-', 40 ),
		'',
		'CONTACT INFORMATION',
		'Name:               ' . $contact_name,
		'Email:              ' . $contact_email,
		'Phone:              ' . $contact_phone,
		'',
		'CUSTOMER / LOCATION',
		'Company:            ' . $facility_name,
		'Location Name:      ' . $location_name,
		'Customer ID:        ' . $smti_customer_id,
		'Location ID:        ' . $smti_location_id,
		'Location Key:       ' . $smti_location_key,
		'Address:            ' . trim( $address1 . ' ' . $address2 ),
		'City / State / Zip: ' . trim( $city . ', ' . $state . ' ' . $postal_code ),
		'Country:            ' . $country,
		'',
		'EQUIPMENT DETAILS',
		'Serial Number:      ' . $serial_number,
		'Asset Name:         ' . $asset_name,
		'Part ID:            ' . $part_id,
		'Part Description:   ' . $part_description,
		'Order Number:       ' . $order_number,
		'Invoice/Ship Date:  ' . $invoice_date,
		'Equipment Type:     ' . $equipment_type,
		'Equipment Model:    ' . $equipment_model,
		'Error Code / LED:   ' . ( $error_code !== '' ? $error_code : smti_st_extract_error_code_from_issue( $issue_description ) ),
		'Match Status:       ' . $match_status,
		'',
		'ISSUE DESCRIPTION',
		$issue_description,
	);

	if ( ! empty( $import_notes ) ) {
		$lines[] = '';
		$lines[] = 'IMPORT NOTES';
		$lines[] = $import_notes;
	}
	if ( ! empty( $assigned_external ) ) {
		$lines[] = '';
		$lines[] = 'Assigned External Tech: ' . $assigned_external;
	}

	if ( $duplicate_action === 'create_new' && ! empty( $duplicate['found'] ) ) {
		$lines[] = '';
		$lines[] = 'DUPLICATE OVERRIDE';
		$lines[] = 'Existing Ticket ID: ' . $duplicate['ticket_id'];
		$lines[] = 'Existing Subject: ' . $duplicate['subject'];
		if ( $override_reason !== '' ) {
			$lines[] = 'Override Reason: ' . $override_reason;
		}
	}

	$ticket_body = implode( "\n", $lines );

	// Priority mapping
	$priority_map = array( 'low' => 'LOW', 'normal' => 'MEDIUM', 'high' => 'HIGH', 'urgent' => 'HIGH' );
	$hs_priority  = isset( $priority_map[ $priority ] ) ? $priority_map[ $priority ] : 'MEDIUM';

	$ticket_props = array(
		'subject'            => $ticket_subject,
		'content'            => $ticket_body,
		'hs_pipeline'        => $settings['ticket_pipeline_id'],
		'hs_pipeline_stage'  => $settings['ticket_stage_id'],
		'hs_ticket_priority' => $hs_priority,
	);
	if ( ! empty( $assigned_to ) ) {
		$ticket_props['hubspot_owner_id'] = $assigned_to;
	}

	// Create the HubSpot ticket
	$ticket_response = smti_st_hs_request( 'POST', '/crm/v3/objects/tickets', array( 'properties' => $ticket_props ) );

	if ( is_wp_error( $ticket_response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $ticket_response->get_error_message() ), 500 );
	}
	if ( (int) $ticket_response['status'] !== 201 || empty( $ticket_response['body']['id'] ) ) {
		return new WP_REST_Response( array(
			'success' => false,
			'message' => 'HubSpot rejected the ticket creation request.',
			'hubspot' => $ticket_response['body'],
		), 500 );
	}

	$ticket_id              = (string) $ticket_response['body']['id'];
	$service_request_number = 'SR-' . gmdate( 'Y' ) . '-' . str_pad( substr( preg_replace( '/\D/', '', $ticket_id ), -6 ), 6, '0', STR_PAD_LEFT );

	// Resolve or create contact
	$resolved_contact_id = '';
	if ( ! empty( $contact_id ) ) {
		$resolved_contact_id = $contact_id;
	} elseif ( ! empty( $contact_email ) ) {
		$resolved_contact_id = smti_st_find_or_create_contact(
			$contact_name, $contact_email, $contact_phone,
			$facility_name, $address1, $city, $state, $postal_code, $country
		);
	}

	// Resolve or create company and associate ticket/contact ↔ company.
	$resolved_company_id = smti_st_find_or_create_company( $facility_name, $smti_customer_id, $company_properties );

	// Associate ticket ↔ contact
	if ( ! empty( $resolved_contact_id ) ) {
		smti_st_hs_request( 'PUT',
			'/crm/v3/objects/tickets/' . rawurlencode( $ticket_id ) .
			'/associations/contacts/' . rawurlencode( $resolved_contact_id ) . '/ticket_to_contact'
		);
	}

	if ( ! empty( $resolved_company_id ) ) {
		smti_st_associate_default( 'tickets', $ticket_id, 'companies', $resolved_company_id );
		if ( ! empty( $resolved_contact_id ) ) {
			smti_st_associate_default( 'contacts', $resolved_contact_id, 'companies', $resolved_company_id );
		}
	}

	// Create the service request note and handle attachments.
	// This intentionally runs for every ticket, even when no files are uploaded,
	// so the HubSpot activity timeline always contains the full service request details.
	$files              = $request->get_file_params();
	$attachment_note_id = smti_st_handle_attachments(
		! empty( $files['smti_attachments'] ) ? $files['smti_attachments'] : array(),
		$ticket_id,
		$resolved_contact_id,
		$attachment_context,
		$resolved_company_id
	);

	smti_st_set_submission_cooldown( $serial_number, $contact_email, $issue_description, $duplicate_action );

	$stage_map = function_exists( 'smti_st_dashboard_stage_map' ) ? smti_st_dashboard_stage_map() : array();
	$status_label = isset( $stage_map[ $settings['ticket_stage_id'] ] ) ? $stage_map[ $settings['ticket_stage_id'] ] : 'Awaiting Review';
	$email_sent = smti_st_send_customer_confirmation_email( array(
		'contact_name'           => $contact_name,
		'contact_email'          => $contact_email,
		'service_request_number' => $service_request_number,
		'status'                 => $status_label,
		'facility_name'          => $facility_name,
		'equipment'              => $equipment_model !== '' ? $equipment_model : $part_description,
		'serial_number'          => $serial_number,
		'issue_description'      => $issue_description,
	) );

	return new WP_REST_Response( array(
		'success'                => true,
		'message'                => 'Service ticket created successfully.',
		'ticket_id'              => $ticket_id,
		'service_request_number' => $service_request_number,
		'contact_id'             => $resolved_contact_id,
		'company_id'             => $resolved_company_id,
		'attachment_note_id'     => $attachment_note_id,
		'confirmation_email_sent' => (bool) $email_sent,
	), 200 );
}

// ---------------------------------------------------------------------------
// Companies: find/create and associate to ticket/contact
// ---------------------------------------------------------------------------

function smti_st_associate_default( $from_type, $from_id, $to_type, $to_id ) {
	$from_id = trim( (string) $from_id );
	$to_id   = trim( (string) $to_id );
	if ( $from_id === '' || $to_id === '' ) return false;

	$response = smti_st_hs_request(
		'PUT',
		'/crm/v4/objects/' . rawurlencode( $from_type ) . '/' . rawurlencode( $from_id ) .
		'/associations/default/' . rawurlencode( $to_type ) . '/' . rawurlencode( $to_id )
	);

	return ! is_wp_error( $response ) && (int) $response['status'] >= 200 && (int) $response['status'] < 300;
}

function smti_st_find_or_create_company( $company_name, $smti_customer_id = '', $properties = array() ) {
	$company_name     = trim( (string) $company_name );
	$smti_customer_id = trim( (string) $smti_customer_id );

	if ( $company_name === '' && $smti_customer_id === '' ) {
		return '';
	}

	// First try exact SMTI Customer ID when available.
	if ( $smti_customer_id !== '' ) {
		$search = smti_st_hs_request( 'POST', '/crm/v3/objects/companies/search', array(
			'filterGroups' => array( array( 'filters' => array( array(
				'propertyName' => 'smti_customer_id',
				'operator'     => 'EQ',
				'value'        => $smti_customer_id,
			) ) ) ),
			'properties' => array( 'name', 'smti_customer_id' ),
			'limit'      => 1,
		) );

		if ( ! is_wp_error( $search ) && (int) $search['status'] === 200 && ! empty( $search['body']['results'][0]['id'] ) ) {
			$company_id = (string) $search['body']['results'][0]['id'];
			smti_st_update_company( $company_id, $properties );
			return $company_id;
		}
	}

	// Fallback to exact company/facility name.
	if ( $company_name !== '' ) {
		$search = smti_st_hs_request( 'POST', '/crm/v3/objects/companies/search', array(
			'filterGroups' => array( array( 'filters' => array( array(
				'propertyName' => 'name',
				'operator'     => 'EQ',
				'value'        => $company_name,
			) ) ) ),
			'properties' => array( 'name' ),
			'limit'      => 1,
		) );

		if ( ! is_wp_error( $search ) && (int) $search['status'] === 200 && ! empty( $search['body']['results'][0]['id'] ) ) {
			$company_id = (string) $search['body']['results'][0]['id'];
			smti_st_update_company( $company_id, $properties );
			return $company_id;
		}
	}

	if ( $company_name === '' ) {
		return '';
	}

	$create_props = array_filter( array_merge( array( 'name' => $company_name ), $properties ), function( $value ) {
		return $value !== null && $value !== '';
	} );

	$create = smti_st_hs_request( 'POST', '/crm/v3/objects/companies', array( 'properties' => $create_props ) );

	if ( ! is_wp_error( $create ) && (int) $create['status'] === 201 && ! empty( $create['body']['id'] ) ) {
		return (string) $create['body']['id'];
	}

	// If custom properties caused a create failure, retry with only the standard name property.
	$create = smti_st_hs_request( 'POST', '/crm/v3/objects/companies', array(
		'properties' => array( 'name' => $company_name ),
	) );

	if ( ! is_wp_error( $create ) && (int) $create['status'] === 201 && ! empty( $create['body']['id'] ) ) {
		return (string) $create['body']['id'];
	}

	return '';
}

function smti_st_update_company( $company_id, $properties ) {
	$company_id = trim( (string) $company_id );
	if ( $company_id === '' || empty( $properties ) || ! is_array( $properties ) ) return false;

	$properties = array_filter( $properties, function( $value ) {
		return $value !== null && $value !== '';
	} );
	if ( empty( $properties ) ) return false;

	$response = smti_st_hs_request( 'PATCH', '/crm/v3/objects/companies/' . rawurlencode( $company_id ), array(
		'properties' => $properties,
	) );

	return ! is_wp_error( $response ) && (int) $response['status'] >= 200 && (int) $response['status'] < 300;
}

// ---------------------------------------------------------------------------
// Contact: find by email or create
// ---------------------------------------------------------------------------

function smti_st_find_or_create_contact( $name, $email, $phone, $company, $address, $city, $state, $zip, $country ) {
	// Search for existing contact by email
	$search = smti_st_hs_request( 'POST', '/crm/v3/objects/contacts/search', array(
		'filterGroups' => array( array( 'filters' => array( array(
			'propertyName' => 'email',
			'operator'     => 'EQ',
			'value'        => $email,
		) ) ) ),
		'properties' => array( 'email', 'firstname', 'lastname' ),
		'limit'      => 1,
	) );

	if ( ! is_wp_error( $search ) && (int) $search['status'] === 200 && ! empty( $search['body']['results'][0]['id'] ) ) {
		return (string) $search['body']['results'][0]['id'];
	}

	// Create new contact
	$parts     = explode( ' ', trim( $name ), 2 );
	$firstname = $parts[0];
	$lastname  = isset( $parts[1] ) ? $parts[1] : '';

	$properties = array_filter( array(
		'firstname' => $firstname,
		'lastname'  => $lastname,
		'email'     => $email,
		'phone'     => $phone,
		'company'   => $company,
		'address'   => $address,
		'city'      => $city,
		'state'     => $state,
		'zip'       => $zip,
		'country'   => $country,
	) );

	$create = smti_st_hs_request( 'POST', '/crm/v3/objects/contacts', array( 'properties' => $properties ) );

	if ( ! is_wp_error( $create ) && (int) $create['status'] === 201 && ! empty( $create['body']['id'] ) ) {
		return (string) $create['body']['id'];
	}

	return '';
}


function smti_st_extract_error_code_from_issue( $issue_description ) {
	$issue_description = (string) $issue_description;
	if ( preg_match( '/Error Code \/ Error Lights:\s*(.+)/i', $issue_description, $matches ) ) {
		$value = trim( $matches[1] );
		return $value !== '' ? $value : '';
	}
	return '';
}

function smti_st_context_value( $context, $key ) {
	if ( ! is_array( $context ) || ! isset( $context[ $key ] ) ) {
		return '';
	}
	return trim( (string) $context[ $key ] );
}

// ---------------------------------------------------------------------------
// Attachments: log file names as a note on the ticket
// ---------------------------------------------------------------------------

function smti_st_handle_attachments( $files, $ticket_id, $contact_id, $context = array(), $company_id = '' ) {
	$uploaded_files = array();
	$failed_files   = array();

	if ( isset( $files['name'] ) && is_array( $files['name'] ) ) {
		foreach ( $files['name'] as $i => $name ) {
			if ( empty( $name ) || ! isset( $files['error'][ $i ] ) || $files['error'][ $i ] !== UPLOAD_ERR_OK ) {
				continue;
			}

			$result = smti_st_upload_one_file_to_hubspot(
				$files['tmp_name'][ $i ],
				$files['name'][ $i ],
				$files['type'][ $i ] ?? ''
			);

			if ( ! empty( $result['success'] ) ) {
				$uploaded_files[] = $result;
			} else {
				$failed_files[] = sanitize_file_name( $files['name'][ $i ] ) . ' — ' . ( $result['message'] ?? 'Upload failed' );
			}
		}
	} elseif ( isset( $files['name'] ) && isset( $files['error'] ) && $files['error'] === UPLOAD_ERR_OK ) {
		$result = smti_st_upload_one_file_to_hubspot( $files['tmp_name'], $files['name'], $files['type'] ?? '' );
		if ( ! empty( $result['success'] ) ) {
			$uploaded_files[] = $result;
		} else {
			$failed_files[] = sanitize_file_name( $files['name'] ) . ' — ' . ( $result['message'] ?? 'Upload failed' );
		}
	}

	// Continue even when there are no uploaded files.
	// The note is used as the structured service request record in HubSpot.
	$file_ids = array();
	$note_lines = array(
		'SERVICE REQUEST DETAILS / ATTACHMENTS',
		str_repeat( '-', 40 ),
		'Facility / Company: ' . smti_st_context_value( $context, 'facility_name' ),
		'Department / Room / Location: ' . smti_st_context_value( $context, 'location_name' ),
		'Facility Address: ' . trim( smti_st_context_value( $context, 'address1' ) . ' ' . smti_st_context_value( $context, 'address2' ) ),
		'City / State / Zip: ' . trim( smti_st_context_value( $context, 'city' ) . ', ' . smti_st_context_value( $context, 'state' ) . ' ' . smti_st_context_value( $context, 'postal_code' ) ),
		'Contact: ' . smti_st_context_value( $context, 'contact_name' ),
		'Email: ' . smti_st_context_value( $context, 'contact_email' ),
		'Phone: ' . smti_st_context_value( $context, 'contact_phone' ),
		'',
		'EQUIPMENT',
		'Serial Number: ' . smti_st_context_value( $context, 'serial_number' ),
		'Model Number: ' . smti_st_context_value( $context, 'model_number' ),
		'Asset Name: ' . smti_st_context_value( $context, 'asset_name' ),
		'Part ID: ' . smti_st_context_value( $context, 'part_id' ),
		'Part Description: ' . smti_st_context_value( $context, 'part_description' ),
		'Order Number: ' . smti_st_context_value( $context, 'order_number' ),
		'',
		'ERROR / LED LIGHTS',
		smti_st_context_value( $context, 'error_code' ),
		'',
		'ISSUE DESCRIPTION',
		smti_st_context_value( $context, 'issue_description' ),
		'',
		'ATTACHMENTS',
	);

	if ( empty( $uploaded_files ) && empty( $failed_files ) ) {
		$note_lines[] = 'No attachments submitted.';
	}

	foreach ( $uploaded_files as $file ) {
		$file_ids[] = (string) $file['id'];
		$line = $file['name'] . ' — HubSpot File ID: ' . $file['id'];
		if ( ! empty( $file['url'] ) ) {
			$line .= ' — ' . $file['url'];
		}
		$note_lines[] = $line;
	}

	if ( ! empty( $failed_files ) ) {
		$note_lines[] = '';
		$note_lines[] = 'Files that could not be uploaded:';
		foreach ( $failed_files as $failed ) {
			$note_lines[] = $failed;
		}
	}

	$note_props = array(
		'hs_note_body' => nl2br( esc_html( implode( "\n", $note_lines ) ) ),
		'hs_timestamp' => gmdate( 'c' ),
	);

	if ( ! empty( $file_ids ) ) {
		$note_props['hs_attachment_ids'] = implode( ';', $file_ids );
	}

	$note_payload = array(
		'properties' => $note_props,
		'associations' => array(
			array(
				'to' => array( 'id' => $ticket_id ),
				'types' => array(
					array(
						'associationCategory' => 'HUBSPOT_DEFINED',
						'associationTypeId' => 228, // note_to_ticket
					),
				),
			),
		),
	);

	if ( ! empty( $contact_id ) ) {
		$note_payload['associations'][] = array(
			'to' => array( 'id' => $contact_id ),
			'types' => array(
				array(
					'associationCategory' => 'HUBSPOT_DEFINED',
					'associationTypeId' => 202, // note_to_contact
				),
			),
		);
	}

	if ( ! empty( $company_id ) ) {
		$note_payload['associations'][] = array(
			'to' => array( 'id' => $company_id ),
			'types' => array(
				array(
					'associationCategory' => 'HUBSPOT_DEFINED',
					'associationTypeId' => 190, // note_to_company
				),
			),
		);
	}

	$note_response = smti_st_hs_request( 'POST', '/crm/v3/objects/notes', $note_payload );

	if ( is_wp_error( $note_response ) || (int) $note_response['status'] !== 201 || empty( $note_response['body']['id'] ) ) {
		return '';
	}

	$note_id = $note_response['body']['id'];

	// Extra fallback associations. If inline associations already worked, these are harmless.
	smti_st_hs_request( 'PUT',
		'/crm/v3/objects/notes/' . rawurlencode( $note_id ) .
		'/associations/tickets/' . rawurlencode( $ticket_id ) . '/228'
	);

	smti_st_hs_request( 'PUT',
		'/crm/v3/objects/notes/' . rawurlencode( $note_id ) .
		'/associations/tickets/' . rawurlencode( $ticket_id ) . '/note_to_ticket'
	);

	if ( ! empty( $contact_id ) ) {
		smti_st_hs_request( 'PUT',
			'/crm/v3/objects/notes/' . rawurlencode( $note_id ) .
			'/associations/contacts/' . rawurlencode( $contact_id ) . '/202'
		);

		smti_st_hs_request( 'PUT',
			'/crm/v3/objects/notes/' . rawurlencode( $note_id ) .
			'/associations/contacts/' . rawurlencode( $contact_id ) . '/note_to_contact'
		);
	}

	if ( ! empty( $company_id ) ) {
		smti_st_hs_request( 'PUT',
			'/crm/v3/objects/notes/' . rawurlencode( $note_id ) .
			'/associations/companies/' . rawurlencode( $company_id ) . '/190'
		);

		smti_st_hs_request( 'PUT',
			'/crm/v3/objects/notes/' . rawurlencode( $note_id ) .
			'/associations/companies/' . rawurlencode( $company_id ) . '/note_to_company'
		);
	}

	return $note_id;
}
// ---------------------------------------------------------------------------
// Dashboard API v1.1.7.5
// Secure read-only endpoints for a HubSpot-hosted service dashboard.
// ---------------------------------------------------------------------------

function smti_st_dashboard_origin_ok() {
	smti_st_send_cors_headers();
	$settings = smti_st_get_settings();
	$allowed_origin = trim( (string) $settings['allowed_origin'] );
	if ( $allowed_origin === '' ) {
		return true;
	}
	$origin  = isset( $_SERVER['HTTP_ORIGIN'] )  ? trim( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) )  : '';
	$referer = isset( $_SERVER['HTTP_REFERER'] ) ? trim( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
	return ( $origin && stripos( $origin, $allowed_origin ) === 0 ) || ( $referer && stripos( $referer, $allowed_origin ) === 0 );
}

function smti_st_dashboard_token_key( $token ) {
	return 'smti_dash_' . md5( (string) $token );
}

function smti_st_dashboard_login( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	if ( ! smti_st_dashboard_origin_ok() ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Origin not allowed.' ), 403 );
	}

	$settings = smti_st_get_settings();
	$hash = isset( $settings['dashboard_pin_hash'] ) ? (string) $settings['dashboard_pin_hash'] : '';
	if ( $hash === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Dashboard PIN is not configured.' ), 500 );
	}

	$params = $request->get_json_params();
	if ( ! is_array( $params ) ) {
		$params = $request->get_params();
	}
	$pin = isset( $params['pin'] ) ? preg_replace( '/\D/', '', (string) $params['pin'] ) : '';
	if ( strlen( $pin ) !== 6 || ! wp_check_password( $pin, $hash ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Invalid PIN.' ), 403 );
	}

	$token = wp_generate_password( 48, false, false );
	set_transient( smti_st_dashboard_token_key( $token ), array( 'created' => time() ), 8 * HOUR_IN_SECONDS );

	return new WP_REST_Response( array(
		'success'    => true,
		'token'      => $token,
		'expires_in' => 8 * HOUR_IN_SECONDS,
	), 200 );
}

function smti_st_dashboard_permission_callback() {
	smti_st_send_cors_headers();
	if ( ! smti_st_dashboard_origin_ok() ) {
		return new WP_Error( 'smti_bad_origin', 'Origin not allowed.', array( 'status' => 403 ) );
	}
	$token = smti_st_get_header( 'X-SMTI-Dashboard-Token' );
	if ( $token === '' || ! get_transient( smti_st_dashboard_token_key( $token ) ) ) {
		return new WP_Error( 'smti_dashboard_forbidden', 'Invalid or expired dashboard session.', array( 'status' => 403 ) );
	}
	return true;
}

function smti_st_dashboard_stage_map() {
	$settings = smti_st_get_settings();
	$pipeline = trim( (string) $settings['ticket_pipeline_id'] );
	if ( $pipeline === '' ) return array();
	$response = smti_st_hs_request( 'GET', '/crm/v3/pipelines/tickets/' . rawurlencode( $pipeline ) );
	if ( is_wp_error( $response ) || (int) $response['status'] !== 200 || empty( $response['body']['stages'] ) ) {
		return array();
	}
	$map = array();
	foreach ( $response['body']['stages'] as $stage ) {
		if ( ! empty( $stage['id'] ) ) {
			$map[ (string) $stage['id'] ] = isset( $stage['label'] ) ? (string) $stage['label'] : (string) $stage['id'];
		}
	}
	return $map;
}

function smti_st_dashboard_ticket_summary_from_hubspot( $ticket, $stage_map = array() ) {
	$props = isset( $ticket['properties'] ) && is_array( $ticket['properties'] ) ? $ticket['properties'] : array();
	$content = isset( $props['content'] ) ? (string) $props['content'] : '';
	$stage_id = smti_st_prop_value( $props, array( 'hs_pipeline_stage' ) );
	return array(
		'ticket_id'              => isset( $ticket['id'] ) ? (string) $ticket['id'] : '',
		'subject'                => smti_st_prop_value( $props, array( 'subject' ) ),
		'service_request_number' => smti_st_prop_value( $props, array( 'smti_service_request_number' ) ),
		'stage_id'               => $stage_id,
		'status'                 => isset( $stage_map[ $stage_id ] ) ? $stage_map[ $stage_id ] : $stage_id,
		'createdate'             => smti_st_prop_value( $props, array( 'createdate' ) ),
		'lastmodifieddate'       => smti_st_prop_value( $props, array( 'hs_lastmodifieddate' ) ),
		'company'                => smti_st_prop_value( $props, array( 'smti_facility_name' ), smti_st_extract_ticket_body_value( $content, 'Company' ) ),
		'contact_name'           => smti_st_prop_value( $props, array( 'smti_contact_name' ), smti_st_extract_ticket_body_value( $content, 'Name' ) ),
		'contact_email'          => smti_st_prop_value( $props, array( 'smti_contact_email' ), smti_st_extract_ticket_body_value( $content, 'Email' ) ),
		'contact_phone'          => smti_st_prop_value( $props, array( 'smti_contact_phone' ), smti_st_extract_ticket_body_value( $content, 'Phone' ) ),
		'location_name'          => smti_st_prop_value( $props, array( 'smti_location_name' ), smti_st_extract_ticket_body_value( $content, 'Location Name' ) ),
		'serial_number'          => smti_st_prop_value( $props, array( 'smti_serial_number' ), smti_st_extract_ticket_body_value( $content, 'Serial Number' ) ),
		'equipment_model'        => smti_st_prop_value( $props, array( 'smti_equipment_model' ), smti_st_extract_ticket_body_value( $content, 'Equipment Model' ) ),
		'part_id'                => smti_st_prop_value( $props, array( 'smti_part_id', 'smti_equipment_type' ), smti_st_extract_ticket_body_value( $content, 'Part ID' ) ),
		'issue_summary'          => wp_trim_words( wp_strip_all_tags( smti_st_prop_value( $props, array( 'smti_issue_description' ), smti_st_extract_issue_description_from_ticket_body( $content ) ) ), 22, '…' ),
	);
}

function smti_st_dashboard_ticket_properties() {
	return array(
		'subject',
		'content',
		'createdate',
		'hs_lastmodifieddate',
		'hs_pipeline',
		'hs_pipeline_stage',
		'smti_service_request_number',
		'smti_contact_name',
		'smti_contact_email',
		'smti_contact_phone',
		'smti_facility_name',
		'smti_location_name',
		'smti_serial_number',
		'smti_equipment_type',
		'smti_equipment_model',
		'smti_issue_description',
		'smti_part_id',
		'smti_order_number',
		'smti_customer_id',
	);
}

function smti_st_dashboard_tickets( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$settings = smti_st_get_settings();
	$pipeline = trim( (string) $settings['ticket_pipeline_id'] );
	$status   = trim( sanitize_text_field( (string) $request->get_param( 'status' ) ) );
	$query    = trim( sanitize_text_field( (string) $request->get_param( 'q' ) ) );
	$limit    = min( 100, max( 1, (int) ( $request->get_param( 'limit' ) ?: 50 ) ) );

	$filters = array();
	if ( $pipeline !== '' ) {
		$filters[] = array( 'propertyName' => 'hs_pipeline', 'operator' => 'EQ', 'value' => $pipeline );
	}
	if ( $status !== '' && strtolower( $status ) !== 'all' ) {
		$filters[] = array( 'propertyName' => 'hs_pipeline_stage', 'operator' => 'EQ', 'value' => $status );
	}

	$search_body = array(
		'properties' => smti_st_dashboard_ticket_properties(),
		'sorts'      => array( '-createdate' ),
		'limit'      => $limit,
	);
	if ( ! empty( $filters ) ) {
		$search_body['filterGroups'] = array( array( 'filters' => $filters ) );
	}
	if ( $query !== '' ) {
		$search_body['query'] = $query;
	}

	$response = smti_st_hs_request( 'POST', '/crm/v3/objects/tickets/search', $search_body );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] !== 200 ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'HubSpot ticket search failed.', 'hubspot' => $response['body'] ), 500 );
	}

	$stage_map = smti_st_dashboard_stage_map();
	$tickets = array();
	foreach ( (array) ( $response['body']['results'] ?? array() ) as $ticket ) {
		$tickets[] = smti_st_dashboard_ticket_summary_from_hubspot( $ticket, $stage_map );
	}

	return new WP_REST_Response( array(
		'success' => true,
		'tickets' => $tickets,
		'stages'  => $stage_map,
		'total'   => isset( $response['body']['total'] ) ? (int) $response['body']['total'] : count( $tickets ),
	), 200 );
}

function smti_st_dashboard_associated_ids( $from_type, $from_id, $to_type ) {
	$response = smti_st_hs_request( 'GET', '/crm/v4/objects/' . rawurlencode( $from_type ) . '/' . rawurlencode( $from_id ) . '/associations/' . rawurlencode( $to_type ) . '?limit=100' );
	if ( is_wp_error( $response ) || (int) $response['status'] !== 200 || empty( $response['body']['results'] ) ) return array();
	$ids = array();
	foreach ( $response['body']['results'] as $row ) {
		if ( isset( $row['toObjectId'] ) ) $ids[] = (string) $row['toObjectId'];
	}
	return array_values( array_unique( $ids ) );
}

function smti_st_dashboard_get_object( $type, $id, $properties ) {
	$id = trim( (string) $id );
	if ( $id === '' ) return array();
	$response = smti_st_hs_request( 'GET', '/crm/v3/objects/' . rawurlencode( $type ) . '/' . rawurlencode( $id ) . '?properties=' . rawurlencode( implode( ',', $properties ) ) );
	if ( is_wp_error( $response ) || (int) $response['status'] !== 200 || empty( $response['body'] ) ) return array();
	return $response['body'];
}

function smti_st_dashboard_ticket_detail( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$ticket_id = trim( sanitize_text_field( (string) $request->get_param( 'id' ) ) );
	if ( $ticket_id === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Ticket ID is required.' ), 400 );
	}

	$response = smti_st_hs_request( 'GET', '/crm/v3/objects/tickets/' . rawurlencode( $ticket_id ) . '?properties=' . rawurlencode( implode( ',', smti_st_dashboard_ticket_properties() ) ) );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] !== 200 || empty( $response['body'] ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Ticket not found.', 'hubspot' => $response['body'] ), 404 );
	}

	$stage_map = smti_st_dashboard_stage_map();
	$ticket = smti_st_dashboard_ticket_summary_from_hubspot( $response['body'], $stage_map );
	$ticket['content'] = $response['body']['properties']['content'] ?? '';

	$contact_ids = smti_st_dashboard_associated_ids( 'tickets', $ticket_id, 'contacts' );
	$company_ids = smti_st_dashboard_associated_ids( 'tickets', $ticket_id, 'companies' );
	$note_ids    = smti_st_dashboard_associated_ids( 'tickets', $ticket_id, 'notes' );

	$contacts = array();
	foreach ( array_slice( $contact_ids, 0, 5 ) as $cid ) {
		$obj = smti_st_dashboard_get_object( 'contacts', $cid, array( 'firstname', 'lastname', 'email', 'phone', 'company' ) );
		if ( ! empty( $obj ) ) $contacts[] = $obj;
	}

	$companies = array();
	foreach ( array_slice( $company_ids, 0, 5 ) as $coid ) {
		$obj = smti_st_dashboard_get_object( 'companies', $coid, array( 'name', 'phone', 'domain', 'city', 'state', 'zip', 'smti_customer_id' ) );
		if ( ! empty( $obj ) ) $companies[] = $obj;
	}

	$notes = array();
	foreach ( array_slice( $note_ids, 0, 10 ) as $nid ) {
		$obj = smti_st_dashboard_get_object( 'notes', $nid, array( 'hs_note_body', 'hs_timestamp', 'hs_attachment_ids' ) );
		if ( ! empty( $obj ) ) $notes[] = $obj;
	}

	return new WP_REST_Response( array(
		'success'   => true,
		'ticket'    => $ticket,
		'contacts'  => $contacts,
		'companies' => $companies,
		'notes'     => $notes,
		'stages'    => $stage_map,
	), 200 );
}


// ---------------------------------------------------------------------------
// Dashboard API v1.1.7.6 actions and metrics
// Adds safe ticket updates for the HubSpot-hosted dashboard.
// ---------------------------------------------------------------------------

function smti_st_dashboard_get_params( WP_REST_Request $request ) {
	$params = $request->get_json_params();
	if ( ! is_array( $params ) ) {
		$params = $request->get_params();
	}
	return is_array( $params ) ? $params : array();
}

function smti_st_dashboard_update_stage( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$ticket_id = trim( sanitize_text_field( (string) $request->get_param( 'id' ) ) );
	$params = smti_st_dashboard_get_params( $request );
	$stage_id = isset( $params['stage_id'] ) ? trim( sanitize_text_field( (string) $params['stage_id'] ) ) : '';
	if ( $ticket_id === '' || $stage_id === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Ticket ID and stage are required.' ), 400 );
	}

	$stage_map = smti_st_dashboard_stage_map();
	if ( ! empty( $stage_map ) && ! isset( $stage_map[ $stage_id ] ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Invalid ticket stage.' ), 400 );
	}

	$response = smti_st_hs_request( 'PATCH', '/crm/v3/objects/tickets/' . rawurlencode( $ticket_id ), array(
		'properties' => array( 'hs_pipeline_stage' => $stage_id ),
	) );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] < 200 || (int) $response['status'] >= 300 ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'HubSpot stage update failed.', 'hubspot' => $response['body'] ), 500 );
	}

	$label = isset( $stage_map[ $stage_id ] ) ? $stage_map[ $stage_id ] : $stage_id;
	smti_st_add_note_to_ticket( $ticket_id, 'Dashboard update: ticket status changed to ' . $label . '.' );

	return new WP_REST_Response( array( 'success' => true, 'stage_id' => $stage_id, 'status' => $label ), 200 );
}

function smti_st_dashboard_add_note( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$ticket_id = trim( sanitize_text_field( (string) $request->get_param( 'id' ) ) );
	$params = smti_st_dashboard_get_params( $request );
	$note = isset( $params['note'] ) ? trim( wp_strip_all_tags( (string) $params['note'] ) ) : '';
	if ( $ticket_id === '' || $note === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Ticket ID and note are required.' ), 400 );
	}
	$contact_ids = smti_st_dashboard_associated_ids( 'tickets', $ticket_id, 'contacts' );
	$company_ids = smti_st_dashboard_associated_ids( 'tickets', $ticket_id, 'companies' );
	$body = "Dashboard note:\n" . $note;
	$note_id = smti_st_add_note_to_ticket( $ticket_id, $body, $contact_ids[0] ?? '', $company_ids[0] ?? '' );
	if ( $note_id === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Could not create HubSpot note.' ), 500 );
	}
	return new WP_REST_Response( array( 'success' => true, 'note_id' => $note_id ), 200 );
}

function smti_st_dashboard_assign_owner( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$ticket_id = trim( sanitize_text_field( (string) $request->get_param( 'id' ) ) );
	$params = smti_st_dashboard_get_params( $request );
	$owner_id = isset( $params['owner_id'] ) ? preg_replace( '/[^0-9]/', '', (string) $params['owner_id'] ) : '';
	if ( $ticket_id === '' || $owner_id === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Ticket ID and owner are required.' ), 400 );
	}
	$response = smti_st_hs_request( 'PATCH', '/crm/v3/objects/tickets/' . rawurlencode( $ticket_id ), array(
		'properties' => array( 'hubspot_owner_id' => $owner_id ),
	) );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] < 200 || (int) $response['status'] >= 300 ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'HubSpot owner assignment failed.', 'hubspot' => $response['body'] ), 500 );
	}
	smti_st_add_note_to_ticket( $ticket_id, 'Dashboard update: ticket assigned to HubSpot owner ID ' . $owner_id . '.' );
	return new WP_REST_Response( array( 'success' => true, 'owner_id' => $owner_id ), 200 );
}

function smti_st_dashboard_owners( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$response = smti_st_hs_request( 'GET', '/crm/v3/owners/?limit=100&archived=false' );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'owners' => array(), 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] !== 200 || empty( $response['body']['results'] ) ) {
		return new WP_REST_Response( array( 'success' => true, 'owners' => array() ), 200 );
	}
	$owners = array();
	foreach ( $response['body']['results'] as $owner ) {
		$id = isset( $owner['id'] ) ? (string) $owner['id'] : '';
		$email = isset( $owner['email'] ) ? (string) $owner['email'] : '';
		$name = trim( ( $owner['firstName'] ?? '' ) . ' ' . ( $owner['lastName'] ?? '' ) );
		if ( $name === '' ) $name = $email;
		if ( $id !== '' ) $owners[] = array( 'id' => $id, 'label' => $name, 'email' => $email );
	}
	return new WP_REST_Response( array( 'success' => true, 'owners' => $owners ), 200 );
}

function smti_st_dashboard_metrics( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	$settings = smti_st_get_settings();
	$pipeline = trim( (string) $settings['ticket_pipeline_id'] );
	$stage_map = smti_st_dashboard_stage_map();
	$search_body = array(
		'properties' => array( 'hs_pipeline_stage', 'createdate', 'hs_lastmodifieddate' ),
		'sorts' => array( '-createdate' ),
		'limit' => 100,
	);
	if ( $pipeline !== '' ) {
		$search_body['filterGroups'] = array( array( 'filters' => array( array( 'propertyName' => 'hs_pipeline', 'operator' => 'EQ', 'value' => $pipeline ) ) ) );
	}
	$response = smti_st_hs_request( 'POST', '/crm/v3/objects/tickets/search', $search_body );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] !== 200 ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'HubSpot metrics search failed.', 'hubspot' => $response['body'] ), 500 );
	}
	$by_stage = array();
	foreach ( (array) ( $response['body']['results'] ?? array() ) as $ticket ) {
		$stage_id = $ticket['properties']['hs_pipeline_stage'] ?? '';
		$label = isset( $stage_map[ $stage_id ] ) ? $stage_map[ $stage_id ] : $stage_id;
		if ( ! isset( $by_stage[ $stage_id ] ) ) $by_stage[ $stage_id ] = array( 'stage_id' => $stage_id, 'label' => $label, 'count' => 0 );
		$by_stage[ $stage_id ]['count']++;
	}
	return new WP_REST_Response( array(
		'success' => true,
		'total' => isset( $response['body']['total'] ) ? (int) $response['body']['total'] : count( $response['body']['results'] ?? array() ),
		'by_stage' => array_values( $by_stage ),
		'stages' => $stage_map,
	), 200 );
}

function smti_st_customer_ticket_status( WP_REST_Request $request ) {
	smti_st_send_cors_headers();
	if ( ! smti_st_dashboard_origin_ok() ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Origin not allowed.' ), 403 );
	}
	$params = smti_st_dashboard_get_params( $request );
	$request_number = isset( $params['request_number'] ) ? trim( sanitize_text_field( (string) $params['request_number'] ) ) : '';
	$email = isset( $params['email'] ) ? trim( sanitize_email( (string) $params['email'] ) ) : '';
	if ( $request_number === '' || $email === '' ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'Request number and email are required.' ), 400 );
	}
	$filters = array(
		array( 'propertyName' => 'smti_service_request_number', 'operator' => 'EQ', 'value' => $request_number ),
		array( 'propertyName' => 'smti_contact_email', 'operator' => 'EQ', 'value' => $email ),
	);
	$response = smti_st_hs_request( 'POST', '/crm/v3/objects/tickets/search', array(
		'filterGroups' => array( array( 'filters' => $filters ) ),
		'properties' => smti_st_dashboard_ticket_properties(),
		'limit' => 1,
	) );
	if ( is_wp_error( $response ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => $response->get_error_message() ), 500 );
	}
	if ( (int) $response['status'] !== 200 || empty( $response['body']['results'][0] ) ) {
		return new WP_REST_Response( array( 'success' => false, 'message' => 'No matching service request found.' ), 404 );
	}
	$stage_map = smti_st_dashboard_stage_map();
	$ticket = smti_st_dashboard_ticket_summary_from_hubspot( $response['body']['results'][0], $stage_map );
	return new WP_REST_Response( array(
		'success' => true,
		'request_number' => $ticket['service_request_number'],
		'status' => $ticket['status'],
		'createdate' => $ticket['createdate'],
		'lastmodifieddate' => $ticket['lastmodifieddate'],
		'subject' => $ticket['subject'],
	), 200 );
}
