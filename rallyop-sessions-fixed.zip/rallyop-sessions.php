<?php
/**
 * Plugin Name: RallyOP Sessions
 * Description: Schedule open-play sessions and collect player RSVPs inside the RallyOP clubhouse.
 * Version: 2.1.0
 * Author: RallyOP
 */

if (!defined('ABSPATH')) { exit; }

register_activation_hook(__FILE__, 'rallyop_sessions_activate');
function rallyop_sessions_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $sessions = $wpdb->prefix . 'rallyop_sessions';
    $rsvps = $wpdb->prefix . 'rallyop_session_rsvps';
    $seasons = $wpdb->prefix . 'rallyop_seasons';
    $highlights = $wpdb->prefix . 'rallyop_game_highlights';
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE $sessions (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        group_id bigint(20) unsigned NOT NULL DEFAULT 1,
        title varchar(160) NOT NULL,
        starts_at datetime NOT NULL,
        location varchar(190) NOT NULL DEFAULT '',
        notes text NOT NULL,
        capacity smallint(5) unsigned NOT NULL DEFAULT 0,
        created_by bigint(20) unsigned NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY group_starts (group_id, starts_at)
    ) $charset;");
    dbDelta("CREATE TABLE $rsvps (
        session_id bigint(20) unsigned NOT NULL,
        user_id bigint(20) unsigned NOT NULL,
        status varchar(12) NOT NULL DEFAULT 'yes',
        updated_at datetime NOT NULL,
        PRIMARY KEY (session_id, user_id),
        KEY status (status)
    ) $charset;");
    dbDelta("CREATE TABLE $seasons (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        group_id bigint(20) unsigned NOT NULL DEFAULT 1,
        name varchar(120) NOT NULL,
        starts_on date NOT NULL,
        ends_on date NULL,
        champion varchar(160) NOT NULL DEFAULT '',
        created_by bigint(20) unsigned NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY group_dates (group_id, starts_on, ends_on)
    ) $charset;");
    dbDelta("CREATE TABLE $highlights (
        game_id bigint(20) unsigned NOT NULL,
        group_id bigint(20) unsigned NOT NULL DEFAULT 1,
        is_comeback tinyint(1) unsigned NOT NULL DEFAULT 0,
        marked_by bigint(20) unsigned NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY (game_id),
        KEY group_comeback (group_id, is_comeback)
    ) $charset;");
    update_option('rallyop_companion_db_version', '2.1.0');
}

add_action('plugins_loaded', function() {
    if (get_option('rallyop_companion_db_version') !== '2.1.0') { rallyop_sessions_activate(); }
});

add_action('admin_post_rallyop_create_session', 'rallyop_create_session');
function rallyop_create_session() {
    if (!is_user_logged_in()) { auth_redirect(); }
    check_admin_referer('rallyop_create_session');
    global $wpdb;
    $group_id = max(1, absint($_POST['group_id'] ?? 1));
    $title = sanitize_text_field($_POST['title'] ?? 'Open Play');
    $date = sanitize_text_field($_POST['date'] ?? '');
    $time = sanitize_text_field($_POST['time'] ?? '');
    $location = sanitize_text_field($_POST['location'] ?? '');
    $notes = sanitize_textarea_field($_POST['notes'] ?? '');
    $capacity = min(99, max(0, absint($_POST['capacity'] ?? 0)));
    $timestamp = strtotime($date . ' ' . $time);
    if ($title && $timestamp) {
        $wpdb->insert($wpdb->prefix . 'rallyop_sessions', [
            'group_id' => $group_id,
            'title' => $title,
            'starts_at' => wp_date('Y-m-d H:i:s', $timestamp),
            'location' => $location,
            'notes' => $notes,
            'capacity' => $capacity,
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
        ], ['%d','%s','%s','%s','%s','%d','%d','%s']);
        $session_id = (int) $wpdb->insert_id;
        if ($session_id) {
            $wpdb->replace($wpdb->prefix . 'rallyop_session_rsvps', [
                'session_id' => $session_id,
                'user_id' => get_current_user_id(),
                'status' => 'yes',
                'updated_at' => current_time('mysql'),
            ], ['%d','%d','%s','%s']);
        }
    }
    wp_safe_redirect(add_query_arg(['group' => $group_id, 'session_added' => 1], home_url('/')) . '#open-play-sessions');
    exit;
}

add_action('admin_post_rallyop_session_rsvp', 'rallyop_session_rsvp');
function rallyop_session_rsvp() {
    if (!is_user_logged_in()) { auth_redirect(); }
    $session_id = absint($_POST['session_id'] ?? 0);
    check_admin_referer('rallyop_session_rsvp_' . $session_id);
    global $wpdb;
    $session = $wpdb->get_row($wpdb->prepare("SELECT group_id FROM {$wpdb->prefix}rallyop_sessions WHERE id = %d", $session_id));
    $allowed = ['yes', 'maybe', 'no'];
    $status = sanitize_key($_POST['status'] ?? 'yes');
    if ($session && in_array($status, $allowed, true)) {
        $wpdb->replace($wpdb->prefix . 'rallyop_session_rsvps', [
            'session_id' => $session_id,
            'user_id' => get_current_user_id(),
            'status' => $status,
            'updated_at' => current_time('mysql'),
        ], ['%d','%d','%s','%s']);
    }
    $group_id = $session ? (int) $session->group_id : 1;
    wp_safe_redirect(add_query_arg('group', $group_id, home_url('/')) . '#open-play-sessions');
    exit;
}

add_action('admin_post_rallyop_start_season', 'rallyop_start_season');
function rallyop_start_season() {
    if (!is_user_logged_in()) { auth_redirect(); }
    check_admin_referer('rallyop_start_season');
    global $wpdb;
    $group_id = max(1, absint($_POST['group_id'] ?? 1));
    $name = sanitize_text_field($_POST['season_name'] ?? 'New Season');
    $starts_on = sanitize_text_field($_POST['starts_on'] ?? wp_date('Y-m-d'));
    $table = $wpdb->prefix . 'rallyop_seasons';
    $active = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE group_id=%d AND ends_on IS NULL LIMIT 1", $group_id));
    if (!$active && $name && preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $starts_on)) {
        $wpdb->insert($table, ['group_id'=>$group_id,'name'=>$name,'starts_on'=>$starts_on,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')], ['%d','%s','%s','%d','%s']);
    }
    wp_safe_redirect(add_query_arg('group', $group_id, home_url('/')) . '#rallyop-performance'); exit;
}

add_action('admin_post_rallyop_end_season', 'rallyop_end_season');
function rallyop_end_season() {
    if (!is_user_logged_in()) { auth_redirect(); }
    $season_id = absint($_POST['season_id'] ?? 0);
    check_admin_referer('rallyop_end_season_' . $season_id);
    global $wpdb;
    $table = $wpdb->prefix . 'rallyop_seasons';
    $season = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d AND ends_on IS NULL", $season_id));
    if ($season) {
        $champion = sanitize_text_field($_POST['champion'] ?? '');
        $wpdb->update($table, ['ends_on'=>wp_date('Y-m-d'),'champion'=>$champion], ['id'=>$season_id], ['%s','%s'], ['%d']);
    }
    $group_id = $season ? (int)$season->group_id : 1;
    wp_safe_redirect(add_query_arg('group', $group_id, home_url('/')) . '#rallyop-performance'); exit;
}

add_action('admin_post_rallyop_toggle_comeback', 'rallyop_toggle_comeback');
function rallyop_toggle_comeback() {
    if (!is_user_logged_in()) { auth_redirect(); }
    check_admin_referer('rallyop_toggle_comeback');
    global $wpdb;
    $game_id = absint($_POST['game_id'] ?? 0);
    $group_id = max(1, absint($_POST['group_id'] ?? 1));
    $table = $wpdb->prefix . 'rallyop_game_highlights';
    $current = $wpdb->get_var($wpdb->prepare("SELECT is_comeback FROM $table WHERE game_id=%d", $game_id));
    if ($game_id) {
        $wpdb->replace($table, ['game_id'=>$game_id,'group_id'=>$group_id,'is_comeback'=>$current ? 0 : 1,'marked_by'=>get_current_user_id(),'updated_at'=>current_time('mysql')], ['%d','%d','%d','%d','%s']);
    }
    wp_safe_redirect(add_query_arg('group', $group_id, home_url('/')) . '#rallyop-performance'); exit;
}

function rallyop_performance_markup() {
    if (!is_user_logged_in()) { return ''; }
    global $wpdb;
    $group_id = max(1, absint($_GET['group'] ?? 1));
    $table = $wpdb->prefix . 'rallyop_seasons';
    $active = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE group_id=%d AND ends_on IS NULL ORDER BY starts_on DESC LIMIT 1", $group_id));
    $archive = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE group_id=%d AND ends_on IS NOT NULL ORDER BY ends_on DESC LIMIT 8", $group_id));
    $comeback_ids = $wpdb->get_col($wpdb->prepare("SELECT game_id FROM {$wpdb->prefix}rallyop_game_highlights WHERE group_id=%d AND is_comeback=1", $group_id));
    $comeback_nonce = wp_create_nonce('rallyop_toggle_comeback');
    ob_start(); ?>
    <section id="rallyop-performance" class="rop-performance" data-season-start="<?php echo esc_attr($active ? $active->starts_on : ''); ?>" data-comebacks="<?php echo esc_attr(implode(',', array_map('absint', $comeback_ids))); ?>" data-comeback-nonce="<?php echo esc_attr($comeback_nonce); ?>" data-group-id="<?php echo esc_attr($group_id); ?>" data-admin-post="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <div class="rop-kicker">THE NUMBERS</div>
      <div class="rop-heading-row"><div><h2>Stats &amp; Achievements</h2><p>See what’s working, who’s hot, and which partnerships own the court.</p></div><div class="rop-season-pill"><?php echo $active ? esc_html($active->name) : 'ALL TIME'; ?></div></div>
      <div class="rop-achievements" data-rop-achievements><div><span>WEEKLY CHAMPION</span><strong>—</strong></div><div><span>LONGEST STREAK</span><strong>—</strong></div><div><span>BIGGEST UPSET</span><strong>—</strong></div><div><span>COMEBACK WIN</span><strong>Not tracked yet</strong></div><div><span>MOST ACTIVE</span><strong>—</strong></div></div>
      <div class="rop-stat-panels">
        <div class="rop-stat-panel"><h3>Player performance</h3><div class="rop-table-wrap"><table class="rop-table rop-derived-table"><thead><tr><th>Player</th><th>W–L</th><th>Win %</th><th>Point diff.</th><th>Recent</th></tr></thead><tbody data-rop-player-stats></tbody></table></div></div>
        <div class="rop-stat-panel"><h3>Partner combinations</h3><div class="rop-table-wrap"><table class="rop-table rop-derived-table"><thead><tr><th>Partners</th><th>W–L</th><th>Win %</th><th>Diff.</th></tr></thead><tbody data-rop-partners></tbody></table></div></div>
        <div class="rop-stat-panel rop-wide"><h3>Head-to-head</h3><div class="rop-table-wrap"><table class="rop-table rop-derived-table"><thead><tr><th>Matchup</th><th>Games</th><th>Series</th><th>Point diff.</th></tr></thead><tbody data-rop-headtohead></tbody></table></div></div>
      </div>
      <div class="rop-seasons"><div><div class="rop-kicker">SEASONS</div><h3><?php echo $active ? esc_html($active->name) : 'Start a fresh season'; ?></h3><?php if ($active): ?><p>Running since <?php echo esc_html(wp_date('M j, Y', strtotime($active->starts_on))); ?>. Ending it archives the champion and starts a clean statistical chapter.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="rallyop_end_season"><input type="hidden" name="season_id" value="<?php echo absint($active->id); ?>"><input type="hidden" name="champion" value="" data-rop-champion><?php wp_nonce_field('rallyop_end_season_' . $active->id); ?><button class="rop-secondary" type="submit">END &amp; ARCHIVE SEASON</button></form><?php else: ?><form class="rop-season-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="rallyop_start_season"><input type="hidden" name="group_id" value="<?php echo absint($group_id); ?>"><?php wp_nonce_field('rallyop_start_season'); ?><label>SEASON NAME<input name="season_name" placeholder="Fall 2026" required maxlength="120"></label><label>START DATE<input type="date" name="starts_on" value="<?php echo esc_attr(wp_date('Y-m-d')); ?>" required></label><button class="rop-primary" type="submit">START SEASON</button></form><?php endif; ?></div>
        <?php if ($archive): ?><div class="rop-archive"><h4>Season archive</h4><?php foreach ($archive as $season): ?><div><strong><?php echo esc_html($season->name); ?></strong><span><?php echo esc_html(wp_date('M j, Y', strtotime($season->starts_on))); ?>–<?php echo esc_html(wp_date('M j, Y', strtotime($season->ends_on))); ?></span><b><?php echo $season->champion ? esc_html($season->champion) . ' · Champion' : 'Archived'; ?></b></div><?php endforeach; ?></div><?php endif; ?>
      </div>
    </section><?php return ob_get_clean();
}

function rallyop_sessions_markup() {
    if (!is_user_logged_in()) { return ''; }
    $GLOBALS['rallyop_sessions_rendered'] = true;
    global $wpdb;
    $group_id = max(1, absint($_GET['group'] ?? 1));
    $sessions_table = $wpdb->prefix . 'rallyop_sessions';
    $rsvps_table = $wpdb->prefix . 'rallyop_session_rsvps';
    $sessions = $wpdb->get_results($wpdb->prepare(
        "SELECT s.*, SUM(r.status='yes') yes_count, SUM(r.status='maybe') maybe_count
         FROM $sessions_table s LEFT JOIN $rsvps_table r ON r.session_id=s.id
         WHERE s.group_id=%d AND s.starts_at >= DATE_SUB(%s, INTERVAL 3 HOUR)
         GROUP BY s.id ORDER BY s.starts_at ASC LIMIT 12",
        $group_id, current_time('mysql')
    ));
    $my_rsvps = [];
    if ($sessions) {
        $ids = implode(',', array_map('absint', wp_list_pluck($sessions, 'id')));
        $rows = $wpdb->get_results($wpdb->prepare("SELECT session_id,status FROM $rsvps_table WHERE user_id=%d AND session_id IN ($ids)", get_current_user_id()));
        foreach ($rows as $row) { $my_rsvps[(int)$row->session_id] = $row->status; }
    }
    ob_start(); ?>
    <section id="open-play-sessions" class="rop-sessions">
      <div class="rop-kicker">NEXT UP</div>
      <div class="rop-heading-row"><div><h2>Open Play Sessions</h2><p>Pick a time, rally the crew, and know who’s in.</p></div><button class="rop-primary" type="button" data-rop-toggle>＋ SCHEDULE</button></div>
      <?php if (!empty($_GET['session_added'])): ?><div class="rop-notice">Session scheduled. You’re marked as in.</div><?php endif; ?>
      <form class="rop-create" data-rop-form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" hidden>
        <input type="hidden" name="action" value="rallyop_create_session"><input type="hidden" name="group_id" value="<?php echo esc_attr($group_id); ?>">
        <?php wp_nonce_field('rallyop_create_session'); ?>
        <label>SESSION NAME<input name="title" value="Open Play" required maxlength="160"></label>
        <div class="rop-grid"><label>DATE<input type="date" name="date" required min="<?php echo esc_attr(wp_date('Y-m-d')); ?>"></label><label>TIME<input type="time" name="time" required></label></div>
        <label>COURT / LOCATION<input name="location" maxlength="190" placeholder="Riverside Courts"></label>
        <div class="rop-grid"><label>PLAYER LIMIT<input type="number" name="capacity" min="0" max="99" value="8"><small>Use 0 for no limit</small></label><label>NOTE<input name="notes" maxlength="300" placeholder="Bring a ball and water"></label></div>
        <button class="rop-primary" type="submit">CREATE SESSION</button>
      </form>
      <div class="rop-session-list">
      <?php if (!$sessions): ?><div class="rop-empty"><strong>No sessions scheduled yet.</strong><span>Be the first to put the next game on the calendar.</span></div><?php endif; ?>
      <?php foreach ($sessions as $session): $mine = $my_rsvps[(int)$session->id] ?? ''; $start = strtotime($session->starts_at); ?>
        <article class="rop-session-card">
          <div class="rop-date"><strong><?php echo esc_html(wp_date('M', $start)); ?></strong><b><?php echo esc_html(wp_date('j', $start)); ?></b><span><?php echo esc_html(wp_date('D', $start)); ?></span></div>
          <div class="rop-session-info"><h3><?php echo esc_html($session->title); ?></h3><p><?php echo esc_html(wp_date('g:i A', $start)); ?><?php if ($session->location): ?> · <?php echo esc_html($session->location); ?><?php endif; ?></p><?php if ($session->notes): ?><small><?php echo esc_html($session->notes); ?></small><?php endif; ?><div class="rop-count"><strong><?php echo absint($session->yes_count); ?> IN</strong><?php if ($session->capacity): ?> / <?php echo absint($session->capacity); ?> spots<?php endif; ?><?php if ($session->maybe_count): ?> · <?php echo absint($session->maybe_count); ?> maybe<?php endif; ?></div></div>
          <form class="rop-rsvp" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="rallyop_session_rsvp"><input type="hidden" name="session_id" value="<?php echo absint($session->id); ?>"><?php wp_nonce_field('rallyop_session_rsvp_' . $session->id); ?>
            <?php foreach (['yes'=>'I’M IN','maybe'=>'MAYBE','no'=>'CAN’T'] as $value=>$label): ?><button name="status" value="<?php echo esc_attr($value); ?>" class="<?php echo $mine === $value ? 'active' : ''; ?>"><?php echo esc_html($label); ?></button><?php endforeach; ?>
          </form>
        </article>
      <?php endforeach; ?>
      </div>
    </section><?php
    return ob_get_clean();
}

add_shortcode('rallyop_sessions', 'rallyop_sessions_markup');
add_filter('the_content', function($content) {
    if (is_front_page() && is_user_logged_in() && in_the_loop() && is_main_query()) { return $content . rallyop_sessions_markup(); }
    return $content;
}, 25);

add_action('wp_footer', function() {
    if (is_front_page() && is_user_logged_in() && empty($GLOBALS['rallyop_sessions_rendered'])) {
        echo rallyop_sessions_markup();
    }
    if (is_front_page() && is_user_logged_in()) { echo rallyop_performance_markup(); }
}, 5);

add_action('wp_enqueue_scripts', function() {
    if (!is_front_page() || !is_user_logged_in()) { return; }
    wp_register_style('rallyop-sessions', false, [], '2.1.0'); wp_enqueue_style('rallyop-sessions');
    wp_add_inline_style('rallyop-sessions', '.rop-sessions{max-width:1180px;margin:28px auto 72px;padding:36px;border:1px solid #d8d3c7;background:#f7f3e8;color:#17251d;font-family:inherit}.rop-kicker{font-size:12px;font-weight:800;letter-spacing:.16em;color:#db532d}.rop-heading-row{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}.rop-heading-row h2{font-size:clamp(30px,5vw,54px);line-height:1;margin:10px 0}.rop-heading-row p{margin:0 0 24px}.rop-primary{background:#ef5a32!important;color:#fff!important;border:0!important;padding:15px 20px!important;font-weight:800!important;letter-spacing:.05em;cursor:pointer}.rop-create{margin:18px 0 28px;padding:24px;background:#19291f;color:#fff}.rop-create label{display:block;font-size:11px;font-weight:800;letter-spacing:.1em;margin-bottom:16px}.rop-create input{box-sizing:border-box;width:100%;margin-top:7px;padding:13px;border:1px solid #718078;background:#fff;color:#17251d}.rop-create small{display:block;margin-top:5px;font-weight:400;letter-spacing:0}.rop-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.rop-session-list{display:grid;gap:12px}.rop-session-card{display:grid;grid-template-columns:82px 1fr auto;gap:20px;align-items:center;padding:20px;background:#fff;border:1px solid #ded9cf}.rop-date{text-align:center;border-right:1px solid #ded9cf;padding-right:18px}.rop-date strong,.rop-date span{display:block;font-size:11px;letter-spacing:.1em}.rop-date b{display:block;font-size:34px;line-height:1.1}.rop-session-info h3{margin:0 0 5px;font-size:23px}.rop-session-info p,.rop-session-info small{display:block;margin:0 0 5px}.rop-count{margin-top:10px;font-size:12px;color:#59655e}.rop-rsvp{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.rop-rsvp button{border:1px solid #17251d;background:transparent;color:#17251d;padding:9px 11px;font-size:11px;font-weight:800;cursor:pointer}.rop-rsvp button.active{background:#17251d;color:#fff}.rop-empty{display:flex;flex-direction:column;gap:5px;padding:28px;border:1px dashed #aaa297}.rop-notice{padding:12px 16px;margin:0 0 18px;background:#dbe8cf;color:#20351c;font-weight:700}.rop-invite-accept,form:has(input[name="action"][value*="accept"]) button,a[href*="accept_invite"],a[href*="accept-invite"]{display:inline-flex!important;align-items:center!important;justify-content:center!important;background:#087cff!important;color:#fff!important;border:2px solid #087cff!important;box-shadow:0 5px 0 #064fa1!important;padding:15px 24px!important;font-weight:900!important;letter-spacing:.06em!important;text-decoration:none!important;text-transform:uppercase!important;transition:transform .15s,background .15s,border-color .15s!important}.rop-invite-accept:hover,form:has(input[name="action"][value*="accept"]) button:hover,a[href*="accept_invite"]:hover,a[href*="accept-invite"]:hover{background:#ef4e35!important;border-color:#ef4e35!important;box-shadow:0 5px 0 #9e2b1a!important;transform:translateY(-2px)!important}@media(max-width:700px){.rop-sessions{margin:16px 12px 50px;padding:22px}.rop-heading-row{display:block}.rop-heading-row .rop-primary{margin-bottom:18px}.rop-grid{grid-template-columns:1fr}.rop-session-card{grid-template-columns:62px 1fr}.rop-rsvp{grid-column:1/-1;justify-content:stretch}.rop-rsvp button{flex:1}.rop-date{padding-right:12px}}');
    wp_add_inline_style('rallyop-sessions', '.rop-performance{max-width:1180px;margin:28px auto;padding:36px;background:#17271e;color:#fff}.rop-performance .rop-heading-row h2{color:#fff}.rop-season-pill{padding:10px 14px;background:#087cff;color:#fff;font-size:12px;font-weight:900;letter-spacing:.1em}.rop-achievements{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:24px 0}.rop-achievements>div{min-height:100px;padding:16px;background:#22362a;border-top:4px solid #ef5a32}.rop-achievements span{display:block;font-size:10px;font-weight:800;letter-spacing:.09em;color:#aebbb3}.rop-achievements strong{display:block;margin-top:12px;font-size:18px}.rop-stat-panels{display:grid;grid-template-columns:1fr 1fr;gap:14px}.rop-stat-panel{padding:22px;background:#f7f3e8;color:#17251d}.rop-stat-panel.rop-wide{grid-column:1/-1}.rop-stat-panel h3,.rop-seasons h3{margin:0 0 16px;font-size:24px}.rop-derived-table{width:100%;border-collapse:collapse}.rop-derived-table th,.rop-derived-table td{padding:10px 8px;border-bottom:1px solid #d7d0c2;text-align:left;font-size:13px}.rop-derived-table th{font-size:10px;letter-spacing:.08em}.rop-form-dot{display:inline-flex;width:22px;height:22px;margin-right:3px;align-items:center;justify-content:center;border-radius:50%;font-size:10px;font-weight:900}.rop-form-dot.w{background:#d7ebcb;color:#21531a}.rop-form-dot.l{background:#f1d3ca;color:#842a18}.rop-seasons{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:14px;padding:24px;background:#22362a}.rop-season-form{display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:end}.rop-season-form label{font-size:10px;font-weight:800;letter-spacing:.08em}.rop-season-form input{box-sizing:border-box;width:100%;margin-top:7px;padding:12px}.rop-secondary{padding:13px 18px;border:1px solid #fff;background:transparent;color:#fff;font-weight:800}.rop-archive>div{display:grid;grid-template-columns:1fr auto;gap:4px 12px;padding:10px 0;border-bottom:1px solid #4b5b51}.rop-archive span{font-size:12px;color:#afbbb3}.rop-archive b{grid-row:1/3;grid-column:2;align-self:center;color:#f2c94c}.rop-empty-row{text-align:center!important;padding:24px!important;color:#67736b}.rop-table-wrap{overflow-x:auto}@media(max-width:850px){.rop-performance{margin:16px 12px;padding:22px}.rop-achievements{grid-template-columns:1fr 1fr}.rop-stat-panels,.rop-seasons{grid-template-columns:1fr}.rop-stat-panel.rop-wide{grid-column:auto}.rop-season-form{grid-template-columns:1fr}.rop-heading-row{display:block}.rop-season-pill{display:inline-block;margin-bottom:18px}}');
    wp_register_script('rallyop-sessions', '', [], '2.1.0', true); wp_enqueue_script('rallyop-sessions');
    wp_add_inline_script('rallyop-sessions', "document.addEventListener('DOMContentLoaded',function(){var s=document.getElementById('open-play-sessions'),f=document.querySelector('footer');if(s&&f&&s.parentNode===document.body)f.parentNode.insertBefore(s,f);var stats={};document.querySelectorAll('.rop-game-team strong').forEach(function(n){n.textContent.split('&').forEach(function(x){var p=x.trim();if(p&&!stats[p])stats[p]=[0,0];});});document.querySelectorAll('.rop-game-team').forEach(function(t){var won=t.classList.contains('winner');var names=t.querySelector('strong');if(!names)return;names.textContent.split('&').forEach(function(x){var p=x.trim();if(stats[p])stats[p][won?0:1]++;});});document.querySelectorAll('.rop-table').forEach(function(table){var heads=Array.from(table.querySelectorAll('th')).map(function(h){return h.textContent.trim();});var recordIndex=heads.indexOf('Record');if(recordIndex<0)return;table.querySelectorAll('tbody tr').forEach(function(row){var cells=row.children;if(cells.length<=recordIndex)return;var name=(cells[1].textContent||'').replace('♛','').trim();if(stats[name])cells[recordIndex].textContent=stats[name][0]+'–'+stats[name][1];});});document.querySelectorAll('a,button,input[type=submit]').forEach(function(el){var label=(el.textContent||el.value||'').trim();if(/^(accept invitation|accept invite|join group)$/i.test(label))el.classList.add('rop-invite-accept');});});document.addEventListener('click',function(e){var b=e.target.closest('[data-rop-toggle]');if(!b)return;var f=document.querySelector('[data-rop-form]');f.hidden=!f.hidden;b.textContent=f.hidden?'＋ SCHEDULE':'× CLOSE';if(!f.hidden)f.querySelector('input[name=date]').focus();});");
    wp_add_inline_script('rallyop-sessions', "(function(){function run(){var stats={};document.querySelectorAll('.rop-game-team strong').forEach(function(n){n.textContent.split('&').forEach(function(x){var p=x.trim();if(p&&!stats[p])stats[p]=[0,0];});});document.querySelectorAll('.rop-game-team').forEach(function(t){var n=t.querySelector('strong');if(!n)return;n.textContent.split('&').forEach(function(x){var p=x.trim();if(stats[p])stats[p][t.classList.contains('winner')?0:1]++;});});document.querySelectorAll('.rop-table').forEach(function(t){var h=Array.from(t.querySelectorAll('th')).map(function(x){return x.textContent.trim();}),i=h.indexOf('Record');if(i<0)return;t.querySelectorAll('tbody tr').forEach(function(r){var c=r.children,n=(c[1]&&c[1].textContent||'').replace('♛','').trim();if(c[i]&&stats[n])c[i].textContent=stats[n][0]+'–'+stats[n][1];});});document.querySelectorAll('a,button,input[type=submit]').forEach(function(e){var l=(e.textContent||e.value||'').trim();if(/^(accept invitation|accept invite|join group)$/i.test(l))e.classList.add('rop-invite-accept');});}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run);else run();setTimeout(run,300);setTimeout(run,1200);})();");
    wp_add_inline_script('rallyop-sessions', "(function(){function esc(s){return String(s).replace(/[&<>\"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#039;'}[c];});}function pct(w,l){return w+l?Math.round(w*100/(w+l))+'%':'—';}function render(){var box=document.getElementById('rallyop-performance');if(!box)return;var footer=document.querySelector('footer'),sessions=document.getElementById('open-play-sessions');if(footer&&box.parentNode===document.body)footer.parentNode.insertBefore(box,sessions||footer);var ratings={};document.querySelectorAll('.rop-table').forEach(function(t){var h=Array.from(t.querySelectorAll('th')).map(function(x){return x.textContent.trim();});if(h.indexOf('Rating')<0)return;t.querySelectorAll('tbody tr').forEach(function(r){var c=r.children,n=(c[1]&&c[1].textContent||'').replace('♛','').trim();if(n)ratings[n]=parseInt(c[c.length-1].textContent,10)||1200;});});var players={},pairs={},series={},games=[];document.querySelectorAll('.rop-game-date').forEach(function(d){var row=d.closest('tr'),teams=row?row.querySelectorAll('.rop-game-team'):[];if(teams.length!==2)return;var a=Array.from(teams[0].querySelector('strong').textContent.split('&')).map(x=>x.trim()),b=Array.from(teams[1].querySelector('strong').textContent.split('&')).map(x=>x.trim()),sa=parseInt((teams[0].querySelector('span').textContent.match(/·\\s*(\\d+)/)||[])[1],10),sb=parseInt((teams[1].querySelector('span').textContent.match(/·\\s*(\\d+)/)||[])[1],10);if(!Number.isFinite(sa)||!Number.isFinite(sb))return;var aw=teams[0].classList.contains('winner'),date=new Date(d.textContent.trim()+' '+new Date().getFullYear());games.push({a:a,b:b,sa:sa,sb:sb,aw:aw,date:date});});games.forEach(function(g){[[g.a,g.sa,g.sb,g.aw],[g.b,g.sb,g.sa,!g.aw]].forEach(function(x){x[0].forEach(function(n){if(!players[n])players[n]={w:0,l:0,pf:0,pa:0,form:[]};players[n][x[3]?'w':'l']++;players[n].pf+=x[1];players[n].pa+=x[2];players[n].form.push(x[3]?'W':'L');});var key=x[0].slice().sort().join(' & ');if(!pairs[key])pairs[key]={w:0,l:0,pf:0,pa:0};pairs[key][x[3]?'w':'l']++;pairs[key].pf+=x[1];pairs[key].pa+=x[2];});var ak=g.a.slice().sort().join(' & '),bk=g.b.slice().sort().join(' & '),sk=[ak,bk].sort(),key=sk.join(' vs ');if(!series[key])series[key]={teams:sk,w:[0,0],diff:0,games:0};var ai=sk.indexOf(ak);series[key].games++;series[key].w[g.aw?ai:1-ai]++;series[key].diff+=(ai===0?g.sa-g.sb:g.sb-g.sa);});var pbody=box.querySelector('[data-rop-player-stats]'),prows=Object.keys(players).sort(function(a,b){return players[b].w-players[a].w||(players[b].pf-players[b].pa)-(players[a].pf-players[a].pa);}).map(function(n){var s=players[n],form=s.form.slice(0,5).map(function(x){return '<i class=\"rop-form-dot '+x.toLowerCase()+'\">'+x+'</i>';}).join('');return '<tr><td><strong>'+esc(n)+'</strong></td><td>'+s.w+'–'+s.l+'</td><td>'+pct(s.w,s.l)+'</td><td>'+((s.pf-s.pa)>0?'+':'')+(s.pf-s.pa)+'</td><td>'+form+'</td></tr>';}).join('');pbody.innerHTML=prows||'<tr><td colspan=\"5\" class=\"rop-empty-row\">Record a game to unlock stats.</td></tr>';var tbody=box.querySelector('[data-rop-partners]'),pairrows=Object.keys(pairs).sort(function(a,b){return pairs[b].w-pairs[a].w;}).map(function(n){var s=pairs[n];return '<tr><td><strong>'+esc(n)+'</strong></td><td>'+s.w+'–'+s.l+'</td><td>'+pct(s.w,s.l)+'</td><td>'+((s.pf-s.pa)>0?'+':'')+(s.pf-s.pa)+'</td></tr>';}).join('');tbody.innerHTML=pairrows||'<tr><td colspan=\"4\" class=\"rop-empty-row\">No partnerships yet.</td></tr>';var hbody=box.querySelector('[data-rop-headtohead]'),hrows=Object.keys(series).map(function(k){var s=series[k];return '<tr><td>'+esc(k)+'</td><td>'+s.games+'</td><td>'+s.w[0]+'–'+s.w[1]+'</td><td>'+((s.diff)>0?'+':'')+s.diff+'</td></tr>';}).join('');hbody.innerHTML=hrows||'<tr><td colspan=\"4\" class=\"rop-empty-row\">No matchups yet.</td></tr>';var names=Object.keys(players),most=names.sort(function(a,b){return players[b].w+players[b].l-(players[a].w+players[a].l);})[0]||'—',weekly={},cut=Date.now()-7*86400000;games.filter(g=>g.date.getTime()>=cut).forEach(function(g){(g.aw?g.a:g.b).forEach(n=>weekly[n]=(weekly[n]||0)+1);});var champ=Object.keys(weekly).sort((a,b)=>weekly[b]-weekly[a])[0]||'—',streakName='—',streakMax=0;Object.keys(players).forEach(function(n){var run=0;players[n].form.slice().reverse().forEach(function(x){run=x==='W'?run+1:0;streakMax<run&&(streakMax=run,streakName=n+' · '+run);});});var upset='No upset yet',best=0;games.forEach(function(g){var wa=g.aw?g.a:g.b,la=g.aw?g.b:g.a,wr=wa.reduce((s,n)=>s+(ratings[n]||1200),0)/wa.length,lr=la.reduce((s,n)=>s+(ratings[n]||1200),0)/la.length;if(lr-wr>best){best=Math.round(lr-wr);upset=wa.join(' & ')+' · +'+best;}});var cards=box.querySelectorAll('[data-rop-achievements]>div strong');if(cards.length===5){cards[0].textContent=champ;cards[1].textContent=streakName;cards[2].textContent=upset;cards[4].textContent=most;}var lead=Object.keys(players).sort(function(a,b){return players[b].w-players[a].w||(players[b].pf-players[b].pa)-(players[a].pf-players[a].pa);})[0]||'';var input=box.querySelector('[data-rop-champion]');if(input)input.value=lead;}setTimeout(render,350);setTimeout(render,1400);})();");
    wp_add_inline_style('rallyop-sessions', '.rop-comeback-form{display:inline}.rop-comeback-btn{margin-left:6px!important;padding:6px 8px!important;border:1px solid #087cff!important;background:transparent!important;color:#087cff!important;font-size:9px!important;font-weight:900!important}.rop-comeback-btn.active{background:#087cff!important;color:#fff!important}');
    wp_add_inline_script('rallyop-sessions', "(function(){function addComebacks(){var box=document.getElementById('rallyop-performance');if(!box)return;var marked=(box.dataset.comebacks||'').split(',').filter(Boolean),winner='Not marked yet';document.querySelectorAll('.rop-game-date').forEach(function(d){var row=d.closest('tr'),edit=row&&row.nextElementSibling,gameInput=edit&&edit.querySelector('input[name=game_id]'),cell=row&&row.lastElementChild;if(!gameInput||!cell||cell.querySelector('.rop-comeback-form'))return;var id=gameInput.value,isMarked=marked.indexOf(id)>=0,win=row.querySelector('.rop-game-team.winner strong');if(isMarked&&win)winner=win.textContent.trim();var form=document.createElement('form');form.className='rop-comeback-form';form.method='post';form.action=box.dataset.adminPost;[['action','rallyop_toggle_comeback'],['game_id',id],['group_id',box.dataset.groupId],['_wpnonce',box.dataset.comebackNonce]].forEach(function(v){var i=document.createElement('input');i.type='hidden';i.name=v[0];i.value=v[1];form.appendChild(i);});var b=document.createElement('button');b.type='submit';b.className='rop-comeback-btn'+(isMarked?' active':'');b.textContent=isMarked?'COMEBACK ✓':'MARK COMEBACK';form.appendChild(b);cell.appendChild(form);});var cards=box.querySelectorAll('[data-rop-achievements]>div strong');if(cards.length===5)cards[3].textContent=winner;}setTimeout(addComebacks,500);setTimeout(addComebacks,1600);})();");
});
